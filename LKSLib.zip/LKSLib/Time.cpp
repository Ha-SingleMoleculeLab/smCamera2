#include "stdafx.h"
#include "Log.h"

static LONGLONG cnts_per_sec;
static LARGE_INTEGER liNow;

BOOL InitProgramTimer()
{
	LARGE_INTEGER tmp;
	if ( QueryPerformanceFrequency( &tmp ) == 0 )
	{
		LogErr(_T("The high resolution timer is not available."));
		return FALSE;
	}

	cnts_per_sec = tmp.QuadPart;
	return TRUE;
}

double GetProgramTime()
{
	QueryPerformanceCounter(&liNow);
	return ((double) (liNow.QuadPart)) / cnts_per_sec;
}

INT64 GetProgramTimeInTicks()
{
	QueryPerformanceCounter(&liNow);
	return (INT64) liNow.QuadPart;
}

double ProgramTime_Tick2Second(INT64 tick)
{
	return ((double) tick) / cnts_per_sec;
}

INT64 ProgramTime_Second2Tick(double time)
{
	return (INT64) ( time * cnts_per_sec + 0.5 );
}