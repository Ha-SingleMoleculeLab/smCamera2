#include "stdafx.h"
#include "Log.h"
#include "FileAndDirectory.h"
#include "DirectoryTraverse.h"

#undef	_MAX_PATH
#define _MAX_PATH	(1024)
CDirectoryTraverse::CDirectoryTraverse()
{
	m_path = _T("");
	m_old_path = _T("");

	m_prefix = _T("");
	m_postfix = _T("");
	m_fileno = -1;
	m_find_handle = -1L;
	return;
}

CDirectoryTraverse::~CDirectoryTraverse()
{
	if ( m_find_handle != -1L )	CloseTraverse();
	if ( m_old_path.IsEmpty() != TRUE )	_tchdir(m_old_path);
	return;
}


int CDirectoryTraverse::SetPath(LPCTSTR path)
{
	if ( !path )	return -1;

	char temp[_MAX_PATH];
	/* Get the current working directory: */
	if( _tgetcwd( temp, _MAX_PATH ) == NULL )
	{
		LogMsg(_T("Error"), _T("Set Path Failed : Get CWD Failed"));
		return -1;
	}
	
	if ( _tchdir(path) != 0 )
	{
		LogMsg(_T("Error"), Stringify(_T("Set Path Failed : chdir[%s] Failed"), path) );
		return -1;
	}
	_tchdir(temp);

	m_path = path;
	m_fileno = -1;
	LastFile();
	return 0;		
}

int CDirectoryTraverse::SetFormat(CString prefix, CString postfix)
{
	if ( prefix.IsEmpty() )	
		m_prefix = _T("");
	else	
		m_prefix = prefix.MakeLower();

	if ( postfix.IsEmpty() )
		m_postfix = _T("");
	else
        m_postfix = postfix.MakeLower();

	m_fileno = -1;
	LastFile();
	return 0;
}


int CDirectoryTraverse::GetFileNo(CString filename)
{
	int n;
	CString lname = filename.MakeLower();

	if ( !m_prefix.IsEmpty() )
	{
		n = lname.Replace(m_prefix, _T(""));
		if ( n <= 0 )	return -1;
	}

    if ( !m_postfix.IsEmpty() )
	{
		n = lname.Find(m_postfix);
		if ( n < 0 )	return -1;

		CString postfix = lname.Mid(n);
		if ( postfix.Compare(m_postfix) != 0 )	return -1;

		lname = lname.Mid(0, n);
	}
	return _tstoi(lname);
}

int CDirectoryTraverse::InitTraverse()
{
	if ( m_path.IsEmpty() )	return -1;
	if ( m_find_handle != -1L )	CloseTraverse();

	CString spec = _T("*");

	char old_path[_MAX_PATH];
	if( _tgetcwd( old_path, _MAX_PATH ) == NULL )
	{
		LogMsg(_T("Error"), _T("Init Traverse Failed : Get CWD Failed"));
		return -1;
	}
		
	if ( _tchdir(m_path) != 0 )
	{
		LogErr(Stringify(_T("Init Traverse [%s] could not be reached."), m_path));
		return -1;
	}
	m_old_path = old_path;
	m_find_handle = (long) _tfindfirst((LPCTSTR)spec, &m_find_data);
	return 0;
}

int CDirectoryTraverse::Traverse(CString &name, BOOL &is_dir)
{
	if ( m_find_handle == -1L )	return -1;

	BOOL found = TRUE;
	name = m_find_data.name;
	is_dir = FALSE;
	if ( m_find_data.attrib & _A_HIDDEN )	found = FALSE;
	else if ( m_find_data.attrib & _A_RDONLY )	found = FALSE;
	else if ( m_find_data.attrib & _A_SYSTEM )	found = FALSE;
	else if ( m_find_data.attrib & _A_SUBDIR )
	{
		is_dir = TRUE;
		if ( name.CompareNoCase(_T(".")) == 0 || name.CompareNoCase(_T("..")) == 0 )	found = FALSE;
	}

	if ( found && is_dir == FALSE )
	{
		if ( GetFileNo(name) < 0 )	found = FALSE;
	}

	if ( _tfindnext( m_find_handle, &m_find_data ) != 0 )
		CloseTraverse();
	
	if ( found == FALSE )
		return Traverse(name, is_dir);
	else
        return 0;
}

int CDirectoryTraverse::CloseTraverse()
{
	if ( m_find_handle != -1L )
	{
		_findclose(m_find_handle);
		m_find_handle = -1L;
	}

	
	if ( m_old_path.IsEmpty() )
	{
		return 0;
	}
	else
	{
		int ret = _tchdir(m_old_path);
   		m_old_path = _T("");
		return ( ret != 0 )	? -1 : 0;
	}
}


int CDirectoryTraverse::FirstFile()
{
	if ( m_path.IsEmpty() )	return -1;

	CString str;
	for ( int fileno = 1; fileno < m_fileno ; fileno++ )
	{
		str.Format(_T("%s%d%s"), m_prefix, fileno, m_postfix);
		if ( DoesProgramFileExist( GetProgramFilePath( m_path, str ) ) )
		{
			m_fileno = fileno;
			break;
		}
	}
	return m_fileno;
}

int CDirectoryTraverse::PrevFile()
{
	if ( m_path.IsEmpty() )	return -1;

	CString str;

	for ( int fileno = m_fileno - 1; fileno >= 1 ; fileno-- )
	{
		str.Format(_T("%s%d%s"), m_prefix, fileno, m_postfix);
		if ( DoesProgramFileExist( GetProgramFilePath( m_path, str ) ) )
		{
			m_fileno = fileno;
			break;
		}
	}
	return m_fileno;
}


int CDirectoryTraverse::LastFile()
{
	if ( m_path.IsEmpty() )	return -1;
	
	if ( InitTraverse() < 0 )	return -1;
	int last_fileno = 0;
	CString name;
	BOOL is_dir;
	while ( Traverse( name, is_dir ) == 0 )
	{
		if ( is_dir )	continue;
		int n = GetFileNo(name);
		if ( last_fileno < n )	last_fileno = n;
	}

	m_fileno = last_fileno;
	return m_fileno;
}

int CDirectoryTraverse::NextFile()
{
	if ( m_path.IsEmpty() )	return -1;

	CString str;
	int last_fileno = LastFile();
	
	for (int fileno = m_fileno+1 ; fileno < last_fileno ; fileno++ )
	{
		str.Format(_T("%s%d%s"), m_prefix, fileno, m_postfix);
		if ( DoesProgramFileExist( GetProgramFilePath( m_path, str ) ) )
		{
			m_fileno = fileno;
			return m_fileno;
		}
	}
	m_fileno = last_fileno;	
	return m_fileno;
}

