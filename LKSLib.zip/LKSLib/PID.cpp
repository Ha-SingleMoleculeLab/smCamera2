#include "stdafx.h"
#include "PID.h"
#include "Time.h"

#define NUM_PIDRECORDS	(128)

CPID::CPID()
{
	m_KP = m_KI = m_KD = 0.0;
	m_is_on = FALSE;
	m_init_mv = 0.0;
	m_init_time = 0.0;
	m_final_mv = 0.0;
	m_set_pv = 0.0;	
	m_error_sum = 0.0;	

	m_pvcnt = 0;	
	m_pvdata = NULL;
	m_pvtime = NULL;

}

CPID::~CPID()
{
	if ( m_pvdata )	delete [] m_pvdata;
	if ( m_pvtime )	delete [] m_pvtime;
}

void CPID::Initialize(double init_mv, double set_pv)
{
	m_init_mv = init_mv;
	m_init_time = 0.0;
	m_final_mv = init_mv;
	m_set_pv = set_pv;
	if ( m_pvdata == NULL )	m_pvdata = new double[NUM_PIDRECORDS];
	if ( m_pvtime == NULL )	m_pvtime = new double[NUM_PIDRECORDS];
	m_pvcnt = 0;
	m_error_sum = 0.0;
	InitProgramTimer();
}

double CPID::Feedback(double pv)
{
	if ( !IsInitialized() )	return 0.0;

	double pvtime = GetProgramTime();
	if ( m_pvcnt == 0 )	m_init_time = pvtime;
	pvtime -= m_init_time;

	m_pvdata[ m_pvcnt % NUM_PIDRECORDS ] = pv;
	m_pvtime[ m_pvcnt % NUM_PIDRECORDS ] = pvtime;

	double dedt = 0.0;
	double e = pv - m_set_pv;
	if ( m_pvcnt != 0 )
	{
		double de = pv - m_pvdata[ (m_pvcnt-1) % NUM_PIDRECORDS ];
		double dt = pvtime - m_pvtime[ (m_pvcnt-1) % NUM_PIDRECORDS ];
		m_error_sum += e * dt;
		dedt = de / dt ;
	}

	m_pvcnt++;
	
	if ( m_is_on )	
		m_final_mv = m_init_mv + m_KP*e + m_KI*m_error_sum + m_KD*dedt ;

	return m_final_mv;
}

double CPID::PV(int i)
{
//	if ( IsInitialized() != TRUE )	return NULL;
//	if ( i < 0 || i >= m_pvcnt )	return NULL;
//	return &(m_pvdata[ i%NUM_PIDRECORDS ]);
	return m_pvdata[ i%NUM_PIDRECORDS ];
}

double CPID::PVTime(int i)
{
//	if ( IsInitialized() != TRUE )	return NULL;
//	if ( i < 0 || i >= m_pvcnt )	return NULL;
//	return &(m_pvtime[ i%NUM_PIDRECORDS ]);
	return m_pvtime[ i%NUM_PIDRECORDS ];
}
