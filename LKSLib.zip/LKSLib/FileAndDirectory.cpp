#include "stdafx.h"
#include "Log.h"
#include "FileAndDirectory.h"

#include <direct.h>
#include <errno.h>
#include <string.h>

#define _MAX_BACKUPFILE_NUM	(20)
#define _ARCHIVE_BUF_SIZE	(4096)


BOOL MakeProgramDirectory( LPCTSTR path )
{
	int ret;
	
   	ret = _tchdir( path );
	if ( ret == 0 )	return TRUE;
	ret = _tmkdir( path );
	if ( ret == 0 )	return TRUE;

	// create the super directory first, and retry.
	CString str = path;
	CString mid;
	int pos;
	do 
	{
		pos = str.ReverseFind( (_TCHAR) '\\' );
		if ( pos < 0 || pos == 0 )	return FALSE;
		mid = str.Mid(pos);		
		str = str.Left( pos );	// the super directory of path
	} while ( mid == _T("\\") );	

	ret = MakeProgramDirectory( (LPCTSTR)str );	// recursive calls.
	if ( ret == TRUE )
	{
		if ( _tmkdir( path ) !=  0 )
		{
			LogErr(Stringify(_T("_tmkdir( %s ) failed :  %s "), path, _tcserror(errno) ) );
			return FALSE;
		}

		return TRUE;
	}
	else	return FALSE;
}


//check whether a file exists
BOOL DoesProgramFileExist ( LPCTSTR filepath, CFileStatus *pStatus )
{
	CFileStatus temp_status;
	int nRet;

	try 
	{
		nRet = CFile::GetStatus( filepath, temp_status );
	}
	catch ( CFileException *e )
	{
		e->ReportError();
		e->Delete();
		return FALSE;
	}
	if ( pStatus != NULL )	*pStatus = temp_status;
	return nRet;
}

//check whether a directory exists
BOOL DoesProgramDirectoryExist ( LPCTSTR path )
{
	DWORD attr = GetFileAttributes( path );
	return ( attr == FILE_ATTRIBUTE_DIRECTORY );
}


void RemoveProgramFile( LPCTSTR filepath )
{
	CFile::Remove( filepath );
}

void RemoveProgramDirectory( LPCTSTR path )
{
	_trmdir( path );
}


//get file path (directory, filename )
LPCTSTR GetProgramFilePath ( LPCTSTR dir, LPCTSTR filename )
{
	static CString str;
	str = dir;
	str.Append(_T("\\"));
	str.Append(filename);
	return (LPCTSTR) str;
}

//get backup file path (directory, filename )
		
static LPCTSTR __backup_filepath ( LPCTSTR filepath )
{	
	CFileStatus status;
	static CString backup;
	CString org;
	org = filepath;

	int oldest_idx = 0;
	__time64_t oldest_time = 0;
	for ( int i = 0; i < _MAX_BACKUPFILE_NUM ; i++ )
	{
		backup = org;
		backup.AppendFormat(_T(".%02d"), i);

		if ( DoesProgramFileExist( (LPCTSTR) backup, &status ) != TRUE )	
			return (LPCTSTR) backup;
		else // File Exists
		{
			if ( i == 0 || status.m_mtime.GetTime() < oldest_time )
			{
				oldest_idx = i;
				oldest_time = status.m_mtime.GetTime();
			}
		}
	}

	// MAX_BACKUPFILE_NUM reached.
	backup = org;
	backup.AppendFormat(_T(".%02d"), oldest_idx);	
	return (LPCTSTR) backup;
}


void BackupProgramFile ( LPCTSTR filepath )
{
	if ( DoesProgramFileExist( filepath ) != TRUE )	return;
	//example for CFile::Rename
	try
	{
		LPCTSTR backup_filepath = __backup_filepath( filepath );
		if ( DoesProgramFileExist( backup_filepath ) == TRUE )
			CFile::Remove( backup_filepath );

		CFile::Rename( filepath, backup_filepath );
	}
	catch( CFileException* pEx )
	{
		pEx->ReportError();
		pEx->Delete();
	}

	return;
}

void RenameProgramFile ( LPCTSTR srcpath, LPCTSTR destpath, BOOL do_backup )
{
	try
	{
		if ( DoesProgramFileExist( destpath ) )
		{
			if ( do_backup )	BackupProgramFile( destpath );
			else CFile::Remove( destpath );
		}
		CFile::Rename( srcpath, destpath );
	}
	catch( CFileException* pEx )
	{
		pEx->ReportError();
		pEx->Delete();
	}

	return;
}

//open file for read
CArchive * OpenProgramFileToRead ( LPCTSTR filepath )
{
	CFile *f = new CFile();
	CFileException ex;
	//LPCTSTR filepath = GetProgramFilePath( dir, filename );

	if ( !f->Open( filepath, CFile::modeRead, &ex ) )
	{
		ex.ReportError();
		delete f;
		return NULL;
	}

	return new CArchive( f, CArchive::load, _ARCHIVE_BUF_SIZE );
}

//open file for write
CArchive * OpenProgramFileToWrite ( LPCTSTR filepath, BOOL do_backup )
{
	CFile *f = new CFile();
	CFileException ex;
	//LPCTSTR filepath = GetProgramFilePath( dir, filename );

	if ( do_backup)	BackupProgramFile(filepath);
	
	if ( !f->Open( filepath, CFile::modeCreate | CFile::modeWrite, &ex ) )
	{
		ex.ReportError();
		delete f;
		return NULL;
	}

	return new CArchive( f, CArchive::store, _ARCHIVE_BUF_SIZE );
}


//open file for append
CArchive * OpenProgramFileToAppend ( LPCTSTR filepath )
{
	CFile *f = new CFile();
	CFileException ex;
	//LPCTSTR filepath = GetProgramFilePath( dir, filename );
	
	if ( !f->Open( filepath, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite, &ex ) )
	{
		ex.ReportError();
		delete f;
		return NULL;
	}
	f->SeekToEnd();
	return new CArchive( f, CArchive::store, _ARCHIVE_BUF_SIZE );
}

//open file for buffered writing
CArchive * OpenProgramFileForBufferedWriting ( LPCTSTR filepath, int nBufSize, void *lpBuf )
{
	CFile *f = new CFile();
	CFileException ex;
	//LPCTSTR filepath = GetProgramFilePath( dir, filename );

	if ( !f->Open( filepath, CFile::modeCreate | CFile::modeWrite, &ex ) )
	{
		ex.ReportError();
		delete f;
		return NULL;
	}
	if ( lpBuf )	
		return new CArchive( f, CArchive::store, nBufSize, lpBuf );
	else	
		return new CArchive( f, CArchive::store, nBufSize );
}


//close file
void CloseProgramFile ( CArchive *ar )
{
	CFile *f;
	if ( ar == NULL )	return;
	f = ar->GetFile();
	ar->Close();
	delete ar;
	delete f;
	return;
}