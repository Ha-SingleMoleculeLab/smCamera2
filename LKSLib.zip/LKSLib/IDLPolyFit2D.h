double IDLPolyFit2DEstimate(int degree, double x, double y, double *coeff);
void IDLPolyFit2D(int n, int m, double *x, double *y, double *f1, double *f2, double *coeff1, double *coeff2);