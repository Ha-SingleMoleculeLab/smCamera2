#pragma once

class CPID
{
// Construction
public:
	CPID();
	virtual ~CPID();

// Implementation
protected:
	double m_KP;
	double m_KI;
	double m_KD;


	//PV : Process Variable
	BOOL m_is_on;
	double m_init_mv;
	double m_init_time;
	double m_final_mv;
	double m_set_pv;
	double m_error_sum;

	long m_pvcnt;
	double *m_pvdata;
	double *m_pvtime;


public:

	void Initialize(double mv, double set_pv = 0.0);
	double Feedback(double pv);

	inline BOOL IsInitialized()	{	return ( m_pvdata != NULL );	}
	inline void TurnOn()	{	m_is_on = TRUE;		}
	inline void TurnOff()	{	m_is_on = FALSE;	}
	inline BOOL IsOn()			{	return m_is_on;	}
	inline double FinalMV()	{	return m_final_mv;	}
	inline double SetPV()	{	return m_set_pv;	}

	inline long PVCount()	{	return m_pvcnt;	}
	double PV(int i);
	double PVTime(int i);


	inline void SetKP(double KP)	{	m_KP = KP;	}
	inline void SetKI(double KI)	{	m_KI = KI;	}
	inline void SetKD(double KD)	{	m_KD = KD;	}
	inline double KP()	{	return m_KP;	}
	inline double KI()	{	return m_KI;	}
	inline double KD()	{	return m_KD;	}
};
