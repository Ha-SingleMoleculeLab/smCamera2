#pragma once

class CSharedMemoryHeader
{
public:
    BOOL valid;
	UINT32 size;
};

class CSharedMemory
{
public:
	CSharedMemory();
	virtual ~CSharedMemory();

	HANDLE hMapFile;
	CSharedMemoryHeader *pHeader;
	BYTE *pBuffer;

	BOOL creater;
	int Create(LPCTSTR name, UINT32 size);

	int Open(LPCTSTR name);
	int Close();
};