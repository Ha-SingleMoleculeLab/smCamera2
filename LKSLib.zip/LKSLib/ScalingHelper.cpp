#include "stdafx.h"
#include "LKSLibCommon.h"
#include <math.h>

inline static double __my_pow(int x, int y)
{
	if ( y < 0 )	return pow((double) 1.0/x, -1 * y );
	return pow((double) x, y );
}

inline static double __standard_scale_value( int order, int index )
{
	// 1, 2, 4, 8
	while ( index < 0 )	index += 4;
	index = index % 4;
	return  __my_pow((double)10, order) * __my_pow((double) 2, index );
}

inline static int __compare_with_standard_scale_value( double value, int order, int index )
{
	double tolerance = 1e-8 * __standard_scale_value( order, 0 );
	double std_value = __standard_scale_value( order, index );
	if ( fabs( value - std_value ) < tolerance )	return 0;	// equal
	if ( value > std_value )	return 1;
	else if ( value < std_value )	return -1;

	// LKSCMT : This area can not be reached.
	ASSERT(FALSE);
	return 0;
}

static int __find_scale_order( double value )
{
	int order = 0;
	int res1, res2;
	res1 = res2 = __compare_with_standard_scale_value( value, order, 0 );
	while ( 1 )
	{
		if ( res2 == 0 )	return order;
		
		if ( res2 * res1 < 0 )
		{
			// if res1 > 0 & res2 < 0
			// order - res1 < value < order
			if ( res1 > 0 )	return order - res1;
			// if res1 < 0 & res2 > 0
			// order < value < order - res1
			else	return order;
		}

		order += res1;
		res2 = __compare_with_standard_scale_value( value, order, 0 );
	}

	// LKSCMT : This area can not be reached.
	ASSERT(FALSE);
	return 0;
}


double ScaleToNewValue(double value, BOOL is_increment)
{
	if ( fabs( value ) < ZERO_TOLERANCE )	return 0.0;

	int order = __find_scale_order(value);
	int index;

	if ( is_increment )
	{	// increment
		for ( index = 1; index <=3 ; index++ )
		{
			if ( __compare_with_standard_scale_value( value, order, index ) < 0 )
				return __standard_scale_value( order, index );
		}
        return __standard_scale_value( order+1, 0 );
	}
	else // decrement
	{
        for ( index = 3; index >= 0; index-- )
		{	
			if ( __compare_with_standard_scale_value( value, order, index ) > 0 )
				return __standard_scale_value( order, index );
		}
		return __standard_scale_value( order-1, 3 );
	}

	// LKSCMT : This area can not be reached.	
	ASSERT(FALSE);
	return 0;
}
