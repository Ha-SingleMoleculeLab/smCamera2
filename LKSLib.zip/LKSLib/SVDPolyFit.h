double svdfit(int ndata, const int *index, 
			const double *x, const double *y, const double *f, const double *sigma,  
			int nterms, void (*basis_func)(double x, double y, double *terms),
			double *coeffs, double **cvm );

double svdfit(int ndata, 
			const double *x, const double *y, const double *f, const double *sigma,  
			int nterms, void (*basis_func)(double x, double y, double *terms),
			double *coeffs, double **cvm );