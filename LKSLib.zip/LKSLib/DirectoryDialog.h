#ifndef	__DIRECTORYDIALOG_H__
#define __DIRECTORYDIALOG_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DirectoryDialog.h - header for CDirectoryDialog class

// CDirectoryDialogWnd - intercepts messages from child controls
class CDirectoryDialogWnd : public CWnd
{
protected:
    afx_msg void OnOpen();              // Open button clicked
	afx_msg void OnSize(UINT nType,int cx,int cy);

    DECLARE_MESSAGE_MAP()
};

// CDirectoryDialog - directory selection dialog
class CDirectoryDialog : public CFileDialog
{
public:
    CDirectoryDialog(LPCTSTR initial = NULL, LPCTSTR filter = NULL, CWnd* pParentWnd = NULL);
    CString GetPath() { return m_strPath; }

    // Overriden members of CFileDialog
    virtual void OnInitDone();
    virtual void OnFolderChange();
	// Disallow selection of files (since we're only selecting directories)
    virtual BOOL OnFileNameOK() { return TRUE; }

public:
    CString m_strPath;                  // Current directory
    CString m_strFilter;                // The current file filters string (used for string storage
                                        // for internal use of File Open dialog)

    CDirectoryDialogWnd m_DirectoryDialogWnd;                   // Subclassed dialog window (parent of CDirectoryDialog window)
    CButton m_SelectButton;                     // "Open" button (replaces OK button)
};

#endif // __DIRECTORYDIALOG_H__
