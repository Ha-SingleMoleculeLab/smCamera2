#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

class CMatrix
{
public:
	CMatrix(int nrows, int ncols);
	CMatrix(int nrows, int ncols, double *data);
	virtual ~CMatrix();
	int m_nrows;
	int m_ncols;
	BOOL m_is_allocated;
	double *m_data;

	inline double* operator[](const int i)
	{	return m_data + i*m_ncols ;	}
	inline double& NRMatrix(const int i, const int j)
	{	return m_data[ (i-1) * m_ncols + (j-1) ];	}
	inline int nrows()
	{	return m_nrows;	}
	inline int ncols()
	{	return m_ncols;	}

	static int Transpose(CMatrix &A, CMatrix &TA);
	static int Multiply(CMatrix &A, CMatrix &B, CMatrix &AB);
	static int Inverse(CMatrix &A, CMatrix &IA);
};

CMatrix::CMatrix(int nrows, int ncols)
{
	m_nrows = nrows;
	m_ncols = ncols;
	m_data = NULL;
	m_is_allocated = TRUE;
	m_data = new double[nrows*ncols];
}

CMatrix::CMatrix(int nrows, int ncols, double *data)
{
	m_nrows = nrows;
	m_ncols = ncols;
	m_is_allocated = FALSE;
	m_data = data;
}

CMatrix::~CMatrix()
{
	if ( m_is_allocated && m_data )	delete [] m_data;
}

int CMatrix::Transpose(CMatrix &A, CMatrix &TA)
{
	if ( A.nrows() != TA.ncols() || A.ncols() != TA.nrows() )	return -1;
	for ( int r = 0 ; r < A.nrows() ; r++ )
		for ( int c = 0 ; c < A.ncols() ; c++ )
			TA[c][r] = A[r][c];
	return 0;
}

int CMatrix::Multiply(CMatrix &A, CMatrix &B, CMatrix &AB)
{
	double temp;
	if ( A.ncols() != B.nrows() || A.nrows() != AB.nrows() || B.ncols() != AB.ncols() )	return -1;

	for ( int r = 0 ; r < A.nrows() ; r++ )
	{
		for ( int c = 0 ; c < B.ncols() ; c++ )
		{
			temp = 0.0;
			for ( int i = 0 ; i < A.ncols() ; i++ )	temp += A[r][i]*B[i][c];
			AB[r][c] = temp;
		}
	}
	return 0;
}

//Matrix Inversion by Gauss-Jordan Elimination
int CMatrix::Inverse(CMatrix &A, CMatrix &IA)
{
	int N = A.nrows();	
	if ( N != A.ncols() || N != IA.nrows() || N != IA.ncols() )	return -1;
	
	//Initialization
	CMatrix tempA(N,N);
	for ( int r = 0 ; r < N ; r++ )
	{
		for ( int c = 0 ; c < N ; c++ )
		{
			tempA[r][c] = A[r][c];
			IA[r][c] = ( r == c ) ? 1.0 : 0.0;
		}
	}

	//Echelon Form, Pivotting
	int num_pivotting =  0;
	double max_element;
	int max_element_row;
	for ( int i = 0 ; i < N ; i++ )
	{
		max_element = 0.0;
		max_element_row = i;

		//Pivotting
		for ( int r = i ; r < N ; r++ )
		{
			if ( fabs( tempA[r][i] ) > max_element )
			{
				max_element = fabs( tempA[r][i] );
				max_element_row = r;
			}
		}
		if ( max_element_row != i )
		{
			double temp_pivot;
			for ( int c = 0 ; c < N ; c++ )
			{
				temp_pivot = tempA[max_element_row][c];
				tempA[max_element_row][c] = tempA[i][c];
				tempA[i][c] = temp_pivot;

				temp_pivot = IA[max_element_row][c];
				IA[max_element_row][c] = IA[i][c];
				IA[i][c] = temp_pivot;
			}
			num_pivotting++;
		}
		//Echelon Form
		for ( int r = i+1 ; r < N ; r++ )
		{
			double ratio = tempA[r][i]/tempA[i][i];
			for ( int c = 0 ; c < N ; c++ )
			{
				tempA[r][c] = tempA[r][c] - ratio * tempA[i][c];
				IA[r][c] = IA[r][c] - ratio * IA[i][c];
			}
			tempA[r][i] = 0.0;
		}
	}


	//Determinant
	double detA = ( ( num_pivotting % 2 ) == 0 ) ? 1.0 : -1.0;
	for ( int r = 0 ; r < N ; r++ )	detA *= tempA[r][r];
	if ( detA == 0 )	return -1;


	//Make tempA diagonal
	for ( int i = N-1 ; i >= 0 ; i-- )
	{
		for ( int r = i ; r > 0 ; r-- )
		{
			double ratio = tempA[r-1][i]/tempA[i][i];
			for ( int c = 0 ; c < N ; c++ )
			{
				tempA[r-1][c] = tempA[r-1][c] - ratio * tempA[i][c];
				if ( fabs(tempA[r-1][c]) < 0.0000000 )	tempA[r-1][c] = 0.0;
				IA[r-1][c] = IA[r-1][c] - ratio * IA[i][c];
				if ( fabs(IA[r-1][c]) < 0.0000000 )	IA[r-1][c] = 0.0;
			}
			tempA[r-1][i] = 0.0;
		}
	}

	//Make tempA Identity Matrix
	for ( int r = 0; r < N ; r++ )
	{
		for ( int c = 0; c < N ; c++ )	IA[r][c] /= tempA[r][r];
		tempA[r][r] = 1.0;
	}

	return 0;
}



static void IDLPolyFit2DBasis(int degree, double x, double y, double *terms)
{
	for ( int i = 0 ; i <= degree ; i++ )
		for ( int j = 0 ; j <= degree ; j++ )
			terms[ (degree+1)*i + j ] = pow((double)x,i) * pow((double)y,j);

}

double IDLPolyFit2DEstimate(int degree, double x, double y, double *coeff)
{
	double result = 0.0;
	for ( int i = 0 ; i <= degree ; i++ )
		for ( int j = 0 ; j <= degree ; j++ )
			result += coeff[ (degree+1)*i + j ] * pow((double)x,i) * pow((double)y,j);
	return result;
}

//cf. POLYWARP procedure in IDL
void IDLPolyFit2D(int n, int m, double *x, double *y, double *f1, double *f2, double *coeff1, double *coeff2)
{
	// n : degree
	// m : number of points
	int n2 = (n+1)*(n+1);
	CMatrix ut(m,n2);
	CMatrix Tut(n2,m);
	CMatrix uu(n2,n2);
	CMatrix Iuu(n2,n2);
	CMatrix kk(m,n2);

	double *terms = new double[n2];
	for ( int i = 0 ; i < m ; i++ )
	{
		IDLPolyFit2DBasis(n, x[i], y[i], terms);
		for ( int j = 0 ; j < n2 ; j++ )	ut[i][j] = terms[j];
	}

	CMatrix::Transpose(ut, Tut);
	CMatrix::Multiply(Tut, ut, uu);
	CMatrix::Inverse(uu, Iuu);
	CMatrix::Multiply(ut, Iuu, kk);

	if ( f1 )
	{
        CMatrix Tf1(1,m,f1);
		CMatrix k1(1,n2,coeff1);
		CMatrix::Multiply(Tf1, kk, k1);
	}
	if ( f2 )
	{
		CMatrix Tf2(1,m,f2);
		CMatrix k2(1,n2, coeff2);
		CMatrix::Multiply(Tf2, kk, k2);
	}
	delete [] terms;
	return;
}