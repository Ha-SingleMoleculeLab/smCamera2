void PSD_NR ( int N, double * sampled_data, /*input*/
		   	double * psd /*output*/ );
// LKSCMT : Get Power Spectral Density.
// P(k) = SQR ( DFT( k, x(t) ) * msr_interval ) / total_msr_time
// 
//	array-size of sampled_data : 0, 1,.., N
//	array-size of psd : 0, 1, .. , N/2
// XXX : N, total number of sampled data, MUST be an integer power of 2 (this is not checked for!).

void PSD_Sorensen ( int N, double Tmsr, double * sampled_data, //input 
										double * psd );	//output