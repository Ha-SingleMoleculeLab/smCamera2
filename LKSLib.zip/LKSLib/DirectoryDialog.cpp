/*****************************************************************************************/
// DirectoryDialog.cpp - implements class CDirectoryDialog
/*****************************************************************************************/
// Originally DirDialog.cpp		
// by	Andrew Phillips (view profile)		January 14, 2000
// http://www.codeguru.com/cpp/w-d/dislog/dialogforselectingfolders/article.php/c1885/
//
/*****************************************************************************************/
// Original Documentation
/*****************************************************************************************/
//
// The CDirectoryDialog class implements a directory selection dialog by deriving from the file
// selection dialog class (CFileDialog).  This dialog has the advantages of the standard
// file open dialog (resizeable, ability to create/delete directories etc) but is
// customized for the selection of a directory rather than a file.
//
// USER INTERFACE
// --------------
//
// For example, the user can double click on a directory name or type it into the
// edit control to open it in the directory listing display.  To say that this is
// the directory they want the user must click the "Open" button.  When the user
// enters a backslash (\) as the last character in the edit control the display is
// changed to show the contents of the directory if it exists.  The same is done if
// the user presses the Enter key except that if the directory does not exist the
// user is asked if they want to create it.
//
// When the user enters other characters and the contents don't end in a backslash
// then automatic directory name completion is attempted.  If the contents of the
// edit box are the first character(s) of one unique existing directory then the
// rest of the directory name is added to the end of the edit box.  These characters
// are selected so that the user can type something else and it they will be ignored.
//
// When selecting a directory you would normally not want to see files, but you may on
// occasion.  The normal "Files of Type:" drop down list is available but it has an
// extra entry "Show Folders Only" that is selected by default.  When files are
// displayed double clicking of them is ignored (unlike the normal File Open dialog).
// Double-clicking a directory name changes to that directory as normal.
//
// PROGRAMMER INTERFACE
// --------------------
//
// Add DirectoryDialog.cpp and DirectoryDialog.h to your project.  Include DirectoryDialog.h
// in the source file(s) where you want to use the CDirectoryDialog class.
//
// Create a CDirectoryDialog object using the constructor described below.  If necessary
// you may then modify values in the m_ofn member of the CFileDialog base class
// (see the Win32 documentation for OPENFILENAME).  For example, to change the
// text that appears in the title bar of the dialog use m_ofn.lpstrTitle.
//
// Call DoModal() to activate the dialog.  If DoModal() return IDOK you can then
// call GetPath() to obtain the name of the directory that the user selected.
//
//
// CDirectoryDialog::CDirectoryDialog(LPCTSTR lpstrInitialDir = NULL,
//                        LPCTSTR lpszFilter = NULL, CWnd* pParentWnd = NULL);
// 
//      lpstrInitialDir
//          The initial directory.  If NULL then the current directory is used.
//          See lpstrInitialDir in the Win32 documentation for OPENFILENAME for more info.
//
//      lpszFilter
//          The string pairs that specify the file filters to use.  See lpszFilter
//          in the documentation for the CFileDialog constructor for more info.
//          Note that an extra entry is always added that allows the user to hide the
//          display of all files.  If NULL is used (the default) then only the
//          "no files" entry and an "all files" entry are provided.
//    
//      pParentWnd
//          A pointer to the dialog parent window.
//
// virtual int CDirectoryDialog::DoModal()
//
//      see CFileDialog::DoModal().
//
// CString CDirectoryDialog::GetPath()
//
//      return value
//          The full path name chosen by the user.
//
// Example:
//
//      // Called when the Browse button is clicked in CMyDialog
//      void CMyDialog::OnBrowseDir() 
//      {
//          if (!UpdateData(TRUE))          // Update current value of m_dir from control
//              return;
//
//          CDirectoryDialog dlg(m_dir,
//                        "JPEG Files (*.jpg; *.jpeg)|*.jpg;*.jpeg|All Files (*.*)|*.*||",
//                        this);
//          dlg.m_ofn.lpstrTitle = "Select Folder to Store Images";
//
//          if (dlg.DoModal() == IDOK)
//          {
//              m_dir = dlg.GetPath();      // Store selected directory name back into the control
//              UpdateData(FALSE);
//          }
//      }
//
//
// INTERNAL DESIGN
// ---------------
//
// The following changes are made to the controls in the standard file open dialog:
//
// The "Open" button is hidden and replaced with another button (IDC_SELECT).
// The normal edit control (edt1) where the file name is entered is hidden and replaced 
// by a "subclassed" edit control (IDC_DIR) of class CDirEdit (derived from CEdit).
// By hiding and replacing these controls we can manipulate the behaviour
// of the dialog in ways not provided for in any other way.  For example, by changing
// the contents of the hidden edit control (edt1) and simulating a click of the hidden
// Open button (IDOK) we can force the contents of a directory to be displayed.
//
// An extra entry is added to the file types drop down combo called "Show Folders Only"
// that causes no files to be displayed.  (If no filters are supplied at all by using
// the default value of NULL, then an "All Files" filter type is also added.)
// The filter string is a single dot (full-stop) which will match no files.
//
// The new edit control (IDC_DIR) is subclassed so that the contents are monitored and
// the some keys can be intercepted.  When the contents are changed and they end with
// a backslash the current display is changed to point to the directory entered (if it
// exists).  When return is pressed the directory is also changed, but if it doesn't
// exist then the user is asked if he wants to create it.  The way the directory is
// changed (ie. the files of that directory are shown in the display) is by putting the
// directory name into the original edit control (edt1) and simulating a click of the
// original Open button (IDOK).  Directory name completion is also performed as the
// user types in a directory name.
//
// The IDC_SELECT button is used as a replacement for the IDOK button while still allowing
// the hidden IDOK button to be used to change the displayed directory.
//
// The CDirectoryDialog class is derived from CFileDialog. The following base class members
// are overridden:
// - OnInitDone: so that the dialog controls can be reorganized
// - OnFolderChange: so that when the user clicks on a folder name the edit control can
//   be updated to reflect the name of the currently selected directory
// - OnFileNameOK: always returns TRUE so that the user can't select files by
//   double-clicking them (this is a DIRECTORY selection dialog after all)


#include "stdafx.h"
// If you don't want this as part of your project (eg to put in a library) remove
// the above #include "stdafx.h" and uncomment the following 3 lines:
//#define VC_EXTRALEAN        // Exclude rarely-used stuff from Windows headers
//#include <afxwin.h>         // MFC core and standard components
//#include <afxext.h>         // MFC extensions

#include <Dlgs.h>           // For file dialog control IDs
#include <imagehlp.h>       // For ::MakeSureDirectoryPathExists()
#include "DirectoryDialog.h"      // Our own header file

#define IDC_SELECT 182        // New "Open" button

/*****************************************************************************************/
// Class CDirectoryDialogWnd
/*****************************************************************************************/
BEGIN_MESSAGE_MAP(CDirectoryDialogWnd, CWnd)
        ON_BN_CLICKED(IDC_SELECT, OnOpen)
END_MESSAGE_MAP()


void CDirectoryDialogWnd::OnOpen()
{
    ::EndDialog(m_hWnd, IDOK);
}

void CDirectoryDialogWnd::OnSize(UINT nType,int cx,int cy)
{
	CWnd::OnSize(nType, cx, cy);
	CRect rct; // Used to move/resize controls

	ASSERT(GetDlgItem(IDCANCEL) != NULL);
	GetDlgItem(IDCANCEL)->GetWindowRect(rct); //Get OK button rectangle
	ScreenToClient(rct);
	GetDlgItem(IDC_SELECT)->SetWindowPos(&wndTopMost, rct.left, rct.top, 0,0, SWP_NOSIZE);
} 
/*****************************************************************************************/
// --- class CDirectoryDialogWnd ---
/*****************************************************************************************/


/*****************************************************************************************/
// class CDirectoryDialog
/*****************************************************************************************/
CDirectoryDialog::CDirectoryDialog(LPCTSTR initial, LPCTSTR filter, CWnd* pParentWnd)
    : CFileDialog(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST, NULL, pParentWnd)      
{
    // Note: m_strFilter is a member variable so it doesn't disappear because
    // it is used later internally by the file open dialog (via m_ofn.lpstrFilter).
	if ( initial )	m_strPath = initial;
	else	m_strPath = _T("");
    if ( filter )	m_strFilter = filter + CString(_T("Show Folders Only|.||"));
    else	m_strFilter = _T("Show Folders Only|.|All Files (*.*)|*.*||");

    m_strFilter.Replace('|', '\0');
    m_ofn.lpstrFilter = m_strFilter;
    m_ofn.lpstrInitialDir = initial;
    m_ofn.lpstrTitle = _T("Select Folder");
}

void CDirectoryDialog::OnInitDone()
{
    CRect rct;                          // Used to move/resize controls
    CWnd *pp;                           // Parent = the dialog window itself
    VERIFY(pp = GetParent());

   	SetControlText(stc3, _T("Folder:"));
	SetControlText(IDOK, _T("Change Path"));

    // Create a new CDirectoryDialogWnd so we can catch dialog control notifications
    VERIFY(m_DirectoryDialogWnd.SubclassWindow(pp->m_hWnd));
    
    // Create a new button where the Cancel button now is
	CWnd *pCancel = pp->GetDlgItem(IDCANCEL);
    ASSERT(pCancel != NULL);
	pCancel->GetWindowRect(rct); //Get Cancel button rectangle
    pp->ScreenToClient(rct);

    m_SelectButton.Create(_T("Select Path"), WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, rct, pp, IDC_SELECT);
    m_SelectButton.SetFont(pp->GetDlgItem(IDCANCEL)->GetFont());
    m_SelectButton.SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

	pCancel->SetWindowPos(&m_SelectButton, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

    // Change default push button
    pp->GetDlgItem(IDOK)->ModifyStyle(BS_DEFPUSHBUTTON, 0);
    //pp->SendMessage(DM_SETDEFID, IDC_SELECT);

    // Hide the controls we don't want the user to use
    HideControl(IDCANCEL);

    CFileDialog::OnInitDone();
}


/*
//LKSCMT : Useful Comment

Old  February 10th, 2005, 05:41 PM	gooshbob 
http://codeguru.earthweb.net/forum/showthread.php?t=286705
Re: I can't access the edit box from a CFIleDialog derived class!
.net has changed the Filedialog edit box. If you instantiate a CFiledialog, you'll see the difference. The edit box, edt1, is replaced by a combo box, cmb13. You should be able to figure out what to do from this is your code.
For example, in the DirDialog code by Andrew Phillips, you can just do a find/replace (cmb13 for edt1) and it works.
*/

void CDirectoryDialog::OnFolderChange()
{	
    CWnd *pp;  

    VERIFY(pp = GetParent());


	CWnd *pWnd = pp->GetDlgItem(cmb13);
	if ( pWnd )	pWnd->SetWindowText(m_strPath);
	CFileDialog::OnFolderChange();
}


/*****************************************************************************************/
// --- class CDirectoryDialog ---
/*****************************************************************************************/