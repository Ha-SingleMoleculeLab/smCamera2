#include "stdafx.h"

static CView *pLogView = NULL;
static CEdit *pLogEdit = NULL;
static CStatusBar *pLogStatusBar = NULL;

LPCTSTR Stringify(LPCTSTR format, ... )
{
	static CString str;

	// format and write the data you were given	
	va_list args;
	va_start(args, format);
	str.FormatV(format, args);
	va_end(args);

	return str;
}

void LogOpen(CView *view, CEdit *edit, CStatusBar *status)
{
	pLogView = view;
	pLogEdit = edit;
	pLogStatusBar = NULL;
}

void LogFlush()
{
	if ( pLogView )	pLogView->UpdateWindow();		
}

void LogClose()
{

}

#include <time.h>
#define	_MAX_LOGFILE_SIZE	(1024*1024)
void LogMessage(int line, LPCTSTR function, LPCTSTR file, LPCTSTR category, LPCTSTR msg )
{
	if ( pLogStatusBar )	pLogStatusBar->SetPaneText(0, msg );

	__time64_t tmp_time64;
	_time64( &tmp_time64 );
	struct tm *tmp_tm;
	tmp_tm = _localtime64( &tmp_time64 );

	CString str;
	str.Format(_T("[%02d:%02d:%02d %s] %s \r\n"), 
				tmp_tm->tm_hour, tmp_tm->tm_min, tmp_tm->tm_sec, category, msg );	
	if ( pLogEdit && ::IsWindow( pLogEdit->m_hWnd ) )
	{
		CString strEdit;
		pLogEdit->GetWindowText(strEdit);
		strEdit = str + strEdit;
		if ( strEdit.GetLength() > _MAX_LOGFILE_SIZE )
			strEdit = strEdit.Left(_MAX_LOGFILE_SIZE);
		pLogEdit->SetWindowText(strEdit);
	}

	return;
}