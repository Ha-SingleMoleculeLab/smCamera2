#include "stdafx.h"
#include "SVDPolyFitTools.h"
#include "SVDPolyFit.h"
#include <math.h>



static void PolyFit1Basis(double x, double y, double *terms)
{
	terms[0] = 1.0;
	for ( int i = 1 ; i < NUM_COEFFS_FOR_POLYFIT1 ; i++ )	
		terms[i] = terms[i-1] * x;
}
void PolyFit1(const int N, const double *x, const double *f, double *a)
{
	svdfit( N, x, NULL, f, NULL, NUM_COEFFS_FOR_POLYFIT1, PolyFit1Basis, a, NULL ); 
}
double PolyFit1Estimate(double x, double *a)
{
	double result = 0.0;
	double xterm = 1.0;
	for ( int i = 0 ; i < NUM_COEFFS_FOR_POLYFIT1 ; i++ )
	{
		result += a[i]*xterm;
		xterm = xterm * x;
	}
	return result;
}

static void PolyFit2Basis(double x, double y, double *terms)
{
	terms[0] = 1.0;
	for ( int i = 1 ; i < NUM_COEFFS_FOR_POLYFIT2 ; i++ )	
		terms[i] = terms[i-1] * x;
}
void PolyFit2(const int N, const double *x, const double *f, double *a)
{
	svdfit( N, x, NULL, f, NULL, NUM_COEFFS_FOR_POLYFIT2, PolyFit2Basis, a, NULL ); 
}
double PolyFit2Estimate(double x, double *a)
{
	double result = 0.0;
	double xterm = 1.0;
	for ( int i = 0 ; i < NUM_COEFFS_FOR_POLYFIT2 ; i++ )
	{
		result += a[i]*xterm;
		xterm = xterm * x;
	}
	return result;
}

static void PolyFit3Basis(double x, double y, double *terms)
{
	terms[0] = 1.0;
	for ( int i = 1 ; i < NUM_COEFFS_FOR_POLYFIT3 ; i++ )	
		terms[i] = terms[i-1] * x;
}
void PolyFit3(const int N, const double *x, const double *f, double *a)
{
	svdfit( N, x, NULL, f, NULL, NUM_COEFFS_FOR_POLYFIT3, PolyFit3Basis, a, NULL ); 
}
double PolyFit3Estimate(double x, double *a)
{
	double result = 0.0;
	double xterm = 1.0;
	for ( int i = 0 ; i < NUM_COEFFS_FOR_POLYFIT3 ; i++ )
	{
		result += a[i]*xterm;
		xterm = xterm * x;
	}
	return result;
}












static void PolyFit2D1Basis(double x, double y, double *terms)
{
	int idx = 0;
	for ( int i = 0 ; i <= 1 ; i++ )
		for ( int j = 0 ; j <= 1 ; j++ )
		{
			if ( i + j > 1 )	continue;
			terms[idx++] = pow((double)x,j) * pow((double)y,i);
		}
}

void PolyFit2D1(int N, const int *index, 
				const double *x, const double *y, const double *f, double *a)
{
	svdfit( N, index, x, y, f, NULL, 
			NUM_COEFFS_FOR_POLYFIT2D1, PolyFit2D1Basis, a, NULL );
}

void PolyFit2D1(int N, const double *x, const double *y, const double *f, double *a)
{
	svdfit( N, x, y, f, NULL, 
			NUM_COEFFS_FOR_POLYFIT2D1, PolyFit2D1Basis, a, NULL );
}


double PolyFit2D1Estimate(double x, double y, double *coeff)
{
	double result = 0.0;
	int idx = 0;
	for ( int i = 0 ; i <= 1 ; i++ )
		for ( int j = 0 ; j <= 1 ; j++ )
		{
			if ( i + j > 1 )	continue;
			result += coeff[idx++] * pow((double)x,j) * pow((double)y,i);
		}
	return result;
}

double& PolyFit2D1Coeff(double *coeff, int x_index, int y_index)
{
	int idx = 0;
	for ( int i = 0 ; i <= 1 ; i++ )
		for ( int j = 0 ; j <= 1 ; j++ )
		{
			if ( i + j > 1 )	continue;
			if ( i == y_index && j == x_index )	return coeff[idx];
			idx++;
		}

	ASSERT(FALSE);
	return coeff[0];
}

LPCTSTR PolyFit2D1Text(LPCSTR ZTEXT, LPCSTR XTEXT, LPCSTR YTEXT, double *a)
{
	static CString str;
	CString xterm, yterm;

	str.Format(_T("%s ="), ZTEXT);
	for ( int i = 0 ; i <= 1 ; i++ )
	{
		for ( int x = i ; x >= 0 ; x-- )
		{
			int y = i - x ;
			
			if ( x == 0 )
				xterm = _T("");
			else
				xterm.Format(_T("%s^%d"), XTEXT, x);

			if ( y == 0 )
				yterm = _T("");
			else
				yterm.Format(_T("%s^%d"), YTEXT, y);


			str.AppendFormat(_T("%s %.3f%s%s%s"), ( i == 0 ) ? _T("") : _T(" +"), PolyFit2D1Coeff(a, x, y), ( i ) ? _T(" ") : _T(""), xterm, yterm );
		}
	}

	return (LPCTSTR) str;
}




static void PolyFit2D2Basis(double x, double y, double *terms)
{
	int idx = 0;
	for ( int i = 0 ; i <= 2 ; i++ )
		for ( int j = 0 ; j <= 2 ; j++ )
		{
			if ( i + j > 2 )	continue;
			terms[idx++] = pow((double)x,j) * pow((double)y,i);
		}
}

void PolyFit2D2(int N, const int *index, 
				const double *x, const double *y, const double *f, double *a)
{
	svdfit( N, index, x, y, f, NULL, 
			NUM_COEFFS_FOR_POLYFIT2D2, PolyFit2D2Basis, a, NULL );
}

void PolyFit2D2(int N, const double *x, const double *y, const double *f, double *a)
{
	svdfit( N, x, y, f, NULL, 
			NUM_COEFFS_FOR_POLYFIT2D2, PolyFit2D2Basis, a, NULL );
}


double PolyFit2D2Estimate(double x, double y, double *coeff)
{
	double result = 0.0;
	int idx = 0;
	for ( int i = 0 ; i <= 2 ; i++ )
		for ( int j = 0 ; j <= 2 ; j++ )
		{
			if ( i + j > 2 )	continue;
			result += coeff[idx++] * pow((double)x,j) * pow((double)y,i);
		}
	return result;
}

double& PolyFit2D2Coeff(double *coeff, int x_index, int y_index)
{
	int idx = 0;
	for ( int i = 0 ; i <= 2 ; i++ )
		for ( int j = 0 ; j <= 2 ; j++ )
		{
			if ( i + j > 2 )	continue;
			if ( i == y_index && j == x_index )	return coeff[idx];
			idx++;
		}

	ASSERT(FALSE);
	return coeff[0];
}

LPCTSTR PolyFit2D2Text(LPCSTR ZTEXT, LPCSTR XTEXT, LPCSTR YTEXT, double *a)
{
	static CString str;
	CString xterm, yterm;

	str.Format(_T("%s ="), ZTEXT);
	for ( int i = 0 ; i <= 2 ; i++ )
	{
		for ( int x = i ; x >= 0 ; x-- )
		{
			int y = i - x ;
			
			if ( x == 0 )
				xterm = _T("");
			else
				xterm.Format(_T("%s^%d"), XTEXT, x);

			if ( y == 0 )
				yterm = _T("");
			else
				yterm.Format(_T("%s^%d"), YTEXT, y);


			str.AppendFormat(_T("%s %.3f%s%s%s"), ( i == 0 ) ? _T("") : _T(" +"), PolyFit2D2Coeff(a, x, y), ( i ) ? _T(" ") : _T(""), xterm, yterm );
		}
	}

	return (LPCTSTR) str;
}




static void PolyFit2D5Basis(double x, double y, double *terms)
{
	int idx = 0;
	for ( int i = 0 ; i <= 5 ; i++ )
		for ( int j = 0 ; j <= 5 ; j++ )
		{
			if ( i + j > 5 )	continue;
			terms[idx++] = pow((double)x,j) * pow((double)y,i);
		}
}

void PolyFit2D5(int N, const int *index, 
				const double *x, const double *y, const double *f, double *a)
{
	svdfit( N, index, x, y, f, NULL, 
			NUM_COEFFS_FOR_POLYFIT2D5, PolyFit2D5Basis, a, NULL );
}

void PolyFit2D5(int N, const double *x, const double *y, const double *f, double *a)
{
	svdfit( N, x, y, f, NULL, 
			NUM_COEFFS_FOR_POLYFIT2D5, PolyFit2D5Basis, a, NULL );
}


double PolyFit2D5Estimate(double x, double y, double *coeff)
{
	double result = 0.0;
	int idx = 0;
	for ( int i = 0 ; i <= 5 ; i++ )
		for ( int j = 0 ; j <= 5 ; j++ )
		{
			if ( i + j > 5 )	continue;
			result += coeff[idx++] * pow((double)x,j) * pow((double)y,i);
		}
	return result;
}

double& PolyFit2D5Coeff(double *coeff, int x_index, int y_index)
{
	int idx = 0;
	for ( int i = 0 ; i <= 5 ; i++ )
		for ( int j = 0 ; j <= 5 ; j++ )
		{
			if ( i + j > 5 )	continue;
			if ( i == y_index && j == x_index )	return coeff[idx];
			idx++;
		}

	ASSERT(FALSE);
	return coeff[0];
}

/*
double PolyFit2D5LinearEstimate(double x, double y, double *coeff)
{
	return PolyFit2D5Coeff(coeff,0,0) 
		+ PolyFit2D5Coeff(coeff,1,0) * x 
		+ PolyFit2D5Coeff(coeff,0,1) * y ;
}
*/

LPCTSTR PolyFit2D5Text(LPCSTR ZTEXT, LPCSTR XTEXT, LPCSTR YTEXT, double *a)
{
	static CString str;
	CString xterm, yterm;

	str.Format(_T("%s ="), ZTEXT);
	for ( int i = 0 ; i <= 5 ; i++ )
	{
		for ( int x = i ; x >= 0 ; x-- )
		{
			int y = i - x ;
			
			if ( x == 0 )
				xterm = _T("");
			else
				xterm.Format(_T("%s^%d"), XTEXT, x);

			if ( y == 0 )
				yterm = _T("");
			else
				yterm.Format(_T("%s^%d"), YTEXT, y);


			str.AppendFormat(_T("%s %.3f%s%s%s"), ( i == 0 ) ? _T("") : _T(" +"), PolyFit2D5Coeff(a, x, y), ( i ) ? _T(" ") : _T(""), xterm, yterm );
		}
	}

	return (LPCTSTR) str;
}