/******************************* For Polynomical Fitting ***************************/
#define NUM_COEFFS_FOR_IDLPOLYFIT2D1	(4)
void IDLPolyFit2D1(int m, double *x, double *y, double *f1, double *f2, double *coeff1, double *coeff2);
double IDLPolyFit2D1Estimate(double x, double y, double *coeff);
double& IDLPolyFit2D1Coeff(double *a, int x_index, int y_index);
//double IDLPolyFit2D1LinearEstimate(double x, double y, double *a);
LPCTSTR IDLPolyFit2D1Text(LPCSTR Z, LPCSTR X, LPCSTR Y, double *a);


#define NUM_COEFFS_FOR_IDLPOLYFIT2D3	(16)
void IDLPolyFit2D3(int m, double *x, double *y, double *f1, double *f2, double *coeff1, double *coeff2);
double IDLPolyFit2D3Estimate(double x, double y, double *coeff);
double& IDLPolyFit2D3Coeff(double *a, int x_index, int y_index);
//double IDLPolyFit2D3LinearEstimate(double x, double y, double *a);
LPCTSTR IDLPolyFit2D3Text(LPCSTR Z, LPCSTR X, LPCSTR Y, double *a);