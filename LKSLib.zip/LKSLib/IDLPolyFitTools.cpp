#include "stdafx.h"
#include "IDLPolyFitTools.h"
#include "IDLPolyFit2D.h"


void IDLPolyFit2D1(int m, double *x, double *y, double *f1, double *f2, double *coeff1, double *coeff2)
{
	return IDLPolyFit2D(1, m, x, y, f1, f2, coeff1, coeff2);
}

double IDLPolyFit2D1Estimate(double x, double y, double *coeff)
{
	return IDLPolyFit2DEstimate(1, x, y, coeff);
}

double& IDLPolyFit2D1Coeff(double *coeff, int x_index, int y_index)
{
	return coeff[ 2*x_index + y_index ];
}

/*
double IDLPolyFit2D1LinearEstimate(double x, double y, double *coeff)
{
	return IDLPolyFit2D1Coeff(coeff,0,0)
		+ IDLPolyFit2D1Coeff(coeff,1,0) * x
		+ IDLPolyFit2D1Coeff(coeff,0,1) * y;
}
*/

LPCTSTR IDLPolyFit2D1Text(LPCSTR ZTEXT, LPCSTR XTEXT, LPCSTR YTEXT, double *a)
{
	static CString str;
	CString xterm, yterm;

	str.Format(_T("%s ="), ZTEXT);
	for ( int i = 0 ; i <= 2 ; i++ )
	{
		for ( int y = 0 ; y <= i ; y++ )
		{
			if ( y > 1 )	continue;
			for ( int x = i ; x >= 0 ; x-- )
			{
				if ( x > 1 )	continue;
				if ( x + y  != i )	continue;
			
				if ( x == 0 )
					xterm = _T("");
				else
					xterm.Format(_T("%s^%d"), XTEXT, x);

				if ( y == 0 )
					yterm = _T("");
				else
					yterm.Format(_T("%s^%d"), YTEXT, y);

                str.AppendFormat(_T("%s %.3f%s%s%s"), ( i == 0 ) ? _T("") : _T(" +"), IDLPolyFit2D1Coeff(a, x, y), ( i ) ? _T(" ") : _T(""), xterm, yterm );
			}
		}
	}

	return (LPCTSTR) str;
}






void IDLPolyFit2D3(int m, double *x, double *y, double *f1, double *f2, double *coeff1, double *coeff2)
{
	return IDLPolyFit2D(3, m, x, y, f1, f2, coeff1, coeff2);
}

double IDLPolyFit2D3Estimate(double x, double y, double *coeff)
{
	return IDLPolyFit2DEstimate(3, x, y, coeff);
}

double& IDLPolyFit2D3Coeff(double *coeff, int x_index, int y_index)
{
	return coeff[ 4*x_index + y_index ];
}

/*
double IDLPolyFit2D3LinearEstimate(double x, double y, double *coeff)
{
	return IDLPolyFit2D3Coeff(coeff,0,0)
		+ IDLPolyFit2D3Coeff(coeff,1,0) * x
		+ IDLPolyFit2D3Coeff(coeff,0,1) * y;
}
*/
LPCTSTR IDLPolyFit2D3Text(LPCSTR ZTEXT, LPCSTR XTEXT, LPCSTR YTEXT, double *a)
{
	static CString str;
	CString xterm, yterm;

	str.Format(_T("%s ="), ZTEXT);
	for ( int i = 0 ; i <= 6 ; i++ )
	{
		for ( int y = 0 ; y <= i ; y++ )
		{
			if ( y > 3 )	continue;
			for ( int x = i ; x >= 0 ; x-- )
			{
				if ( x > 3 )	continue;
				if ( x + y  != i )	continue;
			
				if ( x == 0 )
					xterm = _T("");
				else
					xterm.Format(_T("%s^%d"), XTEXT, x);

				if ( y == 0 )
					yterm = _T("");
				else
					yterm.Format(_T("%s^%d"), YTEXT, y);

                str.AppendFormat(_T("%s %.3f%s%s%s"), ( i == 0 ) ? _T("") : _T(" +"), IDLPolyFit2D3Coeff(a, x, y), ( i ) ? _T(" ") : _T(""), xterm, yterm );
			}
		}
	}

	return (LPCTSTR) str;
}