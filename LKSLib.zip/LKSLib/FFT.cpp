#include "stdafx.h"
#include "LKSLibCommon.h"


//LKSCMT : four1 function from "Numerical Recipes in C"
//	DFT(k) = SUM(j=0..N-1) [ c(j) * exp(2*pi*i*  j*k/N) ], 
//	where k = 0... N-1
//	or where k = 0, 1, .. , N/2 -1, N/2, -(N/2-1), ..., -1.

// i.e.
//	zero frequency component -> data[1], data[2]
//	smallest nonzero positive -> data[3], data[4]
//	smallest nonzero negative -> data[2*nn-1], data[2*nn]
//	positive frequencies -> data[3], data[4] ~ data[nn-1], data[nn]
//	negative frequencies -> data[2*nn-1], data[2*nn] ~ data[nn+3], data[nn+4]
//	data[nn+1], data[nn+2] -> the most positive freq == the most negative freq

void FFT(double data[], unsigned long nn, int isign)
// Replaces data[1..2*nn] by its discrete Fourier transform, if isign is input as 1;
// or replaces data[1..2*nn] by nn times its inverse discrete Fourier tranform, 
// if isign is input as -1. Data is a complex array of length nn or, equivalently, a real array of length 2*nn.
// XXX : nn MUST be an integer power of 2 (this is not checked for!).
// If input data array is zero-offset, simply decrement the pointer to data by one when four1 is invoked,
// e.g., four1(data-1, 1024, 1);. The real part of f0 will now be returned in data[0], the imaginary part in data[1], and so on.
{
	unsigned long n, mmax, m, j, istep, i;
	double wtemp, wr, wpr, wpi, wi, theta, swap;
	double tempr, tempi;

#define SWAP(a,b) {swap=(a);(a)=(b);(b)=swap;}

	// Bit-reversal section 
	n = nn << 1;
	j = 1;
	for(i = 1; i < n; i+= 2){
		if(j > i){
			SWAP(data[j], data[i]);
			SWAP(data[j+1], data[i+1]);
		}
		m = n >> 1;
		while (m >= 2 && j > m){
			j -= m;
			m >>= 1;
		}
		j += m;
	}

	// Danielson-Lanczos section of the routine.
	mmax = 2;
	while(n > mmax){  // Outer loop executed log2(nn) times.
		istep = mmax << 1;
		theta = isign * (6.28318530717959 / mmax); // Initialize the trigonometric recurrence.
		wtemp = sin(0.5 * theta);
		wpr = -2.0 * wtemp * wtemp;
		wpi = sin(theta);
		wr = 1.0;
		wi = 0.0;
		for(m = 1; m < mmax; m += 2){            // Two nested inner loops.
			for(i = m; i <= n; i += istep){
				j = i + mmax;					 // This is the Danielson-Lanczos formula.
				tempr = wr * data[j] - wi* data[j+1];
				tempi = wr * data[j+1] + wi * data[j];
				data[j] = data[i] - tempr;
				data[j+1] = data[i+1] - tempi;
				data[i] += tempr;
				data[i+1] += tempi;
			}
			wr = (wtemp = wr) * wpr - wi * wpi + wr;     // trigonometric recurrence.
			wi = wi * wpr + wtemp * wpi + wi;
		}
		mmax = istep;
	}
}

inline static double __data_window(int j, int N)
{	// j : current index, N : total number of data
	//return 1 - fabs( ( j - 0.5 * N ) * 2.0 / N );	//Bartlett window
	return 1 - SQR( ( j - 0.5 * N ) * 2.0 / N );	//Welch window
}

void PSD_NR ( int N, double * sampled_data, //input 
							double * psd )	//output
// LKSCMT : Get Power Spectral Density. ref. NR. 13.4
// 
//	array-size of sampled_data : 0, 1,.., N
//	array-size of psd : 0, 1, .. , N/2
// XXX : N, total number of sampled data, MUST be an integer power of 2 (this is not checked for!).
{
	double * pdBuffer = new double[ 2*N ];
	double Wss = 0;	// "window squared and summed"

	// Data Windowing is being used.
	for(int j = 0; j < N; j++){
		double w_j = __data_window(j, N);
		pdBuffer[ 2*j ] = w_j * sampled_data[j];
		pdBuffer[ 2*j + 1 ] = w_j * 0.0;
		
		Wss += N * SQR( w_j ); 
	}

	FFT(pdBuffer - 1, N, 1);	// LKSCMT : In Numerical Recipes Coding Convention, array index starts from 1 instead of 0.
	
	//Except for k = 0 & N/2,
	//	P(k) = 1/Wss * ( |DFT(k)|^2 + |DFT(N-k)|^2 )
	
	psd[0] = 1/Wss * ( SQR( pdBuffer[2*0] ) + SQR( pdBuffer[2*0+1] ) );
	psd[N/2] = 1/Wss * ( SQR( pdBuffer[2*N/2] ) + SQR( pdBuffer[2*N/2+1] ) );
	for(int k = 1; k <= (N/2-1) ; k++)
	{
		psd[k] = 1/Wss *
			( SQR( pdBuffer[2*k] ) + SQR( pdBuffer[2*k+1] )
				+ SQR( pdBuffer[2*(N-k)] ) + SQR( pdBuffer[2*(N-k)+1] ) );
	}

	delete [] pdBuffer;
	
	return;
}

void PSD_Sorensen ( int N, double Tmsr, double * sampled_data, //input 
										double * psd )	//output
// LKSCMT : Get Power Spectral Density. ref. 2004 Rev. Sci. Instrum. Power Spectrum Analysis for Optical Tweezers.
//	P(k) = (dt*|x(k)|)^2 / Tmsr
//  Negative k components are discarded.
//	array-size of sampled_data : 0, 1,.., N
//	array-size of psd : 0, 1, .. , N/2
// XXX : N, total number of sampled data, MUST be an integer power of 2 (this is not checked for!).
{
	double * pdBuffer = new double[ 2*N ];

	//No data windowing
	for(int j = 0; j < N; j++){
		pdBuffer[ 2*j ] = sampled_data[j];
		pdBuffer[ 2*j + 1 ] = 0.0;
	}

	FFT(pdBuffer - 1, N, 1);	// LKSCMT : In Numerical Recipes Coding Convention, array index starts from 1 instead of 0.

	for(int k = 0; k <= (N/2) ; k++ )
	{
		psd[k] = ( SQR( pdBuffer[2*k] ) + SQR( pdBuffer[2*k+1] ) ) * Tmsr /N/N;
	}
	delete [] pdBuffer;
	
	return;
}
