#pragma once
#include <direct.h>
#include <io.h>

class CDirectoryTraverse
{
public:
	CDirectoryTraverse();
	virtual ~CDirectoryTraverse();

	CString m_path;
	CString m_old_path;
	int SetPath(LPCTSTR path);
	int SetFormat(CString prefix, CString postfix);
	int GetFileNo(CString filename);
	CString m_prefix;
	CString m_postfix;

	int m_fileno;
	int FirstFile();
	int PrevFile();
	int NextFile();
	int LastFile();

	long m_find_handle;
	struct _tfinddata_t m_find_data;
	int InitTraverse();
	int Traverse(CString &name, BOOL &is_dir);
	int CloseTraverse();
};