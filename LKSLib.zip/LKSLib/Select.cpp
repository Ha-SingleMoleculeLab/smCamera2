#include "stdafx.h"
#include "LKSLibCommon.h"


//LKSCMT : select function from "Numerical Recipes in C"
//Returns the kth smallest value in the array arr[1..n]. The input array will be rearranged to have this value in location arr[k], with all smaller elements moved to arr[1..k-1] (in arbitrary order) and all larger elements in arr[k+1..n] (also in arbitrary order).

#define SWAP(a,b)	temp=(a); (a)=(b); (b) = temp;
#define ORDER(a,b)	\
{	\
	if ( (a) > (b) )	\
	{	SWAP(a,b)	}	\
}
static double __select(UINT k, UINT n, double arr[])
{
	UINT i, ir, j, l, mid;
	double a, temp;

	l = 1;
	ir = n;
	for ( ;; )
	{
		if ( ir <= l+1 )
		{
			if ( ir == l+1 )
			{
				ORDER( arr[l], arr[ir] )
			}
			return arr[k];
		}
		else
		{
			mid = (l+ir) >> 1 ;
			SWAP(arr[mid], arr[l+1])
			ORDER(arr[l], arr[ir])
			ORDER(arr[l+1], arr[ir])
			ORDER(arr[l], arr[l+1])
			
			i=l+1;
			j=ir;
			a=arr[l+1];
			for ( ;; )
			{
				do i++; while ( arr[i] < a );
				do j--; while ( arr[j] > a );
				if ( j < i ) break;
				SWAP( arr[i], arr[j] )
			}
			arr[l+1]=arr[j];
			arr[j]=a;
			if ( j >= k )	ir=j-1;
			if ( j <= k )	l=i;
		}
	}
}

double Select_Kth_among_N(UINT k, UINT n, double *pArr)
{
	return __select( k, n, pArr-1 );
}

