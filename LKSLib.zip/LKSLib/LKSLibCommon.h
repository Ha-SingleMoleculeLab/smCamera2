#pragma once
#include <math.h>
#include "Time.h"
#include "Log.h"
#include "SharedMemory.h"
#include "FileAndDirectory.h"
#include "DirectoryTraverse.h"
#include "DirectoryDialog.h"
#include "FFT.h"
#include "PID.h"
#include "Select.h"
#include "ScalingHelper.h"
#include "BMP.h"
#include "SVDPolyFitTools.h"
#include "IDLPolyFitTools.h"

enum AXIS_T	{ NULL_AXIS = 0, X_AXIS, Y_AXIS, Z_AXIS, NUM_AXES };

#define MILLISECOND_PER_SECOND	(1000)
#define SECOND_PER_MILLISECOND	(0.001)
#define MILLIVOLT_PER_VOLT	(1000.0)
#define VOLT_PER_MILLIVOLT	(0.001)
#define MICRON_PER_NM	(0.001)
#define NM_PER_MICRON	(1000.0)
#define	MHZ_PER_KHZ		(0.001)
#define	KHZ_PER_MHZ		(1000.0)

#define ZERO_LIKE_VALUE	(1e-10)
#define ZERO_TOLERANCE	(1e-5)

#define SQR(x)	( (x)*(x) )
#define VARIANCE(N, sum, sq_sum)	( ( N > 1 ) ? ( ( (sq_sum) - SQR(sum)/(N) )/((N)-1) ) : 0.0 )
#define STDDEV(N, sum, sq_sum)		( sqrt(VARIANCE(N, sum, sq_sum)) )
#define LIMIT_DECIMAL_PLACES( f, N )	(((int) (f * pow((double)10, N)))*1.0/pow((double)10, N))


#ifndef __DPTR_DEFINED__
#define __DPTR_DEFINED__
typedef double * DPTR;
#endif

#ifndef __UINT8PTR_DEFINED__
#define __UINT8PTR_DEFINED__
typedef UINT8 * UINT8PTR;
#endif