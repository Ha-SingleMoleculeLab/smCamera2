void LinearFit(int n, double *x, double *y, double *yerr, 
				double *a, double *b, double *aerr, double *berr );

#define NUM_COEFFS_POLYFIT2D_IDL3	(16)
double PolyFit2D_IDL3(int N, double *x, double *y, double *f, double *coeff);
double PolyFit2DEstimate_IDL3(double x, double y, double *coeff);