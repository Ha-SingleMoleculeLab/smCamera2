#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "LKSLibCommon.h"

// Linear Fit to y = a + b x
void LinearFit(int n, double *x, double *y, double *yerr, //input
				double *a, double *b, double *aerr, double *berr ) //output
{
	*a = *b = 0.0;

	if ( n <= 0 )	return;
	
	int i;
	double *sig = new double[n];
	double y_mean = 0.0;
	
	for ( i = 0 ; i < n ; i++ )
	{
        if ( yerr )	sig[i] = yerr[i];
		else	sig[i] = 1.0;

		if ( sig[i] == 0.0 )	sig[i] = ZERO_LIKE_VALUE;

		y_mean += y[i];
	}
	y_mean = y_mean/n;
    
	//Accumulate sums
	double wt, sx = 0.0, sy = 0.0, ss = 0.0; 

	for ( i = 0 ; i < n ; i++ )
	{
		wt = 1.0 / SQR(sig[i]) ;
		ss += wt;
		sx += x[i] * wt;
		sy += y[i] * wt;
	}

	double t, st2 = 0.0, sxoss;
	sxoss = sx/ss;
	for ( i = 0 ; i < n ; i++ )
	{
		t = ( x[i] - sxoss ) / sig[i];
		st2 += SQR(t);
		*b += t * y[i] / sig[i];
	}

	//Solve for a, b, aerr, berr
	*b /= st2;
	*a = ( sy - sx * (*b) ) / ss;
	if ( aerr )	*aerr = sqrt( ( 1.0 + SQR(sx) / (ss * st2) ) / ss );
	if ( berr ) *berr = sqrt( 1.0 / st2 );


	double chi2 = 0.0;
	if ( n <= 2 )	return;

	if ( yerr == NULL )
	{		
		double sigdat;
		for ( i = 0 ; i < n ; i++ )
		{
			chi2 += SQR(  y[i] - (*a) - (*b)*x[i] );
		}

		//For unweighted data evaluate typical sig using chi2 
		//	and adjust the standard deviations.
		sigdat = sqrt ( chi2/ (n-2) );
		if ( aerr ) *aerr *= sigdat;
		if ( berr ) *berr *= sigdat;
	}
	else
	{
		for ( i = 0 ; i < n ; i++ )
		{
			chi2 += SQR( ( y[i] - (*a) - (*b)*x[i] )/sig[i] );
		}

	}
	return;
}




#define NRvector( v, i )		( (v)[i-1] )
#define NRmatrix(	m, i, j )	( (m)[i-1][j-1] )

static double maxarg1,maxarg2; 
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ? (maxarg1) : (maxarg2)) 
static int iminarg1,iminarg2; 
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ? (iminarg1) : (iminarg2))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
static double sqrarg; 

#undef SQR
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)


//hypotenuse of a and b. avoiding underflow/overflow using (a * sqrt( 1 + (b/a)^2 ), rather than sqrt(a*a + b*b).
inline static double pythag(const double &a, const double &b)
{
	if (a == 0)	return fabs(b);
	double c = b/a;
	return fabs(a) * sqrt(1 + c*c);
}

// cf. Numerical Recipes in C, 2nd ed, Chapter 2-6 
// SVD(Singular Value Decomposition) of
// M by N matrix A
// A = U S V_T
// U : M by N , orthonormal matrix
// S : N by N , diagonal matrix
// V : N by N , orthonormal matrix, V_T : Transpose(V)
#define MAX_SVDCMP_ITERATION	(30)
static int svdcmp(int M, int N, double **A, double **U, double *W, double **V)
{
	
	double volatile temp;

	int flag,i,its,j,jj,k,l,nm; 
	double anorm,c,f,g,h,s,scale,x,y,z;
	double *rv1 = new double[N];

	for (i=1;i<=M;i++)
	{
		for (j=1;j<=N;j++)
		{
			NRmatrix(U,i,j) = NRmatrix(A,i,j);
		}
	}

	g=scale=anorm=0.0; 

	for (i=1;i<=N;i++) 
	{ 
		l=i+1; 
		NRvector(rv1,i)=scale*g; 
		g=s=scale=0.0; 
		if (i <= M) 
		{ 
			for (k=i;k<=M;k++) scale += fabs(NRmatrix(U,k,i)); 
			if (scale) 
			{ 
				for (k=i;k<=M;k++) 
				{ 
					NRmatrix(U,k,i) /= scale; 
					s += NRmatrix(U,k,i)*NRmatrix(U,k,i); 
				} 
				f=NRmatrix(U,i,i); 
				g = -SIGN(sqrt(s),f); 
				h=f*g-s; 
				NRmatrix(U,i,i)=f-g; 
				for (j=l;j<=N;j++) { 
					for (s=0.0,k=i;k<=M;k++) s += NRmatrix(U,k,i)*NRmatrix(U,k,j); 
					f=s/h; 
					for (k=i;k<=M;k++) NRmatrix(U,k,j) += f*NRmatrix(U,k,i); 
				} 
				for (k=i;k<=M;k++) NRmatrix(U,k,i) *= scale; 
			} 
		} 
		NRvector(W,i)=scale *g; 
		g=s=scale=0.0; 
		if (i <= M && i != N) 
		{ 
			for (k=l;k<=N;k++) scale += fabs(NRmatrix(U,i,k)); 
			if (scale) 
			{
				for (k=l;k<=N;k++) 
				{ 
					NRmatrix(U,i,k) /= scale; 
					s += NRmatrix(U,i,k)*NRmatrix(U,i,k); 
				} 
				f=NRmatrix(U,i,l); 
				g = -SIGN(sqrt(s),f); 
				h=f*g-s; 
				NRmatrix(U,i,l)=f-g; 
				for (k=l;k<=N;k++) NRvector(rv1,k)=NRmatrix(U,i,k)/h; 
				for (j=l;j<=M;j++) 
				{ 
					for (s=0.0,k=l;k<=N;k++) s += NRmatrix(U,j,k)*NRmatrix(U,i,k); 
					for (k=l;k<=N;k++) NRmatrix(U,j,k) += s*NRvector(rv1,k); 
				} 
				for (k=l;k<=N;k++) NRmatrix(U,i,k) *= scale; 
			} 
		} 
		anorm=FMAX(anorm,(fabs(NRvector(W,i))+fabs(NRvector(rv1,i)))); 
	} 
	for (i=N;i>=1;i--) 
	{ 
		if (i < N) 
		{ 
			if (g) 
			{ 
				for (j=l;j<=N;j++) NRmatrix(V,j,i)=(NRmatrix(U,i,j)/NRmatrix(U,i,l))/g; 
				for (j=l;j<=N;j++) 
				{ 
					for (s=0.0,k=l;k<=N;k++) s += NRmatrix(U,i,k)*NRmatrix(V,k,j); 
					for (k=l;k<=N;k++) NRmatrix(V,k,j) += s*NRmatrix(V,k,i); 
				} 
			} 
			for (j=l;j<=N;j++) NRmatrix(V,i,j)=NRmatrix(V,j,i)=0.0; 
		} 
		NRmatrix(V,i,i)=1.0; 
		g=NRvector(rv1,i); 
		l=i; 
	} 
	for (i=IMIN(M,N);i>=1;i--) { 
		l=i+1; 
		g=NRvector(W,i); 
		for (j=l;j<=N;j++) NRmatrix(U,i,j)=0.0; 
		if (g) 
		{ 
			g=1.0/g; 
			for (j=l;j<=N;j++) 
			{ 
				for (s=0.0,k=l;k<=M;k++) s += NRmatrix(U,k,i)*NRmatrix(U,k,j); 
				f=(s/NRmatrix(U,i,i))*g; 
				for (k=i;k<=M;k++) NRmatrix(U,k,j) += f*NRmatrix(U,k,i); 
			} 
			for (j=i;j<=M;j++) NRmatrix(U,j,i) *= g; 
		} else for (j=i;j<=M;j++) NRmatrix(U,j,i)=0.0; 
		++NRmatrix(U,i,i); 
	} 
	for (k=N;k>=1;k--) 
	{ 
		for (its=1;its<=MAX_SVDCMP_ITERATION;its++) 
		{ 
			flag=1; for (l=k;l>=1;l--) 
			{ 
				nm=l-1; 
				
				//LKSCHANGE according to Old Bug Reports at www.nr.com/forum
				//if ((double)(fabs(NRvector(rv1,l))+anorm) == anorm) 
				//{ 
				//	flag=0; 
				//	break; 
				//} 
				//if ((double)(fabs(NRvector(W,nm))+anorm) == anorm) break; 
                temp = fabs(NRvector(rv1,l)) + anorm;
				if ( temp == anorm )
				{ 
					flag=0; 
					break; 
				} 
				temp = fabs(NRvector(W,nm)) + anorm;
				if ( temp == anorm )	break;
				//END of LKSCHANGE
			} 
			if (flag) 
			{ 
				c=0.0;  
				s=1.0; 
				for (i=l;i<=k;i++) 
				{
					f=s*NRvector(rv1,i); 
					NRvector(rv1,i)=c*NRvector(rv1,i); 

					//LKSCHANGE according to Old Bug Reports at www.nr.com/forum
					//if ((double)(fabs(f)+anorm) == anorm) break; 
					temp = fabs(f) + anorm;
					if ( temp == anorm )	break;
					//END of LKSCHANGE

					g=NRvector(W,i); 
					h=pythag(f,g); 
					NRvector(W,i)=h; 
					h=1.0/h; 
					c=g*h; 
					s = -f*h; 
					for (j=1;j<=M;j++) 
					{ 
						y=NRmatrix(U,j,nm); 
						z=NRmatrix(U,j,i); 
						NRmatrix(U,j,nm)=y*c+z*s; 
						NRmatrix(U,j,i)=z*c-y*s; 
					} 
				} 
			} 
			z=NRvector(W,k); 
			if (l == k) 
			{ 
				if (z < 0.0) 
				{ 
					NRvector(W,k) = -z; 
					for (j=1;j<=N;j++) NRmatrix(V,j,k) = -NRmatrix(V,j,k); 
				} 
				break; 
			} 
			if (its == MAX_SVDCMP_ITERATION)
			{
				delete [] rv1;
				return -1;
			}
			x=NRvector(W,l);
			nm=k-1; 
			y=NRvector(W,nm); 
			g=NRvector(rv1,nm); 
			h=NRvector(rv1,k); 
			f=((y-z)*(y+z)+(g-h)*(g+h))/(2.0*h*y); 
			g=pythag(f,1.0); 
			f=((x-z)*(x+z)+h*((y/(f+SIGN(g,f)))-h))/x; 
			c=s=1.0; 
			for (j=l;j<=nm;j++) 
			{ 
				i=j+1; 
				g=NRvector(rv1,i); 
				y=NRvector(W,i); 
				h=s*g;
				g=c*g; 
				z=pythag(f,h); 
				NRvector(rv1,j)=z; 
				c=f/z; 
				s=h/z; 
				f=x*c+g*s; 
				g = g*c-x*s; 
				h=y*s; 
				y *= c; 
				for (jj=1;jj<=N;jj++) 
				{ 
					x=NRmatrix(V,jj,j); 
					z=NRmatrix(V,jj,i); 
					NRmatrix(V,jj,j)=x*c+z*s; 
					NRmatrix(V,jj,i)=z*c-x*s; 
				} 
				z=pythag(f,h); 
				NRvector(W,j)=z;
				if (z) 
				{ 
					z=1.0/z; 
					c=f*z; 
					s=h*z; 
				} 
				f=c*g+s*y; 
				x=c*y-s*g;
				for (jj=1;jj<=M;jj++) 
				{ 
					y=NRmatrix(U,jj,j); 
					z=NRmatrix(U,jj,i); 
					NRmatrix(U,jj,j)=y*c+z*s; 
					NRmatrix(U,jj,i)=z*c-y*s; 
				} 
			} 
			NRvector(rv1,l)=0.0; 
			NRvector(rv1,k)=f; 
			NRvector(W,k)=x; 
		} 
	} 

	delete [] rv1;
	return 0;
} 




//LKSCMT : My own routine for verifying whether svdcmp is working nicely.
// It checks, 
// 1. A = U W V_T
// 2. U_T U = 1
// 3. V_T V = 1
// test1 : maximum error element of the matrix ( U W V_T - A )
// test2 : maximum error element of the matrix ( U_T U - 1 )
// test3 : maximum error element of the matrix ( V_T V - 1 )
static int svdcmp_verify( int M, int N, double **A, double **U, double *W, double **V,
					double *test1, double *test2, double *test3 )
{
	double maxerr = 0.0;
	double *tempN = new double[N];
	double **tempMN = new double*[M];
	double **tempNN = new double*[N];
	for ( int i = 0 ; i < M ; i++ )	tempMN[i] = new double[N];	
	for ( int i = 0 ; i < N ; i++ )	tempNN[i] = new double[N];


	// Test 1.
	maxerr = 0.0;	
	for ( int i = 0 ; i < M ; i++ )
	{
		for ( int j = 0 ; j < N ; j++ )
		{
			tempMN[i][j] = U[i][j] * W[j];
		}
	}
	for ( int i = 0 ; i < M ; i++ )
	{
		for ( int j = 0 ; j < N ; j++ )
		{
			tempN[j] = 0.0;
			for ( int k = 0 ; k < N ; k++ )	tempN[j] += tempMN[i][k] * V[j][k];
		}
		for ( int j = 0 ; j < N ; j++ )
			tempMN[i][j] = tempN[j];
	}

	for ( int i = 0 ; i < M ; i++ )
	{		
		for ( int j = 0 ; j < N ; j++ )
		{
			maxerr = max( maxerr, fabs( tempMN[i][j] - A[i][j] ) );
		}
	}
	if ( test1 )	*test1 = maxerr;


	// Test 2. 
	maxerr = 0.0;
	for ( int i = 0 ; i < N ; i++ )
	{
		for ( int j = 0 ; j < N ; j++ )
		{
			tempNN[i][j] = 0.0;
			for ( int k = 0 ; k < M ; k++ )	tempNN[i][j] += U[k][i] * U[k][j];
		}
	}

	for ( int i = 0 ; i < N ; i++ )
	{
		for ( int j = 0 ; j < N ; j++ )
		{
			if ( i == j ) 
				maxerr = max( maxerr, min( fabs(tempNN[i][j]-1.0), fabs(tempNN[i][j]-0.0) ) );
			else	maxerr = max( maxerr, fabs( tempNN[i][j]-0.0 ) );
		}
	}
	if ( test2 )	*test2 = maxerr;



	// Test 3. 
	maxerr = 0.0;
	for ( int i = 0 ; i < N ; i++ )
	{
		for ( int j = 0 ; j < N ; j++ )
		{
			tempNN[i][j] = 0.0;
			for ( int k = 0 ; k < N ; k++ )	tempNN[i][j] += V[k][i] * V[k][j];
		}
	}
	
	for ( int i = 0 ; i < N ; i++ )
	{
		for ( int j = 0 ; j < N ; j++ )
		{
			maxerr = max( maxerr, fabs( tempNN[i][j] - (( i == j ) ? 1.0 : 0.0 )) );
		}
	}
	if ( test3 )	*test3 = maxerr;

	for ( int i = 0 ; i < M ; i++ )	delete [] tempMN[i];
	for ( int i = 0 ; i < N ; i++ )	delete [] tempNN[i];
	delete [] tempN;
	delete [] tempMN;
	delete [] tempNN;

	return 0;
}


void svdcmp_test(int M, int N, float maximum_absolute_value, int num_try )
{
	double test1, test2, test3;

	double **A = new double*[M];
	double **U = new double*[M];
	double *W = new double[N];
	double **V = new double*[N];
	for ( int i = 0 ; i < M ; i++ )	A[i] = new double[N];
	for ( int i = 0 ; i < M ; i++ )	U[i] = new double[N];
	for ( int i = 0 ; i < N ; i++ )	V[i] = new double[N];

	srand( (unsigned) time( NULL ) );

	for ( int i = 0; i < num_try ; i++ )
	{
		for (int m = 0 ; m < M ; m++ )
		{
			for ( int n = 0 ; n < N ; n++ )
			{
				A[m][n] = maximum_absolute_value * 2 * ( rand() * 1.0/RAND_MAX - 0.5 ) ; 
			}
		}

		svdcmp( M, N, A, U, W, V );
		test1 = test2 = test3 = 0;
		svdcmp_verify( M, N, A, U, W, V, &test1, &test2, &test3 );
		fprintf(stderr, "try[%5d] test1[%3e] test2[%3e] test3[%3e]\n", i+1, test1, test2, test3);
	}

	for ( int i = 0 ; i < M ; i++ )	delete [] A[i];
	for ( int i = 0 ; i < M ; i++ )	delete [] U[i];
	for ( int i = 0 ; i < N ; i++ )	delete [] V[i];
	delete [] A;
	delete [] U;
	delete [] W;
	delete [] V;

	return;
}


//LKSCMT:
//Fixes ill-conditioning by removing small singular values.
//W : Singular value vector to be conditioned.
#define MIN_SVD_CONDITION_NUMBER	(1.0e-5)
void svdcmp_condition(int N, double *W)
{
	int i;
	double max_v = 0.0;
	// Compute magnitudes and find largest
	for(i=1;i<=N;i++)	
	{
		if ( NRvector(W,i) > max_v )	max_v = NRvector(W,i);
	}

	// No non-zero singular values
	if (max_v == 0.0) return; 

	double min_v = MIN_SVD_CONDITION_NUMBER	* max_v;
	for(i=1;i<=N;i++) 
		if ( NRvector(W,i) < min_v )	NRvector(W,i) = 0.0;

	return;
}


//cf. Numerical Recipes in C, 2nd ed, Chapter 2-6
// Solves A X = B	for a vector X
// A : M by N matrix
// X : N by 1 vector
// B : M by 1 vector
// U : M by N matrix
// W : N by 1 vector
// V : N by N matrix
// Procedure :
// A is SVdecomposed by svdcmp() as A = U W V_T
// then X = V [diag(1/W(j))] U_T B
static int svbksb(int M, int N, double **A, double *X, double *B, 
		   double **U, double *W, double **V )
{
	if ( svdcmp( M, N, A, U, W, V ) < 0 )	return -1;
//	svdcmp_condition(N, W);

	double *tempN = new double[N];
	double s;
	
	// tempN = [diag(1/W(j))] U_T B
	for ( int j = 1 ; j <= N ; j++ )
	{
		s = 0.0;
		if ( NRvector(W,j) )	//Nonzero result only if W(j) is nonzero
		{
			for ( int i = 1 ; i <= M ; i++ )	s += NRmatrix(U,i,j)*NRvector(B,i);
			s /= NRvector(W,j);
		}
		NRvector(tempN, j) = s;
	}

	// X = V tempN
	for ( int i = 1 ; i <= N ; i++ )
	{
		s = 0.0;
		for ( int j = 1 ; j <= N ; j++ )	s += NRmatrix(V,i,j)*NRvector(tempN,j);
		NRvector(X,i) = s;
	}
	delete [] tempN;
	return 0;
}


//cf. Numerical Recipes in C, 2nd ed, Chapter 15-4 & 15-1
// Chi-Square Fit
// Given a set of data points, 
//	x[0..ndata-1], y[0..ndata-1] -> f[0..ndata-1], sigma[0..ndata-1]
// Use Chi Square minimization to determine the coeffs of the fitting function
// f = f(x,y) = SUM(i=1..nterms) [ coeffs(i) * (i)th_term(x,y) ]
// To solve Chi-Square minimization, Singular Value Decomposition is used.

// ndata : # of data points
// x,y,f,sigma : ndata by 1 vector. 
// nterms : # of terms in the fit function
// coeffs : nterms by 1 vector. coeffs for each terms in the fit function
// cvm : nterms by nterms matrix. covariance matrix of the fit coeffs.
// return : Chi-Square value.

static double svdfit(int ndata, double *x, double *y, double *f, double *sigma,  
			int nterms, void (*basis_func)(double x, double y, double *terms),
			double *coeffs, double **cvm )
{
	double **A = new double*[ndata];
	double **U = new double*[ndata];
	double *W = new double[nterms];
	double **V = new double*[nterms];
	for ( int i = 0 ; i < ndata ; i++ )		A[i] = new double[nterms];
	for ( int i = 0 ; i < ndata ; i++ )		U[i] = new double[nterms];
	for ( int i = 0 ; i < nterms ; i++ )	V[i] = new double[nterms];

	double *B = new double[ndata];
	double *terms = new double[nterms];

	double chisq = -1.0;
	double sigma0;
	double sigma_inverse;

	double tempx, tempy;
	for ( int i = 1 ; i <= ndata ; i++ )
	{
		tempx = tempy = 0.0;
		if ( x )	tempx = NRvector(x,i);
		if ( y )	tempy = NRvector(y,i);
		basis_func( tempx, tempy, terms );

		//If sigma is given, assume sigma[1..ndata] = sigma0 = 1.0
		sigma_inverse = ( sigma ) ? ( sigma_inverse = 1.0 / NRvector(sigma,i) ) : 1.0;

		for ( int j = 1 ; j <= nterms ; j++ )	NRmatrix(U,i,j) = NRvector(terms,j) * sigma_inverse;
		NRvector(B,i) = NRvector(f,i) * sigma_inverse;
	}

	if ( !coeffs )	goto FAIL;

	// Get SVD for A(=U) -> U, W, V
	// Solve A X = B for X(=coeffs)
	if ( svbksb(ndata, nterms, U, coeffs, B, U, W, V ) < 0 )	goto FAIL;


	// If sigma is not given, assume sigma[1..ndata] = sigma0.
	// Estimate sigma0.
	// SQR( sigma0 )  = SUM(i=1..ndata)[ f(i) - f0(i) ] / ( ndata - nterms )

	double f0;
	if ( sigma == NULL && ndata > nterms )
	{		
		sigma0 = 0.0;

		for ( int i = 1 ; i <= ndata ; i++ )
		{
			tempx = tempy = 0.0;
			if ( x )	tempx = NRvector(x,i);
			if ( y )	tempy = NRvector(y,i);
			basis_func( tempx, tempy, terms );

			f0 = 0.0;		
			for ( int j = 1 ; j <= nterms ; j++ )	f0 += NRvector(coeffs,j) * NRvector(terms,j);

			sigma0 += SQR( NRvector(f,i) - f0 );
		}
		sigma0 = sqrt( sigma0 / (ndata-nterms) );

		for ( int i = 1 ; i <= nterms ; i++ )	NRvector(W,i) = NRvector(W,i)/sigma0;
	}

	// Evaluate the covariance matrix cvm[1..nterms][1..nterms]
	if ( cvm ) 
	{
		for ( int i = 1 ; i <= nterms ; i++ )
		{
			NRvector(terms,i) = 0.0;
			if ( NRvector(W,i) )	NRvector(terms,i) = 1.0/(NRvector(W,i)*NRvector(W,i));
		}
		for ( int i = 1 ; i <= nterms ; i++ )
		{
			for ( int j = 1 ; j <= i ; j++ )
			{
				double sum = 0.0;
				for ( int k = 1 ; k <= nterms ; k++ )	sum += NRmatrix(V,i,k) * NRmatrix(V,j,k) * NRvector(terms,k);
				NRmatrix(cvm,j,i) = NRmatrix(cvm,i,j) = sum;
			}
		}
	}

	// Evaluate chi-square
	chisq = 0.0;
	sigma0 = 1.0;

	for ( int i = 1 ; i <= ndata ; i++ )
	{
		tempx = tempy = 0.0;
		if ( x )	tempx = NRvector(x,i);
		if ( y )	tempy = NRvector(y,i);
		basis_func( tempx, tempy, terms );

		f0 = 0.0;
		for ( int j = 1 ; j <= nterms ; j++ )	f0 += NRvector(coeffs,j) * NRvector(terms,j);
		chisq += ( sigma ) ? SQR( (NRvector(f,i)-f0)/NRvector(sigma,i) ) : SQR( (NRvector(f,i)-f0)/sigma0 ) ;
	}

FAIL:
	delete [] B;
	delete [] terms;

	for ( int i = 0 ; i < ndata ; i++ )		delete [] A[i];
	for ( int i = 0 ; i < ndata ; i++ )		delete [] U[i];
	for ( int i = 0 ; i < nterms ; i++ )	delete [] V[i];
	delete [] A;
	delete [] U;
	delete [] W;
	delete [] V;

	return chisq;
}



/*
static void IDLPoly3_Basis(double x, double y, double *terms)
{
	for ( int i = 0 ; i < 4 ; i++ )
	{
		for ( int j = 0 ; j < 4 ; j++ )
		{
			terms[4*i+j] = pow(x,j) * pow(y,i);
		}
	}
}
double* IDLPoly3_Fit(int N, double *x, double *y, double *f)
{
	double *ret = new double[16];

	fprintf(stderr, "chisq[%f]\n", 
	svdfit( N, x, y, f, NULL, 16, IDLPoly3_Basis, ret, NULL ) );
	return ret;
}
*/


static void __PolyFit2D_IDL3_Basis(double x, double y, double *terms)
{
	for ( int i = 0 ; i < 4 ; i++ )
		for ( int j = 0 ; j < 4 ; j++ )
			terms[4*i+j] = pow(x,j) * pow(y,i);
}

double PolyFit2D_IDL3(int N, double *x, double *y, double *f, double *coeff)
{
	return svdfit( N, x, y, f, NULL, NUM_COEFFS_POLYFIT2D_IDL3, __PolyFit2D_IDL3_Basis, coeff, NULL );
}

double PolyFit2DEstimate_IDL3(double x, double y, double *coeff)
{
	static double terms[NUM_COEFFS_POLYFIT2D_IDL3];
	double result = 0.0;
	__PolyFit2D_IDL3_Basis( x, y, terms );
	for ( int i = 0 ; i < NUM_COEFFS_POLYFIT2D_IDL3 ; i++ )
	{
		result += coeff[i] * terms[i];
	}
	return result;
}