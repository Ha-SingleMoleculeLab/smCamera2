LPCTSTR Stringify(LPCTSTR format, ... );

void LogOpen(CView *view, CEdit *edit, CStatusBar *status);
void LogFlush();
void LogClose();
void LogMessage(int line, LPCTSTR function, LPCTSTR file, LPCTSTR category, LPCTSTR msg );


#define LogMsg( category, msg )	\
	LogMessage(__LINE__, __FUNCTION__, __FILE__, category, msg )

#define LogNotice( msg )	\
{	\
	AfxMessageBox( msg, MB_ICONWARNING);	\
	LogMsg( _T("Notice"), msg );	\
}

#define LogErr( msg )	\
{	\
	AfxMessageBox( msg, MB_ICONERROR);	\
	LogMsg( _T("Error"), msg );	\
}

#define LogException( pEx, msg )	\
{	\
	TCHAR	szCause[255];	\
	CString strFormatted;	\
	(pEx)->GetErrorMessage(szCause, 255);	\
	strFormatted.Format(_T("%s: %s"), msg, szCause);	\
	AfxMessageBox( strFormatted, MB_ICONERROR );	\
	LogMsg( _T("Exception"), strFormatted );	\
}