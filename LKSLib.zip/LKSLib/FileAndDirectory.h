BOOL DoesProgramDirectoryExist ( LPCTSTR path);
void RemoveProgramDirectory( LPCTSTR path );
BOOL MakeProgramDirectory( LPCTSTR path );

LPCTSTR GetProgramFilePath ( LPCTSTR dir, LPCTSTR filename );
BOOL DoesProgramFileExist ( LPCTSTR filepath, CFileStatus *status = NULL );
void RemoveProgramFile( LPCTSTR filepath );
CArchive * OpenProgramFileToRead ( LPCTSTR filepath );
CArchive * OpenProgramFileToWrite ( LPCTSTR filepath, BOOL do_backup=FALSE );
CArchive * OpenProgramFileToAppend ( LPCTSTR filepath );
CArchive * OpenProgramFileForBufferedWriting ( LPCTSTR filepath, int nBufSize, void *lpBuf=NULL );
void CloseProgramFile ( CArchive *ar );
void BackupProgramFile ( LPCTSTR filepath );
void RenameProgramFile ( LPCTSTR srcpath, LPCTSTR destpath, BOOL do_backup=FALSE );