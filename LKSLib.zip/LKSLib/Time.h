BOOL InitProgramTimer();
double GetProgramTime();
INT64 GetProgramTimeInTicks();
double ProgramTime_Tick2Second(INT64 tick);
INT64 ProgramTime_Second2Tick(double time);