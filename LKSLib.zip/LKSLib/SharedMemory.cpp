#include "stdafx.h"
#include "SharedMemory.h"
#include "Log.h"

CSharedMemory::CSharedMemory()
{
	hMapFile = NULL;
	pHeader = NULL;
	pBuffer = NULL;

	creater = FALSE;
}

CSharedMemory::~CSharedMemory()
{
	Close();
}

int CSharedMemory::Create(LPCTSTR name, UINT32 size)
{
	CString FileMappingObjectName;
	FileMappingObjectName.Format(_T("Global\\%s"), name);
	
	hMapFile = CreateFileMapping(
						INVALID_HANDLE_VALUE,    // use paging file
						NULL,                    // default security 
						PAGE_READWRITE,          // read/write access
						0,                       // 
						sizeof(CSharedMemoryHeader) + size * sizeof(BYTE),	// buffer size  
						FileMappingObjectName	);	              // name of mapping object
 
	if (hMapFile == NULL)
	{	
		
		LogMsg(_T("Error"), Stringify( _T("CreateFileMapping Failed [%d]."), GetLastError()) );
		Close();
        return -1;
	}

	pHeader = (CSharedMemoryHeader *) MapViewOfFile(
						hMapFile,   // handle to map object
						FILE_MAP_ALL_ACCESS, // read/write permission
						0,                   
						0,                   
						sizeof(CSharedMemoryHeader) + size * sizeof(BYTE));

	if (pHeader == NULL) 
	{
		
		LogMsg( _T("Error"), Stringify(_T("MapViewOfFile Failed [%d]."), GetLastError()) );
		Close();
        return -1;
	}
	memset(pHeader, 0, sizeof(CSharedMemoryHeader) + size * sizeof(BYTE));

	pHeader->valid = TRUE;
	pHeader->size = size;
	pBuffer = (BYTE *) pHeader + sizeof(CSharedMemoryHeader);

	creater = TRUE;
	return 0;
}


int CSharedMemory::Open(LPCTSTR name)
{
	if ( creater )	return -1;

	CString FileMappingObjectName;
	FileMappingObjectName.Format(_T("Global\\%s"), name);

	hMapFile = OpenFileMapping(
						FILE_MAP_ALL_ACCESS,	// read/write access
						FALSE,					// do not inherit the name
						FileMappingObjectName); // name of mapping object 

	if (hMapFile == NULL) 
	{
	//	LogErr( Stringify(_T("OpenFileMapping Failed [%d]."), GetLastError()) );
		Close();
		return -1;
	}

	pHeader = (CSharedMemoryHeader *) MapViewOfFile(
						hMapFile,   // handle to map object
						FILE_MAP_ALL_ACCESS, // read/write permission
						0,                   
						0,                   
						sizeof(CSharedMemoryHeader));
	if (pHeader == NULL) 
	{ 
	//	LogErr( Stringify(_T("MapViewOfFile Failed [%d]."), GetLastError()) );
		Close();
		return -1;
	}
	if (pHeader->valid != TRUE)
	{
		LogErr(_T("This shared memory is deleted by the creater, and is not valid any more."));
		Close();
		return -1;
	}

	UINT32 size = pHeader->size;
	UnmapViewOfFile(pHeader);

	pHeader = (CSharedMemoryHeader *) MapViewOfFile(
						hMapFile,   // handle to map object
						FILE_MAP_ALL_ACCESS, // read/write permission
						0,                   
						0,                   
						sizeof(CSharedMemoryHeader) + size * sizeof(BYTE));
	if (pHeader == NULL) 
	{ 
	//	LogErr( Stringify(_T("MapViewOfFile Failed [%d]."), GetLastError()) );
		Close();
		return -1;
	}

	pBuffer = (BYTE *) pHeader + sizeof(CSharedMemoryHeader);
	return 0;
}

int CSharedMemory::Close()
{
	if ( creater )
	{
		if ( pHeader )	pHeader->valid = FALSE;
	}

	if ( pHeader )	UnmapViewOfFile(pHeader);
	pHeader = NULL;
	pBuffer = NULL;
	if ( hMapFile )	CloseHandle(hMapFile);
	hMapFile = NULL;

	creater = FALSE;
	return 0;
}