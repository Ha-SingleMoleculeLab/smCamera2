
/******************************* For Polynomical Fitting ***************************/



// 1D Polynomial Fit 
// f = a[0] + a[1] x + a[2] x^2 + a[3] x^3 + ...
#define NUM_COEFFS_FOR_POLYFIT1	(2)
#define NUM_COEFFS_FOR_POLYFIT2	(3)
#define NUM_COEFFS_FOR_POLYFIT3	(4)
void PolyFit1(const int N, const double *x, const double *f, double *a);
double PolyFit1Estimate(double x, double *a);
void PolyFit2(const int N, const double *x, const double *f, double *a);
double PolyFit2Estimate(double x, double *a);
void PolyFit3(const int N, const double *x, const double *f, double *a);
double PolyFit3Estimate(double x, double *a);



// 2D Polynomial Fit

#define NUM_COEFFS_FOR_POLYFIT2D1	(3)
// 2nd order 2D Polynomial Fit
// f = a[0] + a[1] x + a[2] y + a[3] x^2 + a[4] xy + a[5] y^2
#define NUM_COEFFS_FOR_POLYFIT2D2	(6)
// 5th order 2D Polynomial Fit
// f = a[0] + a[1] x + a[2] y + a[3] x^2 + a[4] xy + a[5] y^2 ... + a[20] y^5
#define NUM_COEFFS_FOR_POLYFIT2D5	(21)


void PolyFit2D1(const int N, const int *index, 
				const double *x, const double *y, const double *f, double *a);
void PolyFit2D1(const int N, const double *x, const double *y, const double *f, double *a);
double& PolyFit2D1Coeff(double *a, int x_index, int y_index);
double PolyFit2D1Estimate(double x, double y, double *a);
LPCTSTR PolyFit2D1Text(LPCSTR Z, LPCSTR X, LPCSTR Y, double *a);

void PolyFit2D2(const int N, const int *index, 
				const double *x, const double *y, const double *f, double *a);
void PolyFit2D2(const int N, const double *x, const double *y, const double *f, double *a);
double& PolyFit2D2Coeff(double *a, int x_index, int y_index);
double PolyFit2D2Estimate(double x, double y, double *a);
LPCTSTR PolyFit2D2Text(LPCSTR Z, LPCSTR X, LPCSTR Y, double *a);


void PolyFit2D5(const int N, const int *index, 
				const double *x, const double *y, const double *f, double *a);
void PolyFit2D5(const int N, const double *x, const double *y, const double *f, double *a);
double& PolyFit2D5Coeff(double *a, int x_index, int y_index);
double PolyFit2D5Estimate(double x, double y, double *a);
//double PolyFit2D5LinearEstimate(double x, double y, double *a);
LPCTSTR PolyFit2D5Text(LPCSTR Z, LPCSTR X, LPCSTR Y, double *a);