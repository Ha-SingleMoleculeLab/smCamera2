#include "stdafx.h"
#include <math.h>
#include "SVDPolyFit.h"

// for singular value decomposition
#include "tnt/tnt.h" 
#include "tnt/jama_svd.h" 


#define NRvector( v, i )		( (v)[i-1] )
#define NRmatrix( m, i, j )	( (m)[i-1][j-1] )
#define SQR(a) ((a)*(a))

// cf. Numerical Recipes in C, 2nd ed, Chapter 2-6 
// SVD(Singular Value Decomposition) of
// M by N matrix A
// A = U W V_T
// U : M by N , orthonormal matrix
// W : N by N , diagonal matrix
// V : N by N , orthonormal matrix, V_T : Transpose(V)
static int svdcmp(int M, int N, Array2D<double> &A, Array2D<double> &U, Array2D<double> &W, Array2D<double> &V )
{
	using JAMA::SVD;

	SVD<double> svd(A);
	svd.getU(U);
	svd.getS(W);
	svd.getV(V);
	
	return 0;
}

//cf. Numerical Recipes in C, 2nd ed, Chapter 2-6
// Solves A X = B	for a vector X
// A : M by N matrix
// X : N by 1 vector
// B : M by 1 vector
// U : M by N matrix
// W : N by 1 vector
// V : N by N matrix
// Procedure :
// A is SVdecomposed by svdcmp() as A = U W V_T
// then X = V [diag(1/W(j))] U_T B
static int svbksb(int M, int N, Array2D<double> &A, double *X, double *B, 
		   Array2D<double> &U, Array2D<double> &W, Array2D<double> &V )
{
	if ( svdcmp( M, N, A, U, W, V ) < 0 )	return -1;

	double *tempN = new double[N];
	double s;
	
	// tempN = [diag(1/W(j))] U_T B
	for ( int j = 1 ; j <= N ; j++ )
	{
		s = 0.0;
		if ( NRmatrix(W,j,j) )	//Nonzero result only if W(j,j) is nonzero
		{
			for ( int i = 1 ; i <= M ; i++ )	s += NRmatrix(U,i,j)*NRvector(B,i);
			s /= NRmatrix(W,j,j);
		}
		NRvector(tempN, j) = s;
	}

	// X = V tempN
	for ( int i = 1 ; i <= N ; i++ )
	{
		s = 0.0;
		for ( int j = 1 ; j <= N ; j++ )	s += NRmatrix(V,i,j)*NRvector(tempN,j);
		NRvector(X,i) = s;
	}
	delete [] tempN;
	return 0;
}


//cf. Numerical Recipes in C, 2nd ed, Chapter 15-4 & 15-1
// Chi-Square Fit
// Given a set of data points, 
//	x[0..ndata-1], y[0..ndata-1] -> f[0..ndata-1], sigma[0..ndata-1]
// Use Chi Square minimization to determine the coeffs of the fitting function
// f = f(x,y) = SUM(i=1..nterms) [ coeffs(i) * (i)th_term(x,y) ]
// To solve Chi-Square minimization, Singular Value Decomposition is used.

// ndata : # of data points
// index : a list of index 
// x,y,f,sigma : data to be fitted
// nterms : # of terms in the fit function
// coeffs : nterms by 1 vector. coeffs for each terms in the fit function
// cvm : nterms by nterms matrix. covariance matrix of the fit coeffs.
// return : Chi-Square value.

double svdfit(int ndata, const int *index, 
			  const double *x, const double *y, const double *f, const double *sigma,  
			int nterms, void (*basis_func)(double x, double y, double *terms),
			double *coeffs, double **cvm )
{
	Array2D<double> A(ndata, nterms);
	Array2D<double> U(ndata, nterms);
	Array2D<double> W(nterms, nterms);
	Array2D<double> V(nterms, nterms);

	double *B = new double[ndata];
	double *terms = new double[nterms];

	double chisq = -1.0;
	double sigma0;
	double sigma_inverse;

	double tempx, tempy;
	for ( int i = 1 ; i <= ndata ; i++ )
	{
		tempx = tempy = 0.0;
		if ( x )	tempx = x[NRvector(index,i)];
		if ( y )	tempy = y[NRvector(index,i)];
		basis_func( tempx, tempy, terms );

		//If sigma is given, assume sigma[1..ndata] = sigma0 = 1.0
		sigma_inverse = ( sigma ) ? ( 1.0 / sigma[NRvector(index,i)]) : 1.0;

		for ( int j = 1 ; j <= nterms ; j++ )	NRmatrix(A,i,j) = NRvector(terms,j) * sigma_inverse;
		NRvector(B,i) = f[NRvector(index,i)] * sigma_inverse;
	}

	if ( !coeffs )	goto FAIL;

	// Get SVD for A -> U, W, V
	// Solve A X = B for X(=coeffs)
	if ( svbksb(ndata, nterms, A, coeffs, B, U, W, V ) < 0 )	goto FAIL;


	// If sigma is not given, assume sigma[1..ndata] = sigma0.
	// Estimate sigma0.
	// SQR( sigma0 )  = SUM(i=1..ndata)[ f(i) - f0(i) ] / ( ndata - nterms )

	double f0;
	if ( sigma == NULL && ndata > nterms )
	{		
		sigma0 = 0.0;

		for ( int i = 1 ; i <= ndata ; i++ )
		{
			tempx = tempy = 0.0;
			if ( x )	tempx = x[NRvector(index,i)];
			if ( y )	tempy = y[NRvector(index,i)];
			basis_func( tempx, tempy, terms );

			f0 = 0.0;		
			for ( int j = 1 ; j <= nterms ; j++ )	f0 += NRvector(coeffs,j) * NRvector(terms,j);

			sigma0 += SQR( f[NRvector(index,i)] - f0 );
		}
		sigma0 = sqrt( sigma0 / (ndata-nterms) );

		for ( int i = 1 ; i <= nterms ; i++ )	NRmatrix(W,i,i) = NRmatrix(W,i,i)/sigma0;
	}

	// Evaluate the covariance matrix cvm[1..nterms][1..nterms]
	if ( cvm ) 
	{
		for ( int i = 1 ; i <= nterms ; i++ )
		{
			NRvector(terms,i) = 0.0;
			if ( NRmatrix(W,i,i) )	NRvector(terms,i) = 1.0/SQR(NRmatrix(W,i,i));
		}
		for ( int i = 1 ; i <= nterms ; i++ )
		{
			for ( int j = 1 ; j <= i ; j++ )
			{
				double sum = 0.0;
				for ( int k = 1 ; k <= nterms ; k++ )	sum += NRmatrix(V,i,k) * NRmatrix(V,j,k) * NRvector(terms,k);
				NRmatrix(cvm,j,i) = NRmatrix(cvm,i,j) = sum;
			}
		}
	}

	// Evaluate chi-square
	chisq = 0.0;
	sigma0 = 1.0;

	for ( int i = 1 ; i <= ndata ; i++ )
	{
		tempx = tempy = 0.0;
		if ( x )	tempx = x[NRvector(index,i)];
		if ( y )	tempy = y[NRvector(index,i)];
		basis_func( tempx, tempy, terms );

		f0 = 0.0;
		for ( int j = 1 ; j <= nterms ; j++ )	f0 += NRvector(coeffs,j) * NRvector(terms,j);
		chisq += ( sigma ) ? SQR( (f[NRvector(index,i)]-f0)/sigma[NRvector(index,i)] ) : SQR( (f[NRvector(index,i)]-f0)/sigma0 ) ;
	}

FAIL:
	delete [] B;
	delete [] terms;

	return chisq;
}



double svdfit(int ndata, const double *x, const double *y, const double *f, const double *sigma,  
			int nterms, void (*basis_func)(double x, double y, double *terms),
			double *coeffs, double **cvm )
{
	int *index = new int[ndata];
	for ( int i = 0 ; i < ndata ; i++ )	index[i] = i;

	double chisq = svdfit(ndata, index, x, y, f, sigma, nterms, basis_func, coeffs, cvm);
	delete [] index;
	return chisq;
}