double Select_Kth_among_N(UINT k, UINT n, double *pArr);
