#pragma once

class CLocalSharedMemoryHeader
{
public:
    BOOL valid;
	UINT32 size;
};

class CLocalSharedMemory
{
public:
	CLocalSharedMemory();
	virtual ~CLocalSharedMemory();

	
	CLocalSharedMemoryHeader *pHeader;
	BYTE *pBuffer;

	BOOL creater;
	BOOL created;
	int Create(LPCTSTR name, UINT32 size);


	int Open(LPCTSTR name);
	LPCTSTR shmem_name;
	
	int Close();
};