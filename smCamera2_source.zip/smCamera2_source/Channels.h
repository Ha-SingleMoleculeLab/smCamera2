#pragma once

enum { CH1 = 0, CH2 = 1, NUM_CHANNELS = 2 };
class CChannels
{
public:
	CChannels()
		{
			w = h = 0 ;
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
				l[i] = r[i] = 0;
		}

	CChannels( UINT fullw, UINT fullh )
		{
			w = fullw / (UINT)NUM_CHANNELS ;
			h = fullh ;

			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				l[i] = (UINT)( (i-CH1+1) * fullw / NUM_CHANNELS ) - w ;
				r[i] = l[i] + w - 1 ;
			}
		}

	UINT w;
	UINT h;
	UINT l[NUM_CHANNELS];
	UINT r[NUM_CHANNELS];
};