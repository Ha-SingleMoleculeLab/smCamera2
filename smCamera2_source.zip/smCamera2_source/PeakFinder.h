#pragma once
#include "afxtempl.h"

#include "Peaks.h"


class CPeakFinder
{
public:
	CPeakFinder();
	virtual ~CPeakFinder();

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	double	m_radius;
	double	m_threshold;

	double	*m_data;
	double	*m_frame;
	double	*m_bgnd;

	UINT16	*m_2bdata;
	UINT16	*m_found;

	CArray<CPeak> m_peaks;
	CArray<CPeak> m_not_peaks;

	void Reset();
	void Clear();
	int	SetFrame(UINT16 w, UINT16 h, double *frame, UINT32 bgnd, UINT32 scaler);    
	int	UpdateFrame(UINT16 w, UINT16 h, double *frame);

	inline double& Frame(UINT x, UINT y)		
		{	return m_frame[m_frame_w*y+x];	}
	inline double& Background(UINT x, UINT y)
		{	return m_bgnd[m_frame_w*y+x];	}
	inline UINT16& PeakFound(UINT x, UINT y)	
		{	return m_found[m_frame_w*y+x] ;	}

	inline UINT8 Pixel2Byte(double val, double min=-1, double max=-1)	
		{
			if ( min < 0 )	min = m_background;
			if ( max < 0 )	max = min + m_data_scaler;
			int byte = (int) (255 * ( val-min ) / ( max-min ));
			return ( byte < 0 ) ? 0 : ( ( byte >= 255 ) ? 255 : (UINT8)byte ) ;
		}
	inline double Byte2Pixel(int byte, double min=-1, double max=-1)
		{
			if ( min < 0 )	min = m_background;
			if ( max < 0 )	max = min + m_data_scaler;
			return ( byte < 0 ) ? min : ( ( byte >= 255 ) ? max : (min + (max-min) * byte * 1.0 / 255) );
		}
	
	void SetRadius(double r)		{	m_radius = ( r > 0 ) ?  r : -1.0 ;	}
	void SetThreshold(double th)	{	m_threshold = ( th > 0 ) ? th : -1.0 ; }


	void MakeBackground(UINT xfrom, UINT yfrom, UINT area_w, UINT area_h);
	void MakeBackground(int id)
		{
			CChannels ch(m_frame_w, m_frame_h);
			MakeBackground(ch.l[id], 0, ch.w, ch.h);
		}

	int MarkPeakPosition(CPeak *peak);
	int MarkNotPeakPosition(UINT x, UINT y);
	int SearchPeakAt(UINT x, UINT y, int l, int r, int b, int t, CPeak *peak = NULL);	

	int FindPeaks(UINT xfrom, UINT yfrom, UINT area_w, UINT area_h);
	int FindPeaks(int id)
		{
			CChannels ch(m_frame_w, m_frame_h);
			return FindPeaks(ch.l[id], 0, ch.w, ch.h);
		}
	int FindNotPeaks(UINT xfrom, UINT yfrom, UINT area_w, UINT area_h);
	int FindNotPeaks(int id)
		{
			CChannels ch(m_frame_w, m_frame_h);
			return FindNotPeaks(ch.l[id], 0, ch.w, ch.h);
		}

	int DrawFrame(UINT16 w, UINT16 h, COLORREF *display);
	int DrawBgndSubFrame(UINT16 w, UINT16 h, COLORREF *display);
	int DrawFrameAndPeaks(UINT16 w, UINT16 h, COLORREF *display);
	int DrawFrameAndNotPeaks(UINT16 w, UINT16 h, COLORREF *display);

	int SaveSnapshot(LPCTSTR filepath, LPCTSTR postfix=_T(""));
};