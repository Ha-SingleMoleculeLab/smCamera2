#pragma once
#include "CameraFile.h"
#include "Mapping.h"
#include "PeakFinder.h"

// CMovieMapperDialog dialog

class CMovieMapperDialog : public CDialog
{
	DECLARE_DYNAMIC(CMovieMapperDialog)

public:
	CMovieMapperDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMovieMapperDialog();

// Dialog Data
	enum { IDD = IDD_MAPPER };

protected:
    virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support


	DECLARE_MESSAGE_MAP()
public:
	CDirectoryTraverse m_directory;

	CSliderCtrl m_slider[NUM_CHANNELS];
	CString m_filepath[NUM_CHANNELS];
	CFilm *m_film[NUM_CHANNELS];

	int OpenFile(int ch, LPCSTR filepath=NULL);
	int CloseFile(int ch);
	int LoadFrameSequence(int ch);
	int ApplyFrameSequence(int ch);
	int Copy(int ch);
	int Superpose(int ch);

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	COLORREF *m_frame_buffer;
	COLORREF *m_channel_buffer[NUM_CHANNELS];
	CBitmap	*m_bitmap[NUM_CHANNELS];		
	double * m_backup_frame[NUM_CHANNELS];

	CStatic m_image[NUM_CHANNELS];
	int m_image_left[NUM_CHANNELS];
	int m_image_top[NUM_CHANNELS];
	int m_image_height[NUM_CHANNELS];
	int m_image_width[NUM_CHANNELS];

	int m_spot_radius;
	CStatic m_spot[NUM_CHANNELS];
	int m_spot_left[NUM_CHANNELS];
	int m_spot_top[NUM_CHANNELS];
	int m_spot_height[NUM_CHANNELS];
	int m_spot_width[NUM_CHANNELS];

	void InitFrame(UINT w, UINT h);
	void UpdateFrame();
	void FreeFrame();


	CPoint *m_ppair[NUM_CHANNELS];
	BOOL GetChannelCoordinate(int ch, CPoint pt, int *x, int *y);
	void DrawCircle(CDC &dcMem, int x, int y, int r, COLORREF color);
    void DrawPointPairs(CClientDC &dcDlg, CDC dcMem[NUM_CHANNELS], CPoint pair[NUM_CHANNELS]);

	CString m_fspath[NUM_CHANNELS];
	CFrameSequence m_fs[NUM_CHANNELS];
	BOOL m_copy[NUM_CHANNELS];
	BOOL m_superpose[NUM_CHANNELS];
	CMapping m_superpose_mapping[NUM_CHANNELS];
	double m_peak_radius[NUM_CHANNELS];
	double m_peak_threshold[NUM_CHANNELS];
	CPeakFinder m_peak_finder[NUM_CHANNELS];

	BOOL m_allow_bad_peaks1;
	BOOL m_allow_bad_peaks2;
	BOOL m_use_old_map;
	CMapping m_old_mapping;
	BOOL m_use_rough_map;
	CMapping m_rough_mapping;
	CButton m_pair1_radio;
	CButton m_pair2_radio;
	CButton m_pair3_radio;
	CPoint m_pair1[NUM_CHANNELS];
	CPoint m_pair2[NUM_CHANNELS];
	CPoint m_pair3[NUM_CHANNELS];
	double m_allowable_error;
	CArray<CPeakSet> m_peaks;
	CMapping m_new_mapping;



	void SetUIs();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	afx_msg void OnBnClickedOpen1();
	afx_msg void OnBnClickedClose1();
	afx_msg void OnBnClickedOpen2();
	afx_msg void OnBnClickedClose2();

	afx_msg void OnBnClickedLoadFsCh1();
	afx_msg void OnBnClickedApplyFsCh1();
	afx_msg void OnBnClickedLoadFsCh2();
	afx_msg void OnBnClickedApplyFsCh2();

	afx_msg void OnBnClickedCopy1();
	afx_msg void OnBnClickedSuperpose1();
	afx_msg void OnBnClickedSuperposeMap1();
	afx_msg void OnEnKillfocusPeakRadius1();
	afx_msg void OnEnKillfocusPeakThreshold1();
	afx_msg void OnBnClickedFind1();
	afx_msg void OnBnClickedBGFind1();
	afx_msg void OnBnClickedCopy2();
	afx_msg void OnBnClickedSuperpose2();
	afx_msg void OnBnClickedSuperposeMap2();
	afx_msg void OnEnKillfocusPeakRadius2();
	afx_msg void OnEnKillfocusPeakThreshold2();
	afx_msg void OnBnClickedFind2();
	afx_msg void OnBnClickedBGFind2();

	afx_msg void OnBnClickedBadPeaks1();
	afx_msg void OnBnClickedBadPeaks2();
	afx_msg void OnBnClickedUseMap();
	afx_msg void OnBnClickedOldMap();
	afx_msg void OnBnClickedUseRoughMap();
	afx_msg void OnBnClickedPair1();
	afx_msg void OnBnClickedPair2();
	afx_msg void OnBnClickedPair3();
	afx_msg void OnEnKillfocusAllowableError();
	afx_msg void OnBnClickedMap();
	afx_msg void OnBnClickedSave();

	afx_msg void OnDeltaposSpinr1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinr2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinx1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinx2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny2(NMHDR *pNMHDR, LRESULT *pResult);
};