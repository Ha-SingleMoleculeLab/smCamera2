// CAQ.h : header file
#pragma once

#define CAQ_SHMEM_NAME		_T("CAQ")

enum { CAQ_CH1 = 0, CAQ_CH2 = 1, NUM_CAQ_CHANNELS = 2 }; //donor and acceptor channels. 
//for more than two colors, this would have to change. For odd numbered channel counts as in three color FRET the code below would need to be modified, I think.
class CCAQChannels
{
public:
	CCAQChannels()
		{
			w = h = 0 ;
			for ( int i = CAQ_CH1 ; i < NUM_CAQ_CHANNELS ; i++ )
				l[i] = r[i] = 0;
		}

	CCAQChannels( UINT fullw, UINT fullh )
		{
			w = fullw / (UINT)NUM_CAQ_CHANNELS ;
			h = fullh ;

			for ( int i = CAQ_CH1 ; i < NUM_CAQ_CHANNELS ; i++ )
			{
				l[i] = (UINT)( (i-CAQ_CH1+1) * fullw / NUM_CAQ_CHANNELS ) - w ; //leftmost point of each channel
				r[i] = l[i] + w - 1 ; //rightmost point of each channel
			}
		}

	UINT w;
	UINT h;
	UINT l[NUM_CAQ_CHANNELS]; //this stores the leftmost position of each channel
	UINT r[NUM_CAQ_CHANNELS]; //this stores the rightmost position of each channel
};

//class CCAQPoint
//{
//public:
//	float x;
//	float y;
//	float signal;
//	float background;
//};

class CCAQHeader
{
public:

	UINT frame_w;
	UINT frame_h;
	UINT32 scaler;
	UINT background;

	UINT32 size;
	UINT64 num_acquired;  //what is this?
	UINT64 num_dismissed; //what is this?

	BOOL is_running;
	double sampling_rate;

	INT64 last_sync_tick; //records the last system time when camera image became available
	UINT64 last_sync_index;//records the number of images acquired by camera so far. Not recorded.

	double r; //radius of circle drawn around a picked point. we can change it using mouse.
	double x[NUM_CAQ_CHANNELS];//we can store a single point on the left and right channel each.
	double y[NUM_CAQ_CHANNELS];//

};