#pragma once

class CCamera
{
// Construction
public:

	CCamera();
	virtual ~CCamera();
	void CameraInit();
	void CameraLoad(LPCSTR path);
	void CameraSave(LPCSTR path);
	void CameraFree();


// Implementation
protected:
public:
	BOOL m_is_initialized;
	CString m_name;
	CString m_interface;
	long m_num_physical_h_pixels;
	long m_num_physical_v_pixels;
	double m_physical_pixel_width;
	double m_physical_pixel_height;
	long m_buffer_size;
	int m_bit_depth;

	int m_hspeed;
	int GetNumberHSpeeds(int *num);
	int GetHSpeed(int index, double *speed);
	int SetHSpeed(int index);
	int m_vspeed;
	int GetNumberVSpeeds(int *num);
	int GetVSpeed(int index, double *speed);
	int SetVSpeed(int index);


	long m_num_h_pixels;
	long m_num_v_pixels;

	BOOL m_is_subimage_available;
	long m_image_left;
	long m_image_right;
	long m_image_bottom;
	long m_image_top;
	int SetImagingArea(long left, long right, long bottom, long top);

	long m_num_h_pixels_to_bin;
	long m_num_v_pixels_to_bin;
	int SetBinning(long h_binning, long v_binning);


	BOOL m_is_fan_available;
	BOOL m_is_fan_on;
	int FanOnOff(BOOL onoff);

	BOOL m_is_cooler_available;
	BOOL m_is_cooler_on;
	int m_set_temperature;	
	int m_max_temperature;
	int m_min_temperature;
	CString m_temperature_control_status;
	int CoolerOnOff(BOOL onoff);
	int SetTemperature(int temperature);
	int GetTemperature(int *temperature);

	BOOL m_h_flip;
	BOOL m_v_flip;
	int m_rotate;
	int FlipImage(BOOL h_flip, BOOL v_flip);
	int RotateImage(int rotate);

	double m_exposure_time;
	double m_kinetic_cycle_time;
	int SetExposureTime(double time, BOOL verbose=TRUE);

	BOOL m_is_gain_available;	
	int m_gain;
	int m_min_gain;
	int m_max_gain;
	int SetGain(int gain);

	BOOL m_is_shutter_open;
	int OpenShutter();
	int CloseShutter();

	BOOL m_is_acquiring;
	int StartAcquisition();
	int StopAcquisition();

	long m_first_image_index;
	long m_last_image_index;
	long m_continuous_image_index;
	int WaitForImages(int timeout, int *num);
	int GetImagesContinuous(int num, long *image);
	int GetImagesLatest(int num, long *image);

};