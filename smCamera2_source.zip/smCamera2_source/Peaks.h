#pragma once
#include "Channels.h"

class CPeak
{
public:
	CPeak()	
		{	
			x = y = -1.0;	
			sx = sy = 0.0;	
			is_good = TRUE;	
		}

	float x;
	float y;
	float sx;
	float sy;
	BOOL is_good;

	inline BOOL IsValid()
		{	return ( x >= 0 && y >= 0 && sx > 0 && sy > 0 );	}
	inline BOOL IsGood()
		{	return ( IsValid() && is_good );	}
};

class CPeakSet
{
public:
	CPeak p[NUM_CHANNELS];

	inline BOOL IsValid()
		{
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
				if ( !p[i].IsValid() )	return FALSE;

			return TRUE;
		}
	inline BOOL IsGood()
		{
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
				if ( !p[i].is_good || !p[i].IsValid() )	return FALSE;

			return TRUE;
		}
};