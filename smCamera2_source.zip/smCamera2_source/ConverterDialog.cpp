// ConverterDialog.cpp : implementation file

#include "stdafx.h"
#include "smCamera.h"
#include "ConverterDialog.h"
#include <math.h>
#include ".\converterdialog.h"

// CConverterDialog dialog

IMPLEMENT_DYNAMIC(CConverterDialog, CDialog)
CConverterDialog::CConverterDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CConverterDialog::IDD, pParent)
	, m_film_convert_cbindex(FILM_CONVERT_TO_OLD_FILM)
	, m_film_convert_status(_T(""))
	, m_trace_convert_status(_T(""))
	, m_resize(FALSE)
	, m_resize_width(0)
	, m_resize_height(0)
	, m_convert_trace(FALSE)
{
}

CConverterDialog::~CConverterDialog()
{
}

BOOL CConverterDialog::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_is_working = FALSE;
	m_directory.SetPath( _PATH_MOVIES );

	m_map.Reset(0, 0);
	m_map_orgx = 0;
	m_map_orgy = 0;
	m_map_width = m_map.m_frame_w;
	m_map_height = m_map.m_frame_h;
	m_map_binning = 1;

	LoadProgramColorTable();
	UpdateData(FALSE);	
	return TRUE;
}

void CConverterDialog::OnCancel()
{
	if ( m_is_working )
	{
		LogErr(_T("Conversion is in progress. Stop it first."));
		return;
	}

	DestroyWindow();
}

void CConverterDialog::OnOK()
{
	SetFocus();
	return;
}

void CConverterDialog::OnDestroy()
{
	m_is_working = FALSE;

	_tchdir(_PATH_ROOT);
	CDialog::OnDestroy();
}

void CConverterDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	

	DDX_CBIndex(pDX, IDC_FILM_CONVERT_COMBO, m_film_convert_cbindex);
	DDX_Check(pDX, IDC_RESIZE, m_resize);
	DDX_Text(pDX, IDC_RESIZE_WIDTH, m_resize_width);
	DDX_Text(pDX, IDC_RESIZE_HEIGHT, m_resize_height);
	DDX_Text(pDX, IDC_FILM_CONVERT_STATUS, m_film_convert_status);

	DDX_Check(pDX, IDC_TRACE_TYPE, m_convert_trace);
	DDX_Text(pDX, IDC_TRACE_CONVERT_STATUS, m_trace_convert_status);

	DDX_Text(pDX, IDC_MAP_ORGY, m_map_orgy);
	DDX_Text(pDX, IDC_MAP_WIDTH, m_map_width);
	DDX_Text(pDX, IDC_MAP_HEIGHT, m_map_height);
	DDX_Text(pDX, IDC_MAP_BINNING, m_map_binning);
	if ( pDX->m_bSaveAndValidate != TRUE )
		DDX_Text(pDX, IDC_MAP_FILEPATH, m_map.m_path);	
}

BEGIN_MESSAGE_MAP(CConverterDialog, CDialog)
	ON_CBN_SELENDOK(IDC_FILM_CONVERT_COMBO, OnCbnSelendokFilmConvertCombo)
	ON_BN_CLICKED(IDC_RESIZE, OnBnClickedResize)
	ON_EN_KILLFOCUS(IDC_RESIZE_WIDTH, OnEnKillfocusResizeWidth)
	ON_EN_KILLFOCUS(IDC_RESIZE_HEIGHT, OnEnKillfocusResizeHeight)
	ON_BN_CLICKED(IDC_FILM_CONVERT, OnBnClickedFilmConvert)
	ON_BN_CLICKED(IDC_FILM_CONVERT_FOLDER, OnBnClickedFilmConvertFolder)
	ON_BN_CLICKED(IDC_TRACE_CONVERT, OnBnClickedTraceConvert)
	ON_BN_CLICKED(IDC_TRACE_CONVERT_FOLDER, OnBnClickedTraceConvertFolder)
	ON_BN_CLICKED(IDC_SELECT_MAP, OnBnClickedSelectMap)
	ON_BN_CLICKED(IDC_MAP_CONVERT, OnBnClickedMapConvert)
	ON_EN_KILLFOCUS(IDC_MAP_ORGY, OnEnKillfocusMapOrgy)
	ON_EN_KILLFOCUS(IDC_MAP_HEIGHT, OnEnKillfocusMapHeight)
	ON_EN_KILLFOCUS(IDC_MAP_BINNING, OnEnKillfocusMapBinning)
	ON_BN_CLICKED(IDC_TRACE_TYPE, OnBnClickedTraceType)
END_MESSAGE_MAP()

void CConverterDialog::ConvertFilmToOldFilm(LPCTSTR filmpath)
{
	MSG message;

	int n;
	CString filepath;
	CString path = _T(""), name = _T("");
	name = filepath = filmpath;

	n = filepath.ReverseFind( (TCHAR)'\\' );
	if ( n >= 0 )
	{
		path = filepath.Mid(0, n);
		name = filepath.Mid(n+1);
	}
	name.Replace(CAMERAFILE_FILM_PREFIX, _T(""));
	n = name.ReverseFind('.');
	if ( n < 0 )	return;
	name = name.Mid(0, n);
	filepath.Format(_T("%s\\%s%s.%s"), path, CAMERAFILE_OLDFILM_PREFIX, name, CAMERAFILE_OLDFILM_EXT);

	CFilm film;
	if ( film.Open(filmpath) < 0 )	return;

	CArchive *ar = OpenProgramFileToWrite(filepath);
	if ( ar == NULL )	return;

	m_film_convert_status.Format(_T("[Converting] %s \r\n -> %s"), filmpath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	UINT16 fw = film.m_frame_w;
	UINT16 fh = film.m_frame_h;
	
	UINT16 w = fw;
	UINT16 h = fh;	
	if ( m_resize )
	{
		w = m_resize_width;
		h = m_resize_height;
	}

	ar->Write((void *)&w, sizeof(UINT16));
	ar->Write((void *)&h, sizeof(UINT16));

	for ( UINT i = 0 ; i < film.m_num_frames ; i++ )
	{
		UINT8 pixel;

		film.MoveFrame(i);
		film.ReadFrame(NULL);

		for ( UINT y = 0 ; y < h ; y++ )
		{
			for ( UINT x = 0 ; x < w ; x++ )
			{
				pixel = 0;
				if ( x < fw && y < fh )		pixel = film.Pixel2Byte( film.Frame(x,y) );
				ar->Write((void *)&pixel, sizeof(UINT8));
			}
		}
		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}
	CloseProgramFile(ar);

	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), filmpath, filepath));
	m_film_convert_status.Format(_T("[Done] %s \r\n -> %s"), filmpath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	return;
}

void CConverterDialog::ConvertFilmToGrayTIFF(LPCTSTR filmpath)
{
	MSG message;

	CFilm film;
	CTIFFFileWriter writer;
	if ( film.Open(filmpath) < 0 || !film.m_film )	return;
	if ( writer.SetFilepath(filmpath) < 0 )	return;
	writer.m_frame_w = film.m_frame_w;
	writer.m_frame_h = film.m_frame_h;
	writer.m_background = film.m_background;
	writer.m_data_scaler = film.m_data_scaler;
	writer.m_byte_per_pixel = film.m_film->m_byte_per_pixel;
	writer.m_8bit_color = FALSE;
	if ( writer.Open() < 0 )	return;
	
	m_film_convert_status.Format(_T("[Converting] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	for ( UINT i = 0 ; i < film.m_num_frames ; i++ )
	{
		film.MoveFrame(i);
		film.ReadFrame(NULL);
		writer.Write( 1, film.m_frame );

		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}


	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), filmpath, writer.m_filepath));
	m_film_convert_status.Format(_T("[Done] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	writer.Close();
	film.Close();

	return;
}

void CConverterDialog::ConvertFilmTo8BitColorTIFF(LPCTSTR filmpath)
{
	MSG message;

	CFilm film;
	CTIFFFileWriter writer;
	if ( film.Open(filmpath) < 0 || !film.m_film )	return;
	if ( writer.SetFilepath(filmpath) < 0 )	return;
	writer.m_frame_w = film.m_frame_w;
	writer.m_frame_h = film.m_frame_h;
	writer.m_background = film.m_background;
	writer.m_data_scaler = film.m_data_scaler;
	writer.m_byte_per_pixel = 1;
	writer.m_8bit_color = TRUE;
	if ( writer.Open() < 0 )	return;
	
	m_film_convert_status.Format(_T("[Converting] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	for ( UINT i = 0 ; i < film.m_num_frames ; i++ )
	{
		film.MoveFrame(i);
		film.ReadFrame(NULL);
		writer.Write( 1, film.m_frame );

		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}

	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), filmpath, writer.m_filepath));
	m_film_convert_status.Format(_T("[Done] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}
	writer.Close();
	film.Close();

	return;
}


void CConverterDialog::ConvertTraceToOldTrace(LPCTSTR tracepath)
{
	int n;
	CString filepath = tracepath;
	n = filepath.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )	filepath = filepath.Mid(0, n);
	filepath.AppendFormat(_T(".%s"), CAMERAFILE_OLDTRACE_EXT);

	CTraceFileReader reader;
	if ( reader.Open(tracepath) < 0 )	return;

	CArchive *ar = OpenProgramFileToWrite( filepath );
	if ( ar == NULL )	return;


	m_trace_convert_status.Format(_T("[Converting] %s \r\n -> %s"), tracepath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	INT16 limit = (1 << (16-1)) - 1;
	double max = 0.0;
	for ( UINT frame_no = 0 ; frame_no < reader.m_num_frames ; frame_no++ )
		for ( UINT peak_no = 0 ; peak_no < reader.m_num_peaks ; peak_no++ )
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				double f = reader.Signal( i, peak_no, frame_no ) - reader.Background( i, peak_no, frame_no );
				if ( f > max )	max = f;
			}



	INT32 num_frames = reader.m_num_frames;
	INT16 num_peaks = 2*reader.m_num_peaks;
	ar->Write((void *)&num_frames, sizeof(INT32));
	ar->Write((void *)&num_peaks, sizeof(INT16));

	INT32 temp32;
	INT16 temp16;
	if ( max < limit )
	{
		max = limit;
	}
	else
	{
		LogMsg(_T("Info"), 
			Stringify(_T("max intensity [%.0f] >= data limit [%d] in old trace in [%s]"), 
						max, limit, tracepath) );
	}
	for ( UINT frame_no = 0 ; frame_no < reader.m_num_frames ; frame_no++ )
		for ( UINT peak_no = 0 ; peak_no < reader.m_num_peaks ; peak_no++ )
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				double f = reader.Signal( i, peak_no, frame_no ) - reader.Background( i, peak_no, frame_no );
				temp32 = (INT32) ( f * limit * 1.0 / max );
				temp16 = ( temp32 > (INT32)limit ) ? limit : (INT16)temp32;
                ar->Write((void *)&temp16, sizeof(INT16));
			}

	CloseProgramFile(ar);
	reader.Close();

	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), tracepath, filepath));
	m_trace_convert_status.Format(_T("[Done] %s \r\n -> %s"), tracepath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	return;
}


void CConverterDialog::ConvertFilmFolder(LPCTSTR folder )
{
	MSG message;
	CDirectoryTraverse directory;
	directory.SetFormat(_T(""), CAMERAFILE_FILM_EXT);
	directory.SetPath( folder );

	if ( directory.InitTraverse() < 0 )	return;
	CString fullpath;
	CString name;
	BOOL is_dir;
	while ( directory.Traverse( name, is_dir ) == 0 )
	{

		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
		if ( ::IsWindow(m_hWnd) )	UpdateWindow();

		if ( m_is_working != TRUE )	break;

		fullpath = directory.m_path + '\\' + name;
		if ( is_dir )
		{
			ConvertFilmFolder(fullpath);
		}
		else
		{
			if ( m_film_convert_cbindex == FILM_CONVERT_TO_OLD_FILM )
	            ConvertFilmToOldFilm( fullpath );
			else if ( m_film_convert_cbindex == FILM_CONVERT_TO_GRAY_TIFF )
				ConvertFilmToGrayTIFF( fullpath );
			else if ( m_film_convert_cbindex == FILM_CONVERT_TO_8BITCOLOR_TIFF )
				ConvertFilmTo8BitColorTIFF( fullpath );
		}
	}
	directory.CloseTraverse();

	return;
}

void CConverterDialog::ConvertTraceFolder(LPCTSTR folder)
{
	MSG message;
	CDirectoryTraverse directory;
	if ( m_convert_trace != TRUE )
		directory.SetFormat(_T(""), CAMERAFILE_TRACE_EXT);
	else
		directory.SetFormat(_T(""), CAMERAFILE_TRACE2_EXT);
	directory.SetPath( folder );

	if ( directory.InitTraverse() < 0 )	return;
	CString fullpath;
	CString name;
	BOOL is_dir;
	while ( directory.Traverse( name, is_dir ) == 0 )
	{

		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
		if ( ::IsWindow(m_hWnd) )	UpdateWindow();

		if ( m_is_working != TRUE )	break;

		fullpath = directory.m_path + '\\' + name;
		if ( is_dir )
			ConvertTraceFolder(fullpath);
		else
			ConvertTraceToOldTrace(fullpath);

	}
	directory.CloseTraverse();

	return;
}



void CConverterDialog::OnCbnSelendokFilmConvertCombo()
{
	UpdateData(TRUE);
	if ( m_film_convert_cbindex != FILM_CONVERT_TO_OLD_FILM )
	{
		m_resize = FALSE;
		UpdateData(FALSE);
	}
}

void CConverterDialog::OnBnClickedResize()
{
	UpdateData(TRUE);
}

void CConverterDialog::OnEnKillfocusResizeWidth()
{
	UpdateData(TRUE);
}

void CConverterDialog::OnEnKillfocusResizeHeight()
{
	UpdateData(TRUE);
}



void CConverterDialog::OnBnClickedFilmConvert()
{
	if ( m_is_working )	return;
	m_is_working = TRUE;
	UpdateData(TRUE);

	CString szFilters;
	szFilters.Format(_T("Film Files (*.%s;*.%s)|*.%s; *.%s|"
						"All Files (*.*)|*.*||"),
					CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path ;
	if( fileDlg.DoModal ()==IDOK )
	{
		CString filename = fileDlg.GetPathName();
		int n = filename.ReverseFind((TCHAR)'\\');
		if ( n < 0 )	n = 0;
		m_directory.SetPath( filename.Mid(0, n) );

		if ( m_film_convert_cbindex == FILM_CONVERT_TO_OLD_FILM )
            ConvertFilmToOldFilm( filename );
		else if ( m_film_convert_cbindex == FILM_CONVERT_TO_GRAY_TIFF )
			ConvertFilmToGrayTIFF( filename );
		else if ( m_film_convert_cbindex == FILM_CONVERT_TO_8BITCOLOR_TIFF )
			ConvertFilmTo8BitColorTIFF( filename );
	}

	m_is_working = FALSE;
}

void CConverterDialog::OnBnClickedFilmConvertFolder()
{
	static BOOL convert_in_progress = FALSE;
	CWnd *pWnd;

	if ( m_is_working && !convert_in_progress )	return;
	if ( convert_in_progress )
	{
		m_is_working = FALSE;
		return;
	}
	UpdateData(TRUE);

	CString szFilters;
	szFilters.Format(_T("Film Files (*.%s)|*.%s|All Files (*.*)|*.*|"), 
					CAMERAFILE_FILM_EXT, CAMERAFILE_FILM_EXT );
	CDirectoryDialog dirDlg( m_directory.m_path, szFilters);
	if ( dirDlg.DoModal()  != TRUE )	return;

	m_is_working = TRUE;
	convert_in_progress = TRUE;
	pWnd = GetDlgItem(IDC_FILM_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Stop"));

	m_directory.SetPath( dirDlg.m_strPath );
	ConvertFilmFolder( m_directory.m_path );

	pWnd = GetDlgItem(IDC_FILM_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Convert Folder"));
	convert_in_progress = FALSE;
	
	m_is_working = FALSE;
}

void CConverterDialog::OnBnClickedTraceType()
{
	UpdateData(TRUE);
}

void CConverterDialog::OnBnClickedTraceConvert()
{
	if ( m_is_working )	return;
	m_is_working = TRUE;

	CString szFilters;
	szFilters.Format(_T("Trace Files (*.%s)|*.%s|"
						"Trace Files (*.%s)|*.%s|"
						"BGTrace Files (*.%s)|*.%s|"
						"BGTrace Files (*.%s)|*.%s|"
						"All Files (*.*)|*.*||"),
						CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE2_EXT, CAMERAFILE_TRACE2_EXT,
						CAMERAFILE_BGTRACE_EXT, CAMERAFILE_BGTRACE_EXT, CAMERAFILE_BGTRACE2_EXT, CAMERAFILE_BGTRACE2_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path ;
	if( fileDlg.DoModal ()==IDOK )
	{
		CString filename = fileDlg.GetPathName();
		int n = filename.ReverseFind((TCHAR)'\\');
		if ( n < 0 )	n = 0;
		m_directory.SetPath( filename.Mid(0, n) );

		ConvertTraceToOldTrace( filename );
	}

	m_is_working = FALSE;
}

void CConverterDialog::OnBnClickedTraceConvertFolder()
{
	static BOOL convert_in_progress = FALSE;
	CWnd *pWnd;

	if ( m_is_working && !convert_in_progress )	return;
	if ( convert_in_progress )
	{
		m_is_working = FALSE;
		return;
	}

	CString szFilters;
	szFilters.Format(_T("Trace Files (*.%s)|*.%s|"
						"Trace Files (*.%s)|*.%s|"
						"All Files (*.*)|*.*||"),
						CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE2_EXT, CAMERAFILE_TRACE2_EXT );
	CDirectoryDialog dirDlg( m_directory.m_path, szFilters);
	if ( dirDlg.DoModal()  != TRUE )	return;

	m_is_working = TRUE;
	convert_in_progress = TRUE;
	pWnd = GetDlgItem(IDC_TRACE_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Stop"));

	m_directory.SetPath( dirDlg.m_strPath );
	ConvertTraceFolder( m_directory.m_path );

	pWnd = GetDlgItem(IDC_TRACE_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Convert Folder"));
	convert_in_progress = FALSE;
	m_is_working = FALSE;
}

void CConverterDialog::OnBnClickedSelectMap()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_map.Load(fileDlg.GetPathName());
		if ( !m_map.m_is_mapping_ready )
		{
			LogErr(Stringify(_T("Load Mapping File[%s] Failed."), fileDlg.GetPathName()));		
			return;
		}
		m_map_orgx = 0;
		m_map_orgy = 0;
		m_map_width = m_map.m_frame_w;
		m_map_height = m_map.m_frame_h;
		m_map_binning = 1;

		CWnd *pWnd;
		CString str;
	
		str.Format(_T("%d x %d"), m_map_width / m_map_binning, m_map_height / m_map_binning );
		pWnd = GetDlgItem(IDC_MAP_SIZE);
		if ( pWnd )	pWnd->SetWindowText( str );
		pWnd = GetDlgItem(IDC_MAP_FILEPATH);
		if ( pWnd )	pWnd->SetWindowText(m_map.m_path);

		UpdateData(FALSE);
	}
}

void CConverterDialog::OnBnClickedMapConvert()
{
	if ( m_map.m_is_mapping_ready != TRUE )
	{
		LogErr(_T("The selected mapping is not valid."));
		return;
	}

	if ( m_map_binning < 1 || m_map_width % m_map_binning != 0 || m_map_height % m_map_binning != 0 )
	{
		LogErr(	_T("Invalid binning : Width and Height should be divided with the binsize") );
		return;
	}
	
	if ( m_map_orgy + m_map_binning * m_map_height > m_map.m_frame_h )
	{
		LogErr(_T("The new map is covering larger area than the old one."));
		return;
	}

	CString szFilters;
	szFilters.Format(_T("Mapping File (*.txt)|*.txt|All Files (*.*)|*.*||"));
	CFileDialog fileDlg(FALSE, NULL, NULL, OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	fileDlg.m_ofn.lpstrDefExt = _T("txt");
	if ( fileDlg.DoModal ()!=IDOK )	return;

	double x1, y1, x2, y2;
	CChannels ch(m_map_width, m_map_height);
	CMapping new_map;

	new_map.Reset(m_map_width/m_map_binning, m_map_height/m_map_binning);
	for ( int y = 0 ; y < NUM_MAPPING_COEFFS ; y++ )
	{
		for ( int x = 0 ; x < NUM_MAPPING_COEFFS ; x++ )
		{
			x1 = ch.l[CH1] + ch.w * x / NUM_MAPPING_COEFFS;
			y1 = ch.h * y / NUM_MAPPING_COEFFS;
			x2 = m_map.X2(x1, y1);
			y2 = m_map.Y2(x1, y1);
			new_map.AddMappingPair( (x1-m_map_orgx+0.5)/m_map_binning-0.5, (y1-m_map_orgy+0.5)/m_map_binning-0.5, 
									(x2-m_map_orgx+0.5)/m_map_binning-0.5, (y2-m_map_orgy+0.5)/m_map_binning-0.5 );
		}
	}
	new_map.DoMapping();
	if ( new_map.m_is_mapping_ready != TRUE )
	{
		LogErr(_T("Convert Failed."));
		return;
	}
	new_map.Save( fileDlg.GetPathName() );
	return;
}

void CConverterDialog::OnEnKillfocusMapOrgy()
{
	UpdateData(TRUE);

	CWnd *pWnd;
	CString str;
	str.Format(_T("%d x %d"), m_map_width / m_map_binning, m_map_height / m_map_binning );
	pWnd = GetDlgItem(IDC_MAP_SIZE);
	if ( pWnd )	pWnd->SetWindowText( str );
}

void CConverterDialog::OnEnKillfocusMapHeight()
{
	UpdateData(TRUE);

	CWnd *pWnd;
	CString str;
	str.Format(_T("%d x %d"), m_map_width / m_map_binning, m_map_height / m_map_binning );
	pWnd = GetDlgItem(IDC_MAP_SIZE);
	if ( pWnd )	pWnd->SetWindowText( str );
}

void CConverterDialog::OnEnKillfocusMapBinning()
{
	UpdateData(TRUE);

	CWnd *pWnd;
	CString str;
	str.Format(_T("%d x %d"), m_map_width / m_map_binning, m_map_height / m_map_binning );
	pWnd = GetDlgItem(IDC_MAP_SIZE);
	if ( pWnd )	pWnd->SetWindowText( str );
}

