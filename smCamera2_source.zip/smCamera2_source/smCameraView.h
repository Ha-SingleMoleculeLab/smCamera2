// smCameraView.h : interface of the CsmCameraView class
//

#pragma once
#include "smCameraDoc.h"
#include "CameraDialog.h"
#include "MovieRecorderDialog.h"
#include "MovieAnalysisDialog.h"
#include "MovieMapperDialog.h"
#include "ConverterDialog.h"
#include "HistogramDialog.h"
#include "TraceDialog.h"
#include "..\ShutterManager\ConfigDialog.h"
#include "..\ShutterManager\NI_PCI_6503_Dialog.h"
#include "..\ShutterManager\NI_PCI_6722_Dialog.h"
#include "..\ShutterManager\StatusDialog.h"



class CsmCameraView : public CEditView
{
protected: // create from serialization only
	CsmCameraView();
	DECLARE_DYNCREATE(CsmCameraView)

// Attributes
public:
	CsmCameraDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CsmCameraView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	CCameraDialog *m_camera_dlg;
	CConfigDialog *m_shutter_config_dlg;
	CNI_PCI_6503_Dialog *m_NI_PCI_6503_dlg;
	CNI_PCI_6722_Dialog *m_NI_PCI_6722_dlg;
	CStatusDialog *m_status_dlg;
	CMovieRecorderDialog *m_movie_recorder_dlg;
	CMovieAnalysisDialog *m_movie_analysis_dlg;
	CMovieMapperDialog *m_movie_mapper_dlg;
	CConverterDialog *m_converter_dlg;
	CHistogramDialog *m_histogram_dlg;
	CTraceDialog *m_trace_dlg;

	afx_msg void OnDevicesCamera();
	afx_msg void OnDevicesShutterConfig();
	afx_msg void OnDevicesShutterController_NI_PCI_6503();
	afx_msg void OnDevicesShutterController_NI_PCI_6722();
	afx_msg void OnDevicesShutterStatus();

	afx_msg void OnToolsRecorder();
	afx_msg void OnToolsAnalysis();
	afx_msg void OnToolsMapper();
	afx_msg void OnToolsConverter();
	afx_msg void OnToolsHistogram();
	afx_msg void OnToolsTrace();
};


#ifndef _DEBUG  // debug version in smCameraView.cpp
inline CsmCameraDoc* CsmCameraView::GetDocument() const
   { return reinterpret_cast<CsmCameraDoc*>(m_pDocument); }
#endif

