#pragma once
#include "afxwin.h"
#include "CameraFile.h"
#include "smCamera.h"

// CConverterDialog dialog

class CConverterDialog : public CDialog
{
	DECLARE_DYNAMIC(CConverterDialog)

public:
	CConverterDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CConverterDialog();

// Dialog Data
	enum { IDD = IDD_CONVERTER };
	enum { FILM_CONVERT_TO_OLD_FILM = 0, FILM_CONVERT_TO_GRAY_TIFF = 1, FILM_CONVERT_TO_8BITCOLOR_TIFF };

protected:
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:

	BOOL m_is_working;
	int m_film_convert_cbindex;
	CString m_film_convert_status;
	CString m_trace_convert_status;
	CDirectoryTraverse m_directory;

	void ConvertFilmToOldFilm(LPCTSTR filmpath);
	void ConvertFilmToGrayTIFF(LPCTSTR filmpath);
	void ConvertFilmTo8BitColorTIFF(LPCTSTR filmpath);
	void ConvertTraceToOldTrace(LPCTSTR tracepath);
	void ConvertFilmFolder(LPCTSTR filmpath);
	void ConvertTraceFolder(LPCTSTR tracepath);

	BOOL m_resize;
	UINT m_resize_width;
	UINT m_resize_height;
	afx_msg void OnCbnSelendokFilmConvertCombo();
	afx_msg void OnBnClickedResize();
	afx_msg void OnEnKillfocusResizeWidth();
	afx_msg void OnEnKillfocusResizeHeight();
	afx_msg void OnBnClickedFilmConvert();
	afx_msg void OnBnClickedFilmConvertFolder();


	BOOL m_convert_trace;
	afx_msg void OnBnClickedTraceType();
	afx_msg void OnBnClickedTraceConvert();
	afx_msg void OnBnClickedTraceConvertFolder();


	CMapping m_map;
	UINT m_map_orgx;
	UINT m_map_orgy;
	UINT m_map_width;
	UINT m_map_height;
	afx_msg void OnBnClickedSelectMap();
	afx_msg void OnBnClickedMapConvert();
	afx_msg void OnEnKillfocusMapOrgy();
	afx_msg void OnEnKillfocusMapHeight();
	UINT m_map_binning;
	afx_msg void OnEnKillfocusMapBinning();
};