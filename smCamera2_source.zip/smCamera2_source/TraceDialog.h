#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "Mapping.h"


// CTraceDialog dialog

class CTraceDialog : public CDialog
{
	DECLARE_DYNAMIC(CTraceDialog)

public:
	CTraceDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTraceDialog();

// Dialog Data
	enum { IDD = IDD_TRACE };


protected:
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CDirectoryTraverse m_directory;

	CFilm m_film;
	CSliderCtrl m_slider;

	CPoint m_peak[NUM_CHANNELS];
	int m_radius[NUM_CHANNELS];

	CBitmap	*m_bitmap;
	COLORREF *m_display_buffer;

	CStatic m_image;
	int m_image_left;
	int m_image_top;
	int m_image_height;
	int m_image_width;

	CStatic m_spot[NUM_CHANNELS];
	int m_spot_left[NUM_CHANNELS];
	int m_spot_top[NUM_CHANNELS];
	int m_spot_height[NUM_CHANNELS];
	int m_spot_width[NUM_CHANNELS];

	BOOL GetFrameCoordinate(CPoint pt, int *x, int *y);
	BOOL GetIntensityCoordinate(CPoint pt, int *x, int *y);
	BOOL GetFRETCoordinate(CPoint pt, int *x, int *y);
//	void InitFrame(LPCTSTR filepath);
	void InitFrame(UINT w, UINT h);
	void FreeFrame();
	void UpdateFrame();
	void DrawCircle(CDC &dcMem, int x, int y, int r);

	double *m_CH1;
	double *m_CH2;
	double *m_bg1;
	double *m_bg2;
	double m_bg1_base;
	double m_bg2_base;

	double m_intensity_xoffset;
	double m_intensity_yoffset;
	double m_intensity_xscale;
	double m_intensity_yscale;
	CStatic m_intensity;
	int m_intensity_left;
	int m_intensity_top;
	int m_intensity_height;
	int m_intensity_width;

    double m_FRET_xoffset;
	double m_FRET_yoffset;
	double m_FRET_xscale;
	double m_FRET_yscale;
	CStatic m_FRET;
	int m_FRET_left;
	int m_FRET_top;
	int m_FRET_height;
	int m_FRET_width;

	void BuildTrace();
	void DrawIntensity();
	void DrawFRET();

	int m_peak_no;
	double m_f0_fsum_ratio;
	double m_11;
	double m_21;

	CMapping m_mapping;

	CPoint m_from;
	CPoint m_to;

	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	afx_msg void OnDeltaposSpinx1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinr1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinx2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinr2(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnBnClickedOpen();
	afx_msg void OnBnClickedBuild();
	afx_msg void OnBnClickedSave();
	afx_msg void OnDeltaposIntensityYscale(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposIntensityYoffset(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposIntensityXoffset(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposFRETYscale(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposFRETYoffset(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposFRETXoffset(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnEnKillfocusF0FsumRatio();
	afx_msg void OnEnKillfocusI1CH1();
	afx_msg void OnEnKillfocusI2CH1();
	afx_msg void OnEnKillfocusPeakNo();
	afx_msg void OnDeltaposPeakNoSpin(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnBnClickedLoadMap();
	afx_msg void OnBnClickedMap12();
	afx_msg void OnBnClickedMap21();

	BOOL m_show_total;
	BOOL m_show_background;
	BOOL m_flat_background;
	afx_msg void OnBnClickedShowTotal();
	afx_msg void OnBnClickedShowBackground();
	afx_msg void OnBnClickedFlatBackground();
};
