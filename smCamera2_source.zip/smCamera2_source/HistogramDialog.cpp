// HistogramDialog.cpp : implementation file

#include "stdafx.h"
#include "smCamera.h"
#include "CameraFile.h"
#include "HistogramDialog.h"
#include ".\histogramdialog.h"

#define HISTOGRAM_INIT_DIV		(100)
#define HISTOGRAM_OVERSHOOT		(1.2)
#define HISTOGRAM_V_DIV			(4)
#define HISTOGRAM_H_DIV			(7)


#define REAL_CH1(ch1, ch2)	( ( (1-m_IA_in_CH1)*(ch1) - m_IA_in_CH1*(ch2) ) / ( m_ID_in_CH1 - m_IA_in_CH1 ) )
#define REAL_CH2(ch1, ch2)	( ( m_ID_in_CH1*(ch2) - (1-m_ID_in_CH1)*(ch1) ) / ( m_ID_in_CH1 - m_IA_in_CH1 ) )

// CHistogramDialog dialog

IMPLEMENT_DYNAMIC(CHistogramDialog, CDialog)
CHistogramDialog::CHistogramDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CHistogramDialog::IDD, pParent)
	, m_ID_in_CH1(1.0)
	, m_IA_in_CH1(0.0)
{
	m_traces.SetSize(0);
	m_peaks.SetSize(0);

	m_num_used = 0;
	
	for ( int i = 0 ; i < 2 ; i++ )
	{
		m_cnt[i].SetSize(0);
		m_min[i] = 0.0;
		m_max[i] = 0.0;

		m_ymax[i] = 1.0;
	}

	m_histogram_cbindex[0] = FRET_HIST;
	m_histogram_cbindex[1] = SUM_HIST;

	for ( int i = 0 ; i < 2 ; i++ )
	{
		m_binsize[i][FRET_HIST] = 0.01;
		m_xoffset[FRET_HIST] = 0.5;
		m_xscale[FRET_HIST] = 0.2;
		for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
		{
			m_binsize[i][j] = 1000;
			m_xoffset[j] = 0;
			m_xscale[j] = 1000;
		}
	}
}

CHistogramDialog::~CHistogramDialog()
{
}



static RECT * __find_dest_rect(CDialog *dlg, CStatic *pane)
{
	static RECT	rect;
	long border_thickness;
	
	RECT dlgClientRct, dlgWinRct, paneWinRct;
	dlg->GetWindowRect(&dlgWinRct);
	dlg->GetClientRect(&dlgClientRct);

	pane->GetWindowRect(&paneWinRct);

	border_thickness = ( (dlgWinRct.right-dlgWinRct.left) - (dlgClientRct.right-dlgClientRct.left) )/2;
	rect.left = paneWinRct.left - ( dlgWinRct.left + border_thickness );
	dlgWinRct.top = dlgWinRct.bottom - border_thickness
					- (dlgClientRct.bottom-dlgClientRct.top) - border_thickness;
	rect.top = paneWinRct.top - ( dlgWinRct.top + border_thickness );
	rect.right = rect.left + paneWinRct.right - paneWinRct.left;
	rect.bottom = rect.top + paneWinRct.bottom - paneWinRct.top;

	return &rect;
}




BOOL CHistogramDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	CString str;
	CArchive *ar = NULL;
	if ( DoesProgramFileExist( GetProgramFilePath( _PATH_HISTOGRAM, _T("histogram.save") ) ) )
	{
		ar = OpenProgramFileToRead( GetProgramFilePath( _PATH_HISTOGRAM, _T("histogram.save") ) );
	}
	
	if ( ar )
	{
		for ( int i = 0 ; i < 2 ; i++ )
		{
			ar->ReadString(str);
			m_fspath[i] = str;
			m_fs[i].Load(m_fspath[i]);
		}
		ar->ReadString(str);
		m_ID_in_CH1 = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
		ar->ReadString(str);
		m_IA_in_CH1 = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );		
		ar->ReadString(str);
        m_directory.SetPath(str);

		CloseProgramFile(ar);
	}
	else
	{
		for ( int i = 0 ; i < 2 ; i++ )
		{
			m_fspath[i] = m_fs[i].DefaultPath();
			m_fs[i].Load();
		}
		m_ID_in_CH1 = 1.0;
		m_IA_in_CH1 = 0.0;
		m_directory.SetPath(_T("."));
	}

	CWnd *pWnd;
	pWnd = GetDlgItem(IDC_FS1);
	if ( pWnd )	pWnd->SetWindowText(m_fspath[0]);
	pWnd = GetDlgItem(IDC_FS2);
	if ( pWnd )	pWnd->SetWindowText(m_fspath[1]);

	RECT *rect;

	for ( int i = 0 ; i < 2 ; i++ )
	{
		rect = __find_dest_rect(this, &m_histogram[i]);
		m_left[i] = rect->left;
		m_top[i] = rect->top;
		m_width[i] = rect->right - rect->left;
		m_height[i] = rect->bottom - rect->top;

		m_cnt[i].SetSize(0);
		DrawHistogram(i);
	}

	UpdateData(FALSE);	
	return TRUE;
}

void CHistogramDialog::OnCancel()
{
	DestroyWindow();
}

void CHistogramDialog::OnOK()
{
	SetFocus();
	return;
}

void CHistogramDialog::OnDestroy()
{
	CString str;
	CArchive *ar = OpenProgramFileToWrite( 
					GetProgramFilePath( _PATH_HISTOGRAM, _T("histogram.save") )
					);
	if ( ar )
	{
		for ( int i = 0 ; i < 2 ; i++ )
		{
			str.Format(_T("%s\r\n"), m_fspath[i]);
			ar->WriteString(str);
		}
		str.Format(_T("%f\r\n"), m_ID_in_CH1 );
		ar->WriteString(str);
		str.Format(_T("%f\r\n"), m_IA_in_CH1);
		ar->WriteString(str);

		str = m_directory.m_path;
		ar->WriteString(str);

		CloseProgramFile(ar);
	}

	_tchdir(_PATH_ROOT);
	CDialog::OnDestroy();
}


void CHistogramDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_HISTOGRAM1, m_histogram[0]);
	DDX_Control(pDX, IDC_HISTOGRAM2, m_histogram[1]);
	DDX_Text(pDX, IDC_ID_IN_CH1, m_ID_in_CH1);
	DDX_Text(pDX, IDC_IA_IN_CH1, m_IA_in_CH1);

	int type[2];
	for ( int i = 0 ; i < 2 ; i++ )
		type[i] = m_histogram_cbindex[i];

	DDX_Text(pDX, IDC_LB1, m_cutoff[0][type[0]].low);
	DDX_Text(pDX, IDC_LB2, m_cutoff[1][type[1]].low);
	DDX_Text(pDX, IDC_UB1, m_cutoff[0][type[0]].high);
	DDX_Text(pDX, IDC_UB2, m_cutoff[1][type[1]].high);
	DDX_Text(pDX, IDC_BINSIZE1, m_binsize[0][type[0]]);
	DDX_Text(pDX, IDC_BINSIZE2, m_binsize[1][type[1]]);

	DDX_CBIndex(pDX, IDC_COMBO1, m_histogram_cbindex[0]);
	DDX_CBIndex(pDX, IDC_COMBO2, m_histogram_cbindex[1]);
}


void CHistogramDialog::ReadTraces()
{
	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_PATH);
	if ( pWnd )
	{
		pWnd->SetWindowText( m_directory.m_path );
		((CEdit*)pWnd)->SetSel(0, -1);
	}
	LogMsg(_T("Info"), Stringify(_T("Building histogram at [%s]..."), m_directory.m_path));

	m_peaks.SetSize(0);

	str = _T("");
	pWnd = GetDlgItem(IDC_FILENAME);
	for ( int i = 0 ; i < m_traces.GetCount() ; i++ )
	{
		CTraceFileReader reader;
		if ( reader.Open( m_directory.m_path + _T("\\") + m_traces[i] ) < 0 )
		{
			LogErr(Stringify(_T("Failed to open a trace [%s\\%s]."), m_directory.m_path, m_traces[i]));
		}
		else
		{
			UINT num_peaks = reader.m_num_peaks;
			UINT num_frames = reader.m_num_frames;
			for ( UINT peak_no = 0 ; peak_no < num_peaks ; peak_no++ )
			{
				CHistData tempdata;
				CPeakSet &set = reader.m_peaks[peak_no];				

                int n = 0;
				for ( int i = 0 ; i < 2 ; i++ )
				{
					int cnt = 0;
					double ch1 = 0.0;
					double ch2 = 0.0;
					double bgsub_ch1 = 0.0;
					double bgsub_ch2 = 0.0;

					m_fs[i].Init();
                    while ( m_fs[i].IsEnd() != TRUE )
					{
						if ( m_fs[i].Current() )
						{
							UINT frame_no = m_fs[i].CurrentFrameNo();
							if ( frame_no >= num_frames )	break;

							cnt ++;
							ch1 += reader.Signal( CH1, peak_no, frame_no );							
							ch2 += reader.Signal( CH2, peak_no, frame_no );
							bgsub_ch1 += ( reader.Signal( CH1, peak_no, frame_no ) - reader.Background( CH1, peak_no, frame_no ) );
							bgsub_ch2 += ( reader.Signal( CH2, peak_no, frame_no ) - reader.Background( CH2, peak_no, frame_no ) );

						}
						m_fs[i].Next();
					}
                    if ( cnt <= 0 )	break;
					if ( fabs(bgsub_ch1) < ZERO_TOLERANCE && fabs(bgsub_ch2) < ZERO_TOLERANCE )	break;

					n ++;
					tempdata.ch1[i] = ch1/cnt;
					tempdata.ch2[i] = ch2/cnt;
					tempdata.bgsub_ch1[i] = bgsub_ch1/cnt;
					tempdata.bgsub_ch2[i] = bgsub_ch2/cnt;
				}
				if ( n < 2 )	continue;
				m_peaks.Add(tempdata);
			}			
			LogMsg(_T("Info"), Stringify(_T("Histogram : [%u] peaks from [%s]"), num_peaks, m_traces[i]));

			str.AppendFormat(_T("%s%s"), ( str.IsEmpty() ) ? _T("") : _T(", "), m_traces[i]);
			if ( pWnd )	pWnd->SetWindowText(str);
		}
		reader.Close();
	}

	if ( m_peaks.GetCount() <= 0 )
	{
		LogErr(_T("No peaks were found from all traces."));
		return;	
	}

	InitHistogram();
    BuildHistogram();
	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);

	UpdateData(FALSE);
	return;
}



void CHistogramDialog::InitHistogram()
{
	int num_total = (int) m_peaks.GetCount();
	if ( num_total <= 0 )	return;

	for ( int i = 0 ; i < 2 ; i++ )
		for ( int j = 0 ; j < NUM_HIST_TYPES ; j++ )
			m_cutoff[i][j].Reset();

	float ch1, ch2, sum;
	float min[2][NUM_HIST_TYPES];
	float max[2][NUM_HIST_TYPES];
	for ( int i = 0 ; i < 2 ; i++ )
	{
		ch1 = (float) REAL_CH1( m_peaks[0].bgsub_ch1[i], m_peaks[0].bgsub_ch2[i] );
		ch2 = (float) REAL_CH2( m_peaks[0].bgsub_ch1[i], m_peaks[0].bgsub_ch2[i] );
		sum = ch1 + ch2 ;

		min[i][CH1_HIST] = max[i][CH1_HIST] = ch1;
		min[i][CH2_HIST] = max[i][CH2_HIST] = ch2;
		min[i][SUM_HIST] = max[i][SUM_HIST] = sum;
	}
	for ( int n = 0 ; n < num_total ; n++ )
	{
		for ( int i = 0 ; i < 2 ; i++ )
		{
			ch1 = (float) REAL_CH1( m_peaks[n].bgsub_ch1[i], m_peaks[n].bgsub_ch2[i] );
			ch2 = (float) REAL_CH2( m_peaks[n].bgsub_ch1[i], m_peaks[n].bgsub_ch2[i] );
			sum = ch1 + ch2 ;

			if ( ch1 < min[i][CH1_HIST] )	min[i][CH1_HIST] = ch1;
			else if ( ch1 > max[i][CH1_HIST] )	max[i][CH1_HIST] = ch1;
			if ( ch2 < min[i][CH2_HIST] )	min[i][CH2_HIST] = ch2;
			else if ( ch2 > max[i][CH2_HIST] )	max[i][CH2_HIST] = ch2;
			if ( sum < min[i][SUM_HIST] )	min[i][SUM_HIST] = sum;
			else if ( sum > max[i][SUM_HIST] )	max[i][SUM_HIST] = sum;
		}
	}
	
	float imin = min[0][CH1_HIST];
	float imax = max[0][CH1_HIST];
	for ( int i = 0 ; i < 2 ; i++ )
	{
		m_binsize[i][FRET_HIST] = 0.01;
		m_cutoff[i][FRET_HIST].low = (float) -0.2;
		m_cutoff[i][FRET_HIST].high = (float) 1.2;
		
		for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
		{
			m_binsize[i][j] = LIMIT_DECIMAL_PLACES( ( max[i][j] - min[i][j] ) / HISTOGRAM_INIT_DIV, 0 );
			if ( m_binsize[i][j] < ZERO_TOLERANCE )	m_binsize[i][j] = 1;
			m_cutoff[i][j].low = (float) ( LIMIT_DECIMAL_PLACES( min[i][j], 0 ) - m_binsize[i][j]/2 );
			m_cutoff[i][j].high = (float) ( LIMIT_DECIMAL_PLACES( max[i][j], 0 ) + m_binsize[i][j]/2 );

			if ( min[i][j] < imin )	imin = min[i][j];
			if ( max[i][j] > imax )	imax = max[i][j];
		}
	}
	
	m_xoffset[FRET_HIST] = 0.5;
	m_xscale[FRET_HIST] = 0.2;
	for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
	{
		m_xoffset[j] = ( imax + imin ) / 2;
		m_xscale[j] = ( imax - imin ) / HISTOGRAM_H_DIV ;
	}

	return;
}


void CHistogramDialog::BuildHistogram()
{
	int num_total = (int) m_peaks.GetCount();
	if ( num_total <= 0 )	return;

	m_num_used = 0;


	UINT max_cnt[2];
	double binsize[2];
	for ( int i = 0 ; i < 2 ; i++ )
	{
		max_cnt[i] = 0;
		binsize[i] = m_binsize[i][m_histogram_cbindex[i]];

        m_min[i] = m_cutoff[i][m_histogram_cbindex[i]].low - binsize[i]/2 ;
		m_max[i] = m_cutoff[i][m_histogram_cbindex[i]].high + binsize[i]/2 ;
		m_cnt[i].SetSize( (int) ( ( m_max[i] - m_min[i] ) / binsize[i] ) + 1 );
		for ( int k = 0 ; k < m_cnt[i].GetCount() ; k++ )
			m_cnt[i][k] = 0;
	}

	BOOL flag;
	float ch1, ch2, sum;
	float val[2][NUM_HIST_TYPES];
	for ( int n = 0 ; n < num_total ; n++ )
	{
		flag = TRUE;
		for ( int i = 0 ; i < 2 ; i++ )
		{
			ch1 = (float) REAL_CH1( m_peaks[n].bgsub_ch1[i], m_peaks[n].bgsub_ch2[i] );
			ch2 = (float) REAL_CH2( m_peaks[n].bgsub_ch1[i], m_peaks[n].bgsub_ch2[i] );
			sum = ch1 + ch2 ;

			val[i][FRET_HIST] = ch2/sum;
			val[i][CH1_HIST] = ch1;
			val[i][CH2_HIST] = ch2;
			val[i][SUM_HIST] = sum;

			for ( int j = FRET_HIST ; j < NUM_HIST_TYPES ; j++ )
			{
				if ( m_cutoff[i][j].use
					&& ( val[i][j] < m_cutoff[i][j].low || m_cutoff[i][j].high < val[i][j] ) )
				{
					flag = FALSE;
					break;
				}
			}
            if ( flag != TRUE )	break;
		}
		if ( flag != TRUE )	continue;
		m_num_used ++ ;

		int idx[2];
		for ( int i = 0 ; i < 2 ; i++ )
		{
			idx[i] = (int) ( ( val[i][m_histogram_cbindex[i]] - m_min[i] ) / binsize[i] );
			if ( 0 <= idx[i] && idx[i] < (int) m_cnt[i].GetCount() )
			{
                m_cnt[i][idx[i]]++;
				if ( m_cnt[i][idx[i]] > max_cnt[i] )	
					max_cnt[i] = m_cnt[i][idx[i]];
			}
		}
	}

	LogMsg(_T("Info"), Stringify(_T("Histogram used %.2f%% of the total : Used[%u] / Total[%d]"), m_num_used * 100.0 / num_total, m_num_used, num_total) );
	if ( m_num_used <= 0 )
		LogErr(_T("No peaks were selected."));

	for ( int i = 0 ; i < 2 ; i++ )
	{
		double ymax = LIMIT_DECIMAL_PLACES( HISTOGRAM_OVERSHOOT * max_cnt[i] / m_num_used , 3 );
		if ( ymax > ZERO_TOLERANCE )	m_ymax[i] = ymax;
	}

	return;
}

void CHistogramDialog::DrawHistogram(int id)
{
	if ( m_num_used <= 0 )	return;
	int type = m_histogram_cbindex[id];

	CClientDC dcDlg (this);
	CDC dcMem;
	CBitmap bitmap;

	bitmap.CreateCompatibleBitmap(&dcDlg, m_width[id], m_height[id]);
	dcMem.CreateCompatibleDC (&dcDlg);
	
	CBrush WhiteBrush (RGB (255, 255, 255));
	CPen GrayPen(PS_SOLID, 1, RGB(200,200,200));
	
	dcMem.SelectObject (&bitmap);
	dcMem.FillRect (CRect(0, 0, m_width[id], m_height[id]), &WhiteBrush);

	dcMem.SelectObject(&GrayPen);
	
	int v_div = HISTOGRAM_V_DIV;
	int h_div = HISTOGRAM_H_DIV;

	for ( int i = 1 ; i < v_div ; i++ )
	{
		dcMem.MoveTo( 0, m_height[id] * i / v_div );
		dcMem.LineTo( m_width[id], m_height[id] * i / v_div );
		
	}
	for ( int i = 1 ; i < h_div ; i++ )
	{
		dcMem.MoveTo( m_width[id] * i / h_div , 0 );
		dcMem.LineTo( m_width[id] * i / h_div , m_height[id] );
	}

	dcDlg.SelectObject(	this->GetFont() );
	TEXTMETRIC textMetric;	
	dcDlg.GetTextMetrics(&textMetric);
	RECT rect;
	this->GetClientRect(&rect);
	CBrush BgndBrush( GetSysColor(COLOR_3DFACE) );
	dcDlg.FillRect( CRect( rect.left, m_top[id] - textMetric.tmHeight , m_left[id], m_top[id] + m_height[id] ), &BgndBrush );
	dcDlg.FillRect( CRect( rect.left, m_top[id] + m_height[id], rect.right, m_top[id] + m_height[id] + textMetric.tmHeight ), &BgndBrush );

	CString str;
	dcDlg.SetBkMode( OPAQUE );
	dcDlg.SetBkColor( GetSysColor(COLOR_3DFACE) );

	dcDlg.SetTextAlign( TA_BASELINE | TA_RIGHT ); 
	for ( int i = 0 ; i <= v_div ; i++ )
	{
		str.Format(_T("%.3f%%"), 100 * m_ymax[id] * (v_div-i) / v_div );
		dcDlg.TextOut( m_left[id], m_top[id] + m_height[id] * i / v_div, str );
	}
	dcDlg.SetTextAlign( TA_TOP | TA_CENTER );
	CString xformat = ( type == FRET_HIST ) ? _T("%.2f") : _T("%.0f");
	for ( int i = 0 ; i <= h_div ; i++ )
	{
		str.Format( xformat, m_xoffset[type] + m_xscale[type] * (i - 0.5*h_div) );
		dcDlg.TextOut( m_left[id] + m_width[id] * i / h_div, m_top[id] + m_height[id], str );
	}

	CBrush HistBrush;
	switch ( type )
	{
	case FRET_HIST:
		HistBrush.CreateSolidBrush( RGB (0, 0, 128) );
		break;
	case CH1_HIST:
		HistBrush.CreateSolidBrush( RGB( 0, 128, 0 ) );
		break;
	case CH2_HIST:
        HistBrush.CreateSolidBrush( RGB( 128, 0, 0 ) );
		break;
	default:
		HistBrush.CreateSolidBrush( RGB( 0, 0, 0 ) );
		break;
	}
	
	int num_pockets = (int) m_cnt[id].GetCount();
	double lx = m_xoffset[type] - 0.5 * HISTOGRAM_H_DIV * m_xscale[type];
	double rx = m_xoffset[type] + 0.5 * HISTOGRAM_H_DIV * m_xscale[type];
	double ty = m_ymax[id];
	for ( int i = 0 ; i < num_pockets ; i++ )
	{
		double x1 = m_min[id] + i * m_binsize[id][type] ;
		double x2 = x1 + m_binsize[id][type];
		double y = m_cnt[id][i] * 1.0 / m_num_used;

		if ( x1 > rx )	continue;
		else if ( x2 > rx )	x2 = rx;

		if ( x2 < lx )	continue;
		else if ( x1 < lx )	x1 = lx;

		if ( y > ty  )	y = ty;

		int l = (int) ( m_width[id]*(x1-lx)/(rx-lx) );
		int r = (int) ( m_width[id]*(x2-lx)/(rx-lx) );
		int t = (int) ( m_height[id]*(ty-y)/ty );
		int b = m_height[id];

		if ( l == r	)	r = l+1;
		dcMem.FillRect( CRect( l, t, r, b ), &HistBrush );

	}
	dcDlg.BitBlt(m_left[id], m_top[id], m_width[id], m_height[id], &dcMem,0,0,SRCCOPY);
	return;
}

void CHistogramDialog::SaveHistogram(int id)
{
	int type = m_histogram_cbindex[id];

	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(FALSE, NULL, NULL, OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path;
	if ( fileDlg.DoModal ()!=IDOK )	return;

	CString pathname = fileDlg.GetPathName();
	CString ext = fileDlg.GetFileExt();
	int n = pathname.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )	pathname = pathname.Mid(0, n);

	CString str;
	CArchive *ar;
	
	str.Format(_T("%s.%s"), pathname, ext);
	ar = OpenProgramFileToWrite( str, TRUE );
	if ( ar == NULL )	return;

	UINT cumulative = 0;
	for ( int i = 0 ; i < m_cnt[id].GetCount() ; i++ )
	{
		cumulative += m_cnt[id][i];
		str.Format(_T("%10f \t %10d \t %f \t %f \r\n"), 
					m_min[id] + (i+0.5)*m_binsize[id][type], m_cnt[id][i], m_cnt[id][i]*1.0/m_num_used, cumulative*1.0/m_num_used);
		ar->WriteString(str);
	}
	CloseProgramFile(ar);

	str.Format(_T("%s_raw.%s"), pathname, ext);	
	ar = OpenProgramFileToWrite( str, TRUE );
	str.Format(_T("BGsubCH1[1] \t BGsubCH2[1] \t BGsubCH1[2] \t BGsubCH2[2] \t CH1[1] \t CH2[1] \t CH1[2] \t CH2[2] \t \r\n"));
	ar->WriteString(str);
	if ( ar == NULL )	return;

	BOOL flag;
	float ch1, ch2, sum;
	float val[2][NUM_HIST_TYPES];
	for ( int n = 0 ; n < m_peaks.GetCount() ; n++ )
	{
		flag = TRUE;
		str = _T("");
		for ( int i = 0 ; i < 2 ; i++ )
		{
			ch1 = (float) REAL_CH1( m_peaks[n].bgsub_ch1[i], m_peaks[n].bgsub_ch2[i] );
			ch2 = (float) REAL_CH2( m_peaks[n].bgsub_ch1[i], m_peaks[n].bgsub_ch2[i] );
			sum = ch1 + ch2 ;

			val[i][FRET_HIST] = ch2/sum;
			val[i][CH1_HIST] = ch1;
			val[i][CH2_HIST] = ch2;
			val[i][SUM_HIST] = sum;

			for ( int j = FRET_HIST ; j < NUM_HIST_TYPES ; j++ )
			{
				if ( m_cutoff[i][j].use
					&& ( val[i][j] < m_cutoff[i][j].low || m_cutoff[i][j].high < val[i][j] ) )
				{
					flag = FALSE;
					break;
				}
			}
            if ( flag != TRUE )	break;
		}
		if ( flag != TRUE )	continue;

		for ( int i = 0 ; i < 2 ; i++ )
		{
			double bgsub_ch1 = m_peaks[n].bgsub_ch1[i];
			double bgsub_ch2 = m_peaks[n].bgsub_ch2[i];
			str.AppendFormat(_T("%10f \t %10f \t "), REAL_CH1( bgsub_ch1, bgsub_ch2 ), REAL_CH2( bgsub_ch1, bgsub_ch2 ) );
		}
		for ( int i = 0 ; i < 2 ; i++ )
		{
			double ch1 = m_peaks[n].ch1[i];
			double ch2 = m_peaks[n].ch2[i];
			str.AppendFormat(_T("%10f \t %10f \t "), REAL_CH1( ch1, ch2 ), REAL_CH2( ch1, ch2 ) );
		}
		str.Append(_T("\r\n"));
		ar->WriteString(str);
	}
	CloseProgramFile(ar);
	return;
}


BEGIN_MESSAGE_MAP(CHistogramDialog, CDialog)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_OPEN, OnBnClickedOpen)
	ON_BN_CLICKED(IDC_REOPEN, OnBnClickedReopen)
	ON_BN_CLICKED(IDC_FS1, OnBnClickedFS1)
	ON_BN_CLICKED(IDC_FS2, OnBnClickedFS2)
	ON_EN_KILLFOCUS(IDC_ID_IN_CH1, OnEnKillfocusIDCH1)
	ON_EN_KILLFOCUS(IDC_IA_IN_CH1, OnEnKillfocusIACH1)

	ON_CBN_SELENDOK(IDC_COMBO1, OnCbnSelendokCombo1)
	ON_EN_KILLFOCUS(IDC_LB1, OnEnKillfocusLB1)
	ON_EN_KILLFOCUS(IDC_UB1, OnEnKillfocusUB1)
	ON_BN_CLICKED(IDC_SAVE1, OnBnClickedSave1)
	ON_EN_KILLFOCUS(IDC_BINSIZE1, OnEnKillfocusBinsize1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_YSCALE1, OnDeltaposYScale1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_XSCALE1, OnDeltaposXScale1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_XOFFSET1, OnDeltaposXOffset1)
	
	ON_CBN_SELENDOK(IDC_COMBO2, OnCbnSelendokCombo2)
	ON_EN_KILLFOCUS(IDC_LB2, OnEnKillfocusLB2)
	ON_EN_KILLFOCUS(IDC_UB2, OnEnKillfocusUB2)
	ON_BN_CLICKED(IDC_SAVE2, OnBnClickedSave2)
	ON_EN_KILLFOCUS(IDC_BINSIZE2, OnEnKillfocusBinsize2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_YSCALE2, OnDeltaposYScale2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_XSCALE2, OnDeltaposXScale2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_XOFFSET2, OnDeltaposXOffset2)
END_MESSAGE_MAP()


// CHistogramDialog message handlers

void CHistogramDialog::OnPaint()
{
	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);

	CDialog::OnPaint();
}

void CHistogramDialog::OnBnClickedOpen()
{
	int nChars = 4096;
	TCHAR *filenames = new TCHAR[nChars];
	memset(filenames, 0, sizeof(TCHAR)*nChars);

	CString szFilters;
	szFilters.Format(_T("Trace Files (*.%s)|*.%s|"
						"Trace Files (*.%s)|*.%s|"
						"BGTrace Files (*.%s)|*.%s|"
						"BGTrace Files (*.%s)|*.%s|"
						"All Files (*.*)|*.*||"),
					CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE2_EXT, CAMERAFILE_TRACE2_EXT,
                    CAMERAFILE_BGTRACE_EXT, CAMERAFILE_BGTRACE_EXT, CAMERAFILE_BGTRACE2_EXT, CAMERAFILE_BGTRACE2_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, 
						OFN_ALLOWMULTISELECT | OFN_ENABLESIZING |
						OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path ;
	fileDlg.m_ofn.lpstrFile = filenames;
	fileDlg.m_ofn.nMaxFile = nChars;

	m_traces.SetSize(0);
	CString path;
	if( fileDlg.DoModal () != IDOK )	goto FAIL;

	int nCharsRead = 0;
	TCHAR *filename = filenames;
	
	path = filename;
	while ( 1 ) 
	{
		nCharsRead += lstrlen( filename ) + 1;
		if ( nCharsRead >= nChars )	break;
		filename = filenames + nCharsRead ;
		if ( lstrlen(filename) > 0 )	m_traces.Add( CString(filename) );
	}

	if ( m_traces.GetCount() <= 0 )
	{
		int n = path.ReverseFind((TCHAR)'\\');
		if ( n < 0 )	goto FAIL;
		m_directory.SetPath( path.Mid(0, n) );
		m_traces.Add( path.Mid(n+1) );
	}
	else
	{
		m_directory.SetPath(path);
	}

	ReadTraces();
	delete [] filenames;
	return;
FAIL:
	m_traces.SetSize(0);
	delete [] filenames;
	return;
}

void CHistogramDialog::OnBnClickedReopen()
{
	ReadTraces();
}

void CHistogramDialog::OnBnClickedFS1()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_FRAME_SEQUENCE;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_fspath[0] =fileDlg.GetPathName();
		m_fs[0].Load( m_fspath[0] );
		CWnd *pWnd = GetDlgItem(IDC_FS1);
		if ( pWnd )	pWnd->SetWindowText( m_fspath[0] );
		UpdateData(FALSE);
	}
}
void CHistogramDialog::OnBnClickedFS2()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_FRAME_SEQUENCE;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_fspath[1] =fileDlg.GetPathName();
		m_fs[1].Load( m_fspath[1] );
		CWnd *pWnd = GetDlgItem(IDC_FS2);
		if ( pWnd )	pWnd->SetWindowText( m_fspath[1] );
		UpdateData(FALSE);
	}
}

void CHistogramDialog::OnEnKillfocusIDCH1()
{
	double backup = m_ID_in_CH1;
	UpdateData(TRUE);
	m_ID_in_CH1 = LIMIT_DECIMAL_PLACES( m_ID_in_CH1, 3 );
	if ( 0.0 <= m_ID_in_CH1 && m_ID_in_CH1 <= 1.0 
		&& fabs(m_ID_in_CH1-m_IA_in_CH1) > 0.01 )
	{
		BuildHistogram();
		for ( int i = 0 ; i < 2 ; i++ )
			DrawHistogram(i);
	}
	else
	{
		m_ID_in_CH1 = backup;
	}
	UpdateData(FALSE);
}
void CHistogramDialog::OnEnKillfocusIACH1()
{
	double backup = m_IA_in_CH1;
	UpdateData(TRUE);
	m_IA_in_CH1 = LIMIT_DECIMAL_PLACES( m_IA_in_CH1, 3 );
	if ( 0.0 <= m_IA_in_CH1 && m_IA_in_CH1 <= 1.0 
		&& fabs(m_ID_in_CH1-m_IA_in_CH1) > 0.01)
	{
		BuildHistogram();
		for ( int i = 0 ; i < 2 ; i++ )
			DrawHistogram(i);
	}
	else
	{
		m_IA_in_CH1 = backup;
	}
	UpdateData(FALSE);
}


void CHistogramDialog::OnCbnSelendokCombo1()
{
	int backup = m_histogram_cbindex[0];
	UpdateData(TRUE);
	if ( m_histogram_cbindex[0] != backup )
	{
		BuildHistogram();
		DrawHistogram(0);
	}
	UpdateData(FALSE);
}
void CHistogramDialog::OnEnKillfocusLB1()
{
	UpdateData(TRUE);
	int type = m_histogram_cbindex[0];
	m_cutoff[0][type].use = TRUE;
	if ( type == FRET_HIST )
		m_cutoff[0][type].low = (float) LIMIT_DECIMAL_PLACES( m_cutoff[0][type].low, 3 );
	else
		m_cutoff[0][type].low = (float) LIMIT_DECIMAL_PLACES( m_cutoff[0][type].low, 0 );
	
	BuildHistogram();
	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}
void CHistogramDialog::OnEnKillfocusUB1()
{
	UpdateData(TRUE);
	int type = m_histogram_cbindex[0];
	m_cutoff[0][type].use = TRUE;
	if ( type == FRET_HIST )
		m_cutoff[0][type].high = (float) LIMIT_DECIMAL_PLACES( m_cutoff[0][type].high, 3 );
	else
		m_cutoff[0][type].high = (float) LIMIT_DECIMAL_PLACES( m_cutoff[0][type].high, 0 );
	
	BuildHistogram();
	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}
void CHistogramDialog::OnBnClickedSave1()
{
	SaveHistogram(0);
}
void CHistogramDialog::OnEnKillfocusBinsize1()
{
	int type = m_histogram_cbindex[0];
	double backup = m_binsize[0][type];
	UpdateData(TRUE);
	m_binsize[0][type] = LIMIT_DECIMAL_PLACES( m_binsize[0][type], 3 );
	if ( m_binsize[0][type] > ZERO_TOLERANCE )
	{	
		BuildHistogram();
		DrawHistogram(0);
	}
	else
	{
		m_binsize[0][type] = backup;
	}
	UpdateData(FALSE);
}
void CHistogramDialog::OnDeltaposYScale1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	double new_scale = LIMIT_DECIMAL_PLACES( ScaleToNewValue( m_ymax[0], ( pNMUpDown->iDelta < 0 ) ), 3 );
	if ( new_scale > ZERO_TOLERANCE )	m_ymax[0] = new_scale;
	if ( new_scale > 1.0 )	m_ymax[0] = 1.0;
	*pResult = 0;
	DrawHistogram(0);
}
void CHistogramDialog::OnDeltaposXScale1(NMHDR *pNMHDR, LRESULT *pResult)
{
	int type = m_histogram_cbindex[0];
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	double new_scale = LIMIT_DECIMAL_PLACES( ScaleToNewValue( m_xscale[type], ( pNMUpDown->iDelta < 0 ) ), 3 );
	if ( new_scale > ZERO_TOLERANCE )	m_xscale[type] = new_scale;
	*pResult = 0;

	double scale = m_xscale[type];
	if ( type != FRET_HIST )
		for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
			m_xscale[j] = scale;

	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}
void CHistogramDialog::OnDeltaposXOffset1(NMHDR *pNMHDR, LRESULT *pResult)
{
	int type = m_histogram_cbindex[0];
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )
		m_xoffset[type] -= m_xscale[type];
	else
		m_xoffset[type] += m_xscale[type];
	*pResult = 0;

	double offset = m_xoffset[type];
	if ( type != FRET_HIST )
		for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
			m_xoffset[j] = offset;

	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}

void CHistogramDialog::OnCbnSelendokCombo2()
{
	int backup = m_histogram_cbindex[1];
	UpdateData(TRUE);
	if ( m_histogram_cbindex[1] != backup )
	{
		BuildHistogram();
		DrawHistogram(1);
	}
	UpdateData(FALSE);
}
void CHistogramDialog::OnEnKillfocusLB2()
{
	UpdateData(TRUE);
	int type = m_histogram_cbindex[1];
	m_cutoff[1][type].use = TRUE;
	if ( type == FRET_HIST )
		m_cutoff[1][type].low = (float) LIMIT_DECIMAL_PLACES( m_cutoff[1][type].low, 3 );
	else
		m_cutoff[1][type].low = (float) LIMIT_DECIMAL_PLACES( m_cutoff[1][type].low, 0 );
	
	BuildHistogram();
	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}
void CHistogramDialog::OnEnKillfocusUB2()
{
	UpdateData(TRUE);
	int type = m_histogram_cbindex[1];
	m_cutoff[1][type].use = TRUE;
	if ( type == FRET_HIST )
		m_cutoff[1][type].high = (float) LIMIT_DECIMAL_PLACES( m_cutoff[1][type].high, 3 );
	else
		m_cutoff[1][type].high = (float) LIMIT_DECIMAL_PLACES( m_cutoff[1][type].high, 0 );
	
	BuildHistogram();
	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}
void CHistogramDialog::OnBnClickedSave2()
{
	SaveHistogram(1);
}
void CHistogramDialog::OnEnKillfocusBinsize2()
{
	int type = m_histogram_cbindex[1];
	double backup = m_binsize[1][type];
	UpdateData(TRUE);
	m_binsize[1][type] = LIMIT_DECIMAL_PLACES( m_binsize[1][type], 3 );
	if ( m_binsize[1][type] > ZERO_TOLERANCE )
	{	
		BuildHistogram();
		DrawHistogram(1);
	}
	else
	{
		m_binsize[1][type] = backup;
	}
	UpdateData(FALSE);
}
void CHistogramDialog::OnDeltaposYScale2(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	double new_scale = LIMIT_DECIMAL_PLACES( ScaleToNewValue( m_ymax[1], ( pNMUpDown->iDelta < 0 ) ), 3 );
	if ( new_scale > ZERO_TOLERANCE )	m_ymax[1] = new_scale;
	if ( new_scale > 1.0 )	m_ymax[1] = 1.0;
	*pResult = 0;
	DrawHistogram(1);
}
void CHistogramDialog::OnDeltaposXScale2(NMHDR *pNMHDR, LRESULT *pResult)
{
	int type = m_histogram_cbindex[1];
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	double new_scale = LIMIT_DECIMAL_PLACES( ScaleToNewValue( m_xscale[type], ( pNMUpDown->iDelta < 0 ) ), 3 );
	if ( new_scale > ZERO_TOLERANCE )	m_xscale[type] = new_scale;
	*pResult = 0;

	double scale = m_xscale[type];
	if ( type != FRET_HIST )
		for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
			m_xscale[j] = scale;

	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}

void CHistogramDialog::OnDeltaposXOffset2(NMHDR *pNMHDR, LRESULT *pResult)
{
	int type = m_histogram_cbindex[1];
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )
		m_xoffset[type] -= m_xscale[type];
	else
		m_xoffset[type] += m_xscale[type];
	*pResult = 0;

	double offset = m_xoffset[type];
	if ( type != FRET_HIST )
		for ( int j = CH1_HIST ; j < NUM_HIST_TYPES ; j++ )
			m_xoffset[j] = offset;

	for ( int i = 0 ; i < 2 ; i++ )
		DrawHistogram(i);
}