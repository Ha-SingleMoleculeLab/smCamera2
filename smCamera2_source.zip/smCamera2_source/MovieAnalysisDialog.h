#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "CameraFile.h"
#include "Mapping.h"
#include "PeakFinder.h"
#include "FrameSequence.h"

// CMovieAnalysisDialog dialog

class CMovieAnalysisDialog : public CDialog
{
	DECLARE_DYNAMIC(CMovieAnalysisDialog)

public:
	CMovieAnalysisDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMovieAnalysisDialog();

// Dialog Data
	enum { IDD = IDD_ANALYSIS };
protected:
    virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CDirectoryTraverse m_directory;
	CFilm m_film;
	//CameraFileReader *m_reader;
	CPeakFinder m_peak_finder;
	CMapping m_mapping;
	
	CPoint m_point[NUM_CHANNELS];

	int m_spot_radius;
	
	BOOL GetFrameCoordinate(CPoint pt, int *x, int *y);
	void InitFrame(UINT w, UINT h);
	void FreeFrame();
	void UpdateFrame();
	void DrawCircle(CDC &dcMem, int x, int y);
	void DrawCircle(CDC &dcMem, int x, int y, int r, COLORREF color);
    void DrawPointPairs(CClientDC &dcDlg, CDC &dcMem, CPoint pair[NUM_CHANNELS]);

	CBitmap	*m_bitmap;
	COLORREF *m_display_buffer;
	int m_image_left;
	int m_image_top;
	int m_image_height;
	int m_image_width;
	int m_spot_left[NUM_CHANNELS];
	int m_spot_top[NUM_CHANNELS];
	int m_spot_height[NUM_CHANNELS];
	int m_spot_width[NUM_CHANNELS];
	CStatic m_image;
	CStatic m_spot[NUM_CHANNELS];

	CFrameSequence m_fs;
	CString m_fspath;	
	BOOL m_repeat_fs;


	double m_peak_radius;
	double m_peak_threshold;
	BOOL m_find_CH1;
	BOOL m_find_CH2;
	BOOL m_find_and_save;

	double m_peak_sigma;
	BOOL m_analyze_bad_peaks;
	BOOL m_analyze_again;	
	BOOL m_analyze_bg_peaks;
	void AnalyzeFile(BOOL analyze_again);
	void AnalyzeFolder(LPCTSTR folder);

	BOOL m_is_analyzing;
	BOOL m_stop_analyzing;


	void SetUIs();

	CSliderCtrl m_slider;

	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	afx_msg void OnDeltaposSpinr1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinr2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinx1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinx2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny2(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnBnClickedOpenFile();
	afx_msg void OnBnClickedLoadMap();

	afx_msg void OnBnClickedLoadFs();
	afx_msg void OnBnClickedRepeatFs();
	afx_msg void OnBnClickedApplyFs();
	
	afx_msg void OnEnKillfocusPeakRadius();
	afx_msg void OnEnKillfocusPeakThreshold();
	afx_msg void OnBnClickedFindCh1();
	afx_msg void OnBnClickedFindCh2();	
	afx_msg void OnBnClickedFindAndSave();
	afx_msg void OnBnClickedFindPeaks();

	afx_msg void OnEnKillfocusPeakSigma();
	afx_msg void OnBnClickedAnalyzeAgain();
	afx_msg void OnBnClickedAnalyzeBadPeaks();	
	afx_msg void OnBnClickedAnalyzeBgPeaks();
	afx_msg void OnBnClickedAnalyze();
	afx_msg void OnBnClickedAnalyzeFolder();
};