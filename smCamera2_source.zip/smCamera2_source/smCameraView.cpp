// smCameraView.cpp : implementation of the CsmCameraView class
//

#include "stdafx.h"
#include "smCamera.h"

#include "smCameraDoc.h"
#include "smCameraView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsmCameraView

IMPLEMENT_DYNCREATE(CsmCameraView, CEditView)

BEGIN_MESSAGE_MAP(CsmCameraView, CEditView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)

	ON_COMMAND(ID_DEVICES_CAMERA, OnDevicesCamera)
	ON_COMMAND(ID_DEVICES_SHUTTER_CONFIG, OnDevicesShutterConfig)
	ON_COMMAND(ID_DEVICES_SHUTTER_CONTROLLERS_NI_PCI_6722, OnDevicesShutterController_NI_PCI_6722)
	ON_COMMAND(ID_DEVICES_SHUTTER_CONTROLLERS_NI_PCI_6503, OnDevicesShutterController_NI_PCI_6503)
	ON_COMMAND(ID_DEVICES_SHUTTER_STATUS, OnDevicesShutterStatus)
	
	ON_COMMAND(ID_TOOLS_RECORDER, OnToolsRecorder)
	ON_COMMAND(ID_TOOLS_ANALYSIS, OnToolsAnalysis)
	ON_COMMAND(ID_TOOLS_MAPPER, OnToolsMapper)
	ON_COMMAND(ID_TOOLS_CONVERTER, OnToolsConverter)
	ON_COMMAND(ID_TOOLS_HISTOGRAM, OnToolsHistogram)
	ON_COMMAND(ID_TOOLS_TRACE, OnToolsTrace)
END_MESSAGE_MAP()

// CsmCameraView construction/destruction

CsmCameraView::CsmCameraView()
{
	m_camera_dlg =  NULL;
	m_shutter_config_dlg = NULL;
	m_NI_PCI_6503_dlg = NULL;
	m_NI_PCI_6722_dlg = NULL;
	m_status_dlg = NULL;

	m_movie_recorder_dlg =  NULL;
	m_movie_analysis_dlg =  NULL;
	m_movie_mapper_dlg =  NULL;
	m_converter_dlg =  NULL;
	m_histogram_dlg =  NULL;
	m_trace_dlg =  NULL;
}

CsmCameraView::~CsmCameraView()
{
	if ( m_camera_dlg )
	{
		if ( ::IsWindow( m_camera_dlg->m_hWnd ) )	m_camera_dlg->DestroyWindow();
		delete m_camera_dlg;
	}

	if ( m_shutter_config_dlg )
	{
		if ( ::IsWindow( m_shutter_config_dlg->m_hWnd ) )	m_shutter_config_dlg->DestroyWindow();
		delete m_shutter_config_dlg;
	}
	
	if ( m_NI_PCI_6503_dlg )
	{
		if ( ::IsWindow( m_NI_PCI_6503_dlg->m_hWnd ) )	m_NI_PCI_6503_dlg->DestroyWindow();
		delete m_NI_PCI_6503_dlg;
	}

	if ( m_NI_PCI_6722_dlg )
	{
		if ( ::IsWindow( m_NI_PCI_6722_dlg->m_hWnd ) )	m_NI_PCI_6722_dlg->DestroyWindow();
		delete m_NI_PCI_6722_dlg;
	}

	if ( m_status_dlg )
	{
		if ( ::IsWindow( m_status_dlg->m_hWnd ) )	m_status_dlg->DestroyWindow();
		delete m_status_dlg;
	}

	if ( m_movie_recorder_dlg )
	{
		if ( ::IsWindow( m_movie_recorder_dlg->m_hWnd ) )	m_movie_recorder_dlg->DestroyWindow();
		delete m_movie_recorder_dlg;
	}
	if ( m_movie_analysis_dlg )
	{
		if ( ::IsWindow( m_movie_analysis_dlg->m_hWnd ) )	m_movie_analysis_dlg->DestroyWindow();
		delete m_movie_analysis_dlg;
	}
	if ( m_movie_mapper_dlg )
	{
		if ( ::IsWindow( m_movie_mapper_dlg->m_hWnd ) )	m_movie_mapper_dlg->DestroyWindow();
		delete m_movie_mapper_dlg;
	}
	if ( m_converter_dlg )
	{
		if ( ::IsWindow( m_converter_dlg->m_hWnd ) )	m_converter_dlg->DestroyWindow();
		delete m_converter_dlg;
	}
	if ( m_histogram_dlg )
	{
		if ( ::IsWindow( m_histogram_dlg->m_hWnd ) )	m_histogram_dlg->DestroyWindow();
		delete m_histogram_dlg;
	}
	if ( m_trace_dlg )
	{
		if ( ::IsWindow( m_trace_dlg->m_hWnd ) )	m_trace_dlg->DestroyWindow();
		delete m_trace_dlg;
	}
}


BOOL CsmCameraView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}


// CsmCameraView printing

BOOL CsmCameraView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CsmCameraView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CsmCameraView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}


// CsmCameraView diagnostics

#ifdef _DEBUG
void CsmCameraView::AssertValid() const
{
	CView::AssertValid();
}

void CsmCameraView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CsmCameraDoc* CsmCameraView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CsmCameraDoc)));
	return (CsmCameraDoc*)m_pDocument;
}
#endif //_DEBUG


// CsmCameraView message handlers

void CsmCameraView::OnDevicesCamera()
{
	if ( m_camera_dlg )
	{
		if ( ::IsWindow( m_camera_dlg->m_hWnd ) )
		{
			m_camera_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_camera_dlg;
			m_camera_dlg = NULL;
		}
	}
	if ( !m_camera_dlg )
	{
		m_camera_dlg = new CCameraDialog(this);
		if ( m_camera_dlg->Create(m_camera_dlg->IDD, this) )
			m_camera_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_camera_dlg;
			m_camera_dlg = NULL;
		}
	}
}

void CsmCameraView::OnDevicesShutterConfig()
{
	if ( m_shutter_config_dlg )
	{
		if ( ::IsWindow( m_shutter_config_dlg->m_hWnd ) )
		{
			m_shutter_config_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_shutter_config_dlg;
			m_shutter_config_dlg = NULL;
		}
	}
	if ( !m_shutter_config_dlg )
	{
		m_shutter_config_dlg = new CConfigDialog(this);
		if ( m_shutter_config_dlg->Create(m_shutter_config_dlg->IDD, this) )
			m_shutter_config_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_shutter_config_dlg;
			m_shutter_config_dlg = NULL;
		}
	}
}

void CsmCameraView::OnDevicesShutterController_NI_PCI_6503()
{
	if ( m_NI_PCI_6503_dlg )
	{
		if ( ::IsWindow(  m_NI_PCI_6503_dlg->m_hWnd ) )
		{
			 m_NI_PCI_6503_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete  m_NI_PCI_6503_dlg;
			 m_NI_PCI_6503_dlg = NULL;
		}
	}
	if ( !m_NI_PCI_6503_dlg)
	{
		m_NI_PCI_6503_dlg = new CNI_PCI_6503_Dialog(this);
		if ( m_NI_PCI_6503_dlg->Create(m_NI_PCI_6503_dlg->IDD, this) )
			m_NI_PCI_6503_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_NI_PCI_6503_dlg;
			m_NI_PCI_6503_dlg = NULL;
		}
	}
}

void CsmCameraView::OnDevicesShutterController_NI_PCI_6722()
{
	if ( m_NI_PCI_6722_dlg )
	{
		if ( ::IsWindow( m_NI_PCI_6722_dlg->m_hWnd ) )
		{
			m_NI_PCI_6722_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_NI_PCI_6722_dlg;
			m_NI_PCI_6722_dlg = NULL;
		}
	}
	if ( !m_NI_PCI_6722_dlg )
	{
		m_NI_PCI_6722_dlg = new CNI_PCI_6722_Dialog(this);
		if ( m_NI_PCI_6722_dlg->Create(m_NI_PCI_6722_dlg->IDD, this) )
			m_NI_PCI_6722_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_NI_PCI_6722_dlg;
			m_NI_PCI_6722_dlg = NULL;
		}
	}
}

void CsmCameraView::OnDevicesShutterStatus()
{
	if ( m_status_dlg )
	{
		if ( ::IsWindow( m_status_dlg->m_hWnd ) )
		{
			m_status_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_status_dlg;
			m_status_dlg = NULL;
		}
	}
	if ( !m_status_dlg )
	{
		m_status_dlg = new CStatusDialog(this);
		if ( m_status_dlg->Create(m_status_dlg->IDD, this) )
			m_status_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_status_dlg;
			m_status_dlg = NULL;
		}
	}
}

void CsmCameraView::OnToolsRecorder()
{
	if ( m_movie_recorder_dlg )
	{
		if ( ::IsWindow( m_movie_recorder_dlg->m_hWnd ) )
		{
			m_movie_recorder_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_movie_recorder_dlg;
			m_movie_recorder_dlg = NULL;
		}
	}
	if ( !m_movie_recorder_dlg )
	{
		m_movie_recorder_dlg = new CMovieRecorderDialog(this);
		if ( m_movie_recorder_dlg->Create(m_movie_recorder_dlg->IDD, this) )
			m_movie_recorder_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_movie_recorder_dlg;
			m_movie_recorder_dlg = NULL;
		}
	}
}

void CsmCameraView::OnToolsAnalysis()
{
	if ( m_movie_analysis_dlg )
	{
		if ( ::IsWindow( m_movie_analysis_dlg->m_hWnd ) )
		{
			m_movie_analysis_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_movie_analysis_dlg;
			m_movie_analysis_dlg = NULL;
		}
	}
	if ( !m_movie_analysis_dlg )
	{
		m_movie_analysis_dlg = new CMovieAnalysisDialog(this);
		if ( m_movie_analysis_dlg->Create(m_movie_analysis_dlg->IDD, this) )
			m_movie_analysis_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_movie_analysis_dlg;
			m_movie_analysis_dlg = NULL;
		}
	}
}

void CsmCameraView::OnToolsMapper()
{
	if ( m_movie_mapper_dlg )
	{
		if ( ::IsWindow( m_movie_mapper_dlg->m_hWnd ) )
		{
			m_movie_mapper_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_movie_mapper_dlg;
			m_movie_mapper_dlg = NULL;
		}
	}
	if ( !m_movie_mapper_dlg )
	{
		m_movie_mapper_dlg = new CMovieMapperDialog(this);
		if ( m_movie_mapper_dlg->Create(m_movie_mapper_dlg->IDD, this) )
			m_movie_mapper_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_movie_mapper_dlg;
			m_movie_mapper_dlg = NULL;
		}
	}
}

void CsmCameraView::OnToolsConverter()
{
	if ( m_converter_dlg )
	{
		if ( ::IsWindow( m_converter_dlg->m_hWnd ) )
		{
			m_converter_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_converter_dlg;
			m_converter_dlg = NULL;
		}
	}
	if ( !m_converter_dlg )
	{
		m_converter_dlg = new CConverterDialog(this);
		if ( m_converter_dlg->Create(m_converter_dlg->IDD, this) )
			m_converter_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_converter_dlg;
			m_converter_dlg = NULL;
		}
	}
}

void CsmCameraView::OnToolsHistogram()
{
	if ( m_histogram_dlg )
	{
		if ( ::IsWindow( m_histogram_dlg->m_hWnd ) )
		{
			m_histogram_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_histogram_dlg;
			m_histogram_dlg = NULL;
		}
	}
	if ( !m_histogram_dlg )
	{
		m_histogram_dlg = new CHistogramDialog(this);
		if ( m_histogram_dlg->Create(m_histogram_dlg->IDD, this) )
			m_histogram_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_histogram_dlg;
			m_histogram_dlg = NULL;
		}
	}
}

void CsmCameraView::OnToolsTrace()
{
	if ( m_trace_dlg )
	{
		if ( ::IsWindow( m_trace_dlg->m_hWnd ) )
		{
			m_trace_dlg->BringWindowToTop();
			return;
		}
		else
		{
			delete m_trace_dlg;
			m_trace_dlg = NULL;
		}
	}
	if ( !m_trace_dlg )
	{
		m_trace_dlg = new CTraceDialog(this);
		if ( m_trace_dlg->Create(m_trace_dlg->IDD, this) )
			m_trace_dlg->ShowWindow(SW_SHOW);
		else
		{
			delete m_trace_dlg;
			m_trace_dlg = NULL;
		}
	}
}

