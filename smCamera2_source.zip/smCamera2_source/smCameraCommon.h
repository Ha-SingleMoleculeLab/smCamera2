#pragma once
#include "../LKSLib/LKSLibCommon.h"

#define PROGRAM_NAME		_T("smCamera")
#define PROGRAM_MAX_PATH	(1024)


/*********************** Devices Management *************************************/
void InitDevices();
void FreeDevices();

/*********************** Timer Management *************************************/
#define CAMERADIALOG_TIMER		(0)

/*********************** File Management *************************************/

extern CString _PATH_ROOT;

extern CString _PATH_COMMON;
extern CString _PATH_DEVICES;
extern CString _PATH_TOOLS;
extern CString _PATH_MOVIES;

extern CString _PATH_FRAME_SEQUENCE;
extern CString _PATH_CAMERA;
extern CString _PATH_MOVIE_RECORDER;
extern CString _PATH_MOVIE_ANALYSIS;
extern CString _PATH_MOVIE_MAPPER;
extern CString _PATH_HISTOGRAM;
extern CString _PATH_TRACE;
extern CString _PATH_FAKE;

extern void PickContainer();


/*********************** Timer Management *************************************/
#define STATUS_DIALOG_TIMER		(0)

/*********************** File Management *************************************/

extern CString _PATH_SHUTTER;
extern CString _PATH_SHUTTER_CONTROLERS;
extern CString _PATH_SHUTTER_CONTROLERS_NI_PCI_6503;
extern CString _PATH_SHUTTER_CONTROLERS_NI_PCI_6722;




/*********************** Color Table *************************************/
#define RGBReverse(r,g,b)	RGB(b,g,r)
void LoadProgramColorTable();
COLORREF ProgramColor0(int ch, UINT8 byte);
COLORREF ProgramColor1(int ch, UINT8 byte);
UINT16 *ProgramTIFFR();
UINT16 *ProgramTIFFG();
UINT16 *ProgramTIFFB();