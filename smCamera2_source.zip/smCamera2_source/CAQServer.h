#pragma once
#include "CAQ.h"
#include "LocalSharedMemory.h"

class CCAQServer
{
public:
	CCAQServer();
	virtual ~CCAQServer();

	int CAQServerInit(UINT w, UINT h, UINT32 size);
	int CAQServerFree();
	int CAQServerStart(double sampling_rate);
	//int CAQServerRestart();
	int CAQServerStop();
	int CAQServerSync(UINT num);

	int OpenBufferingSpace(UINT num);
	int CloseBufferingSpace(UINT num);

	inline BOOL IsInitialized()	{	return ( m_header != NULL );	}
	inline BOOL IsRunning()		{	return ( m_header && m_header->is_running );	}
	
	
	inline UINT32* CAQServerReadImage(UINT64 index)
	{
		if ( index < m_header->num_dismissed )	return NULL;
		UINT w = m_header->frame_w;
		UINT h = m_header->frame_h;
		return &( m_image_data[ ( index % m_header->size )*w*h ] );
	}
	inline UINT32* CAQServerReadImage()
	{
		if ( m_header->num_acquired <= m_header->num_dismissed )	return NULL;
		return CAQServerReadImage( m_header->num_acquired - 1 );
	}
	UINT32 CAQServerReadPixel(UINT64 index, UINT x, UINT y);
	inline UINT32 CAQServerReadPixel(UINT x, UINT y)
	{
		if ( m_header->num_acquired <= m_header->num_dismissed )	return 0;
		return CAQServerReadPixel( m_header->num_acquired - 1 , x, y ) ;	
	}
//	inline UINT32 CAQServerReadPixel(UINT64 index, UINT x, UINT y)

public:

	//static const UINT8 m_camera_bpp = 4;	
	//LKSCHANGE: camera_bpp is assumed to be 4, UINT32
	//It is because in some old machines, byte conversion is too slow.

	CLocalSharedMemory m_shmem;
	CCAQHeader *m_header;
	//CCAQPoint *m_point_data;
	UINT32 *m_image_data;

	UINT32 m_num_bufferable;
	UINT32 *m_buffering_space;
};