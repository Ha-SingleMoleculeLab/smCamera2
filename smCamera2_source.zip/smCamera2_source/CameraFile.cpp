#include "stdafx.h"
#include "smCamera.h"
#include "CameraFile.h"
#include "Circle.h"
#include "libtiff/tiffio.h"
#include <math.h>

/************************************************************************************/
/***************				CPeaksFileWriter					*****************/
/************************************************************************************/
int CPeaksFileWriter::SetFilepath(LPCTSTR filepath, BOOL bg)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, (!bg) ? CAMERAFILE_PEAKS_EXT:CAMERAFILE_BGPEAKS_EXT);
	return ( DoesProgramFileExist( m_filepath ) ) ? 1 : 0 ;
}

int CPeaksFileWriter::Write(UINT16 w, UINT16 h, CArray<CPeakSet> *peaks)
{
	CString str;
	CArchive *ar;

	if ( m_filepath.IsEmpty() )	return -1;

	ar = OpenProgramFileToWrite( m_filepath ) ;
	if ( ar == NULL )	return -1;

	ar->WriteString(_T("Frame Resolution\r\n"));
	str.Format(_T("%u %u\r\n"), w, h);
	ar->WriteString(str);

	ar->WriteString(_T("Num Channels\r\n"));
	str.Format(_T("%d\r\n"), NUM_CHANNELS);
	ar->WriteString(str);

	ar->WriteString(_T("Num Peak Sets\r\n"));
	str.Format(_T("%d\r\n"), (int) peaks->GetCount());
	ar->WriteString(str);

	for ( int i = 0 ; i < peaks->GetCount() ; i++ )
	{
		CPeakSet &set = (*peaks)[i];
		str = _T("");

		for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
		{
			if ( k != CH1 )	str.AppendFormat(_T(", "));

			str.AppendFormat(_T("%.2f %.2f %.2f %.2f %d"), 
								set.p[k].x, set.p[k].sx, set.p[k].y, set.p[k].sy, set.p[k].is_good);
		}
		str.AppendFormat(_T("\r\n"));
		ar->WriteString(str);
	}
	CloseProgramFile(ar);

	return 0;
}

/************************************************************************************/
/***************				CPeaksFileReader					*****************/
/************************************************************************************/
int CPeaksFileReader::Read(LPCTSTR filepath)
{
	if ( !filepath )	return -1;

	CString str;
	str = filepath;
	if ( str.IsEmpty() )	return -1;

	CArchive *ar;
	if ( DoesProgramFileExist( filepath ) != TRUE )	return -1;
	ar = OpenProgramFileToRead( filepath );
	if ( ar == NULL )	return -1;

	m_frame_w = 0;
	m_frame_h = 0;
	m_peaks.SetSize(0);


	CString line;
	if ( ar->ReadString(line) != TRUE )	goto FAIL;
	if ( ar->ReadString(line) != TRUE )	goto FAIL;
	int n = line.Find(_T(" "));
	if ( n <= 0 )	goto FAIL;
	m_frame_w = _tstoi( line.Mid(0, n) );
	m_frame_h = _tstoi( line.Mid(n+1) );

	if ( ar->ReadString(line) != TRUE )	goto FAIL;
	if ( ar->ReadString(line) != TRUE )	goto FAIL;
	int num_channels = _tstoi( line );
	if ( num_channels != NUM_CHANNELS )	goto FAIL;
	
	if ( ar->ReadString(line) != TRUE )	goto FAIL;
	if ( ar->ReadString(line) != TRUE )	goto FAIL;
	int num_peaks = _tstoi( line );

	m_peaks.SetSize(num_peaks);
	for ( int i = 0 ; i < num_peaks ; i++ )
	{
		CPeakSet set;
        if ( ar->ReadString(line) != TRUE )	goto FAIL;
		for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
		{
			int n;
			CString token;

			line.Trim();
			if ( line.IsEmpty() )	goto FAIL;

			n = line.Find(_T(","));
			if ( n >= 0 )
			{
				token = line.Mid(0, n);
				line = line.Mid(n+1);
			}
			else
			{
				token = line;
				line = _T("");
			}

			n = token.Find(_T(" "));
			if ( n < 0 )	goto FAIL;
			set.p[k].x = (float) _tcstod( token.Mid(0, n), NULL );
			token = token.Mid(n+1);
			n = token.Find(_T(" "));
			if ( n < 0 )	goto FAIL;
			set.p[k].sx = (float) _tcstod( token.Mid(0, n), NULL );
			token = token.Mid(n+1);
			n = token.Find(_T(" "));
			if ( n < 0 )	goto FAIL;
			set.p[k].y = (float) _tcstod( token.Mid(0, n), NULL );
			token = token.Mid(n+1);
			n = token.Find(_T(" "));
			if ( n < 0 )	goto FAIL;
			set.p[k].sy = (float) _tcstod( token.Mid(0, n), NULL );
			set.p[k].is_good = _tstoi( token.Mid(n+1) );
		}
		m_peaks.Add( set );
	}
	CloseProgramFile(ar);
	return 0;
FAIL:
	CloseProgramFile(ar);
	m_peaks.SetSize(0);
	return -1;
}

int CPeaksFileReader::ReadPeaksFileOf(LPCTSTR filepath)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	str.AppendFormat(_T(".%s"), CAMERAFILE_PEAKS_EXT);
	return Read( str );
}


/************************************************************************************/
/***************				CPeakTraceFileWriter					*****************/
/************************************************************************************/
int CPeakTraceFileWriter::SetFilepath(LPCTSTR filepath)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, CAMERAFILE_PEAKTRACE_EXT);
	return ( DoesProgramFileExist( m_filepath ) ) ? 1 : 0 ;
}

int CPeakTraceFileWriter::Open()
{
	if ( IsOpen() )	return -1;
	if ( m_filepath.IsEmpty() )	return -1;

	CString str;

	if ( m_filepath.IsEmpty() )	return -1;

	m_archive = OpenProgramFileToWrite( m_filepath ) ;
	if ( m_archive == NULL )	return -1;

	m_archive->WriteString(_T("Frame Resolution\r\n"));
	str.Format(_T("%u %u\r\n"), m_frame_w, m_frame_h);
	m_archive->WriteString(str);

//	m_archive->WriteString(_T("Kinetic Cycle Time [ms]\r\n"));
//	str.Format(_T("%.3f\r\n"), m_frame_cycle);
//	m_archive->WriteString(str);

	m_archive->WriteString(_T("Num Channels\r\n"));
	str.Format(_T("%d\r\n"), NUM_CHANNELS);
	m_archive->WriteString(str);

	return 0;
}

int CPeakTraceFileWriter::Close()
{
	m_frame_w = 0;
	m_frame_h = 0;

//	m_frame_cycle = 0.0;

	if ( m_archive )	CloseProgramFile(m_archive);
	m_archive = NULL;
	return 0;
}

int CPeakTraceFileWriter::Write(UINT frame_no, CPeakSet *peaks)
{
	if ( !IsOpen() )	return -1;

	CString str;
	str = _T("");
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( i != CH1 )	str.AppendFormat(_T(", "));
		str.AppendFormat(_T("%5u \t %.2f \t %.2f"), frame_no, peaks->p[i].x, peaks->p[i].y);
	}
	str.AppendFormat(_T("\r\n"));
	m_archive->WriteString(str);

	return 0;
}

/************************************************************************************/
/***************				CTIFFFileWriter						*****************/
/************************************************************************************/
int CTIFFFileWriter::SetFilepath(LPCTSTR filepath)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, CAMERAFILE_TIFF1_EXT);
	return ( DoesProgramFileExist( m_filepath ) ) ? 1 : 0 ;
}

int CTIFFFileWriter::Open()
{
	if ( IsOpen() )	return -1;
	
	if ( m_8bit_color )	m_byte_per_pixel = 1;

	//m_tiff = TIFFOpen(m_filepath, "w");
	m_tiff = (void *) TIFFOpen(m_filepath, "w");
	if ( m_tiff == NULL )	return -1;

	return 0;
}

int CTIFFFileWriter::Close()
{
	if ( m_tiff )
	{
		//TIFFClose(m_tiff);
		TIFFClose((TIFF *)m_tiff);
		m_tiff = NULL;
	}

	m_filepath = _T("");

	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = 1;

	m_byte_per_pixel = 1;
	m_8bit_color = TRUE;

	return 0;
}

int CTIFFFileWriter::Write(int num_frames, double *images)
{
	if ( num_frames == 0 )	return 0;
	else if ( !m_tiff || !images || num_frames < 0 )	return -1;


	UINT8 *buffer = new UINT8[m_byte_per_pixel*m_frame_w*m_frame_h];
	for ( int i = 0 ; i < num_frames ; i++ )
	{
		UINT32 limit = (1<< (8*m_byte_per_pixel)) - 1;
		UINT32 pixel;
		UINT8 *ptr;
		UINT num_pixels = m_frame_w * m_frame_h ;

		for ( UINT k = 0; k < num_pixels ; k++ )
		{
			if ( m_byte_per_pixel == 1 )	pixel = (UINT32) Pixel2Byte( (UINT32)images[num_pixels*i + k] );
			else
			{
				pixel = (UINT32) images[num_pixels*i + k];
				if ( m_byte_per_pixel != 4 && pixel > limit )	pixel = limit;
			}
			ptr = (UINT8 *)(&pixel);
			for ( UINT m = 0 ; m < m_byte_per_pixel ; m++ )
			{
				buffer[m_byte_per_pixel*k + m] = *(ptr+m);
			}
		}
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_IMAGEWIDTH, m_frame_w );
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_IMAGELENGTH, m_frame_h );
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_BITSPERSAMPLE, 8*m_byte_per_pixel );
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_SAMPLESPERPIXEL, 1);
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE );
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_ROWSPERSTRIP, m_frame_h );
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB);
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_XRESOLUTION, 100.0);
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_YRESOLUTION, 100.0);
		TIFFSetField((TIFF *)m_tiff, TIFFTAG_RESOLUTIONUNIT, RESUNIT_INCH);

		if ( m_8bit_color )
		{
			TIFFSetField((TIFF *)m_tiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_PALETTE);
			TIFFSetField((TIFF *)m_tiff, TIFFTAG_COLORMAP, ProgramTIFFR(), ProgramTIFFG(), ProgramTIFFB());	
		}
		else
			TIFFSetField((TIFF *)m_tiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK);

		for ( UINT k = 0 ; k < m_frame_h ; k++ )
		{
			tdata_t buf = (tdata_t) ( buffer + m_byte_per_pixel*m_frame_w*k );
			TIFFWriteScanline((TIFF *)m_tiff, buf, k, 0 );
		}
		TIFFWriteDirectory((TIFF *)m_tiff);
	}
	delete [] buffer;

	return num_frames;
}


/************************************************************************************/
/***************				CTIFFFileReader						*****************/
/************************************************************************************/
int CTIFFFileReader::Open(LPCTSTR filepath)
{
	if ( IsOpen() )	return -1;
	if ( !filepath )	return -1;

	m_filepath = filepath;
	if ( m_filepath.IsEmpty() )	return -1;

	//m_tiff = TIFFOpen( m_filepath, "r" );
	m_tiff = (void *) TIFFOpen( m_filepath, "r" );
	if ( m_tiff == NULL )	return -1;

	uint32 u32;
	uint16 u16;
	if ( TIFFGetField((TIFF *)m_tiff, TIFFTAG_IMAGEWIDTH, &u32) == 0 )	goto FAIL;
	m_frame_w = u32;
	if ( TIFFGetField((TIFF *)m_tiff, TIFFTAG_IMAGELENGTH, &u32) == 0 )	goto FAIL;
	m_frame_h = u32;
	if ( TIFFGetField((TIFF *)m_tiff, TIFFTAG_BITSPERSAMPLE, &u16) == 0 )	goto FAIL;
	if ( u16 % 8 != 0 )	goto FAIL;
	m_byte_per_pixel = u16/8;

	m_num_frames = 0;
	do
	{
		m_num_frames++;
	}
	while ( TIFFReadDirectory((TIFF *)m_tiff) );

	MoveFrame(0);
	return 0;
FAIL:
	Close();
	return -1;
}	

int CTIFFFileReader::Close()
{
	if ( m_tiff )
	{
		//TIFFClose(m_tiff);
		TIFFClose((TIFF *)m_tiff);
		m_tiff = NULL;
	}

	m_filepath = _T("");
	
	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = 255;

	m_byte_per_pixel = 1;
	m_num_frames = 0;

	return 0;
}

int CTIFFFileReader::FrameNo()
{	
	if ( !m_tiff )	return -1;
	return (int) TIFFCurrentDirectory((TIFF *)m_tiff);
}
int CTIFFFileReader::MoveFrame(UINT frame_no)
{
	if ( !m_tiff )	return -1;
	return ( TIFFSetDirectory((TIFF *)m_tiff, (tdir_t)frame_no) == 0 ) ? -1 : 0 ;
}

int CTIFFFileReader::ReadFrame(double *pFrame)
{
	if ( !m_tiff || !pFrame )	return -1;

	UINT8 *scanline = new UINT8[m_byte_per_pixel*m_frame_w];
	for ( UINT y = 0; y < m_frame_h ; y++ )
	{
		//TIFFReadScanline( m_tiff, (tdata_t) scanline, y, 0 );
		TIFFReadScanline( (TIFF *)m_tiff, (tdata_t) scanline, y, 0 );

		UINT x = 0;
	
		for ( UINT x = 0 ; x < m_frame_w ; x++ )
		{
			static UINT32 pixel;
			pixel = 0x00000000;
			for ( UINT k = 0 ; k < m_byte_per_pixel ; k++ )
			{
				*(((UINT8 *)(&pixel))+k) = scanline[m_byte_per_pixel*x + k];
			}

			if ( m_byte_per_pixel == 1 )
				pFrame[m_frame_w*y + x] = (double) ( m_background + m_data_scaler * pixel * 1.0 / 255) ;
			else
				pFrame[m_frame_w*y + x] = (double) pixel ;
		}
	}
	delete [] scanline;
	return 0;
}

/************************************************************************************/
/***************					CFilmLogFileWriter				*****************/
/************************************************************************************/
int CFilmLogFileWriter::SetFilepath(LPCTSTR filepath)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, CAMERAFILE_FLOG_EXT);
	return ( DoesProgramFileExist( m_filepath ) ) ? 1 : 0 ;
}

int CFilmLogFileWriter::Write
	( UINT64 server_index, UINT16 frame_w, UINT16 frame_h, UINT32 background, UINT32 scaler, UINT8 byte_per_pixel,
		CString info, int bit_depth, int gain, double exposure_time, double frame_cycle,
		int area_left, int area_right, int area_bottom, int area_top )
{
	CString str;
	CArchive *ar;

	if ( m_filepath.IsEmpty() )	return -1;

	ar = OpenProgramFileToWrite( m_filepath ) ;
	if ( ar == NULL )	return -1;

	__time64_t tmp_time64;
	_time64( &tmp_time64 );
	struct tm *tmp_tm;
	tmp_tm = _localtime64( &tmp_time64 );
	ar->WriteString(_T("Filming Date and Time\r\n"));
	str.Format(_T("%s \r\n"), _tasctime( tmp_tm ) );
	ar->WriteString(str);
	ar->WriteString(_T("Server Index\r\n"));
	str.Format(_T("%I64u\r\n"), server_index);
	ar->WriteString(str);

	ar->WriteString(_T("Frame Resolution\r\n"));
	str.Format(_T("%u %u\r\n"), frame_w, frame_h );
	ar->WriteString(str);
	ar->WriteString(_T("Background\r\n"));
	str.Format(_T("%u\r\n"), background);
	ar->WriteString(str);
	ar->WriteString(_T("Data Scaler\r\n"));
	str.Format(_T("%u\r\n"), scaler);
	ar->WriteString(str);
	ar->WriteString(_T("Byte Per Pixel\r\n"));
	str.Format(_T("%u\r\n"), byte_per_pixel);
	ar->WriteString(str);

	ar->WriteString(_T("Camera Information\r\n"));
	str.Format(_T("%s\r\n"), info);
	ar->WriteString(str);
	ar->WriteString(_T("Camera Bit Depth\r\n"));
	str.Format(_T("%d\r\n"), bit_depth);
	ar->WriteString(str);	
	ar->WriteString(_T("Gain\r\n"));
	str.Format(_T("%d\r\n"), gain);
	ar->WriteString(str);
	ar->WriteString(_T("Exposure Time [ms]\r\n"));
	str.Format(_T("%.3f\r\n"), exposure_time);
	ar->WriteString(str);
	ar->WriteString(_T("Kinetic Cycle Time [ms]\r\n"));
	str.Format(_T("%.3f\r\n"), frame_cycle);
	ar->WriteString(str);
	ar->WriteString(_T("Lag Beetween Images	[ms]\r\n"));
	str.Format(_T("%.3f\r\n"), frame_cycle - exposure_time );
	ar->WriteString(str);
	ar->WriteString(_T("Active Area\r\n"));
	str.Format(_T("%d %d %d %d\r\n"), area_left, area_right, area_bottom, area_top );
	ar->WriteString(str);
	ar->WriteString(_T("\r\n\r\n"));
	CloseProgramFile(ar);

	return 0;
}

int CFilmLogFileWriter::AddComment(LPCTSTR comment)
{
	CString str;
	CArchive *ar;

	if ( m_filepath.IsEmpty() )	goto FAIL;

	ar = OpenProgramFileToAppend( m_filepath ) ;
	if ( ar == NULL )	goto FAIL;

	str = comment;
	str += _T("\r\n");
	ar->WriteString(str);
	CloseProgramFile(ar);

	return 0;
FAIL:
	LogErr(Stringify(_T("Failed to add a comment[%s]."), comment));
	return -1;
}



/************************************************************************************/
/***************					CFilmFileWriter					*****************/
/************************************************************************************/
int CFilmFileWriter::SetFilepath(LPCTSTR filepath)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, ( m_write_as_old_format ) ? CAMERAFILE_OLDFILM_EXT : CAMERAFILE_FILM_EXT );
	m_flog.SetFilepath( filepath );
	m_pktrace.SetFilepath( filepath );
	return ( DoesProgramFileExist( m_filepath ) ) ? 1 : 0 ;
}

int CFilmFileWriter::Open()
{
	if ( IsOpen() )	return -1;
	if ( m_filepath.IsEmpty() )	return -1;

	if ( m_write_as_old_format )
		m_byte_per_pixel = 1;

	try {	m_buffer = new UINT8[ m_byte_per_pixel * m_frame_w * m_frame_h ];	}
	catch(CException *e)
	{
		e->Delete();
		LogMsg(_T("Error"), _T("Memory allocation failed."));
		m_buffer = NULL;
		return -1;
	}

	try	{	m_file = new CFile( m_filepath, CFile::modeCreate | CFile::modeWrite );	}
	catch(CException *e)
	{
		e->Delete();
		LogMsg(_T("Error"), Stringify(_T("Film File [%s] Open Failed."), m_filepath));
		m_file = NULL;
		return -1;
	}

	if ( m_write_as_old_format )
	{
		m_file->Write((void *)&m_frame_w, sizeof(UINT16));
		m_file->Write((void *)&m_frame_h, sizeof(UINT16));
	}
	else
	{
		m_file->Write((void *)&m_frame_w, sizeof(UINT16));
		m_file->Write((void *)&m_frame_h, sizeof(UINT16));
		m_file->Write((void *)&m_byte_per_pixel, sizeof(UINT8));
		m_file->Write((void *)&m_background, sizeof(UINT32));
		m_file->Write((void *)&m_data_scaler, sizeof(UINT32));
		m_file->Write((void *)&m_frame_cycle, sizeof(float));
	}

	return 0;
}

int CFilmFileWriter::Close()
{
	m_pktrace.Close();

	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = 1;
	
	m_byte_per_pixel = 1;
	m_frame_cycle = 0.0;

	if ( m_buffer )
	{
		delete [] m_buffer;
		m_buffer = NULL;
	}

	if ( m_file )
	{
		m_file->Flush();
		m_file->Close();
		delete m_file;
		m_file = NULL;
	}
	return 0;
}
//int CFilmFileWriter::Write(UINT bpp, UINT8 *image)
int CFilmFileWriter::Write(UINT32 *image)
{
	if ( !m_file || !image )	return -1;

	UINT32 buffered_bytes = 0;	
	UINT32 limit = (1<< (8*m_byte_per_pixel)) - 1;
	UINT32 pixel;
	UINT8 *ppixel = (UINT8 *)(&pixel);
	UINT i, k, num_pixels = m_frame_w * m_frame_h ;
    for ( i = 0; i < num_pixels ; i++ )
	{
		if ( m_byte_per_pixel == 1 )	
		{
			m_buffer[buffered_bytes++] = Pixel2Byte( image[i] );
		}
		else
		{
			pixel = ( image[i] > limit ) ? limit : image[i];
			for ( k = 0 ; k < m_byte_per_pixel ; k++ )
			{
				m_buffer[buffered_bytes++] = *(ppixel+k);
			}
		}
	}

	m_file->Write( (void *)m_buffer, buffered_bytes );
	return 0;
}
/*
int CFilmFileWriter::Write(int num_frames, UINT32 *images)
{
	if ( num_frames == 0 )	return 0;
	else if ( !m_file || !images || num_frames < 0 )	return -1;

	UINT8 *buffer = (UINT8 *)images;
	UINT32 buffered_bytes = 0;
	
	UINT32 limit = (1<< (8*m_byte_per_pixel)) - 1;
	UINT32 pixel;
	UINT8 *ptr;
	UINT i, k, num_pixels = num_frames * m_frame_w * m_frame_h ;

    for ( i = 0; i < num_pixels ; i++ )
	{
		if ( m_byte_per_pixel == 1 )	pixel = (UINT32) Pixel2Byte(images[i]);
		else
		{
			pixel = (UINT32) images[i];
			if ( m_byte_per_pixel != 4 && pixel > limit )	pixel = limit;
		}
        ptr = (UINT8 *)(&pixel);
		for ( k = 0 ; k < m_byte_per_pixel ; k++ )
		{
			buffer[buffered_bytes++] = *(ptr+k);
		}
	}

	m_file->Write( (void *)buffer, buffered_bytes );
	return num_frames;
}
*/

/************************************************************************************/
/***************				CFilmFileReader						*****************/
/************************************************************************************/
int CFilmFileReader::Open(LPCTSTR filepath)
{
	if ( IsOpen() )	return -1;
	if ( !filepath )	return -1;

	m_filepath = filepath;
	if ( m_filepath.IsEmpty() )	return -1;

	int n;
	CString ext;

	try	{	m_file = new CFile( m_filepath, CFile::modeRead );	}
	catch(CException *e)
	{
		e->Delete();
		goto FAIL;
	}

	n = m_filepath.ReverseFind( (TCHAR)'.' );
	ext = m_filepath.Mid(n+1);
	if ( ext.CompareNoCase( CAMERAFILE_FILM_EXT ) == 0 )
	{
		if ( m_file->Read((void *)&m_frame_w, sizeof(UINT16)) != sizeof(UINT16) )	goto FAIL;
		if ( m_file->Read((void *)&m_frame_h, sizeof(UINT16)) != sizeof(UINT16) )	goto FAIL;
		if ( m_file->Read((void *)&m_byte_per_pixel, sizeof(UINT8)) != sizeof(UINT8) )	goto FAIL;
		if ( m_file->Read((void *)&m_background, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;
		if ( m_file->Read((void *)&m_data_scaler, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;
		if ( m_file->Read((void *)&m_frame_cycle, sizeof(float)) != sizeof(float) )	goto FAIL;

		m_header_size = 2*sizeof(UINT16) + sizeof(UINT8) + 2*sizeof(UINT32) + sizeof(float);
	}
	else if ( ext.CompareNoCase( CAMERAFILE_OLDFILM_EXT ) == 0 )
	{
		if ( m_file->Read((void *)&m_frame_w, sizeof(UINT16)) != sizeof(UINT16) )	goto FAIL;
		if ( m_file->Read((void *)&m_frame_h, sizeof(UINT16)) != sizeof(UINT16) )	goto FAIL;

		m_byte_per_pixel = 1;
		m_background = 0;
		m_data_scaler = 255;
		m_frame_cycle = 0.0;

		m_header_size = 2*sizeof(UINT16);
	}
	else	goto FAIL;


	m_num_frames = (UINT) (( m_file->GetLength() - m_header_size ) 
							* 1.0 / m_byte_per_pixel / m_frame_w / m_frame_h );

	try	{	m_frame_buffer = new UINT8[m_byte_per_pixel*m_frame_w*m_frame_h];	}
	catch(CException *e)
	{
		e->Delete();
		m_frame_buffer = NULL;
		goto FAIL;
	}

	return 0;
FAIL:
	LogMsg(_T("Error"), Stringify(_T("Film File [%s] Open Failed."), m_filepath));
	Close();
	return -1;
}

int CFilmFileReader::Close()
{
	if ( m_file )
	{
		m_file->Close();
		delete m_file;
		m_file = NULL;
	}

	if ( m_frame_buffer ) 
	{
		delete [] m_frame_buffer;
		m_frame_buffer = NULL;
	}

	m_filepath = _T("");

	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = ULONG_MAX;

	m_byte_per_pixel = 1;
	m_frame_cycle = 0.0;

	m_header_size = 0;
	m_num_frames = 0;

	return 0;	
}

int CFilmFileReader::ReadFrame(double *pFrame)
{
	if ( !m_file )	return -1;
    	
	UINT bytes_to_read = m_byte_per_pixel*m_frame_w*m_frame_h;
	UINT bytes_read = m_file->Read((void *)m_frame_buffer, bytes_to_read);
	UINT byte_idx = 0;
	UINT pixel_idx = 0;
	static UINT32 pixel;

	if ( pFrame )
	{
		while ( byte_idx < bytes_read )
		{
			pixel = 0x00000000;
			for ( UINT k = 0 ; k < m_byte_per_pixel ; k++ )
			{
				*(((UINT8 *)(&pixel))+k) = m_frame_buffer[byte_idx++];
			}
			
			if ( m_byte_per_pixel == 1 )
				pFrame[pixel_idx++] = Byte2Pixel(pixel);
			else
                pFrame[pixel_idx++] = 1.0 * pixel;
		}
	}

	if ( bytes_read == bytes_to_read )	return 0;
	if ( bytes_read != 0 )
	{
		LogMsg(_T("Error"), Stringify(_T("Unexpected End of Camera Film[%s] : to_read[%u] read[%u]bytes"), 
										m_filepath, bytes_to_read, bytes_read ) );
	}
	return -1;
}





/************************************************************************************/
/***************				CTraceLogFileWriter					*****************/
/************************************************************************************/
int CTraceLogFileWriter::SetFilepath(LPCTSTR filepath, BOOL bg)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, (!bg) ? CAMERAFILE_TLOG_EXT:CAMERAFILE_BGTLOG_EXT);
	return ( DoesProgramFileExist( m_filepath ) ) ? 1 : 0 ;
}

int CTraceLogFileWriter::Write
	( UINT16 frame_w, UINT16 frame_h, double frame_cycle, UINT32 num_frames,
		double peak_radius, double peak_sigma, BOOL find[NUM_CHANNELS] )
{
	if ( m_filepath.IsEmpty() )	return -1;

	CString str;
	CArchive *ar;

	ar = OpenProgramFileToWrite( m_filepath );
	if ( ar == NULL )	return -1;

	ar->WriteString(_T("Frame Resolution\r\n"));
	str.Format(_T("%u %u\r\n"), frame_w, frame_h);
	ar->WriteString(str);
	ar->WriteString(_T("Frame Cycle [ms]\r\n"));
	str.Format(_T("%.3f\r\n"), frame_cycle);
	ar->WriteString(str);
	ar->WriteString(_T("Num Frames\r\n"));
	str.Format(_T("%u\r\n"), num_frames);
	ar->WriteString(str);

	ar->WriteString(_T("Peak Radius[px]\r\n"));
	str.Format(_T("%.3f\r\n"), peak_radius);
	ar->WriteString(str);
	ar->WriteString(_T("Peak Sigma[px]\r\n"));
	str.Format(_T("%.3f\r\n"), peak_sigma);
	ar->WriteString(str);
	ar->WriteString(_T("Channel(s) in which peaks were found.\r\n"));
	str = _T("");
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		if ( find[i] )	str.AppendFormat(_T("CH%d "), i-CH1+1);
	str.AppendFormat(_T("\r\n"));
	ar->WriteString(str);

	CloseProgramFile(ar);
	return 0;
}

/************************************************************************************/
/***************				CTraceFileWriter					*****************/
/************************************************************************************/
int CTraceFileWriter::SetFilepath(LPCTSTR filepath, BOOL bg)
{
	if ( !filepath )	return -1;

	CString str = filepath;
	if ( str.IsEmpty() )	return -1;

	int n;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )
		str = str.Mid(0, n);

	m_filepath.Format(_T("%s.%s"), str, (!bg) ? CAMERAFILE_TRACE_EXT : CAMERAFILE_BGTRACE_EXT );
	m_filepath2.Format(_T("%s.%s"), str, (!bg) ? CAMERAFILE_TRACE2_EXT : CAMERAFILE_BGTRACE2_EXT );

	m_peaks.SetFilepath(m_filepath, bg);
	m_tlog.SetFilepath(m_filepath, bg);
	return ( DoesProgramFileExist( m_filepath ) && DoesProgramFileExist( m_filepath2 ) ) ? 1 : 0 ;
}

int CTraceFileWriter::Open(UINT num_frames, CArray<CPeakSet> *peaks)
{
	if ( IsOpen() )	return -1;
	if ( m_filepath.IsEmpty() )	return -1;


	m_archive = OpenProgramFileToWrite( m_filepath );
	if ( m_archive == NULL )	goto FAIL;
	m_archive2 = OpenProgramFileToWrite( m_filepath2 );
	if ( m_archive2 == NULL )	goto FAIL;


	m_num_frames = (UINT32) num_frames;
	m_num_peaks = (UINT32) peaks->GetCount();

	try	{	m_data = new float[ 2 * NUM_CHANNELS * m_num_peaks * m_num_frames ];	}
	catch(CException *e)
	{
		e->Delete();
		m_data = NULL;
		goto FAIL;
	}
	try	{	m_data2 = new float[ 2 * NUM_CHANNELS * m_num_peaks * m_num_frames ];	}
	catch(CException *e)
	{
		e->Delete();
		delete [] m_data;
		m_data = NULL;
		m_data2 = NULL;
		goto FAIL;
	}

	memset( m_data, 0, sizeof(float) * 2 * NUM_CHANNELS * m_num_frames * m_num_peaks );
	memset( m_data2, 0, sizeof(float) * 2 * NUM_CHANNELS * m_num_frames * m_num_peaks );

	UINT32 offset = 3 * sizeof(UINT32) + sizeof(UINT8) + 2 * sizeof(UINT16) + 2 * sizeof(UINT32)
					+ 3 * sizeof(float) // + sizeof(UINT16) 
					+ m_num_peaks * NUM_CHANNELS * ( 4 * sizeof(float) + sizeof(BOOL) );

	m_archive->Write((void *)&m_num_peaks, sizeof(UINT32));
	m_archive2->Write((void *)&m_num_peaks, sizeof(UINT32));
	m_archive->Write((void *)&m_num_frames, sizeof(UINT32));
	m_archive2->Write((void *)&m_num_frames, sizeof(UINT32));
	m_archive->Write((void *)&offset, sizeof(UINT32));
	m_archive2->Write((void *)&offset, sizeof(UINT32));
	UINT8 num_channels = NUM_CHANNELS;
	m_archive->Write((void *)&num_channels, sizeof(UINT8));
	m_archive2->Write((void *)&num_channels, sizeof(UINT8));
	m_archive->Write((void *)&m_frame_w, sizeof(UINT16));
	m_archive2->Write((void *)&m_frame_w, sizeof(UINT16));
	m_archive->Write((void *)&m_frame_h, sizeof(UINT16));
	m_archive2->Write((void *)&m_frame_h, sizeof(UINT16));
	m_archive->Write((void *)&m_background, sizeof(UINT32));
	m_archive2->Write((void *)&m_background, sizeof(UINT32));
	m_archive->Write((void *)&m_data_scaler, sizeof(UINT32));
	m_archive2->Write((void *)&m_data_scaler, sizeof(UINT32));

	m_archive->Write((void *)&m_frame_cycle, sizeof(float));
	m_archive2->Write((void *)&m_frame_cycle, sizeof(float));
	m_archive->Write((void *)&m_peak_radius, sizeof(float));
	m_archive2->Write((void *)&m_peak_radius, sizeof(float));
	m_archive->Write((void *)&m_peak_sigma, sizeof(float));
	m_archive2->Write((void *)&m_peak_sigma, sizeof(float));

	for ( UINT i = 0 ; i < m_num_peaks ; i++ )
	{
		CPeakSet &set = (*peaks)[i];

		for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
		{
            m_archive->Write((void *)&(set.p[k].x), sizeof(float));
			m_archive2->Write((void *)&(set.p[k].x), sizeof(float));
			m_archive->Write((void *)&(set.p[k].sx), sizeof(float));
			m_archive2->Write((void *)&(set.p[k].sx), sizeof(float));
			m_archive->Write((void *)&(set.p[k].y), sizeof(float));
			m_archive2->Write((void *)&(set.p[k].y), sizeof(float));
			m_archive->Write((void *)&(set.p[k].sy), sizeof(float));
			m_archive2->Write((void *)&(set.p[k].sy), sizeof(float));
			m_archive->Write((void *)&(set.p[k].is_good), sizeof(BOOL));
			m_archive2->Write((void *)&(set.p[k].is_good), sizeof(BOOL));
		}
	}

	return 0;
FAIL:
	LogMsg(_T("Error"), Stringify(_T("Trace File [%s] Open Failed."), m_filepath));
	Close();
	return -1;
}

int CTraceFileWriter::Close()
{
	CFileStatus *fsptr = NULL;
	CFileStatus fs;
	if ( m_filmpath.IsEmpty() != TRUE )
	{
		CFile::GetStatus( m_filmpath, fs );
		fsptr = &fs;
	}

	if ( m_archive )
	{
		CloseProgramFile(m_archive);
		m_archive = NULL;
		if ( fsptr )
		{
			CFileStatus temp;
			CFile::GetStatus( m_filepath, temp );
			temp.m_ctime = fsptr->m_ctime;
			temp.m_mtime = fsptr->m_mtime;
			CFile::SetStatus( m_filepath, temp );
		}
	}
	if ( m_archive2 )
	{
		CloseProgramFile(m_archive2);
		m_archive2 = NULL;
		if ( fsptr )
		{
			CFileStatus temp;
			CFile::GetStatus( m_filepath2, temp );
			temp.m_ctime = fsptr->m_ctime;
			temp.m_mtime = fsptr->m_mtime;
			CFile::SetStatus( m_filepath2, temp );
		}
	}


	if ( m_data )
	{
		delete [] m_data;
		m_data = NULL;
	}
	if ( m_data2 )
	{
		delete [] m_data2;
		m_data2 = NULL;
	}

	m_filmpath = _T("");
	m_filepath = _T("");
	m_filepath2 = _T("");
	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = 1;

	m_frame_cycle = 0.0;
	m_peak_radius = 0.0;
	m_peak_sigma = 0.0;

	m_num_frames = 0;
	m_num_peaks = 0;

	return 0;
}

int CTraceFileWriter::Write()
{
	if ( !m_archive || !m_data )	return -1;	
	m_archive->Write( (void *)m_data, sizeof(float) * 2 * NUM_CHANNELS * m_num_peaks * m_num_frames );
	if ( !m_archive2 || !m_data2 )	return -1;
	m_archive2->Write( (void *)m_data2, sizeof(float) * 2 * NUM_CHANNELS * m_num_peaks * m_num_frames );
	return 0;
}

int CTraceFileWriter::SaveMaximumSnapshot(UINT16 w, UINT16 h, double *snapshot)
{
	CString str = m_filepath;
	if ( str.IsEmpty() )	return -1;

	int n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )	str = str.Mid(0, n);
	
	CTIFFFileWriter tiff;
	str.AppendFormat(_T("_max.%s"), CAMERAFILE_TIFF1_EXT);
	tiff.SetFilepath(str);	
	tiff.m_frame_w = w;
	tiff.m_frame_h = h;
	tiff.m_background = m_background;
	tiff.m_data_scaler = m_data_scaler;
	//XXX : Unfair assumption that the pixel values are within UINT32 range.
	//tiff.m_byte_per_pixel = sizeof(UINT32);
	//XXX : Unfair assumption that the pixel values are within UINT16 range.
	tiff.m_byte_per_pixel = 2;
	tiff.m_8bit_color = FALSE;
	//tiff.m_byte_per_pixel = 1;
	//tiff.m_8bit_color = TRUE;

	if ( tiff.Open() < 0 )	return -1;
	tiff.Write( 1, snapshot );
	tiff.Close();
	return 0;
}

/************************************************************************************/
/***************				CTraceFileReader					*****************/
/************************************************************************************/
int CTraceFileReader::Open(LPCTSTR filepath)
{
	if ( IsOpen() )	return -1;
	if ( !filepath )	return -1;

	m_filepath = filepath;
	if ( m_filepath.IsEmpty() )	return -1;

	CString str;
	CArchive *ar = OpenProgramFileToRead( m_filepath );
	if ( ar == NULL )	goto FAIL;



	if ( ar->Read((void *)&m_num_peaks, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;
	if ( ar->Read((void *)&m_num_frames, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;

	try	{	m_data = new float[ 2 * NUM_CHANNELS * m_num_peaks * m_num_frames ];	}
	catch(CException *e)
	{
		e->Delete();
		m_data = NULL;
		goto FAIL;
	}
	memset( m_data, 0, sizeof(float) * 2 * NUM_CHANNELS * m_num_peaks * m_num_frames );

	UINT32 offset;
	if ( ar->Read((void *)&offset, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;
	UINT8 num_channels;
	if ( ar->Read((void *)&num_channels, sizeof(UINT8)) != sizeof(UINT8) )	goto FAIL;
	if ( num_channels != NUM_CHANNELS )	goto FAIL;

	if ( ar->Read((void *)&m_frame_w, sizeof(UINT16)) != sizeof(UINT16) )	goto FAIL;
	if ( ar->Read((void *)&m_frame_h, sizeof(UINT16)) != sizeof(UINT16) )	goto FAIL;
	if ( ar->Read((void *)&m_background, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;
	if ( ar->Read((void *)&m_data_scaler, sizeof(UINT32)) != sizeof(UINT32) )	goto FAIL;

	if ( ar->Read((void *)&m_frame_cycle, sizeof(float)) != sizeof(float) )	goto FAIL;
	if ( ar->Read((void *)&m_peak_radius, sizeof(float)) != sizeof(float) )	goto FAIL;
	if ( ar->Read((void *)&m_peak_sigma, sizeof(float)) != sizeof(float) )	goto FAIL;

	m_peaks.SetSize(m_num_peaks);
	for ( UINT i = 0 ; i < m_num_peaks ; i++ )
	{
		CPeakSet *set = &( m_peaks[i] );

		for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
		{
			if ( ar->Read((void *)&(set->p[k].x), sizeof(float)) != sizeof(float) )	goto FAIL;
			if ( ar->Read((void *)&(set->p[k].sx), sizeof(float)) != sizeof(float) )	goto FAIL;
			if ( ar->Read((void *)&(set->p[k].y), sizeof(float)) != sizeof(float) )	goto FAIL;
			if ( ar->Read((void *)&(set->p[k].sy), sizeof(float)) != sizeof(float) )	goto FAIL;
			if ( ar->Read((void *)&(set->p[k].is_good), sizeof(BOOL)) != sizeof(BOOL) )	goto FAIL;
		}
	}

	UINT32 data_size = 2 * NUM_CHANNELS * m_num_peaks * m_num_frames * sizeof(float) ;
	if ( ar->Read((void *)m_data, data_size) != data_size )	goto FAIL;
	CloseProgramFile(ar);

	LoadSnapshot();

	return 0;
FAIL:
	LogMsg(_T("Error"), Stringify(_T("Trace File [%s] Open Failed."), m_filepath));
	if ( ar )	CloseProgramFile(ar);
	Close();
	return -1;
}

int CTraceFileReader::LoadSnapshot()
{
	int n;
	CString str;
	CTIFFFileReader tiff;

	str = m_filepath;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )	str = str.Mid(0, n);
	str.AppendFormat(_T(".%s"), CAMERAFILE_TIFF1_EXT);
	
	tiff.m_background = m_background;
	tiff.m_data_scaler = m_data_scaler;

	if ( tiff.Open( str ) < 0 )
		return -1;

	if ( tiff.m_frame_w == m_frame_w && tiff.m_frame_h && m_frame_h )
	{
		if ( m_snapshot )
		{
			delete [] m_snapshot;
			m_snapshot = NULL;
		}
		m_snapshot = new double[ m_frame_w * m_frame_h ];
		if ( tiff.ReadFrame( m_snapshot ) < 0 )
		{
			delete [] m_snapshot;
			m_snapshot = NULL;
		}
	}
	tiff.Close();
	return 0;
}

int CTraceFileReader::LoadMaximumSnapshot()
{
	int n;
	CString str;
	CTIFFFileReader tiff;

	str = m_filepath;
	n = str.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )	str = str.Mid(0, n);
	str.AppendFormat(_T("_max.%s"), CAMERAFILE_TIFF1_EXT);
	
	tiff.m_background = m_background;
	tiff.m_data_scaler = m_data_scaler;
	tiff.Open( str );
	if ( tiff.m_frame_w == m_frame_w && tiff.m_frame_h && m_frame_h )
	{
		if ( m_snapshot )
		{
			delete [] m_snapshot;
			m_snapshot = NULL;
		}
		m_snapshot = new double[ m_frame_w * m_frame_h ];
		if ( tiff.ReadFrame( m_snapshot ) < 0 )
		{
			delete [] m_snapshot;
			m_snapshot = NULL;
		}
	}
	tiff.Close();
	return 0;
}

int CTraceFileReader::Close()
{
	if ( m_data )
	{
		delete [] m_data;
		m_data = NULL;
	}

	if ( m_snapshot )
	{
		delete [] m_snapshot;
		m_snapshot = NULL;
	}
    
	m_filepath = _T("");

	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = 1;

	m_frame_cycle = 0.0;
	m_peak_radius = 0.0;
	m_peak_sigma = 0.0;

	m_num_frames = 0;
	m_num_peaks = 0;
	m_peaks.SetSize(0);

	m_f0_fsum_ratio = 1.0;

	return 0;	
}

/************************************************************************************/
/***************					CFilm							*****************/
/************************************************************************************/
#define Z_VALUE		(3.00)
CFilm::CFilm()
{
	m_film = NULL;
	m_peaks = NULL;
	m_tiff = NULL;
	m_trace = NULL;

	m_data = NULL;
	m_frame = NULL;
	m_temp_frame = NULL;

	Close();
}


int CFilm::Open(LPCTSTR filepath)
{
	if ( IsOpen() )	return -1;
	if ( !filepath )	return -1;

	m_filepath = filepath;
	if ( m_filepath.IsEmpty() )	return -1;

	int n;
	CString ext;

	n = m_filepath.ReverseFind( (TCHAR)'.' );
	if ( n < 0 )	goto FAIL;
		
	ext = m_filepath.Mid(n+1);
	if ( ext.CompareNoCase(CAMERAFILE_FILM_EXT) == 0
		|| ext.CompareNoCase(CAMERAFILE_OLDFILM_EXT) == 0)
	{
		m_film = new CFilmFileReader();
		if ( m_film->Open(m_filepath) < 0 )
		{
			delete m_film;
			m_film = NULL;
			goto FAIL;
		}
			
		m_frame_w = m_film->m_frame_w;
		m_frame_h = m_film->m_frame_h;
		m_background = m_film->m_background;
        m_data_scaler = m_film->m_data_scaler;
		m_frame_cycle = m_film->m_frame_cycle;
		m_num_frames = m_film->m_num_frames;
	}
	else if ( ext.CompareNoCase(CAMERAFILE_PEAKS_EXT) == 0 )
	{
		m_peaks = new CPeaksFileReader();
		if ( m_peaks->Read(m_filepath) < 0 )
		{
			delete m_peaks;
			m_peaks = NULL;
			goto FAIL;
		}

		m_frame_w = m_peaks->m_frame_w;
		m_frame_h = m_peaks->m_frame_h;
		m_background = 0;
        m_data_scaler = 255;
		m_frame_cycle = 0.0;
		m_num_frames = 1;
	}
	else if ( ext.CompareNoCase(CAMERAFILE_TIFF1_EXT) == 0
			|| ext.CompareNoCase(CAMERAFILE_TIFF2_EXT) == 0 )
	{
		m_tiff = new CTIFFFileReader();
		if ( m_tiff->Open(m_filepath) < 0 )
		{
			delete m_tiff;
			m_tiff = NULL;
			goto FAIL;
		}

		m_frame_w = m_tiff->m_frame_w;
		m_frame_h = m_tiff->m_frame_h;
		m_background = 0;
        m_data_scaler = 1;
		m_frame_cycle = 0.0;
		m_num_frames = m_tiff->m_num_frames;
	}
	else if ( ext.CompareNoCase(CAMERAFILE_TRACE_EXT) == 0
			|| ext.CompareNoCase(CAMERAFILE_TRACE2_EXT) == 0
			|| ext.CompareNoCase(CAMERAFILE_BGTRACE_EXT) == 0
			|| ext.CompareNoCase(CAMERAFILE_BGTRACE2_EXT) == 0
			)
	{
		m_trace = new CTraceFileReader();
		if ( m_trace->Open(m_filepath) < 0 )
		{
			delete m_trace;
			m_trace = NULL;
			goto FAIL;
		}

		m_frame_w = m_trace->m_frame_w;
		m_frame_h = m_trace->m_frame_h;
		m_background = m_trace->m_background;
        m_data_scaler = m_trace->m_data_scaler;
		m_frame_cycle = m_trace->m_frame_cycle;
		m_num_frames = m_trace->m_num_frames;
	}
	else	goto FAIL;


	try	{	m_data = new double[m_frame_w*m_frame_h*2];	}
	catch(CException *e)
	{
		e->Delete();
		m_data = NULL;
		goto FAIL;
	}

	memset( m_data, 0, sizeof(double)*m_frame_w*m_frame_h*2 );
	m_frame = m_data;
	m_temp_frame = m_data + m_frame_w*m_frame_h;

	MoveFrame(0);
	if ( m_tiff )
	{
		double min, max;
		MakeAverageFrame(NULL);		
		min = max = Frame( 0, 0 );
		for ( UINT y = 0 ; y < m_frame_h ; y++ )
		{
			for ( UINT x = 0 ; x < m_frame_w ; x++ )
			{
				double f = Frame( x, y );
				if ( f < min )	min = f;
				else if ( f > max )	max = f;
			}
		}

		if ( m_tiff->m_byte_per_pixel == 1 )
		{
			m_background = 0;
			m_data_scaler = 255;
		}
		else
		{			
			m_background = (UINT32) min;
			m_data_scaler = (UINT32) (max-min);
			if ( m_data_scaler < 1 )	m_data_scaler = 1;
		}
	}
	MoveFrame(0);

	return 0;
FAIL:
	LogMsg(_T("Error"), Stringify(_T("Film [%s] Open Failed."), m_filepath));
	Close();
	return -1;
}

int CFilm::Close()
{
	if ( m_film )
	{
		m_film->Close();
		delete m_film;
		m_film = NULL;
	}

	if ( m_peaks )
	{
		delete m_peaks;
		m_peaks = NULL;
	}

	if ( m_tiff )
	{
		m_tiff->Close();
		delete m_tiff;
		m_tiff = NULL;
	}

	if ( m_trace )
	{
		m_trace->Close();
		delete m_trace;
		m_trace = NULL;
	}

	if ( m_data )
	{
		delete [] m_data;
		m_data = NULL;
	}
	m_frame = NULL;
	m_temp_frame = NULL;

	m_filepath = _T("");

	m_frame_w = 0;
	m_frame_h = 0;
	m_background = 0;
	m_data_scaler = 1;

	m_frame_cycle = 0.0;
	m_num_frames = 0;
	m_frame_no = 0;

	return 0;
}

/*
int CFilm::FrameNo()
{
	if ( !m_data )	return -1;

	if ( m_film )
		return m_film->FrameNo();
	else if ( m_peaks )
		return 0;
	else if ( m_tiff )
		return m_tiff->FrameNo();
	else if ( m_trace )
		return m_frame_no;
	else
		return -1;
}
*/

int CFilm::MoveFrame(UINT frame_no)
{
	if ( !m_data )	return -1;
	if ( frame_no >= m_num_frames )	return -1;

	int nret = 0;
	if ( m_film )
	{
		nret = m_film->MoveFrame(frame_no);
		m_frame_no = m_film->FrameNo();
	}
	else if ( m_peaks )
	{
		nret = ( frame_no == 0 ) ? 0 : -1;
		m_frame_no = 0;
	}
	else if ( m_tiff )
	{
		nret = m_tiff->MoveFrame(frame_no);
		m_frame_no = m_tiff->FrameNo();
	}
	else if ( m_trace )
		m_frame_no = frame_no;
	else
		m_frame_no = frame_no;

	return nret;
}

int CFilm::ReadFrame(double *pFrame)
{
	if ( !m_data )	return -1;
	if ( m_frame_no >= m_num_frames )	return -1;

	UINT w = m_frame_w;
	UINT h = m_frame_h;

	int nret = 0;
	if ( m_film )
	{
		nret = m_film->ReadFrame(m_frame);
		m_frame_no = m_film->FrameNo();
	}
	else if ( m_peaks )
	{
		memset( m_frame, 0, sizeof(double)*w*h );

		for ( UINT i = 0 ; i < (UINT) m_peaks->m_peaks.GetCount() ; i++ )
		{
			CPeakSet *set = &( m_peaks->m_peaks[i] );
			for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
			{
				CPeak &p = set->p[k];

				int orgx = (int) ( p.x + 0.5 );
				int orgy = (int) ( p.y + 0.5 );
				int rx = (int)ceil( Z_VALUE * p.sx );
				int ry = (int)ceil( Z_VALUE * p.sy );
				if ( rx <= 0 )	rx = 1;
				if ( ry <= 0 )	ry = 1;
				for ( int x = -rx ; x <= rx ; x++ )
				{
					if ( orgx+x < 0 || (int)w <= orgx+x )	continue;
					for ( int y = -ry ; y <= ry ; y++ )
					{
						if ( orgy+y < 0 || (int)h <= orgy+y )	continue;
						double r = exp(-0.5*(SQR(orgx+x - p.x)/SQR(p.sx)+SQR(orgy+y - p.y)/SQR(p.sy)));
						double f = m_background + m_data_scaler * exp(-0.5*(SQR(orgx+x - p.x)/SQR(p.sx)+SQR(orgy+y - p.y)/SQR(p.sy)));
						if ( Frame( orgx+x, orgy+y ) < f )	Frame( orgx+x, orgy+y ) = f;
					}
				}
			}
		}
		m_frame_no++;
	}
	else if ( m_tiff )
	{
		nret = m_tiff->ReadFrame(m_frame);
		m_frame_no = m_tiff->FrameNo();
	}
	else if ( m_trace )
	{
		for ( UINT y = 0 ; y < h ; y++ )
			for ( UINT x = 0 ; x < w ; x++ )
				Frame( x, y ) = m_trace->Snapshot( x, y );

		m_frame_no++;
	}
	else	
		return -1;

	if ( nret < 0 )	return -1;

	if ( pFrame )	memcpy( pFrame, m_frame, sizeof(double)*w*h );
	return 0;
}



int CFilm::DrawFrame(UINT16 w, UINT16 h, COLORREF *display)
{
	if ( !m_data )	return -1;
	if ( w != m_frame_w || h != m_frame_h )	return -1;

	CChannels ch( w, h );
	memset(display, 0, sizeof(COLORREF)*w*h);
	for ( UINT y = 0 ; y < ch.h ; y++ )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			for ( UINT x = ch.l[i] ; x <= ch.r[i] ; x++ )
				display[ w*y + x ] = ProgramColor0( i, Pixel2Byte( Frame(x,y) ) );
		}
	}

	return 0;
}

int CFilm::StartAveragingFrames()
{
	if ( !m_data )	return -1;
	UINT16 w = m_frame_w;
	UINT16 h = m_frame_h;

	memset( m_temp_frame, 0, sizeof(double)*w*h );
	return 0;
}

int CFilm::AddToAveragingFrames()
{
	if ( !m_data )	return -1;
	UINT16 w = m_frame_w;
	UINT16 h = m_frame_h;
	UINT32 num_pixels = w*h;
	for ( UINT pixel_idx = 0 ; pixel_idx < num_pixels ; pixel_idx++ )
		m_temp_frame[pixel_idx] += m_frame[pixel_idx];
	
	return 0;
}

int CFilm::FinishAveragingFrames(int frame_cnt, double *pAve)
{
	if ( !m_data ) return -1;
	UINT16 w = m_frame_w;
	UINT16 h = m_frame_h;
	UINT32 num_pixels = w*h;
	for ( UINT pixel_idx = 0 ; pixel_idx < num_pixels ; pixel_idx++ )
		m_frame[pixel_idx] = m_temp_frame[pixel_idx]/frame_cnt;

	if ( pAve ) memcpy( pAve, m_frame, sizeof(double)*w*h );
	return 0;
}

int CFilm::MakeAverageFrame(int from, int to, double *pAve)
{
	if ( !m_data )	return -1;
	
	UINT16 w = m_frame_w;
	UINT16 h = m_frame_h;
	if ( from < 0 )	from = 0;
	if ( to >= (int)m_num_frames )	to = ((int)m_num_frames) - 1;
	UINT frame_cnt = to - from + 1;
	UINT pixel_idx;
	UINT num_pixels = w*h;

    if ( MoveFrame( from ) < 0 )	return -1;

	memset( m_temp_frame, 0, sizeof(double)*w*h );
	for ( int i = from ; i <= to ;  i++ )
	{
		if ( ReadFrame(NULL) < 0 )	return -1;

		for ( pixel_idx = 0 ; pixel_idx < num_pixels ; pixel_idx++ )
			m_temp_frame[pixel_idx] += m_frame[pixel_idx] / frame_cnt;
	}
	memcpy( m_frame, m_temp_frame, sizeof(double)*w*h );
	if ( pAve )	memcpy( pAve, m_frame, sizeof(double)*w*h );
	return 0;
}