#include "stdafx.h"
#include "LocalSharedMemory.h"
#include "..\LKSLib\Log.h"
#include "smCamera.h"

CLocalSharedMemory::CLocalSharedMemory()
{
	//hMapFile = NULL;
	pHeader = NULL;
	pBuffer = NULL;
	created = FALSE;
	shmem_name = NULL;

}

CLocalSharedMemory::~CLocalSharedMemory()
{
	Close();
}

int CLocalSharedMemory::Create(LPCTSTR name, UINT32 size)
{
	shmem_name = name; 
	if (name[0] == (char) 'C') //CAQ is the full name. I could not figure out how to compare strings.
	{	
		pHeader = (CLocalSharedMemoryHeader *) camera_memory;
		g_camera_recording_on = TRUE;
	}
	else if (name[0]  == (char) 'S') //SHUTTER is the full name.
	{	
		pHeader = (CLocalSharedMemoryHeader *) shutter_memory;
	}


	memset(pHeader, 0, sizeof(CLocalSharedMemoryHeader) + size * sizeof(BYTE));

	pHeader->valid = TRUE;
	pHeader->size = size;
	pBuffer = (BYTE *) pHeader + sizeof(CLocalSharedMemoryHeader);

	creater = TRUE;
	


	return 0;
}


int CLocalSharedMemory::Open(LPCTSTR name)
{
	if ( creater )	return -1;
	shmem_name = name;
	
	if (name[0] == (char) 'C') //CAQ is the full name. I could not figure out how to compare strings.
	{	
		pHeader = (CLocalSharedMemoryHeader *) camera_memory;
	}
	else if (name[0]  == (char) 'S') //SHUTTER is the full name.
	{	
		pHeader = (CLocalSharedMemoryHeader *) shutter_memory;
	}

	pBuffer = (BYTE *) pHeader + sizeof(CLocalSharedMemoryHeader);
	return 0;

}

int CLocalSharedMemory::Close()
{
	if ( creater )
	{
		if ( pHeader )	pHeader->valid = FALSE;
	}

	pHeader = NULL;
	pBuffer = NULL;
	creater = FALSE;
	if (shmem_name)
	{
		if (shmem_name[0] == (char) 'C') 
		{
			g_camera_recording_on = FALSE;
		}
	}
	return 0;
}