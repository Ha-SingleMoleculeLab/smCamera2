#include "stdafx.h"
#include "smCamera.h"

#include "FrameSequence.h"

#define DEFAULT_FRAMESEQUENCE_FILENAME	_T("Default.txt")

CFrameSequence::CFrameSequence() 
{
	m_sequence = NULL;
	Unload();
}

CFrameSequence::~CFrameSequence()
{
	Unload();	
}

LPCTSTR CFrameSequence::DefaultPath()
{
	return GetProgramFilePath( _PATH_FRAME_SEQUENCE, DEFAULT_FRAMESEQUENCE_FILENAME );
}

int CFrameSequence::Load( LPCTSTR path )
{
	CString filepath;
	if ( path )
		filepath = path;
	else
		filepath = _T("");

	if ( filepath.IsEmpty() )
		filepath = GetProgramFilePath( _PATH_FRAME_SEQUENCE, DEFAULT_FRAMESEQUENCE_FILENAME );

	Unload();

	CArray<UINT8> seq;
	seq.SetSize(0);

	
	CArchive *ar = OpenProgramFileToRead(filepath);
	if ( ar == NULL )
	{
		LogErr(Stringify(_T("Frame Sequence [%s] Open Failed."), filepath));
		return -1;
	}

	CString str;
	while( ar->ReadString(str) )
	{
		UINT8 temp = _tstoi( str );
		seq.Add(temp);
	}
    CloseProgramFile(ar);

	Unload();
	m_sequence_cnt = (UINT32) seq.GetCount();
	m_sequence = new UINT8[m_sequence_cnt];
	for ( UINT i = 0 ; i < m_sequence_cnt ; i++ )
		m_sequence[i] = seq[i];

	return Init();
}

int CFrameSequence::Unload()
{
	if ( m_sequence )	delete [] m_sequence;
	m_sequence = NULL;
	m_sequence_cnt = 0;
	m_sequence_index = 0;
	return 0;
}