// smCameraDoc.cpp : implementation of the CsmCameraDoc class
//

#include "stdafx.h"
#include "smCamera.h"

#include "smCameraDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsmCameraDoc

IMPLEMENT_DYNCREATE(CsmCameraDoc, CDocument)

BEGIN_MESSAGE_MAP(CsmCameraDoc, CDocument)
END_MESSAGE_MAP()


// CsmCameraDoc construction/destruction

CsmCameraDoc::CsmCameraDoc()
{
	// TODO: add one-time construction code here

}

CsmCameraDoc::~CsmCameraDoc()
{
}

BOOL CsmCameraDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CsmCameraDoc serialization

void CsmCameraDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CsmCameraDoc diagnostics

#ifdef _DEBUG
void CsmCameraDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CsmCameraDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CsmCameraDoc commands
