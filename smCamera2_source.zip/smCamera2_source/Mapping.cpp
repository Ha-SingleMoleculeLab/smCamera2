#include "stdafx.h"
#include "smCamera.h"

#include <math.h>
#include "Mapping.h"

#define DEFAULT_MAPPING_FILENAME	_T("mapping.txt")

CMapping::CMapping(UINT w, UINT h)
{
	Reset(w, h);
}

CMapping::~CMapping()
{
	Reset(0, 0);
}

void CMapping::Reset(UINT w, UINT h)
{
	m_is_mapping_ready = FALSE;
	m_frame_w = w;
	m_frame_h = h;
	m_time = 0;
	m_path = _T("");
	m_pairs.SetSize(0);

	m_rough_xcoeff1[0] = 0;
	m_rough_xcoeff1[1] = 1;
	m_rough_xcoeff1[2] = 0;
	m_rough_ycoeff1[0] = 0;
	m_rough_ycoeff1[1] = 0;
	m_rough_ycoeff1[2] = 1;

	m_rough_xcoeff2[0] = 0;
	m_rough_xcoeff2[1] = 1;
	m_rough_xcoeff2[2] = 0;
	m_rough_ycoeff2[0] = 0;
	m_rough_ycoeff2[1] = 0;
	m_rough_ycoeff2[2] = 1;

	memset(m_xcoeff1, 0, sizeof(double)*NUM_MAPPING_COEFFS);
	memset(m_ycoeff1, 0, sizeof(double)*NUM_MAPPING_COEFFS);
	m_xerr1 = m_yerr1 = 0.0;
	memset(m_xcoeff2, 0, sizeof(double)*NUM_MAPPING_COEFFS);
	memset(m_ycoeff2, 0, sizeof(double)*NUM_MAPPING_COEFFS);
	m_xerr2 = m_yerr2 = 0.0;
}

int CMapping::Load( LPCTSTR mapping_filepath )
{
	int n;
	CArchive *ar;
	CString str;
	CString filepath;
	
	Reset( 0, 0 );

	if ( mapping_filepath )	
		filepath = mapping_filepath;
	else
		filepath = _T("");

	if ( filepath.IsEmpty() )
		filepath = GetProgramFilePath( _PATH_COMMON, DEFAULT_MAPPING_FILENAME );


	CFileStatus fstatus;
	if ( DoesProgramFileExist( filepath, &fstatus ) != TRUE )	return -1;
	m_time = (time_t) fstatus.m_mtime.GetTime();
	m_path = filepath;

	ar = OpenProgramFileToRead( filepath );
	if ( ar == NULL )	goto FAIL;

	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	n = str.Find(' ');
	if ( n < 0 )	goto FAIL;
	m_frame_w = _tstoi( str.Mid(0, n) );
	m_frame_h = _tstoi( str.Mid(n+1) );

	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
	{
		n = str.Find(' ');
		if ( n < 0 )	goto FAIL;
		m_xcoeff1[i] = _tcstod( str.Mid(0, n), NULL );
		str = str.Mid(n+1);
	}
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	m_xerr1 = _tcstod( str, NULL );

	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
	{
		n = str.Find(' ');
		if ( n < 0 )	goto FAIL;
		m_ycoeff1[i] = _tcstod( str.Mid(0, n), NULL );
		str = str.Mid(n+1);
	}
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	m_yerr1 = _tcstod( str, NULL );

	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
	{
		n = str.Find(' ');
		if ( n < 0 )	goto FAIL;
		m_xcoeff2[i] = _tcstod( str.Mid(0, n), NULL );
		str = str.Mid(n+1);
	}
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	m_xerr2 = _tcstod( str, NULL );

	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
	{
		n = str.Find(' ');
		if ( n < 0 )	goto FAIL;
		m_ycoeff2[i] = _tcstod( str.Mid(0, n), NULL );
		str = str.Mid(n+1);
	}
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	if ( ar->ReadString(str) != TRUE )	goto FAIL;
	m_yerr2 = _tcstod( str, NULL );

	m_is_mapping_ready = TRUE;

	CloseProgramFile(ar);
	return 0;
FAIL:
	if ( ar )	CloseProgramFile(ar);
	Reset( 0, 0 );
	return -1;
}


int CMapping::Save( LPCTSTR mapping_filepath )
{
	if ( m_is_mapping_ready != TRUE )	return -1;

	CArchive *ar;
	CString str;
	CString filepath;
	CString default_mapping_filepath = GetProgramFilePath( _PATH_COMMON, DEFAULT_MAPPING_FILENAME );

	if ( mapping_filepath )	
		filepath = mapping_filepath;
	else
		filepath = _T("");

	if ( filepath.IsEmpty() )	filepath = default_mapping_filepath ;

	ar = OpenProgramFileToWrite( filepath, TRUE );
	if ( ar == NULL )	return -1;

	str.Format(_T("Frame Width & Height\r\n"));
	ar->WriteString(str);
	str.Format(_T("%d %d\r\n"), m_frame_w, m_frame_h);
	ar->WriteString(str);
	
	str.Format(_T("Mapping from CH2 onto CH1 X\r\n"));
	ar->WriteString(str);
	str = _T("");
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
		str.AppendFormat(_T("%g "), m_xcoeff1[i]);
	str.AppendFormat(_T("\r\n"));
	ar->WriteString(str);
	str.Format(_T("Mapping Error\r\n"));
	ar->WriteString(str);
	str.Format(_T("%.3f\r\n"), m_xerr1);
	ar->WriteString(str);

	str.Format(_T("Mapping from CH2 onto CH1 Y\r\n"));
	ar->WriteString(str);
	str = _T("");
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
		str.AppendFormat(_T("%g "), m_ycoeff1[i]);
	str.AppendFormat(_T("\r\n"));
	ar->WriteString(str);
	str.Format(_T("Mapping Error\r\n"));
	ar->WriteString(str);
	str.Format(_T("%.3f\r\n"), m_yerr1);
	ar->WriteString(str);

	str.Format(_T("Mapping from CH1 onto CH2 X\r\n"));
	ar->WriteString(str);
	str = _T("");
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
		str.AppendFormat(_T("%g "), m_xcoeff2[i]);
	str.AppendFormat(_T("\r\n"));
	ar->WriteString(str);
	str.Format(_T("Mapping Error\r\n"));
	ar->WriteString(str);
	str.Format(_T("%.3f\r\n"), m_xerr2);
	ar->WriteString(str);

	str.Format(_T("Mapping from CH1 onto CH2 Y\r\n"));
	ar->WriteString(str);
	str = _T("");
	for ( int i = 0 ; i < NUM_MAPPING_COEFFS ; i++ )
		str.AppendFormat(_T("%g "), m_ycoeff2[i]);
	str.AppendFormat(_T("\r\n"));
	ar->WriteString(str);
	str.Format(_T("Mapping Error\r\n"));
	ar->WriteString(str);
	str.Format(_T("%.3f\r\n"), m_yerr2);
	ar->WriteString(str);

	CloseProgramFile(ar);

	m_time = time(NULL);

	return 0;
}

LPCTSTR CMapping::Information()
{
	static CString infostr;

	if ( m_is_mapping_ready != TRUE )
	{
		infostr = _T("Mapping is not available.");
	}
	else
	{
		int day, hour;
		hour = (int)(time(NULL) - m_time)/3600;
		day = hour/24;
		hour = hour - 24 * day;
		infostr.Format(_T("%s\r\n"), m_path);
		infostr.AppendFormat(_T("%d day(s) %d hour(s) old.\r\n"), day, hour);
		infostr.AppendFormat(_T("Frame Size : %d px x %d px\r\n"), m_frame_w, m_frame_h);
		infostr.AppendFormat(_T("RMSErr[px] : X1[%.2f] Y1[%.2f] X2[%.2f] Y2[%.2f]\r\n"),
							m_xerr1, m_yerr1, m_xerr2, m_yerr2 );
	}

	return (LPCTSTR) infostr;
}

int CMapping::AddMappingPair( double x1, double y1, double x2, double y2 )
{
	CMappingPair pair;
	pair.x1 = x1;
	pair.y1 = y1;
	pair.x2 = x2;
	pair.y2 = y2;
	m_pairs.Add(pair);
	return 0;
}

int CMapping::DoRoughMapping()
{
	double ch1[3][3], ch1_det, ich1[3][3];
	double ch2[3][3], ch2_det, ich2[3][3];
	if ( m_pairs.GetCount() < 3 )	return -1;

	ch1[0][0] = 1; 
	ch1[0][1] = 1; 
	ch1[0][2] = 1;
	ch1[1][0] = m_pairs[0].x1;
	ch1[1][1] = m_pairs[1].x1;
	ch1[1][2] = m_pairs[2].x1;
	ch1[2][0] = m_pairs[0].y1;
	ch1[2][1] = m_pairs[1].y1;
	ch1[2][2] = m_pairs[2].y1;

	ch1_det = ch1[0][0] * (ch1[1][1]*ch1[2][2]-ch1[1][2]*ch1[2][1])
			- ch1[0][1] * (ch1[1][0]*ch1[2][2]-ch1[1][2]*ch1[2][0])
			+ ch1[0][2] * (ch1[1][0]*ch1[2][1]-ch1[1][1]*ch1[2][0]);

	ich1[0][0] = (ch1[1][1]*ch1[2][2]-ch1[1][2]*ch1[2][1])/ch1_det;
	ich1[0][1] = (ch1[0][2]*ch1[2][1]-ch1[0][1]*ch1[2][2])/ch1_det;
	ich1[0][2] = (ch1[0][1]*ch1[1][2]-ch1[0][2]*ch1[1][1])/ch1_det;
	ich1[1][0] = (ch1[1][2]*ch1[2][0]-ch1[1][0]*ch1[2][2])/ch1_det;
	ich1[1][1] = (ch1[0][0]*ch1[2][2]-ch1[0][2]*ch1[2][0])/ch1_det;
	ich1[1][2] = (ch1[0][2]*ch1[1][0]-ch1[0][0]*ch1[1][2])/ch1_det;
	ich1[2][0] = (ch1[1][0]*ch1[2][1]-ch1[1][1]*ch1[2][0])/ch1_det;
	ich1[2][1] = (ch1[0][1]*ch1[2][0]-ch1[0][0]*ch1[2][1])/ch1_det;
	ich1[2][2] = (ch1[0][0]*ch1[1][1]-ch1[0][1]*ch1[1][0])/ch1_det;

	ch2[0][0] = 1; 
	ch2[0][1] = 1; 
	ch2[0][2] = 1;
	ch2[1][0] = m_pairs[0].x2;
	ch2[1][1] = m_pairs[1].x2;
	ch2[1][2] = m_pairs[2].x2;
	ch2[2][0] = m_pairs[0].y2;
	ch2[2][1] = m_pairs[1].y2;
	ch2[2][2] = m_pairs[2].y2;

	ch2_det = ch2[0][0] * (ch2[1][1]*ch2[2][2]-ch2[1][2]*ch2[2][1])
			- ch2[0][1] * (ch2[1][0]*ch2[2][2]-ch2[1][2]*ch2[2][0])
			+ ch2[0][2] * (ch2[1][0]*ch2[2][1]-ch2[1][1]*ch2[2][0]);

	ich2[0][0] = (ch2[1][1]*ch2[2][2]-ch2[1][2]*ch2[2][1])/ch2_det;
	ich2[0][1] = (ch2[0][2]*ch2[2][1]-ch2[0][1]*ch2[2][2])/ch2_det;
	ich2[0][2] = (ch2[0][1]*ch2[1][2]-ch2[0][2]*ch2[1][1])/ch2_det;
	ich2[1][0] = (ch2[1][2]*ch2[2][0]-ch2[1][0]*ch2[2][2])/ch2_det;
	ich2[1][1] = (ch2[0][0]*ch2[2][2]-ch2[0][2]*ch2[2][0])/ch2_det;
	ich2[1][2] = (ch2[0][2]*ch2[1][0]-ch2[0][0]*ch2[1][2])/ch2_det;
	ich2[2][0] = (ch2[1][0]*ch2[2][1]-ch2[1][1]*ch2[2][0])/ch2_det;
	ich2[2][1] = (ch2[0][1]*ch2[2][0]-ch2[0][0]*ch2[2][1])/ch2_det;
	ich2[2][2] = (ch2[0][0]*ch2[1][1]-ch2[0][1]*ch2[1][0])/ch2_det;


	m_rough_xcoeff2[0] = ch2[1][0]*ich1[0][0] + ch2[1][1]*ich1[1][0] + ch2[1][2]*ich1[2][0];
	m_rough_xcoeff2[1] = ch2[1][0]*ich1[0][1] + ch2[1][1]*ich1[1][1] + ch2[1][2]*ich1[2][1];
	m_rough_xcoeff2[2] = ch2[1][0]*ich1[0][2] + ch2[1][1]*ich1[1][2] + ch2[1][2]*ich1[2][2];

	m_rough_ycoeff2[0] = ch2[2][0]*ich1[0][0] + ch2[2][1]*ich1[1][0] + ch2[2][2]*ich1[2][0];
	m_rough_ycoeff2[1] = ch2[2][0]*ich1[0][1] + ch2[2][1]*ich1[1][1] + ch2[2][2]*ich1[2][1];
	m_rough_ycoeff2[2] = ch2[2][0]*ich1[0][2] + ch2[2][1]*ich1[1][2] + ch2[2][2]*ich1[2][2];

	m_rough_xcoeff1[0] = ch1[1][0]*ich2[0][0] + ch1[1][1]*ich2[1][0] + ch1[1][2]*ich2[2][0];
	m_rough_xcoeff1[1] = ch1[1][0]*ich2[0][1] + ch1[1][1]*ich2[1][1] + ch1[1][2]*ich2[2][1];
	m_rough_xcoeff1[2] = ch1[1][0]*ich2[0][2] + ch1[1][1]*ich2[1][2] + ch1[1][2]*ich2[2][2];

	m_rough_ycoeff1[0] = ch1[2][0]*ich2[0][0] + ch1[2][1]*ich2[1][0] + ch1[2][2]*ich2[2][0];
	m_rough_ycoeff1[1] = ch1[2][0]*ich2[0][1] + ch1[2][1]*ich2[1][1] + ch1[2][2]*ich2[2][1];
	m_rough_ycoeff1[2] = ch1[2][0]*ich2[0][2] + ch1[2][1]*ich2[1][2] + ch1[2][2]*ich2[2][2];


	m_pairs.SetSize(0);
	return 0;
}


int CMapping::UseRoughMapping(double err)
{
	int N = SQR(NUM_MAPPING_COEFFS);
	double *x1, *y1;
	double *x2, *y2;
	x1 = new double[N];
	y1 = new double[N];
	x2 = new double[N];
	y2 = new double[N];

	for ( int y = 0 ; y < NUM_MAPPING_COEFFS ; y++ )
	{
		for ( int x = 0 ; x < NUM_MAPPING_COEFFS ; x++ )
		{
			int i = NUM_MAPPING_COEFFS*y+x;
			x1[i] = m_frame_w * x / NUM_MAPPING_COEFFS;
			y1[i] = m_frame_h * y / NUM_MAPPING_COEFFS;
			x2[i] = m_rough_xcoeff2[0] + m_rough_xcoeff2[1]*x1[i] + m_rough_xcoeff2[2]*y1[i];
			y2[i] = m_rough_ycoeff2[0] + m_rough_ycoeff2[1]*x1[i] + m_rough_ycoeff2[2]*y1[i];
		}
	}

	IDLPolyFit2D3( N, x2, y2, x1, y1, m_xcoeff1, m_ycoeff1);
	IDLPolyFit2D3( N, x1, y1, x2, y2, m_xcoeff2, m_ycoeff2);

	m_is_mapping_ready = TRUE;

	delete [] x1;
	delete [] y1;
	delete [] x2;
	delete [] y2;

	m_xerr1 = m_yerr1 = err;
	m_xerr2 = m_yerr2 = err;

	return 0;
}

int CMapping::DoMapping()
{
	int N;
	double *x1, *y1;
	double *x2, *y2;

	N = (int) m_pairs.GetCount();
	if ( N <= NUM_MAPPING_COEFFS )
	{
		LogErr(Stringify(_T("The number of point pairs [%d] is too small to do mapping."), N));
		if ( N >= 3 )
		{
			DoRoughMapping();
		}
		return -1;
	}
	
	x1 = new double[N];
	y1 = new double[N];
	x2 = new double[N];
	y2 = new double[N];

	for ( int i = 0 ; i < N ; i++ )
	{
		x1[i] = m_pairs[i].x1;
		y1[i] = m_pairs[i].y1;
		x2[i] = m_pairs[i].x2;
		y2[i] = m_pairs[i].y2;
	}

	IDLPolyFit2D3( N, x2, y2, x1, y1, m_xcoeff1, m_ycoeff1);
	IDLPolyFit2D3( N, x1, y1, x2, y2, m_xcoeff2, m_ycoeff2);

	m_is_mapping_ready = TRUE;

	m_xerr1 = m_yerr1 = m_xerr2 = m_yerr2 = 0.0;
	for ( int i = 0 ; i < N ; i++ )
	{
		m_xerr1 += SQR(X1(x2[i],y2[i])-x1[i]);
		m_yerr1 += SQR(Y1(x2[i],y2[i])-y1[i]);
		m_xerr2 += SQR(X2(x1[i],y1[i])-x2[i]);
		m_yerr2 += SQR(Y2(x1[i],y1[i])-y2[i]);
	}
	m_xerr1 = sqrt( m_xerr1/N );
	m_yerr1 = sqrt( m_yerr1/N );
	m_xerr2 = sqrt( m_xerr2/N );
	m_yerr2 = sqrt( m_yerr2/N );

	delete [] x1;
	delete [] y1;
	delete [] x2;
	delete [] y2;


	LogMsg(_T("Info"),
		Stringify(_T("Mapping with [%d] point pairs"), N));
	LogMsg(_T("Info"),
		Stringify(_T("Mapping Error(rms) : CH1X[%f] CH1Y[%f] CH2X[%f] CH2Y[%f]"), m_xerr1, m_yerr1, m_xerr2, m_yerr2 ) );

	return 0;
}

double CMapping::X2(double x1, double y1)
{
	if ( m_is_mapping_ready )	return IDLPolyFit2D3Estimate( x1, y1, m_xcoeff2 );
	return m_rough_xcoeff2[0] + m_rough_xcoeff2[1]*x1 + m_rough_xcoeff2[2]*y1;
}

double CMapping::Y2(double x1, double y1)
{
	if ( m_is_mapping_ready )	return IDLPolyFit2D3Estimate( x1, y1, m_ycoeff2 );
	return m_rough_ycoeff2[0] + m_rough_ycoeff2[1]*x1 + m_rough_ycoeff2[2]*y1;
}
double CMapping::X1(double x2, double y2)
{
	if ( m_is_mapping_ready )	return IDLPolyFit2D3Estimate( x2, y2, m_xcoeff1 );
	return m_rough_xcoeff1[0] + m_rough_xcoeff1[1]*x2 + m_rough_xcoeff1[2]*y2;
}

double CMapping::Y1(double x2, double y2)
{
	if ( m_is_mapping_ready )	return IDLPolyFit2D3Estimate( x2, y2, m_ycoeff1 );
	return m_rough_ycoeff1[0] + m_rough_ycoeff1[1]*x2 + m_rough_ycoeff1[2]*y2;
}

int CMapping::SuperposeOnto1( UINT w, UINT h, double *destFrame, double *srcFrame, double *srcBackground, 
						UINT xfrom, UINT yfrom, UINT area_w, UINT area_h )
{
	if ( !m_is_mapping_ready || !IsCompatible( w, h ) )	return -1;
	if ( !destFrame || !srcFrame )	return -1;

	for ( UINT y = yfrom ; y < yfrom + area_h ; y++ )
	{
		for ( UINT x = xfrom ; x < xfrom + area_w ; x++ )
		{
			double f = srcFrame[ w*y + x ];
			if ( srcBackground )	f -= srcBackground[ w*y + x ];
			if ( f <= 0 )	continue;

			double x1 = X1( x, y );
			double y1 = Y1( x, y );
			int ox = (int) ( x1 + 0.5 );
			int oy = (int) ( y1 + 0.5 );
			int px = ( x1 > ox ) ? ox+1 : ox-1;
			int py = ( y1 > oy ) ? oy+1 : oy-1;
			BOOL ox_ok = ( 0 <= ox && ox < (int) w );
			BOOL oy_ok = ( 0 <= oy && oy < (int) h );
			BOOL px_ok = ( 0 <= px && px < (int) w );
			BOOL py_ok = ( 0 <= py && py < (int) h );
			if ( ox_ok && oy_ok )	destFrame[ w*oy + ox ] += fabs((x1-px)*(y1-py))*f;
			if ( ox_ok && py_ok )	destFrame[ w*py + ox ] += fabs((x1-px)*(y1-oy))*f;
			if ( px_ok && oy_ok )	destFrame[ w*oy + px ] += fabs((x1-ox)*(y1-py))*f;
			if ( px_ok && py_ok )	destFrame[ w*py + px ] += fabs((x1-ox)*(y1-oy))*f;
		}
	}
	return 0;
}

int CMapping::SuperposeOnto2( UINT w, UINT h, double *destFrame, double *srcFrame, double *srcBackground, 
						UINT xfrom, UINT yfrom, UINT area_w, UINT area_h )
{
	if ( !m_is_mapping_ready || !IsCompatible( w, h ) )	return -1;
	if ( !destFrame || !srcFrame )	return -1;

	for ( UINT y = yfrom ; y < yfrom + area_h ; y++ )
	{
		for ( UINT x = xfrom ; x < xfrom + area_w ; x++ )
		{
			double f = srcFrame[ w*y + x ];
			if ( srcBackground )	f -= srcBackground[ w*y + x ];
			if ( f <= 0 )	continue;

			double x2 = X2( x, y );
			double y2 = Y2( x, y );
			int ox = (int) ( x2 + 0.5 );
			int oy = (int) ( y2 + 0.5 );
			int px = ( x2 > ox ) ? ox+1 : ox-1;
			int py = ( y2 > oy ) ? oy+1 : oy-1;
			BOOL ox_ok = ( 0 <= ox && ox < (int) w );
			BOOL oy_ok = ( 0 <= oy && oy < (int) h );
			BOOL px_ok = ( 0 <= px && px < (int) w );
			BOOL py_ok = ( 0 <= py && py < (int) h );
			if ( ox_ok && oy_ok )	destFrame[ w*oy + ox ] += fabs((x2-px)*(y2-py))*f;
			if ( ox_ok && py_ok )	destFrame[ w*py + ox ] += fabs((x2-px)*(y2-oy))*f;
			if ( px_ok && oy_ok )	destFrame[ w*oy + px ] += fabs((x2-ox)*(y2-py))*f;
			if ( px_ok && py_ok )	destFrame[ w*py + px ] += fabs((x2-ox)*(y2-oy))*f;
		}
	}
	return 0;
}