#include "stdafx.h"
#include "smCamera.h"
#include "PeakFinder.h"
#include "Circle.h"
#include <math.h>

#define NUM_INTENSITY_LEVELS				(256)
#define Z_VALUE		(3.00)

static int __get_next_scan_site(int &x, int &y)
{
	int r = max( abs(x), abs(y) );
	if ( x == r && y == r )	// move on to the next shell
	{
		x++;
		return r+1;
	}

	if ( y == r )	x++;		// top
	else if ( x == -r )	y++;	// left
	else if ( y == -r )	x--;	// bottom
	else if ( x == r )	y--;	// right
	else return -1;	// should not be reached

	return r;
}

CPeakFinder::CPeakFinder()
{
	m_data = NULL;
	m_2bdata = NULL;
	Reset();
}

CPeakFinder::~CPeakFinder()
{
	Reset();
}

void CPeakFinder::Reset()
{
	m_frame_w = 0;
	m_frame_h = 0;

	m_radius = -1.0;
	m_threshold = -1.0;

	if ( m_data )	delete [] m_data;
	m_data = NULL;
	m_frame = NULL;
	m_bgnd = NULL;

	if ( m_2bdata )	delete [] m_2bdata;
	m_2bdata = NULL;
	m_found = NULL;

	m_peaks.SetSize(0);
	m_not_peaks.SetSize(0);
}

void CPeakFinder::Clear()
{
	memset( m_found, 0, sizeof(UINT16)*m_frame_w*m_frame_h );
	m_peaks.SetSize(0);
	m_not_peaks.SetSize(0);
}

int CPeakFinder::SetFrame(UINT16 w, UINT16 h, double *frame, UINT32 bgnd, UINT32 scaler)
{
	if ( !frame )	return -1;

	Reset();
	try	{	m_data = new double[2*w*h];	}
	catch(CException *e)
	{
		e->Delete();
		m_data = NULL;
		return -1;
	}
	try	{	m_2bdata = new UINT16[w*h];	}
	catch(CException *e)
	{
		e->Delete();
		delete [] m_data;
		m_data = NULL;
		m_2bdata = NULL;
		return -1;
	}

	m_frame_w = w;
	m_frame_h = h;
	m_background = bgnd;
	m_data_scaler = scaler;

	m_frame = m_data;
	memcpy( m_frame, frame, sizeof(double)*w*h );

	m_bgnd = m_data + w*h;
	memset( m_bgnd, 0, sizeof(double)*w*h );
	for ( UINT x = 0 ; x < w ; x++ )
		for ( UINT y = 0 ; y < h ; y++ )
			Background( x, y ) = m_background;

	m_found = m_2bdata;
	memset( m_found, 0, sizeof(UINT16)*w*h );

	return 0;
}

int CPeakFinder::UpdateFrame(UINT16 w, UINT16 h, double *frame)
{
	if ( w != m_frame_w || h != m_frame_h )	return -1;
	memcpy( m_frame, frame, sizeof(double)*w*h );
	memset( m_bgnd, 0, sizeof(double)*w*h );

	return 0;
}

void CPeakFinder::MakeBackground(UINT xfrom, UINT yfrom, UINT area_w, UINT area_h)
{
	double *area = new double[ area_w*area_h ];
	int erange = CCircle::extended_range( m_radius );
    
	UINT N = 0;
	for ( UINT x0 = xfrom ; x0 < xfrom+area_w ; x0++ )
	{
		for ( UINT y0 = yfrom ; y0 < yfrom+area_h ; y0++ )
		{
			area[N] = Frame( x0, y0 );
			N++;
		}
	}

	double framebg = Select_Kth_among_N( N/2, N, area );
	double f;

	for ( UINT x0 = xfrom ; x0 < xfrom+area_w ; x0++ )
	{
		for ( UINT y0 = yfrom ; y0 < yfrom+area_h ; y0++ )
		{
			f = Frame( x0, y0 );
			if ( f <= framebg )
			{
				Background( x0, y0 ) = f;
			}
			else
			{
                N = 0;
				for ( int x = -erange ; x <= erange ; x++ )
				{
					int x1 = x0 + x ;
					if ( x1 < (int)xfrom || (int)(xfrom+area_w) < x1 )
						continue;
					for ( int y = -erange ; y <= erange ; y++ )
					{
						int y1 = y0 + y ;
						if ( y1 < (int)yfrom || (int)(yfrom+area_h) < y1 )
							continue;
						
						area[N] = Frame( x0+x, y0+y );
						N++;
					}
				}
				Background( x0, y0 ) = Select_Kth_among_N( N/2, N, area );
			}
		}
	}
	delete [] area;
	return;
}


int CPeakFinder::MarkPeakPosition(CPeak *peak)
{
	if ( !peak || !peak->IsValid() )	return -1;

//	UINT16 found_peak_no;
	int orgx = (int) ( peak->x + 0.5 );
	int orgy = (int) ( peak->y + 0.5 );
	int range = CCircle::range( m_radius );
	int rx = 0;
	int ry = 0;
	while ( 1 )
	{
		if ( 0 <= orgx+rx && orgx+rx < (int) m_frame_w 
			&& 0 <= orgy+ry && orgy+ry < (int) m_frame_h )
		{
			if ( CCircle::on( rx, ry, m_radius ) )
			{
//				found_peak_no = PeakFound( orgx+rx, orgy+ry );
//				if ( found_peak_no > 0 )
//				{
//					m_peaks[found_peak_no-1].is_good = FALSE;
//					m_peaks[peak_no].is_good = FALSE;
//				}
//				PeakFound( orgx+rx, orgy+ry ) = peak_no+1;
				PeakFound( orgx+rx, orgy+ry ) = 0x01;
			}
		}
		if ( __get_next_scan_site( rx, ry ) > range )	break;
	}

	return 0;
}

int CPeakFinder::MarkNotPeakPosition( UINT x, UINT y )
{
	int orgx = (int) x;
	int orgy = (int) y;
	int range = CCircle::range( 2 * m_radius );
	for ( int rx = -range ; rx <= range ; rx++ )
		for ( int ry = -range ; ry <= range ; ry++ )
		{
            if ( 0 <= orgx+rx && orgx+rx < (int) m_frame_w 
				&& 0 <= orgy+ry && orgy+ry < (int) m_frame_h )
			{
				if ( CCircle::on( rx, ry, 2 * m_radius ) )
				{
					if ( PeakFound( orgx+rx, orgy+ry ) != 0x01 )
					    PeakFound( orgx+rx, orgy+ry ) = 0x02;
				}
			}
		}

	return 0;
}

int CPeakFinder::SearchPeakAt(UINT orgx, UINT orgy, int ll, int rr, int bb, int tt, CPeak *peak)
{
	double th = m_data_scaler * ( m_threshold / 100 ) ;
	double bg = Background( orgx, orgy );
	double f0 = Frame( orgx, orgy ) - bg;
	if ( f0 < th )	return -1;

	int range = CCircle::range( m_radius );
	int erange = CCircle::extended_range( m_radius );
	if ( (int)orgx-erange < ll || rr < (int)orgx+erange )	return -1;
	if ( (int)orgy-erange < bb || tt < (int)orgy+erange )	return -1;

	double pi = CCircle::pi();
	double sigma = m_radius/Z_VALUE;
	double sqsigma = SQR(sigma);
	//double ath = ( 1.0 - exp( -0.5 * SQR(Z_VALUE) ) )/( 0.5 * SQR(Z_VALUE) );

	int cnt = 0;
	double sum = 0.0;
	double lsqint = 0.0;
	double lsqerrx = 0.0;
	double lsqerry = 0.0;
	double sqerr, lsqerr = 2*pi*SQR(f0)*sqsigma;
	// Actually, this should be pi*SQR(f0)*SQR(sigma), but x2 makes sure that lsqfit can not be the least square error

	BOOL is_good = TRUE;
	for ( double offx = -0.5 ; offx < 0.5 + ZERO_TOLERANCE ; offx += 0.1 )
		for ( double offy = -0.5 ; offy < 0.5 + ZERO_TOLERANCE ; offy += 0.1 )
		{
			sqerr = 0.0;
			cnt = 0;
			sum = 0.0;
            for ( int rx = -range; rx <= range ; rx++ )
				for ( int ry = -range; ry <= range ; ry++ )
					if ( CCircle::on( rx, ry, m_radius ) )
					{
						double f = Frame( orgx+rx, orgy+ry ) - bg;
						if ( f > f0 && !( rx == 0 && ry == 0 ) )	return -1;
		
						if ( CCircle::in( rx, ry, m_radius ) )
						{
							cnt ++;
							sum += f;
							sqerr += SQR( f0 * exp( -0.5 * ( SQR( rx - offx ) + SQR( ry - offy ) ) / sqsigma ) - f );
							//if ( CCircle::on( rx, ry, sigma ) && f < 0 )	return -1;
						}
                        else if ( f >= 0.5 * f0 )
						{
							is_good = FALSE;
						}
					}

			if ( sqerr <= lsqerr )
			{
				lsqerr = sqerr;
				lsqint = sum/cnt;
				lsqerrx = offx;
				lsqerry = offy;
			}
		}

	if ( lsqint < th )	return -1;
	if ( peak )
	{
		if ( is_good )
		{
			peak->x = (float) ( orgx + lsqerrx );
			peak->y = (float) ( orgy + lsqerry );
			peak->is_good = TRUE;
		}
		else
		{
			peak->x = (float) ( orgx );
			peak->y = (float) ( orgy );
			peak->is_good = FALSE;
		}
		peak->sx = (float) sigma;
		peak->sy = (float) sigma;
			
	}
	return 0;
}


int CPeakFinder::FindPeaks(UINT xfrom, UINT yfrom, UINT area_w, UINT area_h)
{
	if ( !m_frame || m_radius <= 0  )	return -1;
	if ( area_w <= 0 || area_h <= 0 )	return -1;
	if ( xfrom < 0 || xfrom + area_w > m_frame_w 
		|| yfrom < 0 || yfrom + area_h > m_frame_h )	return -1;

	MakeBackground(xfrom, yfrom, area_w, area_h);

	double minv = -1.0;
	double maxv = -1.0;
	for ( UINT y = yfrom ; y < yfrom + area_h ; y++ )
	{
		for ( UINT x = xfrom ; x < xfrom + area_w ; x++ )
		{
			double f = Frame(x,y) - Background(x,y);
			if ( minv < 0.0 )	minv = f;
			if ( f < minv )	
				minv = f;
			else if ( f > maxv )	
				maxv = f;
		}
	}

	long *intensity_list = new long[m_frame_w*m_frame_h];
	long intensity_level_first[NUM_INTENSITY_LEVELS];
	long intensity_level_last[NUM_INTENSITY_LEVELS];

	memset(intensity_list, 0, sizeof(long)*m_frame_w*m_frame_h);
	for ( int i = 0 ; i < NUM_INTENSITY_LEVELS ; i++ )
		intensity_level_first[i] = intensity_level_last[i] = -1;


	for ( UINT x = xfrom ; x < xfrom + area_w ; x++ )
	{
		for ( UINT y = yfrom ; y < yfrom + area_h ; y++ )
		{
			long index = m_frame_w * y + x;
			UINT level = Pixel2Byte( Frame(x,y) - Background(x,y), minv, maxv );
	
            if ( intensity_level_first[level] < 0 )
				intensity_level_first[level] = intensity_level_last[level] = index ;

			intensity_list[ intensity_level_last[level] ] = index;
			intensity_list[ index ]  = -1;
			intensity_level_last[level] = index;
		}
	}

	for ( int lv = NUM_INTENSITY_LEVELS-1 ; lv > 0 ; lv-- )
	{
		long index = intensity_level_first[lv];
		while ( index >= 0 )
		{
			int x, y;
			x = index % m_frame_w ;
			y = index / m_frame_w ;

//			if ( !PeakFound( x, y )
//				&&  (Frame(x,y)-Background(x,y)) > m_data_scaler * m_threshold / 100 )
			if ( PeakFound( x, y ) == 0 )
			{
				CPeak peak;
				if ( SearchPeakAt(x, y, xfrom, xfrom+area_w-1, yfrom, yfrom+area_h-1, &peak) >= 0 )
				{
					m_peaks.Add(peak);
					MarkPeakPosition(&peak);
				}
			}

			if ( index == intensity_level_last[lv] )	break;
			index = intensity_list[index];
		}
	}

	delete [] intensity_list;
	return 0;
}

int CPeakFinder::FindNotPeaks(UINT xfrom, UINT yfrom, UINT area_w, UINT area_h)
{
	double th = m_data_scaler * ( m_threshold / 100 ) ;
	double sigma = m_radius/Z_VALUE;
	int ll = (int) xfrom;
	int rr = (int) xfrom + area_w - 1;
	int bb = (int) yfrom;
	int tt = (int) yfrom + area_h - 1;

	if ( !m_frame || m_radius <= 0  )	return -1;
	if ( area_w <= 0 || area_h <= 0 )	return -1;
	if ( ll < 0 || rr >= m_frame_w || bb < 0 || tt >= m_frame_h )	return -1;

	m_not_peaks.SetSize(0);

	for ( UINT x = 0 ; x < m_frame_w ; x++ )
		for ( UINT y = 0 ; y < m_frame_h ; y++ )
			if ( PeakFound( x, y ) != 0x01 )	PeakFound( x, y ) = 0x00;

	int peaksl = rr;
	int peaksr = ll;
	int peaksb = tt;
	int peakst = bb;
	for ( int i = 0 ; i < m_peaks.GetCount() ; i++ )
	{
		CPeak p = m_peaks[i];
		if ( !p.IsValid() )	continue;      
		int x = (int) (p.x + 0.5);
		int y = (int) (p.y + 0.5);
		MarkNotPeakPosition( x, y );
		if ( x < peaksl )	peaksl = x;
		if ( x > peaksr )	peaksr = x;
		if ( y < peaksb )	peaksb = y;
		if ( y > peakst )	peakst = y;
	}

	for ( int x = ll ; x <= rr ; x++ )
	{
		for ( int y = bb ; y <= peaksb ; y++ )	MarkNotPeakPosition( x, y );
		for ( int y = peakst ; y <= tt ; y++ )	MarkNotPeakPosition( x, y );
	}
	for ( int y = bb ; y <= tt; y++ )
	{
		for ( int x = ll ; x <= peaksl ; x++ )	MarkNotPeakPosition( x, y );
		for ( int x = peaksr ; x <= rr ; x++ )	MarkNotPeakPosition( x, y );
	}


	double minv = -1.0;
	double maxv = -1.0;
	for ( int x = ll ; x <= rr ; x++ )
	{
		for ( int y = bb ; y <= tt ; y++ )
		{
			if ( PeakFound( x, y ) == 0x00 )
			{
				double f = Frame( x, y );
				if ( minv < 0.0 )	minv = f;
				if ( f < minv )		
					minv = f;
				else if ( f > maxv )	
					maxv = f;
			}
		}
	}

	long *intensity_list = new long[area_w*area_h];
	long intensity_level_first[NUM_INTENSITY_LEVELS];
	long intensity_level_last[NUM_INTENSITY_LEVELS];

	memset(intensity_list, 0, sizeof(long)*area_w*area_h);
	for ( int i = 0 ; i < NUM_INTENSITY_LEVELS ; i++ )
		intensity_level_first[i] = intensity_level_last[i] = -1;


	for ( int x = ll ; x <= rr ; x++ )
	{
		for ( int y = bb ; y <= tt ; y++ )
		{
			long index = area_w * ( y - yfrom ) + ( x - xfrom ) ;
			UINT level = Pixel2Byte( Frame( x, y ), minv, maxv );

            if ( intensity_level_first[level] < 0 )
				intensity_level_first[level] = intensity_level_last[level] = index ;

			intensity_list[ intensity_level_last[level] ] = index;
			intensity_list[ index ]  = -1;
			intensity_level_last[level] = index;
		}
	}

	for ( int lv = 0 ; lv < NUM_INTENSITY_LEVELS ; lv++ )
	{
		long index = intensity_level_first[lv];
		while ( index >= 0 )
		{
			UINT x, y;
			x = xfrom + ( index % area_w );
			y = yfrom + ( index / area_w );

			if ( Frame( x, y ) - Background( x, y ) >= th )
				break;

			if ( PeakFound( x, y ) == 0x00 )
			{
				CPeak peak;
				peak.x = (float) x;
				peak.y = (float) y;
				peak.sx = (float) sigma;
				peak.sy = (float) sigma;
				m_not_peaks.Add(peak);
				MarkNotPeakPosition( x, y );
			}

			if ( index == intensity_level_last[lv] )	break;
			index = intensity_list[index];
		}
	}
	delete [] intensity_list;
	return 0;
}


int CPeakFinder::DrawFrame(UINT16 w, UINT16 h, COLORREF *display)
{
	if ( m_frame_w != w || m_frame_h != h )	return -1;
	if ( !display )	return -1;

	CChannels ch( w, h );
	memset(display, 0, sizeof(COLORREF)*w*h);
	for ( UINT y = 0 ; y < ch.h ; y++ )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			for ( UINT x = ch.l[i] ; x <= ch.r[i] ; x++ )
			{
				display[ w*y + x ] = ProgramColor0( i, Pixel2Byte( Frame(x,y) ) );
			}
		}
	}

	return 0;
}

int CPeakFinder::DrawBgndSubFrame(UINT16 w, UINT16 h, COLORREF *display)
{
	if ( m_frame_w != w || m_frame_h != h )	return -1;
	if ( !display )	return -1;

	CChannels ch( w, h );
	memset(display, 0, sizeof(COLORREF)*w*h);
	for ( UINT y = 0 ; y < ch.h ; y++ )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			for ( UINT x = ch.l[i] ; x <= ch.r[i] ; x++ )
			{
				display[ w*y + x ] = ProgramColor0( i, Pixel2Byte( Frame(x,y)-Background(x,y), 0 ) );
			}
		}
	}

	return 0;
}
int CPeakFinder::DrawFrameAndPeaks(UINT16 w, UINT16 h, COLORREF *display)
{
	if ( DrawFrame( w, h, display ) < 0 )	return -1;
	//if ( DrawBgndSubFrame( w, h, display ) < 0 )	return -1;

	for ( int i = 0 ; i < m_peaks.GetCount() ; i++ )
	{
		CPeak p = m_peaks[i];
		if ( !p.IsValid() )	continue;
		
		int range = CCircle::range( m_radius );
		COLORREF color = ( p.is_good ) ?  RGBReverse( 0, 64, 0 ) : RGBReverse( 64, 0, 0 ) ;
      
		int orgx = (int) (p.x + 0.5);
		int orgy = (int) (p.y + 0.5);
		for ( int x = -range ; x <= range ; x++ )
		{
			for ( int y = -range ; y <= range ; y++ )
			{
				//if ( CCircle::online( orgx+x-p.x, orgy+y-p.y, m_radius) == FALSE )	continue;
				if ( CCircle::online( x, y, m_radius) == FALSE )	continue;
				if ( orgx+x < 0 || (int)w <= orgx+x || orgy+y < 0 || (int)h <= orgy+y )	continue;
                display[ w*(orgy+y) + orgx + x ] = color;
			}
		}
	}

	return 0;
}

int CPeakFinder::DrawFrameAndNotPeaks(UINT16 w, UINT16 h, COLORREF *display)
{
	if ( DrawFrame( w, h, display ) < 0 )	return -1;
	//if ( DrawBgndSubFrame( w, h, display ) < 0 )	return -1;

	for ( int i = 0 ; i < m_not_peaks.GetCount() ; i++ )
	{
		CPeak p = m_not_peaks[i];
		if ( !p.IsValid() )	continue;
		
		int range = CCircle::range( m_radius );
		COLORREF color = RGBReverse( 64, 0, 0 ) ;
      
		int orgx = (int) (p.x + 0.5);
		int orgy = (int) (p.y + 0.5);
		for ( int x = -range ; x <= range ; x++ )
		{
			for ( int y = -range ; y <= range ; y++ )
			{
				if ( CCircle::online( x, y, m_radius) == FALSE )	continue;
				if ( orgx+x < 0 || (int)w <= orgx+x || orgy+y < 0 || (int)h <= orgy+y )	continue;
                display[ w*(orgy+y) + orgx + x ] = color;
			}
		}
	}

	return 0;
}

int CPeakFinder::SaveSnapshot(LPCTSTR filepath, LPCTSTR postfix)
{
	CString filepathstr = filepath;
	CString postfixstr = postfix;
	if ( filepathstr.IsEmpty() )	return -1;

	int n = filepathstr.ReverseFind( (TCHAR)'.' );
	if ( n >= 0 )	filepathstr = filepathstr.Mid(0, n);
	
	CTIFFFileWriter tiff;
	//filepathstr.Replace(CAMERAFILE_FILM_PREFIX, CAMERAFILE_TRACE_PREFIX);
	filepathstr.AppendFormat(_T("%s.%s"), ( postfixstr.IsEmpty() ) ? _T("") : _T("_")+postfixstr, CAMERAFILE_TIFF1_EXT);
	tiff.SetFilepath(filepathstr);	
	tiff.m_frame_w = m_frame_w;
	tiff.m_frame_h = m_frame_h;
	tiff.m_background = m_background;
	tiff.m_data_scaler = m_data_scaler;
	//XXX : Unfair assumption that the pixel values are within UINT32 range.
	//tiff.m_byte_per_pixel = sizeof(UINT32);
	//XXX : Unfair assumption that the pixel values are within UINT16 range.
	tiff.m_byte_per_pixel = 2;
	tiff.m_8bit_color = FALSE;

	if ( tiff.Open() < 0 )	return -1;
	tiff.Write( 1, m_frame );
	tiff.Close();
	return 0;
}