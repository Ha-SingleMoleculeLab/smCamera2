// MovieAnalysisDialog.cpp : implementation file

#include "stdafx.h"
#include "smCamera.h"
#include "MovieAnalysisDialog.h"
#include "Circle.h"
#include <math.h>
#include ".\movieanalysisdialog.h"

#define DEFAULT_ANALYSIS_PATH	(_PATH_MOVIES)
#define DEFAULT_SPOT_RADIUS		(10)	//in px
#define DEFAULT_PEAK_RADIUS		(3)		//in px
#define DEFAULT_PEAK_THRESHOLD	(10.0)	//%

#define Z_VALUE			(3.00)

IMPLEMENT_DYNAMIC(CMovieAnalysisDialog, CDialog)
CMovieAnalysisDialog::CMovieAnalysisDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMovieAnalysisDialog::IDD, pParent)
	, m_fspath(_T(""))
	, m_repeat_fs(FALSE)
	, m_peak_radius(0)
	, m_peak_threshold(0)
	, m_find_CH1(FALSE)
	, m_find_CH2(FALSE)
	, m_find_and_save(FALSE)
	, m_peak_sigma(0)
	, m_analyze_bad_peaks(FALSE)
	, m_analyze_again(FALSE)
	, m_analyze_bg_peaks(FALSE)
{
//	m_reader = NULL;
	m_bitmap = NULL;
	m_display_buffer = NULL;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		m_point[i].SetPoint(-1, -1);
}

CMovieAnalysisDialog::~CMovieAnalysisDialog()
{
}


static int __get_next_scan_site(int &x, int &y)
{
	int r = max( abs(x), abs(y) );
	if ( x == r && y == r )	// move on to the next shell
	{
		x++;
		return r+1;
	}

	if ( y == r )	x++;		// top
	else if ( x == -r )	y++;	// left
	else if ( y == -r )	x--;	// bottom
	else if ( x == r )	y--;	// right
	else return -1;	// should not be reached

	return r;
}

BOOL CMovieAnalysisDialog::OnInitDialog()
{
	CString str;
	CDialog::OnInitDialog();

	CArchive *ar = NULL;
	if ( DoesProgramFileExist( GetProgramFilePath( _PATH_MOVIE_ANALYSIS, _T("analysis.save") ) ) )
	{
        ar = OpenProgramFileToRead( GetProgramFilePath( _PATH_MOVIE_ANALYSIS, _T("analysis.save") ) );
	}

	if ( ar )
	{
		ar->ReadString(str);
		m_mapping.Load(str);

		ar->ReadString(str);
		m_fspath = str;
		m_fs.Load(m_fspath);

		ar->ReadString(str);
		m_peak_radius = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
		ar->ReadString(str);
		m_peak_threshold = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );		
		ar->ReadString(str);
		m_find_CH1 = _tstoi(str);
		ar->ReadString(str);
		m_find_CH2 = _tstoi(str);

		ar->ReadString(str);				
		m_peak_sigma = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );

		ar->ReadString(str);
		m_spot_radius = _tstoi(str);
		ar->ReadString(str);
		m_directory.SetPath( str );		

		CloseProgramFile(ar);
	}
	else
	{
		m_mapping.Load();
		m_fs.Load();
		m_fspath = m_fs.DefaultPath();

		m_peak_radius = LIMIT_DECIMAL_PLACES( DEFAULT_PEAK_RADIUS, 3 );
		m_peak_threshold = LIMIT_DECIMAL_PLACES( DEFAULT_PEAK_THRESHOLD, 3 );	
		m_find_CH1 = TRUE;
		m_find_CH2 = TRUE;

		m_peak_sigma = LIMIT_DECIMAL_PLACES( m_peak_radius / Z_VALUE, 3 );

		m_spot_radius = DEFAULT_SPOT_RADIUS;
		m_directory.SetPath( DEFAULT_ANALYSIS_PATH );
	}
	if ( m_spot_radius <= 0 )	m_spot_radius = 1;

	m_is_analyzing = FALSE;
	m_stop_analyzing = FALSE;

	m_film.Close();
	m_peak_finder.Reset();

	CWnd *pWnd;
	pWnd = GetDlgItem(IDC_MAPPING_INFO);
	if ( pWnd )	pWnd->SetWindowText( m_mapping.Information() );
	
	LoadProgramColorTable();

	SetUIs();
	UpdateData(FALSE);	
	return TRUE;
}

void CMovieAnalysisDialog::OnCancel()
{
	if ( m_is_analyzing )
	{
		LogErr(_T("Analysis is in progress. Stop it first."));
		return;
	}
	DestroyWindow();
}

void CMovieAnalysisDialog::OnOK()
{
	SetFocus();
	return;
}

void CMovieAnalysisDialog::OnDestroy()
{
	CString str;
	CArchive *ar = OpenProgramFileToWrite( 
					GetProgramFilePath( _PATH_MOVIE_ANALYSIS, _T("analysis.save") )
					);
	if ( ar )
	{
		str.Format(_T("%s\r\n"), m_mapping.m_path);
		ar->WriteString(str);
		str.Format(_T("%s\r\n"), m_fspath);
		ar->WriteString(str);

		str.Format(_T("%f\r\n"), m_peak_radius);
		ar->WriteString(str);
		str.Format(_T("%f\r\n"), m_peak_threshold);
		ar->WriteString(str);
		str.Format(_T("%d\r\n"), m_find_CH1);
		ar->WriteString(str);
		str.Format(_T("%d\r\n"), m_find_CH2);
		ar->WriteString(str);

		str.Format(_T("%f\r\n"), m_peak_sigma);
		ar->WriteString(str);

		str.Format(_T("%d\r\n"), m_spot_radius);
		ar->WriteString(str);
		str = m_directory.m_path;
		ar->WriteString(str);

		CloseProgramFile(ar);
	}

	FreeFrame();

	//if ( m_reader )	delete m_reader;
	m_film.Close();
	m_peak_finder.Reset();
	m_mapping.Reset(0,0);
	m_fs.Unload();

	_tchdir(_PATH_ROOT);
	CDialog::OnDestroy();
}

void CMovieAnalysisDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_IMAGE, m_image);
	DDX_Control(pDX, IDC_SPOT1, m_spot[CH1]);
	DDX_Control(pDX, IDC_SPOT2, m_spot[CH2]);

	DDX_Text(pDX, IDC_FSPATH, m_fspath);
	DDX_Check(pDX, IDC_REPEAT_FS, m_repeat_fs);

	DDX_Text(pDX, IDC_PEAK_RADIUS, m_peak_radius);
	DDX_Text(pDX, IDC_PEAK_THRESHOLD, m_peak_threshold);
	DDX_Check(pDX, IDC_FIND_CH1, m_find_CH1);
	DDX_Check(pDX, IDC_FIND_CH2, m_find_CH2);
	DDX_Check(pDX, IDC_FIND_AND_SAVE, m_find_and_save);

	DDX_Text(pDX, IDC_PEAK_SIGMA, m_peak_sigma);
	DDX_Check(pDX, IDC_ANALYZE_BAD_PEAKS, m_analyze_bad_peaks);
	DDX_Check(pDX, IDC_ANALYZE_AGAIN, m_analyze_again);	
	DDX_Check(pDX, IDC_ANALYZE_BG_PEAKS, m_analyze_bg_peaks);

	DDX_Control(pDX, IDC_FRAME_SLIDER, m_slider);

	if ( pDX->m_bSaveAndValidate != TRUE )
	{
		CWnd *pWnd;
		CString str;

		str.Format(_T("Radius : %d px"), m_spot_radius);		
		pWnd = GetDlgItem(IDC_R1_TEXT);
		if ( pWnd )	pWnd->SetWindowText(str);
		pWnd = GetDlgItem(IDC_R2_TEXT);
		if ( pWnd )	pWnd->SetWindowText(str);

		int x, y;
		x = m_point[CH1].x;
		y = m_point[CH1].y;
		pWnd = GetDlgItem(IDC_SPOT1_TEXT);
		if ( m_film.IsOpen() && x >= 0 && y >= 0 )
			str.Format(_T("%.0f at ( %d, %d )"), m_peak_finder.Frame(x,y), x, y );
		else	str = _T("");
		if ( pWnd ) pWnd->SetWindowText(str);

		x = m_point[CH2].x;
		y = m_point[CH2].y;
		pWnd = GetDlgItem(IDC_SPOT2_TEXT);
		if ( m_film.IsOpen() && x >= 0 && y >= 0 )
			str.Format(_T("%.0f at ( %d, %d )"), m_peak_finder.Frame(x,y), x, y );
		else	str = _T("");
		if ( pWnd ) pWnd->SetWindowText(str);

		pWnd = GetDlgItem(IDC_FILEPATH);
		if ( pWnd )
		{
			pWnd->SetWindowText( m_film.m_filepath );
			((CEdit*)pWnd)->SetSel(0, -1);
		}
		pWnd = GetDlgItem(IDC_FRAME_NO);
		if ( pWnd )
		{
			str.Format(_T("%d"), m_film.IsOpen() ? m_film.LastFrameNo() : -1);
			pWnd->SetWindowText( str );
		}
		pWnd = GetDlgItem(IDC_FSPATH);
		if ( pWnd )	((CEdit*)pWnd)->SetSel(0, -1);
	}
}


void CMovieAnalysisDialog::SetUIs()
{
	CWnd *pWnd;
	BOOL flag;
	CString str;

	if ( !m_is_analyzing )
		flag = TRUE;
	else
		flag = FALSE;

	pWnd = GetDlgItem(IDC_OPEN_FILE);
	if ( pWnd )	pWnd->EnableWindow(flag);

	pWnd = GetDlgItem(IDC_LOAD_MAP);
	if ( pWnd )	pWnd->EnableWindow(flag);

	pWnd = GetDlgItem(IDC_LOAD_FS);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_REPEAT_FS);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_APPLY_FS);
	if ( pWnd )	pWnd->EnableWindow(flag);

	pWnd = GetDlgItem(IDC_PEAK_RADIUS);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_PEAK_THRESHOLD);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_FIND_CH1);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_FIND_CH2);
	if ( pWnd )	pWnd->EnableWindow(flag);

	pWnd = GetDlgItem(IDC_PEAK_SIGMA);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_ANALYZE_BAD_PEAKS);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_ANALYZE_AGAIN);
	if ( pWnd )	pWnd->EnableWindow(flag);


	
	if ( m_film.IsOpen() && !m_is_analyzing )
		flag = TRUE;
	else 
		flag = FALSE;

	pWnd = GetDlgItem(IDC_FRAME_SLIDER);
	if ( pWnd )	pWnd->EnableWindow(flag);	
	pWnd = GetDlgItem(IDC_ANALYZE);
	if ( pWnd )	pWnd->EnableWindow(flag);



	pWnd = GetDlgItem(IDC_ANALYZE_FOLDER);
	if ( pWnd )	pWnd->EnableWindow(TRUE);
	if ( pWnd )	pWnd->SetWindowText( 
					(m_is_analyzing) ? _T("Stop") : _T("Analyze Folder") );
}



static RECT * __find_dest_rect(CDialog *dlg, CStatic *pane)
{
	static RECT	rect;
	long border_thickness;
	
	RECT dlgClientRct, dlgWinRct, paneWinRct;
	dlg->GetWindowRect(&dlgWinRct);
	dlg->GetClientRect(&dlgClientRct);

	pane->GetWindowRect(&paneWinRct);

	border_thickness = ( (dlgWinRct.right-dlgWinRct.left) - (dlgClientRct.right-dlgClientRct.left) )/2;
	rect.left = paneWinRct.left - ( dlgWinRct.left + border_thickness );
	dlgWinRct.top = dlgWinRct.bottom - border_thickness
					- (dlgClientRct.bottom-dlgClientRct.top) - border_thickness;
	rect.top = paneWinRct.top - ( dlgWinRct.top + border_thickness );
	rect.right = rect.left + paneWinRct.right - paneWinRct.left;
	rect.bottom = rect.top + paneWinRct.bottom - paneWinRct.top;

	return &rect;
}


void CMovieAnalysisDialog::InitFrame(UINT w, UINT h)
{
	CClientDC dcDlg (this);
	RECT *rect;

	FreeFrame();
	
	m_bitmap = new CBitmap();
	m_bitmap->CreateCompatibleBitmap(&dcDlg, w, h );
	m_display_buffer = new COLORREF[w*h];

	rect = __find_dest_rect(this, &m_image);
	m_image_left = rect->left;
	m_image_top = rect->top;
	m_image_width = rect->right - rect->left;
	m_image_height = rect->bottom - rect->top;

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		m_point[i].SetPoint(-1, -1);

		rect = __find_dest_rect(this, &(m_spot[i]));
		m_spot_left[i] = rect->left;
		m_spot_top[i] = rect->top;
		m_spot_width[i] = rect->right - rect->left;
		m_spot_height[i] = rect->bottom - rect->top;
	}

	memset(m_display_buffer, 0, sizeof(COLORREF)*w*h);
	UpdateFrame();

	if ( m_image_height * w >= m_image_width * h )
		m_image_height = (int) (( m_image_width * h * 1.0 / w ) + 0.5);
	else
		m_image_width = (int) (( m_image_height * w * 1.0 / h ) + 0.5 );

	return;
}



void CMovieAnalysisDialog::FreeFrame()
{
	if ( m_display_buffer )	delete [] m_display_buffer;
	m_display_buffer = NULL;
	if ( m_bitmap )	delete m_bitmap;
	m_bitmap = NULL;
}




BOOL CMovieAnalysisDialog::GetFrameCoordinate(CPoint pt, int *px, int *py)
{
	if ( !m_film.IsOpen() )	return FALSE;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	//say	w' = m_image_width / w
	//		h' = m_image_height / h
	//	[ image_left + x*w' ~ image_left + (x+1)*w' ]	-> x
	//	[ image_top + y*h' ~ image_top + (y+1)*h'	]	-> y
	//	x = (int) (pt.x - image_left)/w'
	//	y = (int) (pt.x - image_top)/h'
	int x = (int) ( w * (pt.x - m_image_left) * 1.0/m_image_width );
	int y = (int) ( h * (pt.y - m_image_top) * 1.0/m_image_height );
	if ( !( 0 <= x && x < (int)w && 0 <= y && y < (int)h ) )	return FALSE;

	if ( px )	*px = x;
	if ( py )	*py = y;
	return TRUE;;
}

void CMovieAnalysisDialog::DrawCircle(CDC &dcMem, int x, int y, int r, COLORREF color)
{
	if ( !m_film.IsOpen() )	return;
	
	CPen pen(PS_SOLID, 1, color);
	dcMem.SelectObject(&pen);
	dcMem.Arc(	x - r, y - r, x + 1 + r, y + 1 + r,
				x - r, y + 1 + r, x - r, y + 1 + r );
	return;
}

void CMovieAnalysisDialog::DrawCircle(CDC &dcMem, int x, int y)
{
	COLORREF color = RGB(255, 255, 0);
	return DrawCircle(dcMem, x, y, m_spot_radius, color);
}


void CMovieAnalysisDialog::DrawPointPairs(CClientDC &dcDlg, CDC &dcMem, CPoint pair[NUM_CHANNELS])
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	int view_l, view_t, view_w, view_h, view_r;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		int x, y;
		x = pair[i].x;
		y = pair[i].y;
		if ( x < 0 || y < 0 )	continue;
		view_r = (int) ceil( m_spot_radius * 4 * 1.0 / 3 );
		view_w = view_h = 2*view_r + 1;

		DrawCircle(dcMem, x, y);
		
        if ( x - view_r	< 0 )	view_l = 0;
		else if ( x + view_r >= (int) w )	view_l = w - 1 - view_w;
		else	view_l = x - view_r;
		if ( y - view_r < 0 )	view_t = 0;
		else if ( y + view_r >= (int) h )	view_t = h - 1 - view_h;
		else	view_t = y - view_r;

		dcDlg.StretchBlt( m_spot_left[i], m_spot_top[i], m_spot_width[i], m_spot_height[i],
							&dcMem, view_l, view_t, view_w, view_h, SRCCOPY );
	}
}


void CMovieAnalysisDialog::UpdateFrame()
{
	if ( !m_film.IsOpen() || !m_display_buffer )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	CClientDC dcDlg (this);
	CDC dcMem;
	
	dcMem.CreateCompatibleDC(&dcDlg);
	CBitmap *pOldBitmap = dcMem.SelectObject(m_bitmap);

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( m_point[i].x >= 0 && m_point[i].y >= 0 )	continue;
		dcMem.SetPixelV( 0, 0, RGB( 0, 0, 0 ) );		
		dcDlg.StretchBlt( m_spot_left[i], m_spot_top[i], m_spot_width[i], m_spot_height[i],
						&dcMem, 0, 0, 1, 1, SRCCOPY );
	}

	m_bitmap->SetBitmapBits(sizeof(COLORREF)*w*h, m_display_buffer);

	DrawPointPairs( dcDlg, dcMem, m_point );

	//	dcDlg.SetStretchBltMode(COLORONCOLOR);
	dcDlg.StretchBlt( m_image_left, m_image_top, m_image_width, m_image_height,
						&dcMem, 0, 0, w, h, SRCCOPY);

	dcMem.SelectObject(pOldBitmap);
	dcMem.DeleteDC();
	
	UpdateData(FALSE);
	return;
}

void CMovieAnalysisDialog::AnalyzeFile(BOOL analyze_again)
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	CChannels ch( w, h );

	int n;
	MSG message;
	CTraceFileWriter writer;
	CPeaksFileReader reader;
	CArray<CPeakSet> peaks;
	CArray<CPeakSet> not_peaks;

	n = writer.SetFilmpath( m_film.m_filepath );
	n = writer.SetFilepath( m_film.m_filepath );
	if ( n > 0 && !analyze_again )	return;
	if ( n < 0 )	goto FAIL;

	if ( !m_mapping.m_is_mapping_ready || !m_mapping.IsCompatible( w, h ) )	goto FAIL;

	LogMsg(_T("Info"), Stringify(_T("Analysis : [%s]"), m_film.m_filepath) );


	InitFrame(w, h);
	//m_film.MakeAverageFrame( from , to, NULL );
	//m_film.DrawFrame( w, h, m_display_buffer );
	//UpdateFrame();

	m_peak_finder.SetFrame( w, h, m_film.m_frame, m_film.m_background, m_film.m_data_scaler );
	m_peak_finder.SetRadius( m_peak_radius );
	m_peak_finder.SetThreshold( m_peak_threshold );

	if ( reader.ReadPeaksFileOf(m_film.m_filepath) >= 0 
		&& reader.m_frame_w == w && reader.m_frame_h == h )
	{
		int erange = CCircle::extended_range( m_peak_radius );
		peaks.SetSize(0);
		for ( int i = 0 ; i < reader.m_peaks.GetCount() ; i++ )
		{
			CPeakSet set = reader.m_peaks[i];
			CPeak &p1 = set.p[CH1];
			CPeak &p2 = set.p[CH2];

			if ( m_find_CH1 && m_find_CH2 )
			{
				if ( m_analyze_bad_peaks == FALSE && ( p1.IsGood() == FALSE || p2.IsGood() == FALSE ) )	continue;
			}
			else if ( m_find_CH1 )
			{
				if ( m_analyze_bad_peaks == FALSE && p1.IsGood() == FALSE ) continue;
				p2.x = (float) m_mapping.X2( p1.x, p1.y );
				p2.y = (float) m_mapping.Y2( p1.x, p1.y );
				p2.sx = (float) fabs( m_mapping.X2( p1.x+p1.sx, p1.y ) - m_mapping.X2( p1.x-p1.sx, p1.y ) ) / 2 ;
				p2.sy = (float) fabs( m_mapping.Y2( p1.x, p1.y+p1.sy ) - m_mapping.Y2( p1.x, p1.y-p1.sy ) ) / 2 ;
				p2.is_good = p1.is_good;
			}
			else if ( m_find_CH2 )
			{
				if ( m_analyze_bad_peaks == FALSE && p2.IsGood() == FALSE )	continue;
				p1.x = (float) m_mapping.X1( p2.x, p2.y );
				p1.y = (float) m_mapping.Y1( p2.x, p2.y );
				p1.sx = (float) fabs( m_mapping.X1( p2.x+p2.sx, p2.y ) - m_mapping.X1( p2.x-p2.sx, p2.y ) ) / 2 ;
				p1.sy = (float) fabs( m_mapping.Y1( p2.x, p2.y+p2.sy ) - m_mapping.Y1( p2.x, p2.y-p2.sy ) ) / 2 ;
				p1.is_good = p2.is_good;
			}
			else
			{
				continue;
			}

			int x0, y0;
            x0 = (int) ( p1.x + 0.5 );
			y0 = (int) ( p1.y + 0.5 );
			if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;

            x0 = (int) ( p2.x + 0.5 );
			y0 = (int) ( p2.y + 0.5 );
			if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;

			peaks.Add(set);
			m_peak_finder.m_peaks.Add(p1);
			m_peak_finder.m_peaks.Add(p2);
		}

		m_peak_finder.DrawFrameAndPeaks( w, h, m_display_buffer );
		UpdateFrame();

		BOOL find[NUM_CHANNELS];
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )	find[i] = FALSE;
		
		LogMsg(_T("Info"), Stringify(_T("Using saved .%s file - %d peaks in [%s]"), 
									CAMERAFILE_PEAKS_EXT, peaks.GetCount(), m_film.m_filepath) );
		writer.m_tlog.Write( w, h, m_film.m_frame_cycle, m_film.m_num_frames, 
							m_peak_radius, m_peak_sigma, find );
	}
	else
	{
		UINT frameno_offset = 0;
		BOOL eof = FALSE;
		do 
		{
			//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
			{
				if ( !IsDialogMessage(&message) )
				{
					::TranslateMessage(&message);
					::DispatchMessage(&message);
				}
			}
			if ( ::IsWindow(m_hWnd) )	UpdateWindow();

			if ( m_fs.Init() < 0 )
			{
				LogErr(_T("Frame Sequence is not loaded."));
				goto FAIL;
			}
			int cnt = 0;
			m_film.StartAveragingFrames();
			while ( m_fs.IsEnd() != TRUE )
			{
				if ( m_fs.Current() )
				{
					if ( frameno_offset + m_fs.CurrentFrameNo() >= m_film.m_num_frames )
					{
						eof = TRUE;
						break;
					}
					m_film.MoveFrame( frameno_offset + m_fs.CurrentFrameNo() );
					m_film.ReadFrame(NULL);
		
					cnt ++;
					m_film.AddToAveragingFrames();
				}
				m_fs.Next();
			}
			m_film.FinishAveragingFrames( cnt, NULL );
			LogMsg(_T("Info"), 
					Stringify(_T("Analysis : Searching Frames [ %u ~ %u ]"), 
							frameno_offset, frameno_offset+m_fs.m_sequence_cnt) );
			LogFlush();
			m_peak_finder.UpdateFrame( w, h, m_film.m_frame );

			if ( m_find_CH1 && m_find_CH2 )
			{
				m_peak_finder.MakeBackground(CH2);
				m_mapping.SuperposeOnto1( w, h, m_peak_finder.m_frame, m_peak_finder.m_frame, m_peak_finder.m_bgnd, ch.l[CH2], 0, ch.w, ch.h );
				m_peak_finder.FindPeaks(CH1);
			}
			else if ( m_find_CH1 )
				m_peak_finder.FindPeaks(CH1);
			else if ( m_find_CH2 )
				m_peak_finder.FindPeaks(CH2);

			m_peak_finder.DrawFrameAndPeaks( w, h, m_display_buffer );
			UpdateFrame();

			frameno_offset += m_fs.m_sequence_cnt;
		} while ( eof != TRUE && m_repeat_fs == TRUE );


		m_peak_finder.SaveSnapshot( m_film.m_filepath );
		int num_peaks = 0;
		int num_good_peaks = 0;
		int erange = CCircle::extended_range( Z_VALUE * m_peak_sigma );
		peaks.SetSize(0);
		for ( int i = 0 ; i < m_peak_finder.m_peaks.GetCount() ; i++ )
		{
			int x0, y0;
			CPeakSet set;
			if ( m_find_CH1 )
			{
				CPeak &p = set.p[CH1] = m_peak_finder.m_peaks[i];
				CPeak &cp = set.p[CH2];

			//	if ( m_analyze_bad_peaks == FALSE && p.IsGood() == FALSE )	continue;

				cp.x = (float) m_mapping.X2( p.x, p.y );
				cp.y = (float) m_mapping.Y2( p.x, p.y );
				cp.sx = (float) fabs( m_mapping.X2( p.x+p.sx, p.y ) - m_mapping.X2( p.x-p.sx, p.y ) ) / 2 ;
				cp.sy = (float) fabs( m_mapping.Y2( p.x, p.y+p.sy ) - m_mapping.Y2( p.x, p.y-p.sy ) ) / 2 ;
				cp.is_good = p.is_good;

	            x0 = (int) ( p.x + 0.5 );
				y0 = (int) ( p.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;

	            x0 = (int) ( cp.x + 0.5 );
				y0 = (int) ( cp.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;
			}
			else if ( m_find_CH2 )
			{
				CPeak &p = set.p[CH2] = m_peak_finder.m_peaks[i];
				CPeak &cp = set.p[CH1];

			//	if ( m_analyze_bad_peaks == FALSE && p.IsGood() == FALSE )	continue;

				cp.x = (float) m_mapping.X1( p.x, p.y );
				cp.y = (float) m_mapping.Y1( p.x, p.y );
				cp.sx = (float) fabs( m_mapping.X1( p.x+p.sx, p.y ) - m_mapping.X1( p.x-p.sx, p.y ) ) / 2 ;
				cp.sy = (float) fabs( m_mapping.Y1( p.x, p.y+p.sy ) - m_mapping.Y1( p.x, p.y-p.sy ) ) / 2 ;
				cp.is_good = p.is_good;

	            x0 = (int) ( p.x + 0.5 );
				y0 = (int) ( p.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;

	            x0 = (int) ( cp.x + 0.5 );
				y0 = (int) ( cp.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;
			}

			num_peaks ++;
			if ( set.IsGood() )
			{
				num_good_peaks ++;
				peaks.Add(set);
			}
			else if ( m_analyze_bad_peaks == TRUE )
			{
				peaks.Add(set);
			}
		}
		LogMsg(_T("Info"), Stringify(_T("%d(%d) peaks in [%s]"), num_good_peaks, num_peaks, m_film.m_filepath));
	
		writer.m_peaks.Write( w, h, &peaks );

		BOOL find[NUM_CHANNELS];
		find[CH1] = m_find_CH1;
		find[CH2] = m_find_CH2;

		writer.m_tlog.Write( w, h, m_film.m_frame_cycle, m_film.m_num_frames, 
							m_peak_radius, m_peak_sigma, find );

	}


	writer.m_frame_w = w;
	writer.m_frame_h = h;
	writer.m_background = m_film.m_background;
	writer.m_data_scaler = m_film.m_data_scaler;

	writer.m_frame_cycle = m_film.m_frame_cycle;
	writer.m_peak_radius = (float) m_peak_radius;
	writer.m_peak_sigma = (float) m_peak_sigma;

	if ( writer.Open( m_film.m_num_frames, &peaks ) < 0 )	goto FAIL;

	double *max_snapshot = new double[w*h];
	memset( max_snapshot, 0, sizeof(double)*w*h );


	m_film.MoveFrame(0);
	for ( UINT frame_no = 0 ; frame_no < writer.m_num_frames ; frame_no++ )
	{
		m_film.MoveFrame(frame_no);
		m_film.ReadFrame(NULL);

		if ( frame_no % 100 == 0 && frame_no > 0 )
		{
			LogMsg(_T("Info"), Stringify(_T("Analysis %.0f %% : Making Traces at Frame[%d/%d]"), 
										100.0*frame_no/writer.m_num_frames, frame_no, writer.m_num_frames) );
			LogFlush();
		}

		for ( UINT y = 0 ; y < h ; y++ )
		{
			for ( UINT x = 0 ; x < w ; x++ )
			{
				double f = m_film.Frame( x, y );
				if ( max_snapshot[ w*y + x ] < f )	max_snapshot[ w*y + x ] = f;
			}
		}

		for ( UINT peak_no = 0 ; peak_no < writer.m_num_peaks ; peak_no++ )
		{
			CPeakSet set = peaks[peak_no];
		//	BOOL error = FALSE;

			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				double sig = 0.0;
				double bg = 0.0;
				double sig2 = 0.0;
				double bg2 = 0.0;

				CCAQClient::AnalyzePeak( w, h, m_film.m_frame, CCAQClient::DFRAME,
										set.p[i].x, set.p[i].y, m_peak_sigma, 
										&sig, &bg, &sig2, &bg2 );
				
				writer.Signal(i, peak_no, frame_no) = (float)sig;
				writer.Background(i, peak_no, frame_no) = (float)bg;
				writer.Signal2(i, peak_no, frame_no) = (float)sig2;
				writer.Background2(i, peak_no, frame_no) = (float)bg2;
			}
		}

		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}
	writer.SaveMaximumSnapshot( w, h, max_snapshot );
	delete [] max_snapshot;

	if ( writer.Write() < 0 )	goto FAIL;
	LogMsg(_T("Info"), 
			Stringify(_T("Analysis : %u peaks, %u frames from [%s]"), 
			writer.m_num_peaks, writer.m_num_frames, m_film.m_filepath) );
	if ( writer.Close() < 0 )	goto FAIL;

		
	//BG Trace
	if ( m_analyze_bg_peaks )
	{
		n = writer.SetFilmpath( m_film.m_filepath );
		n = writer.SetBGFilepath( m_film.m_filepath );
		if ( n > 0 && !analyze_again )	return;
		if ( n < 0 )	goto FAIL;

		if ( !m_mapping.m_is_mapping_ready || !m_mapping.IsCompatible( w, h ) )	goto FAIL;

		LogMsg(_T("Info"), Stringify(_T("BG Analysis : [%s]"), m_film.m_filepath) );

		m_peak_finder.SetRadius( m_peak_radius );
		m_peak_finder.SetThreshold( m_peak_threshold );

		if ( m_find_CH1 )
			m_peak_finder.FindNotPeaks(CH1);
		else if ( m_find_CH2 )
			m_peak_finder.FindNotPeaks(CH2);

		m_peak_finder.DrawFrameAndNotPeaks( w, h, m_display_buffer );
		UpdateFrame();

		
		int erange = CCircle::extended_range( Z_VALUE * m_peak_sigma );
		int num_not_peaks = 0;
		not_peaks.SetSize(0);
		for ( int i = 0 ; i < m_peak_finder.m_not_peaks.GetCount() ; i++ )
		{
			int x0, y0;
			CPeakSet set;
			if ( m_find_CH1 )
			{
				CPeak &p = set.p[CH1] = m_peak_finder.m_not_peaks[i];
				CPeak &cp = set.p[CH2];

				cp.x = (float) m_mapping.X2( p.x, p.y );
				cp.y = (float) m_mapping.Y2( p.x, p.y );
				cp.sx = (float) fabs( m_mapping.X2( p.x+p.sx, p.y ) - m_mapping.X2( p.x-p.sx, p.y ) ) / 2 ;
				cp.sy = (float) fabs( m_mapping.Y2( p.x, p.y+p.sy ) - m_mapping.Y2( p.x, p.y-p.sy ) ) / 2 ;
				cp.is_good = p.is_good;

	            x0 = (int) ( p.x + 0.5 );
				y0 = (int) ( p.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;

	            x0 = (int) ( cp.x + 0.5 );
				y0 = (int) ( cp.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;
			}
			else if ( m_find_CH2 )
			{
				CPeak &p = set.p[CH2] = m_peak_finder.m_not_peaks[i];
				CPeak &cp = set.p[CH1];

				cp.x = (float) m_mapping.X1( p.x, p.y );
				cp.y = (float) m_mapping.Y1( p.x, p.y );
				cp.sx = (float) fabs( m_mapping.X1( p.x+p.sx, p.y ) - m_mapping.X1( p.x-p.sx, p.y ) ) / 2 ;
				cp.sy = (float) fabs( m_mapping.Y1( p.x, p.y+p.sy ) - m_mapping.Y1( p.x, p.y-p.sy ) ) / 2 ;
				cp.is_good = p.is_good;

	            x0 = (int) ( p.x + 0.5 );
				y0 = (int) ( p.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;

	            x0 = (int) ( cp.x + 0.5 );
				y0 = (int) ( cp.y + 0.5 );
				if  ( x0-erange < 0 || (int)w <= x0+erange || y0-erange < 0 || (int)h <= y0+erange )	continue;
			}
            
			num_not_peaks ++;
			not_peaks.Add(set);
		}
		LogMsg(_T("Info"), Stringify(_T("%d not-peaks in [%s]"), num_not_peaks, m_film.m_filepath));
	
		writer.m_peaks.Write( w, h, &not_peaks );

		BOOL find[NUM_CHANNELS];
		find[CH1] = m_find_CH1;
		find[CH2] = m_find_CH2;

		writer.m_tlog.Write( w, h, m_film.m_frame_cycle, m_film.m_num_frames, 
							m_peak_radius, m_peak_sigma, find );

		writer.m_frame_w = w;
		writer.m_frame_h = h;
		writer.m_background = m_film.m_background;
		writer.m_data_scaler = m_film.m_data_scaler;

		writer.m_frame_cycle = m_film.m_frame_cycle;
		writer.m_peak_radius = (float) m_peak_radius;
		writer.m_peak_sigma = (float) m_peak_sigma;

		if ( writer.Open( m_film.m_num_frames, &not_peaks ) < 0 )	goto FAIL;

		m_film.MoveFrame(0);
		for ( UINT frame_no = 0 ; frame_no < writer.m_num_frames ; frame_no++ )
		{
			m_film.MoveFrame(frame_no);
			m_film.ReadFrame(NULL);

			if ( frame_no % 100 == 0 && frame_no > 0 )
			{
				LogMsg(_T("Info"), Stringify(_T("Analysis %.0f %% : Making BGTraces at Frame[%d/%d]"), 
										100.0*frame_no/writer.m_num_frames, frame_no, writer.m_num_frames) );
				LogFlush();
			}

			for ( UINT peak_no = 0 ; peak_no < writer.m_num_peaks ; peak_no++ )
			{
				CPeakSet set = not_peaks[peak_no];
	
				for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
				{
					double sig = 0.0;
					double bg = 0.0;
					double sig2 = 0.0;
					double bg2 = 0.0;

					CCAQClient::AnalyzePeak( w, h, m_film.m_frame, CCAQClient::DFRAME,
											set.p[i].x, set.p[i].y, m_peak_sigma, 
											&sig, &bg, &sig2, &bg2 );
					
					writer.Signal(i, peak_no, frame_no) = (float)sig;
					writer.Background(i, peak_no, frame_no) = (float)bg;
					writer.Signal2(i, peak_no, frame_no) = (float)sig2;
					writer.Background2(i, peak_no, frame_no) = (float)bg2;
				}
			}

			//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE))
			while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
			{
				if ( !IsDialogMessage(&message) )
				{
					::TranslateMessage(&message);
					::DispatchMessage(&message);
				}
			}
		}

		if ( writer.Write() < 0 )	goto FAIL;
		LogMsg(_T("Info"), 
				Stringify(_T("BG Analysis : %u not-peaks, %u frames from [%s]"), 
						writer.m_num_peaks, writer.m_num_frames, m_film.m_filepath) );
		if ( writer.Close() < 0 )	goto FAIL;
	}

	return;
FAIL:
	LogMsg(_T("Error"), Stringify(_T("Analysis of [%s] Failed."), m_film.m_filepath));
	return;
}


void CMovieAnalysisDialog::AnalyzeFolder(LPCTSTR folder)
{
	MSG message;
	CDirectoryTraverse directory;
	directory.SetPath( folder );
	if ( directory.InitTraverse() < 0 )	return;

	CString fullpath;
	CString name;
	BOOL is_dir;
	while ( directory.Traverse( name, is_dir ) == 0 )
	{
		//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
		while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
		{
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
		if ( ::IsWindow(m_hWnd) )
		{
			UpdateData(FALSE);
			UpdateWindow();
		}

		if ( m_stop_analyzing )	break;

		fullpath = directory.m_path + '\\' + name;
		if ( is_dir )
		{
			AnalyzeFolder(fullpath);
		}
		else
		{
			int n = name.ReverseFind( (TCHAR)'.' );
			if ( n < 0 )	continue;
			CString ext = name.Mid(n+1);
			if ( ext.CompareNoCase(CAMERAFILE_FILM_EXT) != 0 
				&& ext.CompareNoCase(CAMERAFILE_OLDFILM_EXT) != 0 )	continue;

			m_film.Close();
			if ( m_film.Open( fullpath ) < 0 )	continue;
		}
		AnalyzeFile(m_analyze_again);
	}

	directory.CloseTraverse();
	return;
}


BEGIN_MESSAGE_MAP(CMovieAnalysisDialog, CDialog)
	ON_WM_DESTROY()	
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
//	ON_WM_MOUSEMOVE()
	ON_WM_HSCROLL()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR1, OnDeltaposSpinr1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR2, OnDeltaposSpinr2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX1, OnDeltaposSpinx1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY1, OnDeltaposSpiny1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX2, OnDeltaposSpinx2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY2, OnDeltaposSpiny2)

	ON_BN_CLICKED(IDC_OPEN_FILE, OnBnClickedOpenFile)

	ON_BN_CLICKED(IDC_LOAD_MAP, OnBnClickedLoadMap)

	ON_BN_CLICKED(IDC_LOAD_FS, OnBnClickedLoadFs)
	ON_BN_CLICKED(IDC_REPEAT_FS, OnBnClickedRepeatFs)
	ON_BN_CLICKED(IDC_APPLY_FS, OnBnClickedApplyFs)

	ON_EN_KILLFOCUS(IDC_PEAK_RADIUS, OnEnKillfocusPeakRadius)
	ON_EN_KILLFOCUS(IDC_PEAK_THRESHOLD, OnEnKillfocusPeakThreshold)
	ON_BN_CLICKED(IDC_FIND_CH1, OnBnClickedFindCh1)
	ON_BN_CLICKED(IDC_FIND_CH2, OnBnClickedFindCh2)
	ON_BN_CLICKED(IDC_FIND_AND_SAVE, OnBnClickedFindAndSave)
	ON_BN_CLICKED(IDC_FIND_PEAKS, OnBnClickedFindPeaks)

	ON_EN_KILLFOCUS(IDC_PEAK_SIGMA, OnEnKillfocusPeakSigma)
	ON_BN_CLICKED(IDC_ANALYZE_BAD_PEAKS, OnBnClickedAnalyzeBadPeaks)
	ON_BN_CLICKED(IDC_ANALYZE_AGAIN, OnBnClickedAnalyzeAgain)
	ON_BN_CLICKED(IDC_ANALYZE, OnBnClickedAnalyze)
	ON_BN_CLICKED(IDC_ANALYZE_FOLDER, OnBnClickedAnalyzeFolder)
	ON_BN_CLICKED(IDC_ANALYZE_BG_PEAKS, OnBnClickedAnalyzeBgPeaks)
END_MESSAGE_MAP()


// CMovieAnalysisDialog message handlers

void CMovieAnalysisDialog::OnPaint()
{
	CDialog::OnPaint();
	UpdateFrame();
}


void CMovieAnalysisDialog::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	static int range_from = -1;
	if ( pScrollBar != (CScrollBar*)&m_slider )	return;
	if ( !m_film.IsOpen() )	return;

	int from, to;
	from = range_from;
	to = m_slider.GetPos();
	if ( from > to )
	{
		from = to;
		to = range_from;
	}

	if ( nSBCode == SB_THUMBTRACK )
	{
		if ( range_from < 0 )	range_from = m_slider.GetPos();
		else
		{
			m_slider.SetSelection(from, to);
			m_slider.SetRange(0, (int)m_film.m_num_frames-1, TRUE);
		}
	}
	else if ( nSBCode != SB_THUMBPOSITION )
	{
		if ( nSBCode == SB_ENDSCROLL && range_from >= 0 )
		{
			m_film.MakeAverageFrame(from, to, NULL);
		}
		else
		{
			m_film.MoveFrame(m_slider.GetPos());
			m_film.ReadFrame(NULL);
			if ( range_from >= 0 )	m_slider.ClearSel(TRUE);
			range_from = -1;
		}
		//m_reader->DrawFrame(m_display_buffer);		
		UINT w = m_film.m_frame_w;
		UINT h = m_film.m_frame_h;
		m_peak_finder.SetFrame( w, h, m_film.m_frame, m_film.m_background, m_film.m_data_scaler );
		m_peak_finder.DrawFrame( w, h, m_display_buffer );
		UpdateFrame();
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CMovieAnalysisDialog::OnLButtonDown(UINT nFlags, CPoint point)
{
	int x, y;
	if ( !m_film.IsOpen() || GetFrameCoordinate(point, &x, &y) != TRUE )	return;

	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	CChannels ch( w, h );

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( x < (int)ch.l[i] || (int)ch.r[i] < x )	continue;

		m_point[i].SetPoint( x, y );
		for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
		{
			if ( k == i )	continue;
			int cx = x - ch.l[i] + ch.l[k];
			int cy = y;
			if ( cx < (int)ch.l[k] )	cx = ch.l[k];
			if ( cx > (int)ch.r[k] )	cx = ch.r[k];
			m_point[k].SetPoint( cx, cy );
		}
		UpdateFrame();
	}

	CDialog::OnLButtonDown(nFlags, point);
}


void CMovieAnalysisDialog::OnDeltaposSpinr1(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() || m_is_analyzing )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_spot_radius++;
	else	m_spot_radius--;

	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	int max_radius = ( w/2 < h ) ? (w/4-1) : (h/2-1);
	if ( m_spot_radius > max_radius )	m_spot_radius = max_radius;
	if ( m_spot_radius < 1 )	m_spot_radius = 1;

	UpdateFrame();
	*pResult = 0;
}

void CMovieAnalysisDialog::OnDeltaposSpinr2(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() || m_is_analyzing )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_spot_radius++;
	else	m_spot_radius--;

	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	int max_radius = ( w/2 < h ) ? (w/4-1) : (h/2-1);
	if ( m_spot_radius > max_radius )	m_spot_radius = max_radius;
	if ( m_spot_radius < 1 )	m_spot_radius = 1;

	UpdateFrame();
	*pResult = 0;
}

void CMovieAnalysisDialog::OnDeltaposSpinx1(NMHDR *pNMHDR, LRESULT *pResult)
{
	int x = m_point[CH1].x;
	int y = m_point[CH1].y;
	if ( !m_film.IsOpen() || x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	x++;
	else	x--;

	CChannels ch( m_film.m_frame_w, m_film.m_frame_h );
	if ( x < (int)ch.l[CH1] )	x = ch.l[CH1];
	if ( x > (int)ch.r[CH1] )	x = ch.r[CH1];

	m_point[CH1].x = x;
	UpdateFrame();
	*pResult = 0;

}

void CMovieAnalysisDialog::OnDeltaposSpiny1(NMHDR *pNMHDR, LRESULT *pResult)
{
	int x = m_point[CH1].x;
	int y = m_point[CH1].y;
	if ( !m_film.IsOpen() || x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	y--;
	else	y++;

	UINT h = m_film.m_frame_h;
	if ( y >= (int)h )	y = (int)h-1;
	if ( y < 0 )	y = 0;

	m_point[CH1].y = y;
	UpdateFrame();
	*pResult = 0;
}

void CMovieAnalysisDialog::OnDeltaposSpinx2(NMHDR *pNMHDR, LRESULT *pResult)
{
	int x = m_point[CH2].x;
	int y = m_point[CH2].y;
	if ( !m_film.IsOpen() || x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	x++;
	else	x--;

	CChannels ch( m_film.m_frame_w, m_film.m_frame_h );
	if ( x < (int)ch.l[CH2] )	x = ch.l[CH2];
	if ( x > (int)ch.r[CH2] )	x = ch.r[CH2];

	m_point[CH2].x = x;
	UpdateFrame();
	*pResult = 0;
}

void CMovieAnalysisDialog::OnDeltaposSpiny2(NMHDR *pNMHDR, LRESULT *pResult)
{
	int x = m_point[CH2].x;
	int y = m_point[CH2].y;
	if ( !m_film.IsOpen() || x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	y--;
	else	y++;

	UINT h = m_film.m_frame_h;
	if ( y >= (int)h )	y = (int)h-1;
	if ( y < 0 )	y = 0;

	m_point[CH2].y = y;
	UpdateFrame();
	*pResult = 0;
}

void CMovieAnalysisDialog::OnBnClickedOpenFile()
{
	CString szFilters;
	szFilters.Format(_T("Film & TIFF Files (*.%s;*.%s;*.%s;*.%s)|*.%s; *.%s; *.%s; *.%s|"
						"All Files (*.*)|*.*||"),
						CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT,
						CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path;
	if( fileDlg.DoModal ()!=IDOK )	return;
	CString filepath = fileDlg.GetPathName();
	int n = filepath.ReverseFind((TCHAR)'\\');
	if ( n >= 0 )	m_directory.SetPath( filepath.Mid(0, n) );

	m_film.Close();
	if ( m_film.Open(filepath) < 0 )
	{
		LogErr(Stringify(_T("Open File[%s] Failed."), filepath));
		FreeFrame();
		return;
	}
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	InitFrame(w, h);

	m_film.ReadFrame(NULL);
	m_film.MoveFrame(0);

	m_peak_finder.SetFrame( w, h, m_film.m_frame, m_film.m_background, m_film.m_data_scaler );
	m_peak_finder.DrawFrame( w, h, m_display_buffer );

	m_slider.ClearSel(TRUE);
	m_slider.SetRange( 0, (int)m_film.m_num_frames - 1, TRUE );
	int pagesize = (int) ceil( m_film.m_num_frames * 1.0 / 100 );
	if ( pagesize <= 0 )	pagesize = 1;
	m_slider.SetPageSize(pagesize);
	m_slider.SetPos(0);

	SetUIs();
	UpdateFrame();
	UpdateData(FALSE);

	return;
}

void CMovieAnalysisDialog::OnBnClickedLoadMap()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_mapping.Load(fileDlg.GetPathName());

		CWnd *pWnd = GetDlgItem(IDC_MAPPING_INFO);
		if ( pWnd )	pWnd->SetWindowText( m_mapping.Information() );

		if ( m_mapping.m_is_mapping_ready != TRUE )
			LogErr(Stringify(_T("Load Mapping File[%s] Failed."), fileDlg.GetPathName()));
		
		UpdateData(FALSE);
	}
}


void CMovieAnalysisDialog::OnBnClickedLoadFs()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_FRAME_SEQUENCE;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_fspath = fileDlg.GetPathName();
		m_fs.Load(m_fspath);
		UpdateData(FALSE);
	}

    CWnd *pWnd = GetDlgItem(IDC_FSPATH);
	if ( pWnd )
		((CEdit*)pWnd)->SetSel(0, -1);

}

void CMovieAnalysisDialog::OnBnClickedRepeatFs()
{
	UpdateData(TRUE);
}

void CMovieAnalysisDialog::OnBnClickedApplyFs()
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;


	if ( m_fs.Init() < 0 )
	{
		LogErr(_T("Frame Sequence is not loaded."));
		return;
	}

	int cnt = 0;
	m_film.StartAveragingFrames();
	while ( m_fs.IsEnd() != TRUE )
	{
		if ( m_fs.Current() )
		{
			if ( m_fs.CurrentFrameNo() >= m_film.m_num_frames )
				break;

			m_film.MoveFrame( m_fs.CurrentFrameNo() );
			m_film.ReadFrame(NULL);

			cnt ++;
			m_film.AddToAveragingFrames();
		}
		m_fs.Next();
	}
	m_film.FinishAveragingFrames( cnt, NULL );
	m_peak_finder.SetFrame( w, h, m_film.m_frame, m_film.m_background, m_film.m_data_scaler );
	m_peak_finder.DrawFrame( w, h, m_display_buffer );
	UpdateFrame();

}



void CMovieAnalysisDialog::OnEnKillfocusPeakRadius()
{
	double backup = m_peak_radius;
	UpdateData(TRUE);
	if ( m_peak_radius <= 0 )	m_peak_radius = backup;
	m_peak_radius = LIMIT_DECIMAL_PLACES( m_peak_radius, 3 );
	UpdateData(FALSE);
}

void CMovieAnalysisDialog::OnEnKillfocusPeakThreshold()
{
	double backup = m_peak_threshold;
	UpdateData(TRUE);
	if ( m_peak_threshold <= 0 )	m_peak_threshold = backup;
	m_peak_threshold = LIMIT_DECIMAL_PLACES( m_peak_threshold, 3 );
	UpdateData(FALSE);
}

void CMovieAnalysisDialog::OnBnClickedFindCh1()
{
	UpdateData(TRUE);
}

void CMovieAnalysisDialog::OnBnClickedFindCh2()
{
	UpdateData(TRUE);
}

void CMovieAnalysisDialog::OnBnClickedFindAndSave()
{
	UpdateData(TRUE);
}


void CMovieAnalysisDialog::OnBnClickedFindPeaks()
{
	if ( !m_film.IsOpen() )	return;

	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	m_peak_finder.SetFrame( w, h, m_film.m_frame, m_film.m_background, m_film.m_data_scaler );
	m_peak_finder.SetRadius(m_peak_radius);
	m_peak_finder.SetThreshold(m_peak_threshold);

	if ( m_find_CH1 && m_find_CH2 )
	{
		if ( !m_mapping.m_is_mapping_ready || !m_mapping.IsCompatible( w, h ) )
		{
			LogErr(_T("Failed to superpose CH1 & CH2 : Invalid Mapping."));
			return;
		}
		CChannels ch(w,h);
		m_peak_finder.MakeBackground(CH2);
		m_mapping.SuperposeOnto1( w, h, m_peak_finder.m_frame, m_peak_finder.m_frame, m_peak_finder.m_bgnd, ch.l[CH2], 0, ch.w, ch.h );
		m_peak_finder.FindPeaks(CH1);
	}
	else if ( m_find_CH1 )
		m_peak_finder.FindPeaks(CH1);
	else if ( m_find_CH2 )
		m_peak_finder.FindPeaks(CH2);

	m_peak_finder.DrawFrameAndPeaks( w, h, m_display_buffer );
	UpdateFrame();

	int num_peaks = (int) m_peak_finder.m_peaks.GetCount();
	int num_good_peaks = 0;
	for ( int i = 0 ; i < num_peaks ; i++ )
		if ( m_peak_finder.m_peaks[i].IsGood() )	num_good_peaks++;

	LogMsg(_T("Info"), Stringify(_T("%d(%d) peaks in [%s]"), num_good_peaks, num_peaks, m_film.m_filepath));

	if ( m_find_and_save )
	{
		CArray<CPeakSet> peaks;
		peaks.SetSize(0);		

		//int range = CCircle::range( m_peak_radius );
		int range = CCircle::range( Z_VALUE * m_peak_sigma );
		for ( int i = 0 ; i < m_peak_finder.m_peaks.GetCount() ; i++ )
		{
			int x0, y0;
			CPeakSet set;
			if ( m_find_CH1 )
			{
				CPeak &p = set.p[CH1] = m_peak_finder.m_peaks[i];
				CPeak &cp = set.p[CH2];

				cp.x = (float) m_mapping.X2( p.x, p.y );
				cp.y = (float) m_mapping.Y2( p.x, p.y );
				cp.sx = (float) fabs( m_mapping.X2( p.x+p.sx, p.y ) - m_mapping.X2( p.x-p.sx, p.y ) ) / 2 ;
				cp.sy = (float) fabs( m_mapping.Y2( p.x, p.y+p.sy ) - m_mapping.Y2( p.x, p.y-p.sy ) ) / 2 ;
				cp.is_good = p.is_good;

	            x0 = (int) ( p.x + 0.5 );
				y0 = (int) ( p.y + 0.5 );
				if  ( x0-range < 0 || (int)w <= x0+range || y0-range < 0 || (int)h <= y0+range )	continue;

	            x0 = (int) ( cp.x + 0.5 );
				y0 = (int) ( cp.y + 0.5 );
				if  ( x0-range < 0 || (int)w <= x0+range || y0-range < 0 || (int)h <= y0+range )	continue;
			}
			else if ( m_find_CH2 )
			{
				CPeak &p = set.p[CH2] = m_peak_finder.m_peaks[i];
				CPeak &cp = set.p[CH1];

				cp.x = (float) m_mapping.X1( p.x, p.y );
				cp.y = (float) m_mapping.Y1( p.x, p.y );
				cp.sx = (float) fabs( m_mapping.X1( p.x+p.sx, p.y ) - m_mapping.X1( p.x-p.sx, p.y ) ) / 2 ;
				cp.sy = (float) fabs( m_mapping.Y1( p.x, p.y+p.sy ) - m_mapping.Y1( p.x, p.y-p.sy ) ) / 2 ;
				cp.is_good = p.is_good;

	            x0 = (int) ( p.x + 0.5 );
				y0 = (int) ( p.y + 0.5 );
				if  ( x0-range < 0 || (int)w <= x0+range || y0-range < 0 || (int)h <= y0+range )	continue;

	            x0 = (int) ( cp.x + 0.5 );
				y0 = (int) ( cp.y + 0.5 );
				if  ( x0-range < 0 || (int)w <= x0+range || y0-range < 0 || (int)h <= y0+range )	continue;
			}

			peaks.Add(set);
		}

		CPeaksFileWriter writer;
		writer.SetFilepath( m_film.m_filepath );
		writer.Write( w, h, &peaks );
		LogMsg(_T("Info"), Stringify(_T("Found peaks were saved as [%s]"), writer.m_filepath) );
		m_peak_finder.SaveSnapshot( m_film.m_filepath );
	}
}


void CMovieAnalysisDialog::OnEnKillfocusPeakSigma()
{
	double backup = m_peak_sigma;
	UpdateData(TRUE);
	if ( m_peak_sigma <= 0 || m_peak_sigma > m_peak_radius )	m_peak_sigma = backup;
	m_peak_sigma = LIMIT_DECIMAL_PLACES( m_peak_sigma, 3 );
	UpdateData(FALSE);
}

void CMovieAnalysisDialog::OnBnClickedAnalyzeBadPeaks()
{
	UpdateData(TRUE);
}

void CMovieAnalysisDialog::OnBnClickedAnalyzeAgain()
{
	UpdateData(TRUE);
}

void CMovieAnalysisDialog::OnBnClickedAnalyzeBgPeaks()
{
	UpdateData(TRUE);
}

void CMovieAnalysisDialog::OnBnClickedAnalyze()
{
	CWaitCursor wait;

	m_is_analyzing = TRUE;
	SetUIs();
	AnalyzeFile(TRUE);
	m_is_analyzing = FALSE;
	SetUIs();
	return;
}

void CMovieAnalysisDialog::OnBnClickedAnalyzeFolder()
{
	if ( m_is_analyzing )	
		m_stop_analyzing = TRUE;
	else
	{
		//CString szFilters;
		//szFilters.Format(_T("Film & TIFF Files (*.%s;*.%s;*.%s;*.%s)|*.%s; *.%s; *.%s; *.%s|"
		//					"All Files (*.*)|*.*||"),
		//					CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT,
		//					CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT );
		//CDirectoryDialog dirDlg( m_directory.m_path, szFilters);
		//
		//
//
		//if ( dirDlg.DoModal()  != TRUE )	return;
		PickContainer();
		m_directory.SetPath( _PATH_FAKE );
	
		m_stop_analyzing = FALSE;
		m_is_analyzing = TRUE;
		SetUIs();
		AnalyzeFolder( m_directory.m_path );
		m_is_analyzing = FALSE;
		SetUIs();
	}
}

