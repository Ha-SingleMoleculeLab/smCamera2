#pragma once

class CFrameSequence
{
// Construction
public:

	CFrameSequence();
	virtual ~CFrameSequence();
	
	LPCTSTR DefaultPath();
	int Load( LPCTSTR filepath = NULL );
	int Unload();

	inline int Init()
	{
		if ( m_sequence && m_sequence_cnt > 0 )
		{
			m_sequence_index = 0;
			return 0;
		}
		else
		{
			Unload();
			return -1;
		}
	}
	inline int Next()
	{
		m_sequence_index ++;
		if ( m_sequence_index >= m_sequence_cnt )	m_sequence_index = m_sequence_cnt;
		return 0;
	}
	inline UINT32 CurrentFrameNo()
	{
		return m_sequence_index;
	}
	inline BOOL Current()
	{
		return ( m_sequence[m_sequence_index] != 0 );		
	}
	inline BOOL IsEnd()
	{
		return ( m_sequence_index >= m_sequence_cnt );
	}

    UINT8 *m_sequence;
	UINT32 m_sequence_cnt;
	UINT32 m_sequence_index;
};