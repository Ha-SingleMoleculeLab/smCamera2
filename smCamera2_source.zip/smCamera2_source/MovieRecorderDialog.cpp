// MovieRecorderDialog.cpp : implementation file
//

#include "stdafx.h"
#include "smCamera.h"
#include "MovieRecorderDialog.h"
#include ".\movierecorderdialog.h"

// CMovieRecorderDialog dialog

#define DEFAULT_MEMORY_BUFFER_SIZE	(1)	//in Mega Bytes
#define DEFAULT_CAMERA_WAIT_TIMEOUT_IN_MS	(100)
#define SHUTTER_INITIATION_DELAY_IN_S		(0.2)

IMPLEMENT_DYNAMIC(CMovieRecorderDialog, CDialog)
CMovieRecorderDialog::CMovieRecorderDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMovieRecorderDialog::IDD, pParent)
{
	m_writer = NULL;
	m_bitmap = NULL;
	m_display_buffer = NULL;

	m_memory_size = DEFAULT_MEMORY_BUFFER_SIZE;
	m_save_as_old_format = FALSE;
	m_save_pixel_in_8bit = FALSE;

	m_should_be_destroyed = FALSE;
	m_is_recording = FALSE;

	m_exposure_time = 1;
	m_gain = 1;
	m_background = 0;
	m_data_scaler = 255;

	m_set_max_frame_no = 0;
	m_max_frame_no = 0;
	m_film_comment = _T("");

	m_auto_scale = FALSE;
	m_overlay_channels = FALSE;
	m_log_selected_spot = FALSE;

	m_point.SetPoint( -1, -1 );
}

CMovieRecorderDialog::~CMovieRecorderDialog()
{

}

BOOL CMovieRecorderDialog::OnInitDialog()
{
	CString str;
	CDialog::OnInitDialog();

	m_writer = NULL;
	m_bitmap = NULL;
	m_display_buffer = NULL;

	//if ( m_client.CAQOpen() >= 0 )
	if (g_camera_recording_on)
	{
		LogErr(_T("Another movie recorder exists in memory."));
		CDialog::OnCancel();
		return FALSE;
	}

	if ( g_camera.m_is_initialized != TRUE )
	{
		
		
			LogErr(_T("Camera is not initialized!"));
			CDialog::OnCancel();
			return FALSE;
		
	}

	CArchive *ar = NULL;
	if ( DoesProgramFileExist( GetProgramFilePath( _PATH_MOVIE_RECORDER, _T("recorder.save") ) ) )
		ar = OpenProgramFileToRead( GetProgramFilePath( _PATH_MOVIE_RECORDER, _T("recorder.save") ) );

	if ( ar )
	{
		
		ar->ReadString(str);
        m_memory_size = _tstoi(str);
		ar->ReadString(str);
		m_save_as_old_format = _tstoi(str);
		ar->ReadString(str);
		m_save_pixel_in_8bit = _tstoi(str);
		if ( m_save_as_old_format )	m_save_pixel_in_8bit = TRUE;
		ar->ReadString(str);
		if ( m_directory.SetPath( str ) < 0 )
		{
			MakeProgramDirectory( _PATH_MOVIES );
			m_directory.SetPath( _PATH_MOVIES );
		}
		
		CloseProgramFile(ar);
	}
	else
	{
		m_memory_size = DEFAULT_MEMORY_BUFFER_SIZE;
		m_save_as_old_format = FALSE;
		m_save_pixel_in_8bit = FALSE;
		MakeProgramDirectory( _PATH_MOVIES );
		m_directory.SetPath( _PATH_MOVIES );
	}

	if ( m_save_as_old_format )
		m_directory.SetFormat(CAMERAFILE_OLDFILM_PREFIX, CAMERAFILE_OLDFILM_EXT);
	else
		m_directory.SetFormat(CAMERAFILE_FILM_PREFIX, CAMERAFILE_FILM_EXT);

	m_directory.LastFile();

	m_is_acquiring = g_camera.m_is_acquiring;
	m_should_be_destroyed = FALSE;
	m_is_recording = FALSE;


	m_exposure_time = g_camera.m_exposure_time;
	m_gain = g_camera.m_gain;
	m_background = 0;
	m_data_scaler = 255;//( 1 << g_camera.m_bit_depth ) - 1;

	m_set_max_frame_no = 0;
	m_max_frame_no = 0;
	m_film_comment = _T("");

	m_auto_scale = FALSE;
	m_overlay_channels = FALSE;
	m_log_selected_spot = FALSE;

	m_point.SetPoint( -1, -1 );
	m_recording_with_shutter = FALSE;

	g_shutter_client.Open();
	LoadProgramColorTable();
	InitRecorder();
	SetUIs();
	UpdateData(FALSE);	
	
	return TRUE;
}

void CMovieRecorderDialog::OnCancel()
{
	if (!m_is_acquiring)
		DestroyWindow();
}

void CMovieRecorderDialog::OnOK()
{
	SetFocus();
	return;
}

void CMovieRecorderDialog::OnDestroy()
{
	g_shutter_client.Close();
	
	if ( m_server.IsInitialized() )
	{
		if ( m_is_recording )	RecordStop();
		if ( g_camera.m_is_initialized )	StopAcquisition();

		if ( m_server.IsRunning() )
		{
			m_should_be_destroyed = TRUE;
			return;
		}

		FreeRecorder();

		if ( m_writer )	delete m_writer;
		m_writer = NULL;


		CString str;
		CArchive *ar = OpenProgramFileToWrite( 
						GetProgramFilePath( _PATH_MOVIE_RECORDER, _T("recorder.save") )
						);
		if ( ar )
		{
			str.Format(_T("%d\r\n"), m_memory_size);
			ar->WriteString(str);
			str.Format(_T("%d\r\n"), m_save_as_old_format );
			ar->WriteString(str);
			str.Format(_T("%d\r\n"), m_save_pixel_in_8bit );
			ar->WriteString(str);
			str = m_directory.m_path;
			ar->WriteString(str);
	
			CloseProgramFile(ar);
		}

		str = GetProgramFilePath( _PATH_CAMERA, _T("camera.save") );
		g_camera.CameraSave( str );

		_tchdir(_PATH_ROOT);
	}
	CDialog::OnDestroy();
}

void CMovieRecorderDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_IMAGE, m_image);
	DDX_Control(pDX, IDC_SPOT, m_spot);
	DDX_Check(pDX, IDC_SAVE_AS_OLD_FORMAT, m_save_as_old_format);
	DDX_Check(pDX, IDC_SAVE_PIXEL_IN_8BIT, m_save_pixel_in_8bit);

	if ( !pDX->m_bSaveAndValidate )
	{
		CWnd *pWnd;
		CString str;

		pWnd = GetDlgItem(IDC_EXPOSURE_TIME);
		str.Format(_T("%.3f"), g_camera.m_exposure_time);
		if ( pWnd ) pWnd->SetWindowText(str);
		pWnd = GetDlgItem(IDC_KINETIC_CYCLE);
		str.Format(_T("%.3f"), g_camera.m_kinetic_cycle_time);
		if ( pWnd ) pWnd->SetWindowText(str);
		pWnd = GetDlgItem(IDC_GAIN_RANGE);
		str.Format(_T("( %d ~ %d )"), g_camera.m_min_gain, g_camera.m_max_gain);	
		if ( pWnd )	pWnd->SetWindowText(str);

		pWnd = GetDlgItem(IDC_SPOT_TEXT);
		int channel = GetChannel(m_point, NULL, NULL);
		if ( channel < CH1 )
			str = _T("");
		else
		{
			double x = m_server.m_header->x[channel] ;
			double y = m_server.m_header->y[channel] ;
			if ( x < 0 || y < 0 )
				str.Format(_T(""));
			else
				str.Format(_T("%5d at ( %.0f, %.0f )"), m_server.CAQServerReadPixel( (int) (x+0.5), (int) (y+0.5) ), x, y );
		}
		if ( pWnd )	pWnd->SetWindowText(str);

		pWnd = GetDlgItem(IDC_PATH);
		if ( pWnd ) pWnd->SetWindowText(m_directory.m_path);
		if ( pWnd ) ((CEdit*)pWnd)->SetSel(0, -1);
		pWnd = GetDlgItem(IDC_FILM_NO);
		str.Format(_T("%d"), m_directory.m_fileno);
		if ( pWnd )	pWnd->SetWindowText(str);
	}

	if ( pDX->m_bSaveAndValidate )
	{
		DDX_Text(pDX, IDC_EXPOSURE_TIME, m_exposure_time);
	}

	if ( pDX->m_bSaveAndValidate || !m_is_acquiring || m_auto_scale )
	{
		DDX_Text(pDX, IDC_BACKGROUND, m_background);
		DDX_Text(pDX, IDC_DATA_SCALER, m_data_scaler);
	}

	if ( pDX->m_bSaveAndValidate || !m_is_acquiring )
	{
		DDX_Text(pDX, IDC_GAIN, m_gain);
		DDX_Text(pDX, IDC_MEMORY_SIZE, m_memory_size);

		DDX_Check(pDX, IDC_AUTO_SCALE, m_auto_scale);
		DDX_Check(pDX, IDC_OVERLAY_CHANNELS, m_overlay_channels);
		DDX_Check(pDX, IDC_LOG_SELECTED_SPOT, m_log_selected_spot);

		DDX_Check(pDX, IDC_SET_MAX_LENGTH, m_set_max_frame_no);
		DDX_Text(pDX, IDC_MAX_FRAME, m_max_frame_no);

		DDX_Text(pDX, IDC_FILM_COMMENT, m_film_comment);
	}


}

static RECT * __find_dest_rect(CDialog *dlg, CStatic *pane)
{
	static RECT	rect;
	long border_thickness;
	
	RECT dlgClientRct, dlgWinRct, paneWinRct;
	dlg->GetWindowRect(&dlgWinRct);
	dlg->GetClientRect(&dlgClientRct);

	pane->GetWindowRect(&paneWinRct);
	//pane->GetClientRect(&rect);

	border_thickness = ( (dlgWinRct.right-dlgWinRct.left) - (dlgClientRct.right-dlgClientRct.left) )/2;
	rect.left = paneWinRct.left - ( dlgWinRct.left + border_thickness );
	dlgWinRct.top = dlgWinRct.bottom - border_thickness
					- (dlgClientRct.bottom-dlgClientRct.top) - border_thickness;
	rect.top = paneWinRct.top - ( dlgWinRct.top + border_thickness );
	rect.right = rect.left + paneWinRct.right - paneWinRct.left;
	rect.bottom = rect.top + paneWinRct.bottom - paneWinRct.top;

	return &rect;
}

int CMovieRecorderDialog::InitRecorder()
{
	UINT w = g_camera.m_num_h_pixels;
	UINT h = g_camera.m_num_v_pixels;


	if ( m_server.IsInitialized() 
		&& m_server.m_header->frame_w == w 
		&& m_server.m_header->frame_h == h )
		return 0;

	FreeRecorder();
	m_frame_w = w;
	m_frame_h = h;
	//if ( m_server.CAQServerInit(m_frame_w, m_frame_h, bpp, m_memory_size) < 0 )
	if ( m_server.CAQServerInit(m_frame_w, m_frame_h, m_memory_size) < 0 )
	{
		LogErr(_T("Recorder initialization failed."));
		return -1;
	}

	RECT *rect;	
	rect = __find_dest_rect(this, &m_image);
	m_image_left = rect->left;
	m_image_top = rect->top;
	m_image_width = rect->right - rect->left;
	m_image_height = rect->bottom - rect->top;
	rect = __find_dest_rect(this, &m_spot);
	m_spot_left = rect->left;
	m_spot_top = rect->top;
	m_spot_width = rect->right - rect->left;
	m_spot_height = rect->bottom - rect->top;

	CClientDC dcDlg (this);
	m_bitmap = new CBitmap();
	m_bitmap->CreateCompatibleBitmap(&dcDlg, m_frame_w, m_frame_h );

	m_display_buffer = new COLORREF[m_frame_w*m_frame_h];
	memset(m_display_buffer, 0, sizeof(COLORREF)*m_frame_w*m_frame_h);

	for ( UINT y = 0 ; y < m_frame_h ; y++ )
	{
		for ( UINT x = 0 ; x < m_frame_w ; x++ )
		{
					UINT8 bpixel =0;
					const UINT8 num_molecules = 14;
					float half_width_half_max = 200/120.;
					float mol_position[num_molecules][2] =
					{
						{m_frame_w*4/6., m_frame_h*2/6.},
						{m_frame_w*4/6., m_frame_h*3/6.},
						{m_frame_w*4/6., m_frame_h*4/6.},
						{m_frame_w*4/6., m_frame_h*5/6.},
						{m_frame_w*4/6., m_frame_h*1/6.},
						{m_frame_w*3/6., m_frame_h*1/6.},
						{m_frame_w*2/6., m_frame_h*1/6.},
						{m_frame_w*2/6., m_frame_h*2/6.},
						{m_frame_w*2/6., m_frame_h*3/6.},
						{m_frame_w*2/6., m_frame_h*4/6.},
						{m_frame_w*2.25/6., m_frame_h*3.5/6.},
						{m_frame_w*1.75/6., m_frame_h*3.5/6.},
						{m_frame_w*2.5/6., m_frame_h*3/6.},
						{m_frame_w*1.5/6., m_frame_h*3/6.},
					};
					for (UINT mol_index = 0 ; mol_index < num_molecules; mol_index ++)
					{			  
						bpixel += Pixel2Byte(UINT32(255*exp(-log(2.)*((x-mol_position[mol_index][0])*(x-mol_position[mol_index][0])+(y-mol_position[mol_index][1])*(y-mol_position[mol_index][1]))/half_width_half_max/half_width_half_max)));
					}
					m_display_buffer[ m_frame_w*y + x ] = ProgramColor0( 0, bpixel ) ;
		}
		
	}


	if ( m_image_height * m_frame_w >= m_image_width * m_frame_h )
		m_image_height = (int) (( (double) m_image_width * (double) m_frame_h * 1.0 / (double) m_frame_w ));
	else
		m_image_width = (int) (( (double) m_image_height * (double) m_frame_w * 1.0 / (double) m_frame_h ));
	DrawFrame();
	return 0;
}

int CMovieRecorderDialog::FreeRecorder()
{
	if ( m_writer )		delete m_writer;
	m_writer = NULL;

	m_frame_w = 0;
	m_frame_h = 0;
	m_server.CAQServerFree();
	m_recording_index = 0;
	m_recording_with_shutter = FALSE;

	if ( m_bitmap )	delete m_bitmap;
	m_bitmap = NULL;
	if ( m_display_buffer )	delete [] m_display_buffer;
	m_display_buffer = NULL;

	return 0;
}

int CMovieRecorderDialog::StartAcquisition()
{
	MSG message;

	UpdateData(TRUE);
	if ( m_data_scaler <= 0 )	m_data_scaler = 1;

	if ( InitRecorder() < 0 )	return -1;
	m_server.m_header->scaler = m_data_scaler;
	m_server.m_header->background = m_background;
	UpdateData(FALSE);
	m_is_acquiring = TRUE;
	SetUIs();

	InitProgramTimer();

	g_camera.OpenShutter();
	g_camera.StartAcquisition();

	if ( m_server.CAQServerStart( 1.0 / ( g_camera.m_kinetic_cycle_time * SECOND_PER_MILLISECOND ) ) == 0 )
	{
		int timeout_in_ms = 100;
		int num_frames_in_camera = 0;
		CWnd *pWnd = GetDlgItem(IDC_CAMERA_STATUS);
		CString camera_status;

		int num_images_per_retrieval;
		int num_unretrieved_images;
		while( m_is_acquiring )
		{
			timeout_in_ms = (int) (g_camera.m_kinetic_cycle_time);
			if ( timeout_in_ms > DEFAULT_CAMERA_WAIT_TIMEOUT_IN_MS )	timeout_in_ms = DEFAULT_CAMERA_WAIT_TIMEOUT_IN_MS;
			if ( g_camera.WaitForImages( timeout_in_ms, &num_frames_in_camera ) < 0 )
				StopAcquisition();
			if ( m_is_acquiring != TRUE )	break;
			if ( num_frames_in_camera > 0 )
			{
				m_server.CAQServerSync( num_frames_in_camera );
				if ( m_recording_with_shutter )
					g_shutter_client.UpdateShutterTime( m_server.m_header->last_sync_tick, m_server.m_header->last_sync_index - m_recording_index );
			}

			camera_status.Format(_T("%d/%d"), num_frames_in_camera, g_camera.m_buffer_size);
			if ( pWnd )	pWnd->SetWindowText(camera_status);
			num_unretrieved_images = num_frames_in_camera;
			while ( num_unretrieved_images > 0 )
			{
				if ( m_server.OpenBufferingSpace( num_unretrieved_images ) < 0 )
					StopAcquisition();
				if ( m_is_acquiring != TRUE )	break;

				num_images_per_retrieval = m_server.m_num_bufferable;
				if ( num_images_per_retrieval > num_unretrieved_images )	
					num_images_per_retrieval = num_unretrieved_images;

				if ( g_camera.GetImagesContinuous( num_images_per_retrieval, 
					(long *) m_server.m_buffering_space ) < 0 )
					StopAcquisition();
				if ( m_is_acquiring != TRUE )	break;

				if ( m_server.CloseBufferingSpace( num_images_per_retrieval ) < 0 )
					StopAcquisition();
				if ( m_is_acquiring != TRUE )	break;

				num_unretrieved_images -= num_images_per_retrieval;
				//			if ( num_unretrieved_images <= 0 )	UpdateFrame();

				if ( Record() < 0 )
					StopAcquisition();
				if ( m_is_acquiring != TRUE )	break;

				//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
				while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
				{
					if ( !IsDialogMessage(&message) )
					{
						::TranslateMessage(&message);
						::DispatchMessage(&message);
					}
				}
				//			if ( ::IsWindow(m_hWnd) )	UpdateWindow();
			}
			if ( m_is_acquiring != TRUE )	break;

			UpdateFrame();
			DrawFrame();
			//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
			{
				if ( !IsDialogMessage(&message) )
				{
					::TranslateMessage(&message);
					::DispatchMessage(&message);
				}
			}
			//		if ( ::IsWindow(m_hWnd) )	UpdateWindow();
		}
	}

	StopAcquisition();
	m_server.CAQServerStop();

	m_is_recording = FALSE;
	Record();
	m_is_acquiring = FALSE;
	SetUIs();

	if ( m_should_be_destroyed )
	{
		FreeRecorder();

		_tchdir(_PATH_ROOT);
		CDialog::OnDestroy();
	}

	return 0;                                        
}

int CMovieRecorderDialog::StopAcquisition()
{
	m_is_recording = FALSE;
	m_is_acquiring = FALSE;
	g_camera.StopAcquisition();
	g_camera.CloseShutter();

	return 0;
}

int CMovieRecorderDialog::RecordStart()
{
	if ( !m_server.IsRunning() )	return -1;
	if ( m_client.CAQOpen() < 0 )	return -1;

	CString name;
	name.Format(_T("%d"), m_directory.m_fileno +  1 );

	if ( g_shutter_client.InitShutter( ( m_set_max_frame_no ) ? m_max_frame_no : 0, 
								1.0 / m_server.m_header->sampling_rate ) < 0 )
	{
		m_client.CAQModeReadFromNow();
		m_recording_index = m_client.m_index;
		m_recording_with_shutter = FALSE;
	}
	else
	{
		m_recording_index = m_server.m_header->num_acquired + 1
						+ (UINT) ceil( SHUTTER_INITIATION_DELAY_IN_S * m_server.m_header->sampling_rate );
		m_recording_with_shutter = TRUE;
		m_client.m_index = m_recording_index ;
		g_shutter_client.UpdateShutterTime( m_server.m_header->last_sync_tick, m_server.m_header->last_sync_index - m_recording_index );
	}

	if ( m_writer )		delete m_writer;
	m_writer = new CFilmFileWriter(m_save_as_old_format);
	m_writer->SetFilepath( m_directory.m_path, name );
//	m_writer->m_flog.Write
//		( m_client.m_index, m_server.m_header->frame_w, m_server.m_header->frame_h, 
//			m_server.m_header->background, m_server.m_header->scaler, m_server.m_header->bpp,
//			g_camera.m_name, g_camera.m_bit_depth, g_camera.m_gain, g_camera.m_exposure_time, g_camera.m_kinetic_cycle_time,
//			g_camera.m_image_left, g_camera.m_image_right, g_camera.m_image_bottom, g_camera.m_image_top );
	//UINT bpp = ( m_save_pixel_in_8bit ) ? 1 : m_server.m_header->bpp ;
	UINT bpp = ( m_save_pixel_in_8bit ) ? 1 : (UINT) ceil( (double) g_camera.m_bit_depth / 8 );
	m_writer->m_flog.Write //m_index is probably the number of frames acquired until start acquisition
		( m_client.m_index, m_server.m_header->frame_w, m_server.m_header->frame_h, 
			m_background, m_data_scaler, bpp,
			g_camera.m_name, g_camera.m_bit_depth, g_camera.m_gain, g_camera.m_exposure_time, g_camera.m_kinetic_cycle_time,
			g_camera.m_image_left, g_camera.m_image_right, g_camera.m_image_bottom, g_camera.m_image_top );

	if ( m_log_selected_spot )
	{
		m_writer->m_pktrace.m_frame_w = m_server.m_header->frame_w;
		m_writer->m_pktrace.m_frame_h = m_server.m_header->frame_h;
		m_writer->m_pktrace.Open();
	}

	m_writer->m_frame_w = m_server.m_header->frame_w;
	m_writer->m_frame_h = m_server.m_header->frame_h;
	m_writer->m_background = m_background;
	m_writer->m_data_scaler = m_data_scaler;
	m_writer->m_byte_per_pixel = bpp;
	m_writer->m_frame_cycle = (float) g_camera.m_kinetic_cycle_time;
	if ( m_writer->Open() < 0 )
	{
		delete m_writer;
		m_writer = NULL;
		m_client.CAQClose();
		m_recording_index = 0;
		m_recording_with_shutter = FALSE;
		return -1;
	}

	m_directory.m_fileno = m_directory.m_fileno + 1;
	m_is_recording = TRUE;

	SetUIs();
	UpdateData(FALSE);
	return 0;
}


BOOL CMovieRecorderDialog::Record()
{
	//Recording is not in progress.
	if ( !m_writer || !(m_writer->m_file) )	return 0;

	UINT64 num_acquired = m_server.m_header->num_acquired;
	if ( m_is_recording == TRUE )
	{		
		UINT32 num_frames = ( num_acquired > m_recording_index ) ? (UINT32) ( num_acquired - m_recording_index ) : 0 ;
		if ( m_recording_with_shutter )
		{
			//I am remarking out because it seems to be executed before shutter manager has a chance to set the shutter to work.
			//If it solves the synchronization problem, I still need to find a way to deal with the case where the shutter control is closed later.
			if ( !g_shutter_client.IsOpen() || 
				( g_shutter_client.IsShutterWorking() !=TRUE && num_frames >= g_shutter_client.m_data->shutter_count ) )
				m_is_recording = FALSE;
				
		}
		else
		{
			if ( m_set_max_frame_no && num_frames >= (UINT) m_max_frame_no )
				m_is_recording = FALSE;
		}
	}

	while ( m_client.m_index < num_acquired )
	{
		UINT32 *image = m_client.CAQReadImage();
		if ( image == NULL )
		{
			LogErr(_T("CAQReadImage Failed."));
			m_is_recording = FALSE;
			break;
		}
		//m_writer->Write( m_server.m_header->bpp, image ) ;
		m_writer->Write( image ) ;

		if ( m_log_selected_spot && m_writer->m_pktrace.IsOpen() )
		{
			CPeakSet set;
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				set.p[i].x = (float) m_server.m_header->x[i];
				set.p[i].y = (float) m_server.m_header->y[i];
			}
			m_writer->m_pktrace.Write( (UINT)(m_client.m_index-m_recording_index), &set );
		}

		m_client.CAQModeReadContinue();
	}

	if ( m_is_recording == FALSE )
	{
		m_writer->Close();
		m_recording_index = 0;
		m_recording_with_shutter = FALSE;
		m_client.CAQClose();
		SetUIs();
	}

	return 0;	
}

int CMovieRecorderDialog::RecordStop()
{
/*
	//if ( m_is_acquiring )	UpdateFrame();
    m_is_recording = FALSE;
*/
	if ( m_recording_with_shutter )
		g_shutter_client.StopShutter();
	else
		m_is_recording = FALSE;

	return 0;
}






void CMovieRecorderDialog::UpdateFrame()
{
	int w = m_frame_w;
	int h = m_frame_h;
	CChannels ch( w, h );

	if ( !m_server.IsInitialized() )	return;
	UINT64 index = m_server.m_header->num_acquired-1;
	if ( index < 0 )	return;

	UINT32 min, max;
	min = max = m_server.CAQServerReadPixel( index, 0, 0 );

	memset( m_display_buffer, 0, sizeof(COLORREF)*w*h );
	for ( UINT y = 0 ; y < ch.h ; y++ )
	{
		for ( UINT x = 0 ; x < ch.w ; x++ )
		{
			UINT32 pixel[NUM_CHANNELS];
			UINT8 bpixel;
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				pixel[i] = m_server.CAQServerReadPixel( index, ch.l[i]+x, y );				
				if ( pixel[i] < min )	min = pixel[i];
				else if ( pixel[i] > max )	max = pixel[i];

				bpixel = Pixel2Byte(pixel[i]);
				if ( m_overlay_channels )
					for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
                        m_display_buffer[ w*y + ch.l[k]+x ] += ProgramColor1( i, bpixel ) ;
				else
					m_display_buffer[ w*y + ch.l[i]+x ] = ProgramColor0( i, bpixel ) ;
			}
		}
	}

	CWnd *pWnd;
	CString str;	

	pWnd = GetDlgItem(IDC_MAX);
	str.Format(_T("%u"), max);
	if ( pWnd )	pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_MIN);
	str.Format(_T("%u"), min);
	if ( pWnd )	pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_MAX_MIN_DIFF);
	str.Format(_T("%u"), max-min);
	if ( pWnd )	pWnd->SetWindowText(str);

	if ( !m_is_recording && m_auto_scale )
	{
		m_background = min;
		m_data_scaler = (UINT32) ( 1.2 * (max-min) );
//		if ( m_data_scaler < 255 )	m_data_scaler = 255;

		pWnd = GetDlgItem(IDC_BACKGROUND);
		str.Format(_T("%u"), m_background);
        if ( pWnd )	pWnd->SetWindowText(str);
		pWnd = GetDlgItem(IDC_DATA_SCALER);
		str.Format(_T("%u"), m_data_scaler);
        if ( pWnd )	pWnd->SetWindowText(str);

		m_server.m_header->background = m_background;
		m_server.m_header->scaler = m_data_scaler;
	}

	pWnd = GetDlgItem(IDC_FRAME_NO);
	str.Format(_T("%ld"), (INT32) (m_server.m_header->num_acquired - m_recording_index));

	if ( pWnd )	pWnd->SetWindowText(str);

//	UpdateData(FALSE);
}


void CMovieRecorderDialog::DrawCircle(CDC &dcMem, int x, int y, int r, COLORREF color)
{
	CPen pen(PS_SOLID, 1, color);
	dcMem.SelectObject(&pen);
	dcMem.Arc(	x - r, y - r, x + 1 + r, y + 1 + r,
				x - r, y + 1 + r, x - r, y + 1 + r );
	return;
}

void CMovieRecorderDialog::DrawFrame()
{
	if ( m_display_buffer == NULL )	return;

	CClientDC dcDlg (this);
	CDC dcMem;	//device context

	dcMem.CreateCompatibleDC(&dcDlg);
	CBitmap *pOldBitmap = dcMem.SelectObject(m_bitmap);
	m_bitmap->SetBitmapBits(sizeof(COLORREF)*m_frame_w*m_frame_h, m_display_buffer);

	CString str = _T("");
	CWnd *pWnd = GetDlgItem(IDC_SPOT_TEXT);
	int channel = GetChannel(m_point, NULL, NULL);

	if ( m_server.IsInitialized() && m_server.m_header->r > ZERO_TOLERANCE )
	{
		int x, y;
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			if ( m_server.m_header->x[i] < 0 || m_server.m_header->y[i] < 0 )	continue;
			x = (int) ( m_server.m_header->x[i] + 0.5 );
			y = (int) ( m_server.m_header->y[i] + 0.5 );
			DrawCircle(dcMem, x, y, (int) ceil(m_server.m_header->r), RGB(255, 255, 255));	
		}

		if ( channel >= CH1 )
		{
			if ( m_server.m_header->x[channel] >= 0 || m_server.m_header->y[channel] >= 0 )
			{
				x = (int) ( m_server.m_header->x[channel] + 0.5 );
				y = (int) ( m_server.m_header->y[channel] + 0.5 );

				str.Format(_T("%5d at ( %.2f, %.2f )"), m_server.CAQServerReadPixel( x, y ), m_server.m_header->x[channel], m_server.m_header->y[channel] );

				int view_r = (int) ceil( m_server.m_header->r * 4 * 1.0 / 3 );
				int view_l, view_t, view_w, view_h;		
				view_w = view_h = 2 * view_r + 1;
				if ( x - view_r	< 0 )	view_l = 0;
				else if ( x + view_r >= (int) m_frame_w )	view_l = m_frame_w - 1 - view_w;
				else	view_l = x - view_r;
				if ( y - view_r < 0 )	view_t = 0;
				else if ( y + view_r >= (int) m_frame_h )	view_t = m_frame_h - 1 - view_h;
				else	view_t = y - view_r;

				dcDlg.StretchBlt( m_spot_left, m_spot_top, m_spot_width, m_spot_height,
								&dcMem, view_l, view_t, view_w, view_h, SRCCOPY );
			}
		}
	}
	
	dcDlg.StretchBlt( m_image_left, m_image_top, m_image_width, m_image_height,
						&dcMem, 0, 0, m_frame_w, m_frame_h, SRCCOPY);
	dcMem.SelectObject(pOldBitmap);
	dcMem.DeleteDC();

	if ( pWnd )	pWnd->SetWindowText(str);
	return;
}

void CMovieRecorderDialog::SetUIs()
{
	CWnd *pWnd;

	if ( ::IsWindow(m_hWnd) != TRUE )	return;

	pWnd = GetDlgItem(IDC_EXPOSURE_TIME);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );
	pWnd = GetDlgItem(IDC_GAIN);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );
	pWnd = GetDlgItem(IDC_MEMORY_SIZE);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );
	pWnd = GetDlgItem(IDC_MAX);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );
	pWnd = GetDlgItem(IDC_MIN);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );
	pWnd = GetDlgItem(IDC_MAX_MIN_DIFF);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );

	pWnd = GetDlgItem(IDC_ACQUISITION);
	if ( pWnd )
	{
        if ( m_is_acquiring )
			pWnd->SetWindowText(_T("Stop Acquisition"));		
		else
			pWnd->SetWindowText(_T("Start Acquisition"));
		pWnd->EnableWindow(!m_is_recording );
	}

	pWnd = GetDlgItem(IDC_BACKGROUND);
	if ( pWnd )	pWnd->EnableWindow( !m_is_recording );
	pWnd = GetDlgItem(IDC_DATA_SCALER);
	if ( pWnd )	pWnd->EnableWindow( !m_is_recording );


	pWnd = GetDlgItem(IDC_RECORD_START);		
	if ( pWnd )	pWnd->EnableWindow( m_is_acquiring && !m_is_recording );
	pWnd = GetDlgItem(IDC_RECORD_STOP);		
	if ( pWnd )	pWnd->EnableWindow( m_is_acquiring && m_is_recording );

//	pWnd = GetDlgItem(IDC_FILM_COMMENT);
//	if ( pWnd && m_is_recording )	pWnd->EnableWindow(FALSE);

	pWnd = GetDlgItem(IDC_SAVE_AS_OLD_FORMAT);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring );
	pWnd = GetDlgItem(IDC_SAVE_PIXEL_IN_8BIT);
	if ( pWnd )	pWnd->EnableWindow( !m_is_acquiring && !m_save_as_old_format );
}

	
BEGIN_MESSAGE_MAP(CMovieRecorderDialog, CDialog)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()

	ON_EN_KILLFOCUS(IDC_EXPOSURE_TIME, OnEnKillfocusExposureTime)
	ON_EN_KILLFOCUS(IDC_GAIN, OnEnKillfocusGain)
	ON_EN_KILLFOCUS(IDC_MEMORY_SIZE, OnEnKillfocusMemorySize)
	ON_BN_CLICKED(IDC_ACQUISITION, OnBnClickedAcquisition)
	ON_EN_KILLFOCUS(IDC_BACKGROUND, OnEnKillfocusBackground)
	ON_EN_KILLFOCUS(IDC_DATA_SCALER, OnEnKillfocusDataScaler)

	ON_BN_CLICKED(IDC_RECORD_START, OnBnClickedRecordStart)
	ON_BN_CLICKED(IDC_RECORD_STOP, OnBnClickedRecordStop)
	ON_BN_CLICKED(IDC_SET_PATH, OnBnClickedSetPath)
	ON_BN_CLICKED(IDC_FILM_FIRST, OnBnClickedFilmFirst)
	ON_BN_CLICKED(IDC_FILM_PREV, OnBnClickedFilmPrev)
	ON_BN_CLICKED(IDC_FILM_NEXT, OnBnClickedFilmNext)
	ON_BN_CLICKED(IDC_FILM_LAST, OnBnClickedFilmLast)
	ON_BN_CLICKED(IDC_SET_MAX_LENGTH, OnBnClickedSetMaxLength)
	ON_EN_KILLFOCUS(IDC_MAX_FRAME, OnEnKillfocusMaxFrame)
	ON_BN_CLICKED(IDC_SAVE_AS_OLD_FORMAT, OnBnClickedSaveAsOldFormat)
	ON_BN_CLICKED(IDC_SAVE_PIXEL_IN_8BIT, OnBnClickedSavePixelIn8bit)
	ON_EN_KILLFOCUS(IDC_FILM_COMMENT, OnEnKillfocusFilmComment)

	ON_BN_CLICKED(IDC_AUTO_SCALE, OnBnClickedAutoScale)
	ON_BN_CLICKED(IDC_OVERLAY_CHANNELS, OnBnClickedOverlayChannels)
	ON_BN_CLICKED(IDC_LOG_SELECTED_SPOT, OnBnClickedLogSelectedSpot)

	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX, OnDeltaposSpinx)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY, OnDeltaposSpiny)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR, OnDeltaposSpinr)
	

END_MESSAGE_MAP()

// CMovieRecorderDialog message handlers

void CMovieRecorderDialog::OnPaint()
{
	CDialog::OnPaint();
	DrawFrame();
}

void CMovieRecorderDialog::OnEnKillfocusExposureTime()
{
	UpdateData(TRUE);
	if ( g_camera.SetExposureTime(m_exposure_time) == 0 
		&& fabs( m_exposure_time - g_camera.m_exposure_time ) > ZERO_TOLERANCE )
	{
		LogNotice(Stringify(_T("Closest Available Exposure Time was %.3f sec."), g_camera.m_exposure_time));
	}
	m_exposure_time = g_camera.m_exposure_time;
	UpdateData(FALSE);
}

void CMovieRecorderDialog::OnEnKillfocusGain()
{
	UpdateData(TRUE);
	g_camera.SetGain(m_gain);
	m_gain = g_camera.m_gain;
	UpdateData(FALSE);
}

void CMovieRecorderDialog::OnEnKillfocusMemorySize()
{
	int backup_memory_size = m_memory_size;
	UpdateData(TRUE);
	FreeRecorder();
	if ( InitRecorder() < 0 )
		m_memory_size = backup_memory_size;

	UpdateData(FALSE);
	return;
}

void CMovieRecorderDialog::OnBnClickedAcquisition()
{
	if ( m_is_acquiring )	
		StopAcquisition();
	else	
		StartAcquisition();
}

void CMovieRecorderDialog::OnEnKillfocusBackground()
{
	if ( m_is_recording )	return;
	UpdateData(TRUE);
	m_server.m_header->background = m_background;
//	m_server.CAQServerRestart();
}

void CMovieRecorderDialog::OnEnKillfocusDataScaler()
{
	if ( m_is_recording )	return;
	UpdateData(TRUE);
	if ( m_data_scaler == 0 )	m_data_scaler = 1;
	m_server.m_header->scaler = m_data_scaler;
//	m_server.CAQServerRestart();
}





void CMovieRecorderDialog::OnBnClickedRecordStart()
{
	RecordStart();
}

void CMovieRecorderDialog::OnBnClickedRecordStop()
{
	RecordStop();
}

void CMovieRecorderDialog::OnBnClickedSetPath()
{
	if ( m_is_recording )	return;
	
	PickContainer();
	m_directory.SetPath(_PATH_FAKE);
	m_directory.LastFile();
	UpdateData(FALSE);
	
}

void CMovieRecorderDialog::OnBnClickedFilmFirst()
{
	m_directory.m_fileno = 0;
	UpdateData(FALSE);
}

void CMovieRecorderDialog::OnBnClickedFilmPrev()
{
	m_directory.m_fileno = ( m_directory.m_fileno < 1 )	? 0 : m_directory.m_fileno-1 ;
	UpdateData(FALSE);
}

void CMovieRecorderDialog::OnBnClickedFilmNext()
{
	m_directory.m_fileno = m_directory.m_fileno+1;
	UpdateData(FALSE);
}

void CMovieRecorderDialog::OnBnClickedFilmLast()
{
	m_directory.LastFile();
	UpdateData(FALSE);
}

void CMovieRecorderDialog::OnBnClickedSetMaxLength()
{
	UpdateData(TRUE);
}

void CMovieRecorderDialog::OnEnKillfocusMaxFrame()
{
	int backup_max_frame_no = m_max_frame_no;
	UpdateData(TRUE);
	if ( m_max_frame_no < 0 )
	{
		LogErr(_T("Invalid Frame No Input."));
		m_max_frame_no = backup_max_frame_no;
		UpdateData(FALSE);
	}
}

void CMovieRecorderDialog::OnBnClickedSaveAsOldFormat()
{
	UpdateData(TRUE);
	if ( m_save_as_old_format )
	{
		m_save_pixel_in_8bit = TRUE;
		m_directory.SetFormat(CAMERAFILE_OLDFILM_PREFIX, CAMERAFILE_OLDFILM_EXT);
	}
	else
		m_directory.SetFormat(CAMERAFILE_FILM_PREFIX, CAMERAFILE_FILM_EXT);

	
	UpdateData(FALSE);
	SetUIs();
}

void CMovieRecorderDialog::OnBnClickedSavePixelIn8bit()
{
	UpdateData(TRUE);
}

void CMovieRecorderDialog::OnEnKillfocusFilmComment()
{
	UpdateData(TRUE);
	if ( m_writer )	m_writer->m_flog.AddComment(m_film_comment);
}


void CMovieRecorderDialog::OnBnClickedAutoScale()
{
	UpdateData(TRUE);
//	m_server.CAQServerRestart();
}

void CMovieRecorderDialog::OnBnClickedOverlayChannels()
{
	UpdateData(TRUE);
}

void CMovieRecorderDialog::OnBnClickedLogSelectedSpot()
{
	if ( !m_server.IsInitialized() || m_server.m_header->num_acquired == 0 )
	{
		m_log_selected_spot = FALSE;
		UpdateData(FALSE);
		return;
	}
		
	UpdateData(TRUE);
	
	if ( m_log_selected_spot )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			if ( m_server.m_header->x[i] < 0 || m_server.m_header->y[i] < 0 )	continue;
			double cx, cy;
			if ( CCAQClient::FindCenter( m_frame_w, m_frame_h, m_server.CAQServerReadImage(), CCAQClient::U32FRAME, 
										m_server.m_header->x[i], m_server.m_header->y[i], m_server.m_header->r,
										&cx, &cy ) < 0 )
			{
				continue;
			}
			m_server.m_header->x[i] = cx;
			m_server.m_header->y[i] = cy;
		}
	}
}

int CMovieRecorderDialog::GetChannel(CPoint point, int *px, int *py)
{
	if ( !m_server.IsInitialized() )	return CH1-1;

	int x = (int) ( m_frame_w * (point.x - m_image_left) * 1.0/m_image_width );
	int y = (int) ( m_frame_h * (point.y - m_image_top) * 1.0/m_image_height );
	if ( px )	*px = x;
	if ( py )	*py = y;

	CChannels ch( m_frame_w, m_frame_h );
	if ( y < 0 || y >= (int) ch.h )	return CH1-1;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( (int) ch.l[i] <= x && x <= (int) ch.r[i] )	return i;
	}
	return CH1-1;
}

#define DEFAULT_SPOT_RADIUS	(3)
void CMovieRecorderDialog::OnLButtonDown(UINT nFlags, CPoint point)
{
	int ch, x, y;

	ch = GetChannel( point, &x, &y );
	if ( ch >= CH1 )
	{
		if ( m_server.m_header->x[ch] < 0 || m_server.m_header->y[ch] < 0 )
		{
			if ( m_server.m_header->r < ZERO_TOLERANCE )
				m_server.m_header->r = DEFAULT_SPOT_RADIUS;
			m_server.m_header->x[ch] = x;
			m_server.m_header->y[ch] = y;
		}
		else
		{
			m_server.m_header->x[ch] = -1.0;
			m_server.m_header->y[ch] = -1.0;
		}
		m_point = point;
		DrawFrame();
		UpdateData(FALSE);
	}
	//else	// Do nothing
	CDialog::OnLButtonDown(nFlags, point);
	return;
}

void CMovieRecorderDialog::OnDeltaposSpinx(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_server.IsInitialized() )	return;

	int channel = GetChannel( m_point, NULL, NULL );
	if ( channel < CH1 )	return;
	double x = m_server.m_header->x[channel];
	if ( x < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	
		x++;
	else	
		x--;

	CChannels ch(m_frame_w, m_frame_h);
	if ( x < ch.l[channel] )	x = ch.l[channel];
	if ( x > ch.r[channel] )	x = ch.r[channel];
	m_server.m_header->x[channel] = x;

	DrawFrame();
	*pResult = 0;
}

void CMovieRecorderDialog::OnDeltaposSpiny(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_server.IsInitialized() )	return;

	int channel = GetChannel( m_point, NULL, NULL );
	if ( channel < CH1 )	return;
	double y = m_server.m_header->y[channel];
	if ( y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	
		y--;
	else	
		y++;

	CChannels ch(m_frame_w, m_frame_h);
	if ( y < 0 )	y = 0;
	if ( y >= ch.h )	y = ch.h - 1;
	m_server.m_header->y[channel] = y;

	DrawFrame();
	*pResult = 0;
}

void CMovieRecorderDialog::OnDeltaposSpinr(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_server.IsInitialized() )	return;

	double r = m_server.m_header->r;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	
		r++;
	else	
		r--;

	CChannels ch(m_frame_w, m_frame_h);
	if ( (int) (r+0.5) <= 0 )	r = 1;
	m_server.m_header->r = r;

	DrawFrame();
	*pResult = 0;
}


