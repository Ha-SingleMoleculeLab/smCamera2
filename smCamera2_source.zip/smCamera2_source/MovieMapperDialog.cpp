// MovieMapperDialog.cpp : implementation file
//

#include "stdafx.h"
#include "smCamera.h"
#include "MovieMapperDialog.h"
#include "Circle.h"
#include <math.h>
#include ".\moviemapperdialog.h"

#define DEFAULT_SPOT_RADIUS		(10)	//in px
#define DEFAULT_PEAK_RADIUS		(3)		//in px
#define DEFAULT_PEAK_THRESHOLD	(10.0)	//%

// CMovieMapperDialog dialog

IMPLEMENT_DYNAMIC(CMovieMapperDialog, CDialog)
CMovieMapperDialog::CMovieMapperDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMovieMapperDialog::IDD, pParent)
	, m_allow_bad_peaks1(FALSE)
	, m_allow_bad_peaks2(FALSE)
{
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
        m_film[i] = NULL;
		m_ppair[i] = NULL;
		m_bitmap[i] = NULL;
		m_channel_buffer[i] = NULL;		
		m_backup_frame[i] = NULL;
		m_fspath[i] = _T("");

	}
	m_frame_buffer = NULL;
}

CMovieMapperDialog::~CMovieMapperDialog()
{
}



BOOL CMovieMapperDialog::OnInitDialog()
{
	CString str;
	CDialog::OnInitDialog();

	BOOL is_ok = TRUE;
	CArchive *ar = NULL;
	if ( DoesProgramFileExist( GetProgramFilePath( _PATH_MOVIE_MAPPER, _T("mapper.save") ) ) )
        ar = OpenProgramFileToRead( GetProgramFilePath( _PATH_MOVIE_MAPPER, _T("mapper.save") ) );

	if ( !ar )	is_ok = FALSE;

	is_ok = ( is_ok && ar->ReadString(str) );
	if ( is_ok )	m_directory.SetPath(str);

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		is_ok = ( is_ok && ar->ReadString(str) );
		if ( is_ok )	m_fspath[i] = str;
		m_fs[i].Load(m_fspath[i]);
		is_ok = ( is_ok && ar->ReadString(str) );
		if ( is_ok )	m_superpose_mapping[i].Load(str);		
		is_ok = ( is_ok && ar->ReadString(str) );
		if ( is_ok )	m_peak_radius[i] = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
		is_ok = ( is_ok && ar->ReadString(str) );
		if ( is_ok )	m_peak_threshold[i] = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
	}

	is_ok = ( is_ok && ar->ReadString(str) );
	if ( is_ok )	m_old_mapping.Load(str);
	is_ok = ( is_ok && ar->ReadString(str) );
	if ( is_ok )	m_allowable_error = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
	is_ok = ( is_ok && ar->ReadString(str) );
	if ( is_ok )	m_spot_radius = _tstoi(str);

	if ( !is_ok )
	{
		m_directory.SetPath(_PATH_MOVIES);
	
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			m_fspath[i] = _T("");
			m_fs[i].Load();
			m_fspath[i] = m_fs[i].DefaultPath();
			m_superpose_mapping[i].Load();
			m_peak_radius[i] = DEFAULT_PEAK_RADIUS;
			m_peak_threshold[i] = DEFAULT_PEAK_THRESHOLD;
		}
		
		m_old_mapping.Load();
		m_allowable_error = 1.0;
		m_spot_radius = DEFAULT_SPOT_RADIUS;
	}
	if ( ar ) CloseProgramFile(ar);

	FreeFrame();
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		m_slider[i].EnableWindow(FALSE);
		m_filepath[i] = _T("");
		m_film[i] = NULL;
		m_copy[i] = FALSE;
		m_superpose[i] = FALSE;
		m_peak_finder[i].Reset();
	}
	m_rough_mapping.Reset(0, 0);
	m_new_mapping.Reset(0, 0);
	OnBnClickedPair1();

	LoadProgramColorTable();
	SetUIs();

	UpdateData(FALSE);	
	return TRUE;
}

void CMovieMapperDialog::OnCancel()
{
	DestroyWindow();
}

void CMovieMapperDialog::OnOK()
{
	SetFocus();
	return;
}

void CMovieMapperDialog::OnDestroy()
{
	CString str;
	CArchive *ar = OpenProgramFileToWrite( GetProgramFilePath( _PATH_MOVIE_MAPPER, _T("mapper.save") ) );
	if ( ar )
	{
		str.Format(_T("%s\r\n"), m_directory.m_path);
		ar->WriteString( str );

		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			str.Format(_T("%s\r\n"), m_fspath[i]);
			ar->WriteString(str);
			str.Format(_T("%s\r\n"), m_superpose_mapping[i].m_path);
			ar->WriteString(str);
			str.Format(_T("%f\r\n"), m_peak_radius[i]);
			ar->WriteString(str);
			str.Format(_T("%f\r\n"), m_peak_threshold[i]);
			ar->WriteString(str);
		}

		str.Format(_T("%s\r\n"), m_old_mapping.m_path);
		ar->WriteString(str);
		str.Format(_T("%f\r\n"), m_allowable_error);
		ar->WriteString(str);
		str.Format(_T("%d\r\n"), m_spot_radius);
		ar->WriteString(str);

		CloseProgramFile(ar);
	}

	FreeFrame();

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( m_film[i] )
		{
			CFilm *film = m_film[i];
			for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
				if ( m_film[k] == film )	m_film[k] = NULL;

			delete film;
		}
        m_filepath[i] = _T("");
		m_superpose_mapping[i].Reset(0,0);
		m_peak_finder[i].Reset();
	}
	m_old_mapping.Reset(0,0);
	m_rough_mapping.Reset(0,0);
	m_new_mapping.Reset(0,0);

	_tchdir(_PATH_ROOT);
	CDialog::OnDestroy();
}

void CMovieMapperDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_IMAGE1, m_image[CH1]);
	DDX_Control(pDX, IDC_IMAGE2, m_image[CH2]);
	DDX_Control(pDX, IDC_SLIDER1, m_slider[CH1]);
	DDX_Control(pDX, IDC_SLIDER2, m_slider[CH2]);

	DDX_Text(pDX, IDC_FSPATH1, m_fspath[CH1]);
	DDX_Text(pDX, IDC_FSPATH2, m_fspath[CH2]);

	DDX_Check(pDX, IDC_COPY1, m_copy[CH1]);
	DDX_Check(pDX, IDC_COPY2, m_copy[CH2]);
	DDX_Check(pDX, IDC_SUPERPOSE1, m_superpose[CH1]);
	DDX_Check(pDX, IDC_SUPERPOSE2, m_superpose[CH2]);
	DDX_Text(pDX, IDC_PEAK_RADIUS1, m_peak_radius[CH1]);
	DDX_Text(pDX, IDC_PEAK_RADIUS2, m_peak_radius[CH2]);
	DDX_Text(pDX, IDC_PEAK_THRESHOLD1, m_peak_threshold[CH1]);
	DDX_Text(pDX, IDC_PEAK_THRESHOLD2, m_peak_threshold[CH2]);

	DDX_Check(pDX, IDC_BAD_PEAKS1, m_allow_bad_peaks1);
	DDX_Check(pDX, IDC_BAD_PEAKS2, m_allow_bad_peaks2);
	DDX_Check(pDX, IDC_USE_MAP, m_use_old_map);
	DDX_Check(pDX, IDC_USE_ROUGH_MAP, m_use_rough_map);
	DDX_Control(pDX, IDC_PAIR1, m_pair1_radio);
	DDX_Control(pDX, IDC_PAIR2, m_pair2_radio);
	DDX_Control(pDX, IDC_PAIR3, m_pair3_radio);
	DDX_Text(pDX, IDC_ERROR, m_allowable_error);

	DDX_Control(pDX, IDC_SPOT1, m_spot[CH1]);
	DDX_Control(pDX, IDC_SPOT2, m_spot[CH2]);

	if ( pDX->m_bSaveAndValidate != TRUE )
	{
		CWnd *pWnd;
		CString str;

		str.Format(_T("Radius : %d px"), m_spot_radius);
		pWnd = GetDlgItem(IDC_R1_TEXT);
		if ( pWnd )	pWnd->SetWindowText(str);
		pWnd = GetDlgItem(IDC_R2_TEXT);
		if ( pWnd )	pWnd->SetWindowText(str);

	}
}





static RECT * __find_dest_rect(CDialog *dlg, CStatic *pane)
{
	static RECT	rect;
	long border_thickness;
	
	RECT dlgClientRct, dlgWinRct, paneWinRct;
	dlg->GetWindowRect(&dlgWinRct);
	dlg->GetClientRect(&dlgClientRct);

	pane->GetWindowRect(&paneWinRct);

	border_thickness = ( (dlgWinRct.right-dlgWinRct.left) - (dlgClientRct.right-dlgClientRct.left) )/2;
	rect.left = paneWinRct.left - ( dlgWinRct.left + border_thickness );
	dlgWinRct.top = dlgWinRct.bottom - border_thickness
					- (dlgClientRct.bottom-dlgClientRct.top) - border_thickness;
	rect.top = paneWinRct.top - ( dlgWinRct.top + border_thickness );
	rect.right = rect.left + paneWinRct.right - paneWinRct.left;
	rect.bottom = rect.top + paneWinRct.bottom - paneWinRct.top;

	return &rect;
}

void CMovieMapperDialog::InitFrame(UINT w, UINT h)
{
	CClientDC dcDlg (this);
	RECT *rect;

	FreeFrame();
	OnBnClickedPair1();

	CChannels ch( w, h );
	m_frame_w = w;
	m_frame_h = h;
	m_frame_buffer = new COLORREF[w*h];
	memset(m_frame_buffer, 0, sizeof(COLORREF)*w*h);

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
        m_bitmap[i] = new CBitmap();
		m_bitmap[i]->CreateCompatibleBitmap(&dcDlg, ch.w, ch.h );
		m_channel_buffer[i] = new COLORREF[ch.w*ch.h];
		memset(m_channel_buffer[i], 0, sizeof(COLORREF)*ch.w*ch.h);
		m_backup_frame[i] = new double[w*h];
		memset(m_backup_frame[i], 0, sizeof(double)*w*h);

		rect = __find_dest_rect(this, &(m_image[i]));
		m_image_left[i] = rect->left;
		m_image_top[i] = rect->top;
		m_image_width[i] = rect->right - rect->left;
		m_image_height[i] = rect->bottom - rect->top;

		rect = __find_dest_rect(this, &(m_spot[i]));
		m_spot_left[i] = rect->left;
		m_spot_top[i] = rect->top;
		m_spot_width[i] = rect->right - rect->left;
		m_spot_height[i] = rect->bottom - rect->top;
	}

	UpdateFrame();

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( m_image_height[i] * ch.w >= m_image_width[i] * ch.h )
			m_image_height[i] = (int) (( m_image_width[i] * ch.h * 1.0 / ch.w ) + 0.5);
		else
			m_image_width[i] = (int) (( m_image_height[i] * ch.w * 1.0 / ch.h ) + 0.5 );
	}

	return;
}

void CMovieMapperDialog::UpdateFrame()
{
	CChannels ch( m_frame_w, m_frame_h );
	if ( ch.w == 0 || ch.h == 0 )	return;

	CClientDC dcDlg (this);
	CDC dcMem[NUM_CHANNELS];	
	CBitmap *pOldBitmap[NUM_CHANNELS];
	
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
        dcMem[i].CreateCompatibleDC(&dcDlg);
		pOldBitmap[i] = dcMem[i].SelectObject(m_bitmap[i]);
        m_bitmap[i]->SetBitmapBits(sizeof(COLORREF)*ch.w*ch.h, m_channel_buffer[i]);
	}

	DrawPointPairs( dcDlg, dcMem, m_pair1 );
	DrawPointPairs( dcDlg, dcMem, m_pair2 );
	DrawPointPairs( dcDlg, dcMem, m_pair3 );

	//	dcDlg.SetStretchBltMode(COLORONCOLOR);
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		dcDlg.StretchBlt( m_image_left[i], m_image_top[i], m_image_width[i], m_image_height[i],
						&(dcMem[i]), 0, 0, ch.w, ch.h, SRCCOPY);
		dcMem[i].SelectObject(pOldBitmap[i]);
		dcMem[i].DeleteDC();
	}
	
	UpdateData(FALSE);
	return;
}

void CMovieMapperDialog::FreeFrame()
{
	CClientDC dcDlg (this);
	CDC dcMem;
	CBitmap bitmap, *pOldBitmap;

	bitmap.CreateCompatibleBitmap(&dcDlg, 1, 1);
    dcMem.CreateCompatibleDC(&dcDlg);
	pOldBitmap = dcMem.SelectObject(&bitmap);
	dcMem.SetPixelV( 0, 0, RGB( 0, 0, 0 ) );
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		dcDlg.StretchBlt( m_image_left[i], m_image_top[i], m_image_width[i], m_image_height[i],
						&dcMem, 0, 0, 1, 1, SRCCOPY);
		dcDlg.StretchBlt( m_spot_left[i], m_spot_top[i], m_spot_width[i], m_spot_height[i],
						&dcMem, 0, 0, 1, 1, SRCCOPY );
	}
	dcMem.SelectObject(pOldBitmap);
	dcMem.DeleteDC();

	m_frame_w = 0;
	m_frame_h = 0;

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( m_channel_buffer[i] )	delete [] m_channel_buffer[i];
		m_channel_buffer[i] = NULL;

		if ( m_bitmap[i] )	delete m_bitmap[i];
		m_bitmap[i] = NULL;

		if ( m_backup_frame[i] )	delete [] m_backup_frame[i];
		m_backup_frame[i] = NULL;
	}
	if ( m_frame_buffer )	delete [] m_frame_buffer;
	m_frame_buffer = NULL;


	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		m_ppair[i] = NULL;
		m_pair1[i].SetPoint(-1, -1);
		m_pair2[i].SetPoint(-1, -1);
		m_pair3[i].SetPoint(-1, -1);
	}
}



BOOL CMovieMapperDialog::GetChannelCoordinate(int id, CPoint pt, int *px, int *py)
{
	CChannels ch( m_frame_w, m_frame_h );
	if ( ch.w == 0 || ch.h == 0 )	return FALSE;

	//say	w' = m_image_width / w
	//		h' = m_image_height / h
	//	[ image_left + x*w' ~ image_left + (x+1)*w' ]	-> x
	//	[ image_top + y*h' ~ image_top + (y+1)*h'	]	-> y
	//	x = (int) (pt.x - image_left)/w'
	//	y = (int) (pt.x - image_top)/h'
	int x = (int) ( ch.w * (pt.x - m_image_left[id]) * 1.0/m_image_width[id] );
	int y = (int) ( ch.h * (pt.y - m_image_top[id]) * 1.0/m_image_height[id] );
	if ( !( 0 <= x && x < (int)ch.w && 0 <= y && y < (int)ch.h ) )	return FALSE;

	if ( px )	*px = x;
	if ( py )	*py = y;

	return TRUE;;
}

void CMovieMapperDialog::DrawCircle(CDC &dcMem, int x, int y, int r, COLORREF color)
{
	CPen pen(PS_SOLID, 1, color);
	dcMem.SelectObject(&pen);
	dcMem.Arc(	x - r, y - r, x + 1 + r, y + 1 + r,
				x - r, y + 1 + r, x - r, y + 1 + r );
	return;
}

void CMovieMapperDialog::DrawPointPairs(CClientDC &dcDlg, CDC dcMem[NUM_CHANNELS], CPoint pair[NUM_CHANNELS])
{
	CChannels ch( m_frame_w, m_frame_h );
	if ( ch.w == 0 || ch.h == 0 )	return;

	int view_l, view_t, view_w, view_h, view_r;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		int x = pair[i].x;
		int y = pair[i].y;
		if ( x < 0 || y < 0 )	continue;

		view_r = (int) ceil( m_spot_radius * 4 * 1.0 / 3 );
		view_w = view_h = 2*view_r + 1;

		if ( m_ppair[i] == &(pair[i]) )
		{
			DrawCircle(dcMem[i], x, y, m_spot_radius, RGB(255, 255, 0));
		}
		else
		{
			DrawCircle(dcMem[i], x, y, m_spot_radius, RGB(128, 128, 0));
			continue;	
		}
	
		
        if ( x - view_r	< 0 )	view_l = 0;
		else if ( x + view_r >= (int) ch.w )	view_l = ch.w - 1 - view_w;
		else	view_l = x - view_r;
		if ( y - view_r < 0 )	view_t = 0;
		else if ( y + view_r >= (int) ch.h )	view_t = ch.h - 1 - view_h;
		else	view_t = y - view_r;
		dcDlg.StretchBlt( m_spot_left[i], m_spot_top[i], m_spot_width[i], m_spot_height[i],
							&(dcMem[i]), view_l, view_t, view_w, view_h, SRCCOPY );
	}
}


#define PAIR_READY_STATUS_FORMAT		_T("[Pair %d is Ready] Readjust if you wish.")
#define PAIR_NOT_READY_STATUS_FORMAT	_T("[Pair %d is Not Ready] Pick a point.")

void CMovieMapperDialog::SetUIs()
{
	CWnd *pWnd;
	BOOL flag;
	CString str;

	pWnd = GetDlgItem(IDC_FILE1);
	if ( pWnd )
	{
		pWnd->SetWindowText( m_filepath[CH1] );
		((CEdit*)pWnd)->SetSel(0, -1);
	}

	flag = ( !m_filepath[CH1].IsEmpty() );
	pWnd = GetDlgItem(IDC_OPEN1);
	if ( pWnd )	pWnd->EnableWindow(!flag);
	pWnd = GetDlgItem(IDC_CLOSE1);
	if ( pWnd )	pWnd->EnableWindow(flag);
	m_slider[CH1].EnableWindow( ( m_film[CH1] != NULL ) );

	pWnd = GetDlgItem(IDC_FIND_CH1);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_MAPPING1);
	str = m_superpose_mapping[CH1].m_path;
	if ( str.IsEmpty() )	str = _T("No map is loaded.");
	if ( pWnd ) pWnd->SetWindowText(str);

	pWnd = GetDlgItem(IDC_FSPATH1);
	if ( pWnd )
		((CEdit*)pWnd)->SetSel(0, -1);


	pWnd = GetDlgItem(IDC_FILE2);
	if ( pWnd )
	{
		pWnd->SetWindowText( m_filepath[CH2] );
		((CEdit*)pWnd)->SetSel(0, -1);
	}

	flag = ( !m_filepath[CH2].IsEmpty() );
	pWnd = GetDlgItem(IDC_OPEN2);
	if ( pWnd )	pWnd->EnableWindow(!flag);
	pWnd = GetDlgItem(IDC_CLOSE2);
	if ( pWnd )	pWnd->EnableWindow(flag);
	m_slider[CH2].EnableWindow( ( m_film[CH2] != NULL ) );

	pWnd = GetDlgItem(IDC_FIND_CH2);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_MAPPING2);
	str = m_superpose_mapping[CH2].m_path;
	if ( str.IsEmpty() )	str = _T("No map is loaded.");
	if ( pWnd ) pWnd->SetWindowText(str);

	pWnd = GetDlgItem(IDC_FSPATH2);
	if ( pWnd )
		((CEdit*)pWnd)->SetSel(0, -1);




	flag = ( !m_filepath[CH1].IsEmpty() && !m_filepath[CH2].IsEmpty() );
	m_pair1_radio.EnableWindow(flag);
	m_pair2_radio.EnableWindow(flag);
	m_pair3_radio.EnableWindow(flag);
	pWnd = GetDlgItem(IDC_PAIR_STATUS);
	if ( pWnd )	pWnd->EnableWindow(flag);

	BOOL is_set = TRUE;
	if ( m_pair1_radio.GetCheck() == BST_CHECKED )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			is_set = is_set && ( m_pair1[i].x >= 0 ) && ( m_pair1[i].y >= 0 ) ;

		str.Format( ( is_set ) ? PAIR_READY_STATUS_FORMAT : PAIR_NOT_READY_STATUS_FORMAT, 1 );
	}
	else if ( m_pair2_radio.GetCheck() == BST_CHECKED )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			is_set = is_set && ( m_pair2[i].x >= 0 ) && ( m_pair2[i].y >= 0 ) ;\

		str.Format( ( is_set ) ? PAIR_READY_STATUS_FORMAT : PAIR_NOT_READY_STATUS_FORMAT, 2 );
	}
	else if ( m_pair3_radio.GetCheck() == BST_CHECKED )
	{
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			is_set = is_set && ( m_pair3[i].x >= 0 ) && ( m_pair3[i].y >= 0 ) ;

		str.Format( ( is_set ) ? PAIR_READY_STATUS_FORMAT : PAIR_NOT_READY_STATUS_FORMAT, 3 );
	}
	
	pWnd = GetDlgItem(IDC_PAIR_STATUS);
	if ( pWnd )	pWnd->SetWindowText( str );


	pWnd = GetDlgItem(IDC_MAP);
	if ( pWnd )	pWnd->EnableWindow(flag);
	pWnd = GetDlgItem(IDC_SAVE);
	if ( pWnd )	pWnd->EnableWindow(flag);
	
	pWnd = GetDlgItem(IDC_MAPPING);
	str = m_old_mapping.m_path;
	if ( str.IsEmpty() )	str = _T("No map is loaded.");
	if ( pWnd ) pWnd->SetWindowText(str);


}


// CMovieMapperDialog message handlers


BEGIN_MESSAGE_MAP(CMovieMapperDialog, CDialog)
	ON_WM_DESTROY()	
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_HSCROLL()

	ON_BN_CLICKED(IDC_OPEN1, OnBnClickedOpen1)
	ON_BN_CLICKED(IDC_CLOSE1, OnBnClickedClose1)
	ON_BN_CLICKED(IDC_OPEN2, OnBnClickedOpen2)
	ON_BN_CLICKED(IDC_CLOSE2, OnBnClickedClose2)

	ON_BN_CLICKED(IDC_LOAD_FS_CH1, OnBnClickedLoadFsCh1)
	ON_BN_CLICKED(IDC_APPLY_FS_CH1, OnBnClickedApplyFsCh1)
	ON_BN_CLICKED(IDC_LOAD_FS_CH2, OnBnClickedLoadFsCh2)
	ON_BN_CLICKED(IDC_APPLY_FS_CH2, OnBnClickedApplyFsCh2)

	ON_BN_CLICKED(IDC_COPY1, OnBnClickedCopy1)
	ON_BN_CLICKED(IDC_SUPERPOSE1, OnBnClickedSuperpose1)
	ON_BN_CLICKED(IDC_MAPPING1, OnBnClickedSuperposeMap1)
	ON_EN_KILLFOCUS(IDC_PEAK_RADIUS1, OnEnKillfocusPeakRadius1)
	ON_EN_KILLFOCUS(IDC_PEAK_THRESHOLD1, OnEnKillfocusPeakThreshold1)
	ON_BN_CLICKED(IDC_FIND_CH1, OnBnClickedFind1)
	ON_BN_CLICKED(IDC_BGFIND_CH1, OnBnClickedBGFind1)
	ON_BN_CLICKED(IDC_COPY2, OnBnClickedCopy2)
	ON_BN_CLICKED(IDC_SUPERPOSE2, OnBnClickedSuperpose2)
	ON_BN_CLICKED(IDC_MAPPING2, OnBnClickedSuperposeMap2)
	ON_EN_KILLFOCUS(IDC_PEAK_RADIUS2, OnEnKillfocusPeakRadius2)
	ON_EN_KILLFOCUS(IDC_PEAK_THRESHOLD2, OnEnKillfocusPeakThreshold2)
	ON_BN_CLICKED(IDC_FIND_CH2, OnBnClickedFind2)
	ON_BN_CLICKED(IDC_BGFIND_CH2, OnBnClickedBGFind2)

	ON_BN_CLICKED(IDC_BAD_PEAKS1, OnBnClickedBadPeaks1)
	ON_BN_CLICKED(IDC_BAD_PEAKS2, OnBnClickedBadPeaks2)
	ON_BN_CLICKED(IDC_USE_MAP, OnBnClickedUseMap)
	ON_BN_CLICKED(IDC_MAPPING, OnBnClickedOldMap)
	ON_BN_CLICKED(IDC_USE_ROUGH_MAP, OnBnClickedUseRoughMap)
	ON_BN_CLICKED(IDC_PAIR1, OnBnClickedPair1)
	ON_BN_CLICKED(IDC_PAIR2, OnBnClickedPair2)
	ON_BN_CLICKED(IDC_PAIR3, OnBnClickedPair3)
	ON_EN_KILLFOCUS(IDC_ERROR, OnEnKillfocusAllowableError)
	ON_BN_CLICKED(IDC_MAP, OnBnClickedMap)
	ON_BN_CLICKED(IDC_SAVE, OnBnClickedSave)

	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR1, OnDeltaposSpinr1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR2, OnDeltaposSpinr2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX1, OnDeltaposSpinx1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY1, OnDeltaposSpiny1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX2, OnDeltaposSpinx2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY2, OnDeltaposSpiny2)
END_MESSAGE_MAP()


// CMovieMapperDialog message handlers

void CMovieMapperDialog::OnPaint()
{
	CDialog::OnPaint();
	UpdateFrame();
}


void CMovieMapperDialog::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int id;
	if ( pScrollBar == (CScrollBar*)&(m_slider[CH1]) )	
		id = CH1;
	else if ( pScrollBar == (CScrollBar*)&(m_slider[CH2]) )	
		id = CH2;
	else
		return;

	if ( m_film[id] == NULL )	return;


	static int range_from[NUM_CHANNELS] = { -1, -1 };
	int from, to;
	from = range_from[id];
	to = m_slider[id].GetPos();
	if ( from > to )
	{
		from = to;
		to = range_from[id];
	}

	if ( nSBCode == SB_THUMBTRACK )
	{
		if ( range_from[id] < 0 )	range_from[id] = m_slider[id].GetPos();
		else
		{
			m_slider[id].SetSelection(from, to);			
			m_slider[id].SetRange(0, m_slider[id].GetRangeMax(), TRUE);
		}
	}
	else if ( nSBCode != SB_THUMBPOSITION )
	{
		if ( nSBCode == SB_ENDSCROLL && range_from[id] >= 0 )
		{
			m_film[id]->MakeAverageFrame(from, to, NULL);
		}
		else
		{
			m_film[id]->MoveFrame(m_slider[id].GetPos());
			m_film[id]->ReadFrame(NULL);
			if ( range_from[id] >= 0 )	m_slider[id].ClearSel(TRUE);
			range_from[id] = -1;
		}
		m_peak_finder[id].UpdateFrame( m_frame_w, m_frame_h, m_film[id]->m_frame );
		m_peak_finder[id].DrawFrame( m_frame_w, m_frame_h, m_frame_buffer );

		CChannels ch( m_frame_w, m_frame_h );
		for ( UINT y = 0 ; y < ch.h ; y++ )
			for ( UINT x = 0 ; x < ch.w ; x++ )
				m_channel_buffer[id][ch.w*y + x] = m_frame_buffer[m_frame_w*y + ch.l[id]+x];

		UpdateFrame();
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CMovieMapperDialog::OnLButtonDown(UINT nFlags, CPoint point)
{
	int x, y;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( m_filepath[i].IsEmpty() )	continue;

		if ( GetChannelCoordinate(i, point, &x, &y) )
		{
			for ( int k = CH1 ; k < NUM_CHANNELS ; k++ )
			{
				if ( !m_filepath[k].IsEmpty() )	
                    m_ppair[k]->SetPoint( x, y );
				else
					m_ppair[k]->SetPoint( -1, -1 );
			}
			SetUIs();
			UpdateFrame();
			CDialog::OnLButtonDown(nFlags, point);
			return;
		}
	}
	CDialog::OnLButtonDown(nFlags, point);
	return;
}

int CMovieMapperDialog::OpenFile(int id, LPCTSTR path)
{
	CString filepath;

	if ( path == NULL )
	{
		CString szFilters;
		szFilters.Format(_T("Film Files (*.%s;*.%s)|*.%s; *.%s|"
							"TIFF Files (*.%s;*.%s)|*.%s; *.%s|"
							"Peaks Files (*.%s)|*.%s|"
							"All Files (*.*)|*.*||"),
							CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT,
							CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT,
							CAMERAFILE_PEAKS_EXT, CAMERAFILE_PEAKS_EXT );
		CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
		fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path;
		if( fileDlg.DoModal ()!=IDOK )	return -1;
		filepath = fileDlg.GetPathName();
	}
	else
		filepath = path;

	int n = filepath.ReverseFind((TCHAR)'\\');
	if ( n >= 0 )	m_directory.SetPath( filepath.Mid(0, n) );

	CloseFile(id);

	CFilm *film = NULL;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( filepath.Compare( m_filepath[i] ) == 0 )	film = m_film[i];
		if ( film )	break;
	}
	if ( !film )
	{
		film = new CFilm();
		if ( film->Open(filepath) < 0 )
		{
			delete film;
			return -1;
		}
		
		if ( m_frame_w == 0 || m_frame_h == 0 )	InitFrame( film->m_frame_w, film->m_frame_h );
		if ( m_frame_w != film->m_frame_w || m_frame_h != film->m_frame_h )	
		{
			delete film;
			return -1;
		}
	}

	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_filepath[id] = filepath;
	m_film[id] = film;
	film->MoveFrame(0);
	film->ReadFrame(NULL);

	m_peak_finder[id].SetFrame( w, h, film->m_frame, film->m_background, film->m_data_scaler );
	m_peak_finder[id].SetRadius( m_peak_radius[id] );
	m_peak_finder[id].SetThreshold( m_peak_threshold[id] );
	m_peak_finder[id].DrawFrameAndPeaks( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[id][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[id]+x ];

	m_slider[id].ClearSel(TRUE);
	m_slider[id].SetRange( 0, (int)film->m_num_frames - 1, TRUE );
	int pagesize = (int) ceil( film->m_num_frames * 1.0 / 100 );
	if ( pagesize <= 0 )	pagesize = 1;
	m_slider[id].SetPageSize(pagesize);
	m_slider[id].SetPos(0);

	SetUIs();
	UpdateFrame();
	UpdateData(FALSE);

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		if ( m_filepath[i].IsEmpty() )	OpenFile(i, filepath);

	return 0;
}

int CMovieMapperDialog::CloseFile(int id)
{
	int cnt1 = 0 ;
	int cnt2 = 0 ; 
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( i == id )	continue;

		if ( !m_filepath[i].IsEmpty() )	cnt1++;
		if ( m_filepath[i].Compare( m_filepath[id] ) == 0 )	cnt2++;
	}

	if ( cnt2 <= 0 )	delete m_film[id];

	m_filepath[id] = _T("");
	m_film[id] = NULL;
	m_peak_finder[id].Reset();
	m_slider[id].ClearSel(TRUE);
	m_slider[id].SetRange( 0, 0, TRUE );
	m_slider[id].SetPos(0);

	CChannels ch( m_frame_w, m_frame_h );
	if ( cnt1 > 0 )
		memset(m_channel_buffer[id], 0, sizeof(COLORREF)*ch.w*ch.h);
	else 
		FreeFrame();

	SetUIs();
	UpdateFrame();
	UpdateData(FALSE);
	return 0;
}

void CMovieMapperDialog::OnBnClickedOpen1()
{
	OpenFile(CH1);
}
void CMovieMapperDialog::OnBnClickedClose1()
{
	CloseFile(CH1);
}
void CMovieMapperDialog::OnBnClickedOpen2()
{
	OpenFile(CH2);
}
void CMovieMapperDialog::OnBnClickedClose2()
{
	CloseFile(CH2);
}

int CMovieMapperDialog::LoadFrameSequence(int ch)
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_FRAME_SEQUENCE;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_fspath[ch] = fileDlg.GetPathName();
		m_fs[ch].Load(m_fspath[ch]);
		UpdateData(FALSE);
	}
	return 0;
}

int CMovieMapperDialog::ApplyFrameSequence(int ch)
{
	if ( !m_film[ch] || !m_film[ch]->IsOpen() )	return -1;
	UINT w = m_film[ch]->m_frame_w;
	UINT h = m_film[ch]->m_frame_h;
	CChannels channel( w, h );

	if ( m_fs[ch].Init() < 0 )
	{
		LogErr(_T("Frame Sequence is not loaded."));
		return -1;
	}

	int cnt = 0;
	m_film[ch]->StartAveragingFrames();
	while ( m_fs[ch].IsEnd() != TRUE )
	{
		if ( m_fs[ch].Current() )
		{
			if ( m_fs[ch].CurrentFrameNo() >= m_film[ch]->m_num_frames )
				break;

			m_film[ch]->MoveFrame( m_fs[ch].CurrentFrameNo() );
			m_film[ch]->ReadFrame(NULL);

			cnt ++;
			m_film[ch]->AddToAveragingFrames();
		}
		m_fs[ch].Next();
	}
	m_film[ch]->FinishAveragingFrames( cnt, NULL );
	m_peak_finder[ch].SetFrame( w, h, m_film[ch]->m_frame, m_film[ch]->m_background, m_film[ch]->m_data_scaler );
	m_peak_finder[ch].SetRadius( m_peak_radius[ch] );
	m_peak_finder[ch].SetThreshold( m_peak_threshold[ch] );
	m_peak_finder[ch].DrawFrameAndPeaks( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < channel.h ; y++ )
		for ( UINT x = 0 ; x < channel.w ; x++ )
			m_channel_buffer[ch][ channel.w*y + x ] = m_frame_buffer[ w*y + channel.l[ch]+x ];

	UpdateFrame();
	return 0;
}

void CMovieMapperDialog::OnBnClickedLoadFsCh1()
{
	LoadFrameSequence(CH1);

    CWnd *pWnd = GetDlgItem(IDC_FSPATH1);
	if ( pWnd )
		((CEdit*)pWnd)->SetSel(0, -1);
}

void CMovieMapperDialog::OnBnClickedApplyFsCh1()
{
	ApplyFrameSequence(CH1);
}

void CMovieMapperDialog::OnBnClickedLoadFsCh2()
{
	LoadFrameSequence(CH2);
    CWnd *pWnd = GetDlgItem(IDC_FSPATH2);
	if ( pWnd )
		((CEdit*)pWnd)->SetSel(0, -1);
}

void CMovieMapperDialog::OnBnClickedApplyFsCh2()
{
	ApplyFrameSequence(CH2);
}


int CMovieMapperDialog::Copy(int id)
{
	int src = ( id == CH1 ) ? CH2 : CH1 ;
	int dest = id;

	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_peak_finder[id].Clear();
	if ( m_copy[id] )
	{
		memcpy( m_backup_frame[id], m_peak_finder[id].m_frame, sizeof(double)*w*h );
		for ( UINT y = 0 ; y < ch.h ; y++ )
			for ( UINT x = 0 ; x < ch.w ; x++ )
				m_peak_finder[dest].Frame( ch.l[dest]+x, y ) = m_peak_finder[src].Frame( ch.l[src]+x, y );
				//m_peak_finder[id].Frame( ch.l[dest]+x, y ) = m_peak_finder[id].Frame( ch.l[src]+x, y );
	}
	else
	{
		m_peak_finder[id].UpdateFrame( w, h, m_backup_frame[id] );
	}
//	m_peak_finder[id].MakeBackground(id);
//	m_peak_finder[id].DrawFrameAndPeaks( w, h, m_frame_buffer );
	m_peak_finder[id].DrawFrame( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[id][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[id]+x ];

	UpdateFrame();
	return 0;
}

int CMovieMapperDialog::Superpose(int id)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_peak_finder[id].Clear();
	if ( m_superpose[id] )
	{
		memcpy( m_backup_frame[id], m_peak_finder[id].m_frame, sizeof(double)*w*h );
		CMapping *map = &(m_superpose_mapping[id]);
		if ( map->m_is_mapping_ready && map->IsCompatible( w, h ) )
		{
			if ( id == CH1 )
			{
//				m_peak_finder[id].MakeBackground(CH2);
//				map->SuperposeOnto1( w, h, m_peak_finder[id].m_frame, m_peak_finder[id].m_bgnd, 
//									ch.l[CH2], 0, ch.w, ch.h );
				m_peak_finder[CH2].MakeBackground(CH2);
                map->SuperposeOnto1( w, h, m_peak_finder[CH1].m_frame, m_peak_finder[CH2].m_frame, m_peak_finder[CH2].m_bgnd, 
									ch.l[CH2], 0, ch.w, ch.h );

			}
			else if ( id == CH2 )
			{
//				m_peak_finder[id].MakeBackground(CH1);
//				map->SuperposeOnto2( w, h, m_peak_finder[id].m_frame, m_peak_finder[id].m_bgnd, 
//									ch.l[CH1], 0, ch.w, ch.h );
				m_peak_finder[CH1].MakeBackground(CH1);
                map->SuperposeOnto2( w, h, m_peak_finder[CH2].m_frame, m_peak_finder[CH1].m_frame, m_peak_finder[CH1].m_bgnd, 
									ch.l[CH1], 0, ch.w, ch.h );
			}
		}
		else
		{
			LogErr(_T("Superposition Failed: Invalid Mapping."));
		}
	}
	else
	{
		m_peak_finder[id].UpdateFrame( w, h, m_backup_frame[id] );
	}
//	m_peak_finder[id].MakeBackground(id);
//	m_peak_finder[id].DrawFrameAndPeaks( w, h, m_frame_buffer );
	m_peak_finder[id].DrawFrame( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[id][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[id]+x ];

	UpdateFrame();
	return 0;
}


void CMovieMapperDialog::OnBnClickedCopy1()
{
	UpdateData(TRUE);
	Copy(CH1);
}

void CMovieMapperDialog::OnBnClickedSuperpose1()
{
	UpdateData(TRUE);
	Superpose(CH1);
}

void CMovieMapperDialog::OnBnClickedSuperposeMap1()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	if( fileDlg.DoModal ()==IDOK )
	{
		CWnd *pWnd = GetDlgItem(IDC_MAPPING1);
		CMapping *map = &(m_superpose_mapping[CH1]);

		map->Load(fileDlg.GetPathName());
		if ( !map->m_is_mapping_ready )
			LogErr(Stringify(_T("Load Mapping File[%s] Failed."), fileDlg.GetPathName()));		

		SetUIs();
		UpdateData(FALSE);
	}
}
void CMovieMapperDialog::OnEnKillfocusPeakRadius1()
{
	double backup = m_peak_radius[CH1];
	UpdateData(TRUE);
	if ( m_peak_radius[CH1] <= 0 )	m_peak_radius[CH1] = backup;
	m_peak_radius[CH1] = LIMIT_DECIMAL_PLACES( m_peak_radius[CH1], 3 );
	UpdateData(FALSE);
}
void CMovieMapperDialog::OnEnKillfocusPeakThreshold1()
{
	double backup = m_peak_threshold[CH1];
	UpdateData(TRUE);
	if ( m_peak_threshold[CH1] <= 0 )	m_peak_threshold[CH1] = backup;
	m_peak_threshold[CH1] = LIMIT_DECIMAL_PLACES( m_peak_threshold[CH1], 3 );
	UpdateData(FALSE);
}

void CMovieMapperDialog::OnBnClickedFind1()
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_peak_finder[CH1].Clear();
	m_peak_finder[CH1].SetRadius(m_peak_radius[CH1]);
	m_peak_finder[CH1].SetThreshold(m_peak_threshold[CH1]);
	m_peak_finder[CH1].FindPeaks(CH1);
	m_peak_finder[CH1].DrawFrameAndPeaks( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[CH1][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[CH1]+x ];

	UpdateFrame();
	UpdateData(FALSE);

	int num_peaks = (int) m_peak_finder[CH1].m_peaks.GetCount();
	int num_good_peaks = 0;
	for ( int i = 0 ; i < num_peaks ; i++ )
		if ( m_peak_finder[CH1].m_peaks[i].IsGood() )	num_good_peaks++;

	LogMsg(_T("Info"), Stringify(_T("%d(%d) peaks in CH1"), num_good_peaks, num_peaks ) );
	return;
}

void CMovieMapperDialog::OnBnClickedBGFind1()
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_peak_finder[CH1].SetRadius(m_peak_radius[CH1]);
	m_peak_finder[CH1].SetThreshold(m_peak_threshold[CH1]);
	m_peak_finder[CH1].FindNotPeaks(CH1);
	m_peak_finder[CH1].DrawFrameAndNotPeaks( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[CH1][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[CH1]+x ];

	UpdateFrame();
	UpdateData(FALSE);

	int num_not_peaks = (int) m_peak_finder[CH1].m_not_peaks.GetCount();
	LogMsg(_T("Info"), Stringify(_T("%d not-peaks in CH1"), num_not_peaks ) );

	CString str = m_filepath[CH1];
	if ( !str.IsEmpty() )
	{
		int n;
		n = str.ReverseFind( (TCHAR)'.' );
		if ( n >= 0 )	str = str.Mid(0, n);
		str.AppendFormat(_T(".CH1.%s"), CAMERAFILE_BGPEAKS_EXT);

		CPeaksFileWriter writer;
		CArray<CPeakSet> peaks;        
		peaks.SetSize(0);
		for ( int i = 0 ; i < m_peak_finder[CH1].m_not_peaks.GetCount() ; i++ )
		{
			CPeakSet set;
			set.p[CH1] = m_peak_finder[CH1].m_not_peaks[i];
			peaks.Add(set);
		}
		writer.SetBGFilepath( str );
		writer.Write( m_frame_w, m_frame_h, &peaks );
		LogMsg(_T("Info"), Stringify(_T("These not-peaks were saved as [%s]"), writer.m_filepath) );
	}

	return;
}

void CMovieMapperDialog::OnBnClickedCopy2()
{
	UpdateData(TRUE);
	Copy(CH2);
}

void CMovieMapperDialog::OnBnClickedSuperpose2()
{
	UpdateData(TRUE);
	Superpose(CH2);
}

void CMovieMapperDialog::OnBnClickedSuperposeMap2()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	if( fileDlg.DoModal ()==IDOK )
	{
		CWnd *pWnd = GetDlgItem(IDC_MAPPING2);
		CMapping *map = &(m_superpose_mapping[CH2]);

		map->Load(fileDlg.GetPathName());
		if ( !map->m_is_mapping_ready )
			LogErr(Stringify(_T("Load Mapping File[%s] Failed."), fileDlg.GetPathName()));		

		SetUIs();
		UpdateData(FALSE);
	}
}
void CMovieMapperDialog::OnEnKillfocusPeakRadius2()
{
	double backup = m_peak_radius[CH2];
	UpdateData(TRUE);
	if ( m_peak_radius[CH2] <= 0 )	m_peak_radius[CH2] = backup;
	m_peak_radius[CH2] = LIMIT_DECIMAL_PLACES( m_peak_radius[CH2], 3 );
	UpdateData(FALSE);
}
void CMovieMapperDialog::OnEnKillfocusPeakThreshold2()
{
	double backup = m_peak_threshold[CH2];
	UpdateData(TRUE);
	if ( m_peak_threshold[CH2] <= 0 )	m_peak_threshold[CH2] = backup;
	m_peak_threshold[CH2] = LIMIT_DECIMAL_PLACES( m_peak_threshold[CH2], 3 );
	UpdateData(FALSE);
}
void CMovieMapperDialog::OnBnClickedFind2()
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_peak_finder[CH2].Clear();
	m_peak_finder[CH2].SetRadius(m_peak_radius[CH2]);
	m_peak_finder[CH2].SetThreshold(m_peak_threshold[CH2]);
	m_peak_finder[CH2].FindPeaks(CH2);
	m_peak_finder[CH2].DrawFrameAndPeaks( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[CH2][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[CH2]+x ];

	UpdateFrame();
	UpdateData(FALSE);

	int num_peaks = (int) m_peak_finder[CH2].m_peaks.GetCount();
	int num_good_peaks = 0;
	for ( int i = 0 ; i < num_peaks ; i++ )
		if ( m_peak_finder[CH2].m_peaks[i].IsGood() )	num_good_peaks++;

	LogMsg(_T("Info"), Stringify(_T("%d(%d) peaks in CH2"), num_good_peaks, num_peaks ) );
	return;
}

void CMovieMapperDialog::OnBnClickedBGFind2()
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	CChannels ch( w, h );

	m_peak_finder[CH2].SetRadius(m_peak_radius[CH2]);
	m_peak_finder[CH2].SetThreshold(m_peak_threshold[CH2]);
	m_peak_finder[CH2].FindNotPeaks(CH2);
	m_peak_finder[CH2].DrawFrameAndNotPeaks( w, h, m_frame_buffer );
	for ( UINT y = 0 ; y < ch.h ; y++ )
		for ( UINT x = 0 ; x < ch.w ; x++ )
			m_channel_buffer[CH2][ ch.w*y + x ] = m_frame_buffer[ w*y + ch.l[CH2]+x ];

	UpdateFrame();
	UpdateData(FALSE);

	int num_not_peaks = (int) m_peak_finder[CH2].m_not_peaks.GetCount();
	LogMsg(_T("Info"), Stringify(_T("%d not-peaks in CH2"), num_not_peaks ) );

	CString str = m_filepath[CH2];
	if ( !str.IsEmpty() )
	{
		int n;
		n = str.ReverseFind( (TCHAR)'.' );
		if ( n >= 0 )	str = str.Mid(0, n);
		str.AppendFormat(_T(".CH2.%s"), CAMERAFILE_BGPEAKS_EXT);

		CPeaksFileWriter writer;
		CArray<CPeakSet> peaks;        
		peaks.SetSize(0);
		for ( int i = 0 ; i < m_peak_finder[CH2].m_not_peaks.GetCount() ; i++ )
		{
			CPeakSet set;
			set.p[CH2] = m_peak_finder[CH2].m_not_peaks[i];
			peaks.Add(set);
		}
		writer.SetBGFilepath( str );
		writer.Write( m_frame_w, m_frame_h, &peaks );
		LogMsg(_T("Info"), Stringify(_T("These not-peaks were saved as [%s]"), writer.m_filepath) );
	}

	return;
}

void CMovieMapperDialog::OnBnClickedBadPeaks1()
{
	UpdateData(TRUE);
}

void CMovieMapperDialog::OnBnClickedBadPeaks2()
{
	UpdateData(TRUE);
}

void CMovieMapperDialog::OnBnClickedUseMap()
{
	UpdateData(TRUE);
	if ( m_use_old_map )	m_use_rough_map = FALSE;
	UpdateData(FALSE);
}

void CMovieMapperDialog::OnBnClickedOldMap()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	if( fileDlg.DoModal ()==IDOK )
	{
		CWnd *pWnd = GetDlgItem(IDC_MAPPING);
		CMapping *map = &(m_old_mapping);

		map->Load(fileDlg.GetPathName());
		if ( !map->m_is_mapping_ready )
			LogErr(Stringify(_T("Load Mapping File[%s] Failed."), fileDlg.GetPathName()));		

		SetUIs();
		UpdateData(FALSE);
	}
}

void CMovieMapperDialog::OnBnClickedUseRoughMap()
{
	UpdateData(TRUE);
	if ( m_use_rough_map )	m_use_old_map = FALSE;
	UpdateData(FALSE);
}

void CMovieMapperDialog::OnBnClickedPair1()
{
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		m_ppair[i] = &(m_pair1[i]);

	m_pair1_radio.SetCheck(BST_CHECKED);
	m_pair2_radio.SetCheck(BST_UNCHECKED);
	m_pair3_radio.SetCheck(BST_UNCHECKED);

	SetUIs();
	UpdateFrame();
	UpdateData(FALSE);    
}

void CMovieMapperDialog::OnBnClickedPair2()
{
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		m_ppair[i] = &(m_pair2[i]);

	m_pair2_radio.SetCheck(BST_CHECKED);
	m_pair1_radio.SetCheck(BST_UNCHECKED);
	m_pair3_radio.SetCheck(BST_UNCHECKED);

	SetUIs();
	UpdateFrame();
	UpdateData(FALSE);    
}

void CMovieMapperDialog::OnBnClickedPair3()
{
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		m_ppair[i] = &(m_pair3[i]);

	m_pair3_radio.SetCheck(BST_CHECKED);
	m_pair1_radio.SetCheck(BST_UNCHECKED);
	m_pair2_radio.SetCheck(BST_UNCHECKED);

	SetUIs();
	UpdateFrame();
	UpdateData(FALSE);    
}

void CMovieMapperDialog::OnEnKillfocusAllowableError()
{
	double backup = m_allowable_error;
	UpdateData(TRUE);
	m_allowable_error = LIMIT_DECIMAL_PLACES( m_allowable_error, 3 );
	if ( m_allowable_error < 0 )	m_allowable_error = backup;

	UpdateData(FALSE);
}

void CMovieMapperDialog::OnBnClickedMap()
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;
	CChannels ch( w, h );
	CMapping *map = NULL;

	if ( m_use_old_map )
	{
		map = &(m_old_mapping);
		if ( !map->m_is_mapping_ready || !map->IsCompatible( w, h ) )
		{
			LogErr(_T("This mapping is not valid."));
			return;
		}
	}
	else if ( m_use_rough_map )
	{
		int x1, y1, x2, y2;

		map = &(m_rough_mapping);
		map->Reset( w, h );

		x1 = m_pair1[CH1].x;
		y1 = m_pair1[CH1].y;
		x2 = m_pair1[CH2].x;
		y2 = m_pair1[CH2].y;
		if ( x1 >= 0 && y1 >= 0 && x2 >= 0 && y2 >= 0 )
            map->AddMappingPair( ch.l[CH1]+x1, y1, ch.l[CH2]+x2, y2 );

		x1 = m_pair2[CH1].x;
		y1 = m_pair2[CH1].y;
		x2 = m_pair2[CH2].x;
		y2 = m_pair2[CH2].y;
		if ( x1 >= 0 && y1 >= 0 && x2 >= 0 && y2 >= 0 )
            map->AddMappingPair( ch.l[CH1]+x1, y1, ch.l[CH2]+x2, y2 );

		x1 = m_pair3[CH1].x;
		y1 = m_pair3[CH1].y;
		x2 = m_pair3[CH2].x;
		y2 = m_pair3[CH2].y;
		if ( x1 >= 0 && y1 >= 0 && x2 >= 0 && y2 >= 0 )
            map->AddMappingPair( ch.l[CH1]+x1, y1, ch.l[CH2]+x2, y2 );

		if ( map->DoRoughMapping() < 0 )
		{
			LogErr(_T("Rough Mapping Failed."));
			map->Reset( 0, 0 );
			return;
		}
	}
	else
	{
		LogMsg(_T("Warning"), _T("Mapping method is not selected."));

		map = &(m_rough_mapping);
		map->Reset( w, h );
		map->m_rough_xcoeff1[0] = -1.0*ch.w;
		map->m_rough_xcoeff2[0] = 1.0*ch.w;

	}

	UINT16 *pkmap1 = new UINT16[ ch.w*ch.h ];
	UINT16 *pkmap2 = new UINT16[ ch.w*ch.h ];
	CArray<CPeak> cpeaks;
	cpeaks.SetSize(0);

	// CH2 peaks onto CH1
	memset( pkmap1, 0, sizeof(UINT16)*ch.w*ch.h );
	for ( int i = 0 ; i < m_peak_finder[CH2].m_peaks.GetCount(); i++ )
	{
		CPeak *p = &( m_peak_finder[CH2].m_peaks[i] );
		if ( m_allow_bad_peaks2 != TRUE && p->IsGood() != TRUE )	continue;
		//if ( p->IsGood() != TRUE )	continue;

		int x1 = (int) ( map->X1( p->x, p->y ) + 0.5 );
		int y1 = (int) ( map->Y1( p->x, p->y ) + 0.5 );
		if ( x1 < (int)ch.l[CH1] || (int)ch.r[CH1] < x1 || y1 < 0 || y1 >= (int)ch.h )	continue;

		pkmap1[ ch.w*y1 + x1 ] = (i+1);
	}

	// CH1 peaks onto CH2
	memset( pkmap2, 0, sizeof(UINT16)*ch.w*ch.h );
	for ( int i = 0 ; i < m_peak_finder[CH1].m_peaks.GetCount(); i++ )
	{
		CPeak *p = &( m_peak_finder[CH1].m_peaks[i] );
		if ( m_allow_bad_peaks1 != TRUE && p->IsGood() != TRUE )	continue;
//		if ( p->IsGood() != TRUE )	continue;

		int x2 = (int) ( map->X2( p->x, p->y ) + 0.5 );
		int y2 = (int) ( map->Y2( p->x, p->y ) + 0.5 );
		if ( x2 < (int)ch.l[CH2] || (int)ch.r[CH2] < x2 || y2 < 0 || y2 >= (int)ch.h )	continue;

		int xi = (int) ( p->x - m_allowable_error + 0.5 ) - ch.l[CH1];
		int xf = (int) ( p->x + m_allowable_error + 0.5 ) - ch.l[CH1];
		int yi = (int) ( p->y - m_allowable_error + 0.5 );
		int yf = (int) ( p->y + m_allowable_error + 0.5 );
		if ( xi < 0 )			xi = 0;
		if ( xf >= (int)ch.w )	xf = ch.w - 1;
		if ( yi < 0 )			yi = 0;
		if ( yf >= (int)ch.h )	yf = ch.h - 1;

		double cp_dist = m_allowable_error;
		CPeak *cp = NULL;
		for ( int x = xi ; x <= xf ; x++ )
		{
			for ( int y = yi ; y <= yf ; y++ )
			{
				UINT cp_idx = pkmap1[ ch.w*y + x ];
				if ( cp_idx < 1 )	continue;

				CPeak *temp = &( m_peak_finder[CH2].m_peaks[cp_idx-1] );
				double dist = sqrt( SQR(p->x - map->X1(temp->x, temp->y)) + SQR(p->y - map->Y1(temp->x, temp->y)) );
				if ( dist < cp_dist )
				{
					cp = temp;
					cp_dist = dist;
				}				
			}
		}
		if ( cp == NULL )	continue;

		CPeak chosen = *cp;
		cpeaks.Add(chosen);
		pkmap2[ ch.w*y2 + x2 ] = (i+1);
	}

	// Chosen CH2 peaks...
	m_peaks.SetSize(0);
	m_new_mapping.Reset( w, h );
	for ( int i = 0 ; i < cpeaks.GetCount() ; i++ )
	{
		CPeak *cp = &( cpeaks[i] );
		if ( m_allow_bad_peaks2 != TRUE && cp->IsGood() != TRUE )	continue;
//		if ( cp->IsGood() != TRUE )	continue;

		int xi = (int) ( cp->x - m_allowable_error + 0.5 ) - ch.l[CH2];
		int xf = (int) ( cp->x + m_allowable_error + 0.5 ) - ch.l[CH2];
		int yi = (int) ( cp->y - m_allowable_error + 0.5 );
		int yf = (int) ( cp->y + m_allowable_error + 0.5 );
		if ( xi < 0 )			xi = 0;
		if ( xf >= (int)ch.w )	xf = ch.w - 1;
		if ( yi < 0 )			yi = 0;
		if ( yf >= (int)ch.h )	yf = ch.h - 1;

		double p_dist = m_allowable_error;
		CPeak *p = NULL;
		for ( int x = xi ; x <= xf ; x++ )
		{
			for ( int y = yi ; y <= yf ; y++ )
			{
				UINT p_idx = pkmap2[ ch.w*y + x ];
				if ( p_idx < 1 )	continue;

				CPeak *temp = &( m_peak_finder[CH1].m_peaks[p_idx-1] );
				double dist = sqrt( SQR(cp->x - map->X2(temp->x, temp->y)) + SQR(cp->y - map->Y2(temp->x, temp->y)) );
				if ( dist < p_dist )
				{
					p = temp;
					p_dist = dist;
				}				
			}
		}
		if ( p == NULL )	continue;

		CPeakSet set;
		set.p[CH1] = *p;
		set.p[CH2] = *cp;
		m_peaks.Add(set);
		m_new_mapping.AddMappingPair( p->x, p->y, cp->x, cp->y );
	}
	delete [] pkmap1;
	delete [] pkmap2;



	int num_all_peaks1 = (int) m_peak_finder[CH1].m_peaks.GetCount();
	int num_all_peaks2 = (int) m_peak_finder[CH2].m_peaks.GetCount();
	int num_good_peaks1 = 0;
	int num_good_peaks2 = 0;
	for ( int i = 0 ; i < num_all_peaks1 ; i++ )
		if ( m_peak_finder[CH1].m_peaks[i].IsGood() )	num_good_peaks1++;
	for ( int i = 0 ; i < num_all_peaks2 ; i++ )
		if ( m_peak_finder[CH2].m_peaks[i].IsGood() )	num_good_peaks2++;


	if ( m_filepath[CH1].Compare( m_filepath[CH2] ) == 0 )
	{
		LogMsg(_T("Info"), Stringify(_T("Overlap : CH1[ %3d / %3d(%3d) ] & CH2[ %3d / %3d(%3d)] in [%s]"), 
									m_peaks.GetCount(), num_good_peaks1, num_all_peaks1,  
									m_peaks.GetCount(), num_good_peaks2, num_all_peaks2, 
									m_filepath[CH1]) );
	}
	else
	{
		LogMsg(_T("Info"), Stringify(_T("Overlap : CH1[ %3d / %3d(%3d) ] & CH2[ %3d / %3d(%3d)] in CH1[%s] & CH2[%s]"), 
									m_peaks.GetCount(), num_good_peaks1, num_all_peaks1,  
									m_peaks.GetCount(), num_good_peaks2, num_all_peaks2, 
									m_filepath[CH1], m_filepath[CH2])  );
	}

	m_new_mapping.DoMapping();

	// Draw Superposed CH1 & CH2
	double *superposed1 = new double[w*h];
	double *superposed2 = new double[w*h];
	memset( superposed1, 0, sizeof(double)*w*h );
	memset( superposed2, 0, sizeof(double)*w*h );
	for ( int i = 0 ; i < m_peak_finder[CH1].m_peaks.GetCount(); i++ )
	{
		int range = (int) ceil( m_peak_radius[CH1] );
		double r = m_peak_radius[CH1];
		double xo1 = m_peak_finder[CH1].m_peaks[i].x;
		double yo1 = m_peak_finder[CH1].m_peaks[i].y;
		double f = 1.0;
		if ( m_peak_finder[CH1].m_peaks[i].IsGood() != TRUE )
			f = 0.5;

		for ( int x = -range ; x <= range ; x++ )
		{
			for ( int y = -range ; y <= range ; y++ )
			{
				int x1 = (int) ( xo1 + 0.5 ) + x ;
				int y1 = (int) ( yo1 + 0.5 ) + y ;
				//double f = exp( -0.5 * ( SQR( x1-xo1 ) + SQR( y1-yo1 ) )/SQR(sigma) );
				
				if ( !CCircle::in( x1-xo1, y1-yo1, r ) )	continue;

				superposed1[ w*y1 + x1 ] += f;

				double x2 = map->X2( x1, y1 );
				double y2 = map->Y2( x1, y1 );
				int ox = (int) ( x2 + 0.5 );
				int oy = (int) ( y2 + 0.5 );
				int px = ( x2 > ox ) ? ox+1 : ox-1;
				int py = ( y2 > oy ) ? oy+1 : oy-1;
				BOOL ox_ok = ( 0 <= ox && ox < (int)w );
				BOOL oy_ok = ( 0 <= oy && oy < (int)h );
				BOOL px_ok = ( 0 <= px && px < (int)w );
				BOOL py_ok = ( 0 <= py && py < (int)h );
				if ( ox_ok && oy_ok )	superposed1[ w*oy + ox ] += fabs((x2-px)*(y2-py)) * f;
				if ( ox_ok && py_ok )	superposed1[ w*py + ox ] += fabs((x2-px)*(y2-oy)) * f;
				if ( px_ok && oy_ok )	superposed1[ w*oy + px ] += fabs((x2-ox)*(y2-py)) * f;
				if ( px_ok && py_ok )	superposed1[ w*py + px ] += fabs((x2-ox)*(y2-oy)) * f;
			}
		}
	}
	for ( int i = 0 ; i < m_peak_finder[CH2].m_peaks.GetCount(); i++ )
	{
		int range = (int) ceil( m_peak_radius[CH2] );
		double r = m_peak_radius[CH2];
		double xo2 = m_peak_finder[CH2].m_peaks[i].x;
		double yo2 = m_peak_finder[CH2].m_peaks[i].y;
		double f = 1.0;
		if ( m_peak_finder[CH2].m_peaks[i].IsGood() != TRUE )
			f = 0.5;

		for ( int x = -range ; x <= range ; x++ )
		{
			for ( int y = -range ; y <= range ; y++ )
			{
				int x2 = (int) ( xo2 + 0.5 ) + x ;
				int y2 = (int) ( yo2 + 0.5 ) + y ;
				//double f = exp( -0.5 * ( SQR( x2-xo2 ) + SQR( y2-yo2 ) )/SQR(sigma) );

				if ( !CCircle::in( x2-xo2, y2-yo2, r ) )	continue;

				superposed2[ w*y2 + x2 ] += f;

				double x1 = map->X1( x2, y2 );
				double y1 = map->Y1( x2, y2 );
				int ox = (int) ( x1 + 0.5 );
				int oy = (int) ( y1 + 0.5 );
				int px = ( x1 > ox ) ? ox+1 : ox-1;
				int py = ( y1 > oy ) ? oy+1 : oy-1;
				BOOL ox_ok = ( 0 <= ox && ox < (int)w );
				BOOL oy_ok = ( 0 <= oy && oy < (int)h );
				BOOL px_ok = ( 0 <= px && px < (int)w );
				BOOL py_ok = ( 0 <= py && py < (int)h );
				if ( ox_ok && oy_ok )	superposed2[ w*oy + ox ] += fabs((x1-px)*(y1-py)) * f;
				if ( ox_ok && py_ok )	superposed2[ w*py + ox ] += fabs((x1-px)*(y1-oy)) * f;
				if ( px_ok && oy_ok )	superposed2[ w*oy + px ] += fabs((x1-ox)*(y1-py)) * f;
				if ( px_ok && py_ok )	superposed2[ w*py + px ] += fabs((x1-ox)*(y1-oy)) * f;
			}
		}
	}

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		memset( m_channel_buffer[i], 0, sizeof(COLORREF)*ch.w*ch.h );
        for ( int y = 0 ; y < (int)ch.h ; y++ )
		{
			for ( int x = 0 ; x < (int)ch.w ; x++ )
			{
				double i1 = 196 * superposed1[ w*y + ch.l[i]+x ];
				double i2 = 196 * superposed2[ w*y + ch.l[i]+x ];
				if ( i1 > 255 )	i1 = 255;
				if ( i2 > 255 ) i2 = 255;
				m_channel_buffer[i][ ch.w*y + x ] += ProgramColor1( CH1, (UINT8)i1 );
				m_channel_buffer[i][ ch.w*y + x ] += ProgramColor1( CH2, (UINT8)i2 );
			}
		}
	}
	delete [] superposed1;
	delete [] superposed2;

/*
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		for ( int k = 0 ; k < m_peak_finder[i].m_peaks.GetCount(); k++ )
		{
			CPeak *p = &( m_peak_finder[i].m_peaks[k] );
			int range = CCircle::range( m_peak_finder[i].m_radius );	  
			int orgx = (int) (p->x + 0.5) - ch.l[i];
			int orgy = (int) (p->y + 0.5);
			for ( int x = -range ; x <= range ; x++ )
			{
				for ( int y = -range ; y <= range ; y++ )
				{
					if ( CCircle::online( x, y, m_peak_finder[i].m_radius) == FALSE )	continue;
					if ( orgx+x < 0 || (int)ch.w <= orgx+x || orgy+y < 0 || (int)ch.h <= orgy+y )	continue;
					m_channel_buffer[i][ ch.w*(orgy+y) + orgx+x ] = RGBReverse( 0, 0, 255 ) ;
				}
			}
		}
	}
*/

	for ( int i = 0 ; i < m_peaks.GetCount() ; i++ )
	{
		CPeak *p1 = &( m_peaks[i].p[CH1] );
		CPeak *p2 = &( m_peaks[i].p[CH2] );

		int range, orgx, orgy;
		
		range = CCircle::range( m_peak_finder[CH1].m_radius );
		orgx = (int) (p1->x + 0.5) - ch.l[CH1];
		orgy = (int) (p1->y + 0.5);
		for ( int x = -range ; x <= range ; x++ )
		{
			for ( int y = -range ; y <= range ; y++ )
			{
				if ( CCircle::online( orgx+x+ch.l[CH1]-p1->x, orgy+y-p1->y, m_peak_finder[CH1].m_radius) == FALSE )	continue;
				if ( orgx+x < 0 || (int)ch.w <= orgx+x || orgy+y < 0 || (int)ch.h <= orgy+y )	continue;
				m_channel_buffer[CH1][ ch.w*(orgy+y) + orgx+x ] = RGBReverse( 255, 255, 255 ) ;
			}
		}

		range = CCircle::range( m_peak_finder[CH2].m_radius );
		orgx = (int) (p2->x + 0.5) - ch.l[CH2];
		orgy = (int) (p2->y + 0.5);
		for ( int x = -range ; x <= range ; x++ )
		{
			for ( int y = -range ; y <= range ; y++ )
			{
				if ( CCircle::online( orgx+x+ch.l[CH2]-p2->x, orgy+y-p2->y, m_peak_finder[CH2].m_radius) == FALSE )	continue;
				if ( orgx+x < 0 || (int)ch.w <= orgx+x || orgy+y < 0 || (int)ch.h <= orgy+y )	continue;
				m_channel_buffer[CH2][ ch.w*(orgy+y) + orgx+x ] = RGBReverse( 255, 255, 255 ) ;
			}
		}
	}

	UpdateFrame();
	return;
}

void CMovieMapperDialog::OnBnClickedSave()
{
	CString szFilters;
	szFilters.Format(_T("Mapping File (*.txt)|*.txt|"
						"Peaks File (*.%s)|*.%s|"
						"All Files (*.*)|*.*||"),
						CAMERAFILE_PEAKS_EXT, CAMERAFILE_PEAKS_EXT);
	CFileDialog fileDlg(FALSE, NULL, NULL, OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	//fileDlg.m_ofn.lpstrDefExt = CAMERAFILE_PEAKS_EXT;
	fileDlg.m_ofn.lpstrDefExt = _T("txt");
	if ( fileDlg.DoModal ()!=IDOK )	return;

	CString ext = fileDlg.GetFileExt();
	if ( ext.CompareNoCase( CAMERAFILE_PEAKS_EXT ) == 0 )
	{
		CPeaksFileWriter writer;
		writer.SetFilepath( fileDlg.GetPathName() );
		writer.Write( m_frame_w, m_frame_h, &m_peaks );
		m_peak_finder[CH1].SaveSnapshot( m_filepath[CH1], _T("CH1") );
		m_peak_finder[CH2].SaveSnapshot( m_filepath[CH2], _T("CH2") );
		LogMsg(_T("Info"), Stringify(_T("Mapped peaks were saved as [%s]"), writer.m_filepath) );
	}
	else
	{
		if ( m_new_mapping.m_is_mapping_ready != TRUE )
		{
			int yesno = MessageBox(_T("Only rough mapping is available.\r\nAre you okay with the rough mapping?"), _T(""), MB_YESNO);
			if ( yesno != IDYES )	return;

			int x1, y1, x2, y2;
			CChannels ch( m_frame_w, m_frame_h );
			m_new_mapping.Reset( m_frame_w, m_frame_h );
			
			x1 = m_pair1[CH1].x;
			y1 = m_pair1[CH1].y;
			x2 = m_pair1[CH2].x;
			y2 = m_pair1[CH2].y;
			m_new_mapping.AddMappingPair( ch.l[CH1]+x1, y1, ch.l[CH2]+x2, y2 );

            x1 = m_pair2[CH1].x;
			y1 = m_pair2[CH1].y;
			x2 = m_pair2[CH2].x;
			y2 = m_pair2[CH2].y;
			m_new_mapping.AddMappingPair( ch.l[CH1]+x1, y1, ch.l[CH2]+x2, y2 );

			x1 = m_pair3[CH1].x;
			y1 = m_pair3[CH1].y;
			x2 = m_pair3[CH2].x;
			y2 = m_pair3[CH2].y;
			m_new_mapping.AddMappingPair( ch.l[CH1]+x1, y1, ch.l[CH2]+x2, y2 );

			m_new_mapping.DoRoughMapping();
            m_new_mapping.UseRoughMapping(m_allowable_error);
		}
		m_new_mapping.Save(fileDlg.GetPathName());
	}

	return;
}


void CMovieMapperDialog::OnDeltaposSpinr1(NMHDR *pNMHDR, LRESULT *pResult)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;
	CChannels ch( w, h );

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_spot_radius++;
	else	m_spot_radius--;

	int max_radius = ( ch.w < h ) ? (ch.w/2-1) : (h/2-1);
	if ( m_spot_radius > max_radius )	m_spot_radius = max_radius;
	if ( m_spot_radius < 1 )	m_spot_radius = 1;

	UpdateFrame();
	*pResult = 0;
}

void CMovieMapperDialog::OnDeltaposSpinr2(NMHDR *pNMHDR, LRESULT *pResult)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;
	CChannels ch( w, h );

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_spot_radius++;
	else	m_spot_radius--;

	int max_radius = ( ch.w < h ) ? (ch.w/2-1) : (h/2-1);
	if ( m_spot_radius > max_radius )	m_spot_radius = max_radius;
	if ( m_spot_radius < 1 )	m_spot_radius = 1;

	UpdateFrame();
	*pResult = 0;
}

void CMovieMapperDialog::OnDeltaposSpinx1(NMHDR *pNMHDR, LRESULT *pResult)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;
	CChannels ch( w, h );

	int x = m_ppair[CH1]->x;
	int y = m_ppair[CH1]->y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	x++;
	else	x--;

	if ( x < 0 )	x = 0;
	if ( x >= (int)ch.w )	x = ch.w-1;
	m_ppair[CH1]->x = x;

	UpdateFrame();
	*pResult = 0;
}

void CMovieMapperDialog::OnDeltaposSpiny1(NMHDR *pNMHDR, LRESULT *pResult)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;

	int x = m_ppair[CH1]->x;
	int y = m_ppair[CH1]->y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	y--;
	else	y++;

	if ( y < 0 )	y = 0;
	if ( y >= (int)h )	y = h-1;
	m_ppair[CH1]->y = y;

	UpdateFrame();
	*pResult = 0;
}

void CMovieMapperDialog::OnDeltaposSpinx2(NMHDR *pNMHDR, LRESULT *pResult)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;
	CChannels ch( w, h );

	int x = m_ppair[CH2]->x;
	int y = m_ppair[CH2]->y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	x++;
	else	x--;

	if ( x < 0 )	x = 0;
	if ( x >= (int)ch.w )	x = ch.w-1;
	m_ppair[CH2]->x = x;

	UpdateFrame();
	*pResult = 0;
}

void CMovieMapperDialog::OnDeltaposSpiny2(NMHDR *pNMHDR, LRESULT *pResult)
{
	UINT w = m_frame_w;
	UINT h = m_frame_h;
	if ( w == 0 || h == 0 )	return;

	int x = m_ppair[CH2]->x;
	int y = m_ppair[CH2]->y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	y--;
	else	y++;

	if ( y < 0 )	y = 0;
	if ( y >= (int)h )	y = h-1;
	m_ppair[CH2]->y = y;

	UpdateFrame();
	*pResult = 0;
}

