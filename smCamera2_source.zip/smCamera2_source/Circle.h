#pragma once
#include "math.h"

class CCircle
{
public:
	inline static double pi()
		{	return 3.14159265;	}
	inline static int range(double r)
		{	return 1 + (int)( ( r <= 0.5 ) ? 0 : ceil( r - 0.5 ) );	}
	inline static int extended_range(double r)
		{	return 	(int) ceil( 3.0 * r / 2 );	}	// At least, 3.0 / 2 > sqrt(2*pi) / 2
	inline static BOOL in(double x, double y, double r)
		{	return ( SQR(x)+SQR(y) <= SQR(r) );		}
	inline static BOOL on(double x, double y, double r)
		{	return in( x, y, r + 0.5 * sqrt(2.0) );	}

	static BOOL online(double x, double y, double r)
	{
		int cnt = 0;
		if ( sqrt( SQR(x-0.5) + SQR(y-0.5) ) < r )	cnt++;
		if ( sqrt( SQR(x-0.5) + SQR(y+0.5) ) < r )	cnt++;
		if ( sqrt( SQR(x+0.5) + SQR(y-0.5) ) < r )	cnt++;
		if ( sqrt( SQR(x+0.5) + SQR(y+0.5) ) < r )	cnt++;
		if ( 0 < cnt && cnt < 4 )	return TRUE;
		return FALSE;
	}
};