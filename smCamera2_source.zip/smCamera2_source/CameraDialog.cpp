// CameraDialog.cpp : implementation file
//

#include "stdafx.h"
#include "smCamera.h"
#include "CameraDialog.h"


#define CAMERADIALOG_STATUS_UPDATE_INTERVAL	(1000)	//in milli-sec
static CCameraDialog *g_cameraDlg = NULL;
static VOID CALLBACK MyCameraTimerProc( 
    HWND hwnd,        // handle to window for timer messages 
    UINT message,     // WM_TIMER message 
    UINT idTimer,     // timer identifier 
    DWORD dwTime)     // current system time 
{ 
	if ( g_cameraDlg )	g_cameraDlg->UpdateStatus();
} 

// CCameraDialog dialog

IMPLEMENT_DYNAMIC(CCameraDialog, CDialog)
CCameraDialog::CCameraDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CCameraDialog::IDD, pParent)
	, m_is_fan_on(FALSE)
	, m_is_cooler_on(FALSE)
	, m_temperature(0)
	, m_image_left(0)
	, m_image_right(0)
	, m_image_bottom(0)
	, m_image_top(0)
	, m_num_pixels_to_bin(0)
	, m_h_flip(FALSE)
	, m_v_flip(FALSE)
	, m_rotate0(FALSE)
	, m_rotate90(FALSE)
	, m_rotate270(FALSE)
{
}

CCameraDialog::~CCameraDialog()
{
}


BOOL CCameraDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	g_cameraDlg = this;
	m_was_acquiring = !g_camera.m_is_acquiring;//strange....

	LogMsg(_T("Info"), _T("Initializing Camera...") );	
	LogFlush();
	g_camera.CameraInit();

	CString str = GetProgramFilePath( _PATH_CAMERA, _T("camera.save") );
	g_camera.CameraLoad( str );



	UpdateData(FALSE);
	
	KillTimer(CAMERADIALOG_TIMER);
	SetTimer(
		CAMERADIALOG_TIMER ,					// timer identifier 
		CAMERADIALOG_STATUS_UPDATE_INTERVAL ,	// interval 
		(TIMERPROC)	MyCameraTimerProc );		// my timer callback 

	return TRUE;
}

void CCameraDialog::OnCancel()
{
	DestroyWindow();
}

void CCameraDialog::OnOK()
{
	SetFocus();
	return;
}

void CCameraDialog::OnDestroy()
{
	g_cameraDlg = NULL;
	KillTimer(CAMERADIALOG_TIMER);

	CString str = GetProgramFilePath( _PATH_CAMERA, _T("camera.save") );
	g_camera.CameraSave( str );

	CDialog::OnDestroy();
}


void CCameraDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_HSPEED_COMBO, m_hspeed_combo);
	DDX_Control(pDX, IDC_VSPEED_COMBO, m_vspeed_combo);

	DDX_Check(pDX, IDC_FAN_ONOFF, m_is_fan_on);
	DDX_Check(pDX, IDC_COOLER_ONOFF, m_is_cooler_on);
	DDX_Text(pDX, IDC_TEMPERATURE_EDIT, m_temperature);

	DDX_Text(pDX, IDC_IMAGE_LEFT, m_image_left);
	DDX_Text(pDX, IDC_IMAGE_RIGHT, m_image_right);
	DDX_Text(pDX, IDC_IMAGE_BOTTOM, m_image_bottom);
	DDX_Text(pDX, IDC_IMAGE_TOP, m_image_top);
	DDX_Text(pDX, IDC_BINNING_EDIT, m_num_pixels_to_bin);
	DDX_Check(pDX, IDC_H_FLIP, m_h_flip);
	DDX_Check(pDX, IDC_V_FLIP, m_v_flip);
	DDX_Radio(pDX, IDC_ROTATE0, m_rotate0);
	DDX_Radio(pDX, IDC_ROTATE90, m_rotate90);
	DDX_Radio(pDX, IDC_ROTATE270, m_rotate270);
}


BEGIN_MESSAGE_MAP(CCameraDialog, CDialog)
	ON_WM_DESTROY()
	ON_CBN_SELENDOK(IDC_HSPEED_COMBO, OnCbnSelendokHSpeedCombo)
	ON_CBN_SELENDOK(IDC_VSPEED_COMBO, OnCbnSelendokVSpeedCombo)
	ON_BN_CLICKED(IDC_FAN_ONOFF, OnBnClickedFanOnoff)
	ON_BN_CLICKED(IDC_COOLER_ONOFF, OnBnClickedCoolerOnoff)
	ON_EN_KILLFOCUS(IDC_TEMPERATURE_EDIT, OnEnKillfocusTemperatureEdit)
	ON_EN_KILLFOCUS(IDC_IMAGE_LEFT, OnEnKillfocusImageLeft)
	ON_EN_KILLFOCUS(IDC_IMAGE_RIGHT, OnEnKillfocusImageRight)
	ON_EN_KILLFOCUS(IDC_IMAGE_BOTTOM, OnEnKillfocusImageBottom)
	ON_EN_KILLFOCUS(IDC_IMAGE_TOP, OnEnKillfocusImageTop)
	ON_EN_KILLFOCUS(IDC_BINNING_EDIT, OnEnKillfocusBinningEdit)
	ON_BN_CLICKED(IDC_H_FLIP, OnBnClickedHFlip)
	ON_BN_CLICKED(IDC_V_FLIP, OnBnClickedVFlip)
	ON_BN_CLICKED(IDC_ROTATE0, OnBnClickedRotate0)
	ON_BN_CLICKED(IDC_ROTATE90, OnBnClickedRotate90)
	ON_BN_CLICKED(IDC_ROTATE270, OnBnClickedRotate270)
END_MESSAGE_MAP()

// CCameraDialog message handlers

void CCameraDialog::UpdateStatus()
{
	CWnd *pWnd;
	CString str;

	BOOL init = g_camera.m_is_initialized;
	BOOL acq = g_camera.m_is_acquiring;

	if ( init && !acq )
	{
        int temp;
		g_camera.GetTemperature(&temp);

		pWnd = GetDlgItem(IDC_TEMPERATURE);
		str.Format(_T("%d"), temp);
		if ( pWnd )	pWnd->SetWindowText(str);

		pWnd = GetDlgItem(IDC_SET_TEMPERATURE);
		str.Format(_T("%d"), g_camera.m_set_temperature);
		if ( pWnd )	pWnd->SetWindowText(str);

		pWnd = GetDlgItem(IDC_TEMPERATURE_STATUS);
		if ( pWnd )	pWnd->SetWindowText(g_camera.m_temperature_control_status);
	}

	if ( m_was_acquiring == g_camera.m_is_acquiring )	return;



	pWnd = GetDlgItem(IDC_CAMERA_NAME);
	if ( pWnd )	pWnd->SetWindowText( (init) ? g_camera.m_name : _T("N/A") );
	pWnd = GetDlgItem(IDC_INTERFACE);
	if ( pWnd )	pWnd->SetWindowText( (init) ? g_camera.m_interface : _T("N/A") );
	pWnd = GetDlgItem(IDC_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_physical_h_pixels, g_camera.m_num_physical_v_pixels );
	if ( pWnd )	pWnd->SetWindowText( str );
	pWnd = GetDlgItem(IDC_PIXEL_SIZE);
	str.Format(_T("%.1f um x %.1f um"), g_camera.m_physical_pixel_height, g_camera.m_physical_pixel_width );
	if ( pWnd )	pWnd->SetWindowText( str );
	pWnd = GetDlgItem(IDC_BIT_DEPTH);
	str.Format(_T("%d Bit"), g_camera.m_bit_depth);
	if ( pWnd )	pWnd->SetWindowText( str );
	pWnd = GetDlgItem(IDC_MAX_NUM_BUFFERED_IMAGES);
	str.Format(_T("%d Images"), g_camera.m_buffer_size);
	if ( pWnd )	pWnd->SetWindowText( str );

	pWnd = GetDlgItem(IDC_STATUS);
	if ( pWnd )
	{
		if ( !init )	
			pWnd->SetWindowText(_T("Camera initialization failed."));
		else if ( acq )	
			pWnd->SetWindowText(_T("Acquisition in progress."));
		else	
			pWnd->SetWindowText(_T("Camera is idle."));
	}

	if ( init && !acq )
	{
		m_hspeed_combo.ResetContent();
		double speed;
		CString speed_text;
		int num=0;
		g_camera.GetNumberHSpeeds(&num);
		for ( int i = 0 ; i < num ; i++ )
		{
			if ( g_camera.GetHSpeed(i, &speed) >= 0 )
				speed_text.Format(_T("%d. %.3f MHz"), i, speed);
			else
				speed_text.Format(_T("%d. N/A"), i);
			
            m_hspeed_combo.InsertString( i, speed_text );
		}
		m_hspeed_combo.SetCurSel( g_camera.m_hspeed );
	}
	m_hspeed_combo.EnableWindow( init && !acq );

	if ( init && !acq )
	{
		m_vspeed_combo.ResetContent();
		double speed;
		CString speed_text;
		int num=0;
		g_camera.GetNumberVSpeeds(&num);
		for ( int i = 0 ; i < num ; i++ )
		{
			if ( g_camera.GetVSpeed(i, &speed) >= 0 )
				speed_text.Format(_T("%d. %.1f us"), i, speed);
			else
				speed_text.Format(_T("%d. N/A"), i);
			
            m_vspeed_combo.InsertString( i, speed_text );
		}
		m_vspeed_combo.SetCurSel( g_camera.m_vspeed );
	}
	m_vspeed_combo.EnableWindow( init && !acq );


	m_is_fan_on = init && g_camera.m_is_fan_on;
	pWnd = GetDlgItem(IDC_FAN_ONOFF);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	m_is_cooler_on = init && g_camera.m_is_cooler_on;
	pWnd = GetDlgItem(IDC_COOLER_ONOFF);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );

    pWnd = GetDlgItem(IDC_TEMPERATURE_RANGE);
	str.Format(_T("( %d 'C ~ %d 'C )"), g_camera.m_min_temperature, g_camera.m_max_temperature );
	if ( pWnd )	pWnd->SetWindowText( str );
	m_temperature = g_camera.m_set_temperature;
	pWnd = GetDlgItem(IDC_TEMPERATURE_EDIT);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );


	m_image_left = g_camera.m_image_left;
	pWnd = GetDlgItem(IDC_IMAGE_LEFT);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	m_image_right = g_camera.m_image_right;
	pWnd = GetDlgItem(IDC_IMAGE_RIGHT);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	m_image_bottom = g_camera.m_image_bottom;
	pWnd = GetDlgItem(IDC_IMAGE_BOTTOM);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	m_image_top = g_camera.m_image_top;
	pWnd = GetDlgItem(IDC_IMAGE_TOP);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );

	m_num_pixels_to_bin = g_camera.m_num_h_pixels_to_bin;
	pWnd = GetDlgItem(IDC_BINNING_EDIT);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	m_h_flip = g_camera.m_h_flip;
	pWnd = GetDlgItem(IDC_H_FLIP);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	m_v_flip = g_camera.m_v_flip;
	pWnd = GetDlgItem(IDC_V_FLIP);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );

	m_rotate0 = m_rotate90 = m_rotate270 = TRUE;
	if ( g_camera.m_rotate == 1 )	
		m_rotate90 = FALSE;
	else if ( g_camera.m_rotate == -1 )	
		m_rotate270 = FALSE;
	else	
		m_rotate0 = FALSE;
	pWnd = GetDlgItem(IDC_ROTATE0);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	pWnd = GetDlgItem(IDC_ROTATE90);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );
	pWnd = GetDlgItem(IDC_ROTATE270);
	if ( pWnd )	pWnd->EnableWindow( init && !acq );

	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	m_was_acquiring = g_camera.m_is_acquiring;
	return;
}

void CCameraDialog::OnCbnSelendokHSpeedCombo()
{
	UpdateData(TRUE);
	int index = m_hspeed_combo.GetCurSel();
	g_camera.SetHSpeed( index  );
	return;
}

void CCameraDialog::OnCbnSelendokVSpeedCombo()
{
	UpdateData(TRUE);
	int index = m_vspeed_combo.GetCurSel();
	g_camera.SetVSpeed( index  );
	return;
}

void CCameraDialog::OnBnClickedFanOnoff()
{
	UpdateData(TRUE);
	m_is_fan_on = !m_is_fan_on;
	g_camera.FanOnOff(m_is_fan_on);
	UpdateData(FALSE);
}
void CCameraDialog::OnBnClickedCoolerOnoff()
{
	UpdateData(TRUE);
	m_is_cooler_on = !m_is_cooler_on;
	g_camera.CoolerOnOff(m_is_cooler_on);
	UpdateData(FALSE);
}

void CCameraDialog::OnEnKillfocusTemperatureEdit()
{
	UpdateData(TRUE);
	g_camera.SetTemperature(m_temperature);
}


void CCameraDialog::OnEnKillfocusImageLeft()
{
	UpdateData(TRUE);
	g_camera.SetImagingArea( m_image_left, m_image_right, m_image_bottom, m_image_top );

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}
void CCameraDialog::OnEnKillfocusImageRight()
{
	UpdateData(TRUE);
	g_camera.SetImagingArea( m_image_left, m_image_right, m_image_bottom, m_image_top );

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}
void CCameraDialog::OnEnKillfocusImageBottom()
{
	UpdateData(TRUE);
	g_camera.SetImagingArea( m_image_left, m_image_right, m_image_bottom, m_image_top );

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}
void CCameraDialog::OnEnKillfocusImageTop()
{
	UpdateData(TRUE);
	g_camera.SetImagingArea( m_image_left, m_image_right, m_image_bottom, m_image_top );

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}

void CCameraDialog::OnEnKillfocusBinningEdit()
{
	UpdateData(TRUE);
	g_camera.SetBinning(m_num_pixels_to_bin, m_num_pixels_to_bin);

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);

	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);
}


void CCameraDialog::OnBnClickedHFlip()
{
	UpdateData(TRUE);
	m_h_flip = !m_h_flip;
	g_camera.FlipImage(m_h_flip, m_v_flip);
	UpdateData(FALSE);
}
void CCameraDialog::OnBnClickedVFlip()
{
	UpdateData(TRUE);
	m_v_flip = !m_v_flip;
	g_camera.FlipImage(m_h_flip, m_v_flip);
	UpdateData(FALSE);
}

void CCameraDialog::OnBnClickedRotate0()
{
	if ( g_camera.RotateImage(0) < 0 )	return;
	m_rotate0 = FALSE;
	m_rotate90 = m_rotate270 = TRUE;

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}
void CCameraDialog::OnBnClickedRotate90()
{
	if ( g_camera.RotateImage(1) < 0 )	return;
	m_rotate90 = FALSE;
	m_rotate0 = m_rotate270 = TRUE;

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}
void CCameraDialog::OnBnClickedRotate270()
{
	if ( g_camera.RotateImage(-1) < 0 )	return;
	m_rotate270 = FALSE;
	m_rotate0 = m_rotate90 = TRUE;

	CWnd *pWnd;
	CString str;

	pWnd = GetDlgItem(IDC_BINNING);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels_to_bin, g_camera.m_num_v_pixels_to_bin );
	if ( pWnd ) pWnd->SetWindowText(str);
	pWnd = GetDlgItem(IDC_EFFECTIVE_RESOLUTION);
	str.Format(_T("%d x %d"), g_camera.m_num_h_pixels, g_camera.m_num_v_pixels );
	if ( pWnd )	pWnd->SetWindowText(str);

	UpdateData(FALSE);
}
