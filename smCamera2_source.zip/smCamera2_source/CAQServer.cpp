#include "stdafx.h"
#include "../LKSLib/LKSLibCommon.h"
#include "CAQServer.h"
#include "smCamera.h"


CCAQServer::CCAQServer() 
{
	m_header = NULL;
	//m_point_data = NULL;
	m_image_data = NULL;

	m_num_bufferable = 0;
	m_buffering_space = NULL;
}

CCAQServer::~CCAQServer()
{
	CAQServerFree();
}

int CCAQServer::CAQServerInit(UINT w, UINT h, UINT32 size)
{
	CAQServerFree();
	

	UINT32 size_in_byte = size * 1024 * 1024 ;
//	UINT32 minsize_in_byte = sizeof(CCAQHeader) + ( w*h*sizeof(UINT32) + NUM_CAQ_CHANNELS*sizeof(CCAQPoint) ) * 2 ;
	UINT32 minsize_in_byte = sizeof(CCAQHeader) + ( w*h*sizeof(UINT32) ) * 2 ;

	//LKSCMT : It is somewhat not intuitive to have the factor of 2, but it is required.

	if ( size_in_byte < minsize_in_byte )
	{
		LogMsg(_T("Info"), Stringify(_T("[%u]MB is too small for CAQServer : minimum [%u]Byte. "), size, minsize_in_byte ) );
		size_in_byte = minsize_in_byte;
	}

	if ( m_shmem.Create( CAQ_SHMEM_NAME, size_in_byte ) < 0 )
	{
		LogMsg(_T("Error"), _T("Shared Memory Creation Failed.") );

		return -1;
	}

	m_header = (CCAQHeader *) m_shmem.pBuffer;

	m_header->frame_w = w;
	m_header->frame_h = h;
	//m_header->bpp = bpp;
	//m_header->scaler = (1<< (8*bpp));
	m_header->scaler = (1<< (32))-1;//examine
	m_header->background = 0;

	//m_header->size = ( size_in_byte - sizeof(CCAQHeader) ) / ( w*h*sizeof(UINT32) + NUM_CAQ_CHANNELS*sizeof(CCAQPoint) ) ;
	m_header->size = ( size_in_byte - sizeof(CCAQHeader) ) / ( w*h*sizeof(UINT32) ) ;
	m_header->num_acquired = 0;
	m_header->num_dismissed = 0;

	m_header->is_running = FALSE;
	m_header->sampling_rate = 0;

	m_header->last_sync_tick = 0;
	m_header->last_sync_index = 0;

	m_header->r = 0.0;
	for ( int i = CAQ_CH1 ; i < NUM_CAQ_CHANNELS ; i++ )
        m_header->x[i] = m_header->y[i] = -1.0;

	//m_point_data = (CCAQPoint *) ( m_shmem.pBuffer + sizeof(CCAQHeader) );
	//m_image_data = (UINT32 *) ( m_shmem.pBuffer + sizeof(CCAQHeader) + m_header->size * NUM_CAQ_CHANNELS * sizeof(CCAQPoint) ) ;
	m_image_data = (UINT32 *) ( m_shmem.pBuffer + sizeof(CCAQHeader) );

	m_num_bufferable = 0;
	m_buffering_space = NULL;

	InitProgramTimer();
	return 0;
}

int CCAQServer::CAQServerFree()
{
	CAQServerStop();

	if ( m_header )
	{
		m_header->num_acquired = 0;
		m_header->num_dismissed = 0;
	}
	m_shmem.Close();
	m_header = NULL;
	//m_point_data = NULL;
	m_image_data = NULL;

	m_num_bufferable = 0;
	m_buffering_space = NULL;
	return 0;
}


int CCAQServer::CAQServerStart(double sampling_rate)
{
	if ( m_header == NULL )	return -1;
	if ( m_header->is_running )	return 0;

	m_num_bufferable = 0;
	m_buffering_space = NULL;

	m_header->num_acquired = 0;
	m_header->num_dismissed = 0;	

	m_header->is_running = TRUE;
	m_header->sampling_rate = sampling_rate;

	m_header->last_sync_tick = GetProgramTimeInTicks();
	m_header->last_sync_index = 0;
	return 0;
}

int CCAQServer::CAQServerStop()
{
	if ( m_header == NULL )	return -1;
	m_header->is_running = FALSE;

	m_num_bufferable = 0;
	m_buffering_space = NULL;
	return 0;
}

int CCAQServer::CAQServerSync(UINT num)
{
	if ( m_header == NULL )	return -1;

	m_header->last_sync_tick = GetProgramTimeInTicks();
	m_header->last_sync_index = m_header->num_acquired + num;
	return 0;
}

int CCAQServer::OpenBufferingSpace(UINT num)
{
	if ( m_header == NULL )	return -1;
	if ( m_header->num_acquired - m_header->num_dismissed > m_header->size )	return -1; //if the new frames 
	//are more abundant than what the buffer can hold, dismiss.
	//num_dismissed can increase in this funcion. It must mean that they are getting dismissed here. num_acquired can increase in closebufferingspace
	UINT fsize = m_header->frame_w * m_header->frame_h ;
	UINT start = (UINT) ( m_header->num_dismissed % m_header->size ) ;
	UINT end = (UINT) ( m_header->num_acquired % m_header->size ) ; //

	
	if ( m_header->num_dismissed == m_header->num_acquired || start < end )
	{
		//m_num_bufferable = (bpp * ( m_header->size - end )) / sizeof(UINT32) ;
		m_num_bufferable = ( m_header->size - end );
		m_buffering_space = (UINT32 *) ( m_image_data + end * fsize );
		return 0;
	}


	m_num_bufferable = ( start - end );
	if ( m_num_bufferable >= num )
	{
		int zzz =1;// Case 2-1. Enough space. This section never gets visited in my trials.
	}
	else
	{
		// Case 2-2. Not enough space.
		UINT nstart = (UINT) ( end + num );
		if ( nstart > m_header->size )	nstart = m_header->size;

		m_header->num_dismissed += ( nstart - start );
		//m_num_bufferable = ( bpp * ( nstart - end ) ) / sizeof(UINT32) ;
		m_num_bufferable = ( nstart - end );
	}
	m_buffering_space = (UINT32 *) ( m_image_data + end * fsize ); 
	return 0;
}

int CCAQServer::CloseBufferingSpace(UINT num)
{
	if ( m_header == NULL )	return -1;
	if ( m_buffering_space == NULL )	return -1;
	if ( num > m_num_bufferable )	return -1;

//	for ( UINT i = 0 ; i < num ; i++ )
//	{
//		UINT32 index = (UINT32) ( m_header->num_acquired % m_header->size ) ;
//		for ( int ch = CAQ_CH1 ; ch < NUM_CAQ_CHANNELS ; ch++ )
//		{
//			CCAQPoint *pt = &( m_point_data[ index*NUM_CAQ_CHANNELS + ch ] );
//			pt->x = (float) m_header->x[ch];
//			pt->y = (float) m_header->y[ch];
//		}
//
//		m_header->num_acquired++;
//	}
	m_header->num_acquired += num; //the place where num_acquired changes

	m_num_bufferable = 0;
	m_buffering_space = NULL;
	return 0;
}













UINT32 CCAQServer::CAQServerReadPixel(UINT64 index, UINT x, UINT y)
{
	if ( index < m_header->num_dismissed )	return 0;
	UINT w = m_header->frame_w;
	UINT h = m_header->frame_h;
	return m_image_data[ ( index % m_header->size )*w*h + ( w*y + x ) ];
}