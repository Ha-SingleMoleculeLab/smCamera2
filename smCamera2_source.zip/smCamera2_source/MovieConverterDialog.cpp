// MovieConverterDialog.cpp : implementation file

#include "stdafx.h"
#include "smCamera.h"
#include "MovieConverterDialog.h"
#include <math.h>

// CMovieConverterDialog dialog

IMPLEMENT_DYNAMIC(CMovieConverterDialog, CDialog)
CMovieConverterDialog::CMovieConverterDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMovieConverterDialog::IDD, pParent)
	, m_film_convert_cbindex(FILM_CONVERT_TO_OLD_FILM)
	, m_film_convert_status(_T(""))
	, m_trace_convert_status(_T(""))
{
}

CMovieConverterDialog::~CMovieConverterDialog()
{
}

BOOL CMovieConverterDialog::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_is_working = FALSE;
	m_directory.SetPath( _PATH_MOVIES );

	LoadProgramColorTable();
	UpdateData(FALSE);	
	return TRUE;
}

void CMovieConverterDialog::OnCancel()
{
	if ( m_is_working )
	{
		LogErr(_T("Conversion is in progress. Stop it first."));
		return;
	}

	DestroyWindow();
}

void CMovieConverterDialog::OnOK()
{
	SetFocus();
	return;
}

void CMovieConverterDialog::OnDestroy()
{
	m_is_working = FALSE;

	_tchdir(_PATH_ROOT);
	CDialog::OnDestroy();
}

void CMovieConverterDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	
	DDX_CBIndex(pDX, IDC_FILM_CONVERT_COMBO, m_film_convert_cbindex);
	DDX_Text(pDX, IDC_FILM_CONVERT_STATUS, m_film_convert_status);
	DDX_Text(pDX, IDC_TRACE_CONVERT_STATUS, m_trace_convert_status);
}

BEGIN_MESSAGE_MAP(CMovieConverterDialog, CDialog)
	ON_BN_CLICKED(IDC_FILM_CONVERT, OnBnClickedFilmConvert)
	ON_BN_CLICKED(IDC_FILM_CONVERT_FOLDER, OnBnClickedFilmConvertFolder)
	ON_BN_CLICKED(IDC_TRACE_CONVERT, OnBnClickedTraceConvert)
	ON_BN_CLICKED(IDC_TRACE_CONVERT_FOLDER, OnBnClickedTraceConvertFolder)
END_MESSAGE_MAP()

void CMovieConverterDialog::ConvertFilmToOldFilm(LPCTSTR filmpath)
{
	MSG message;

	int n;
	CString filepath;
	CString path = _T(""), name = _T("");
	name = filepath = filmpath;

	n = filepath.ReverseFind( (TCHAR)'\\' );
	if ( n >= 0 )
	{
		path = filepath.Mid(0, n);
		name = filepath.Mid(n+1);
	}
	name.Replace(CAMERAFILE_FILM_PREFIX, _T(""));
	n = name.ReverseFind('.');
	if ( n < 0 )	return;
	name = name.Mid(0, n);
	filepath.Format(_T("%s\\%s%s.%s"), path, CAMERAFILE_OLDFILM_PREFIX, name, CAMERAFILE_OLDFILM_EXT);

	CFilm film;
	if ( film.Open(filmpath) < 0 )	return;

	CArchive *ar = OpenProgramFileToWrite(filepath);
	if ( ar == NULL )	return;

	m_film_convert_status.Format(_T("[Converting] %s \r\n -> %s"), filmpath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	UINT16 w = film.m_frame_w;
	UINT16 h = film.m_frame_h;
	ar->Write((void *)&w, sizeof(UINT16));
	ar->Write((void *)&h, sizeof(UINT16));

	for ( UINT i = 0 ; i < film.m_num_frames ; i++ )
	{
		UINT8 pixel;

		film.MoveFrame(i);
		film.ReadFrame(NULL);

		for ( UINT y = 0 ; y < h ; y++ )
		{
			for ( UINT x = 0 ; x < w ; x++ )
			{
				pixel = film.Pixel2Byte( film.Frame(x,y) );
				ar->Write((void *)&pixel, sizeof(UINT8));
			}
		}
		if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}
	CloseProgramFile(ar);

	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), filmpath, filepath));
	m_film_convert_status.Format(_T("[Done] %s \r\n -> %s"), filmpath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	return;
}

void CMovieConverterDialog::ConvertFilmToGrayTIFF(LPCTSTR filmpath)
{
	MSG message;

	CFilm film;
	CTIFFFileWriter writer;
	if ( film.Open(filmpath) < 0 || !film.m_film )	return;
	if ( writer.SetFilepath(filmpath) < 0 )	return;
	writer.m_frame_w = film.m_frame_w;
	writer.m_frame_h = film.m_frame_h;
	writer.m_background = film.m_background;
	writer.m_data_scaler = film.m_data_scaler;
	writer.m_byte_per_pixel = film.m_film->m_byte_per_pixel;
	writer.m_8bit_color = FALSE;
	if ( writer.Open() < 0 )	return;
	
	m_film_convert_status.Format(_T("[Converting] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	for ( UINT i = 0 ; i < film.m_num_frames ; i++ )
	{
		film.MoveFrame(i);
		film.ReadFrame(NULL);
		writer.Write( 1, film.m_frame );

		if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}


	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), filmpath, writer.m_filepath));
	m_film_convert_status.Format(_T("[Done] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	writer.Close();
	film.Close();

	return;
}

void CMovieConverterDialog::ConvertFilmTo8BitColorTIFF(LPCTSTR filmpath)
{
	MSG message;

	CFilm film;
	CTIFFFileWriter writer;
	if ( film.Open(filmpath) < 0 || !film.m_film )	return;
	if ( writer.SetFilepath(filmpath) < 0 )	return;
	writer.m_frame_w = film.m_frame_w;
	writer.m_frame_h = film.m_frame_h;
	writer.m_background = film.m_background;
	writer.m_data_scaler = film.m_data_scaler;
	writer.m_byte_per_pixel = 1;
	writer.m_8bit_color = TRUE;
	if ( writer.Open() < 0 )	return;
	
	m_film_convert_status.Format(_T("[Converting] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	for ( UINT i = 0 ; i < film.m_num_frames ; i++ )
	{
		film.MoveFrame(i);
		film.ReadFrame(NULL);
		writer.Write( 1, film.m_frame );

		if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
	}

	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), filmpath, writer.m_filepath));
	m_film_convert_status.Format(_T("[Done] %s \r\n -> %s"), filmpath, writer.m_filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}
	writer.Close();
	film.Close();

	return;
}


void CMovieConverterDialog::ConvertTraceToOldTrace(LPCTSTR tracepath)
{
	int n;
	CString filepath;
	CString path = _T(""), name = _T("");
	name = filepath = tracepath;

	n = filepath.ReverseFind( (TCHAR)'\\' );
	if ( n >= 0 )
	{
		path = filepath.Mid(0, n);
		name = filepath.Mid(n+1);
	}

	name.Replace(CAMERAFILE_TRACE_PREFIX, _T(""));
	n = name.ReverseFind('.');
	if ( n < 0 )	return;
	name = name.Mid(0, n);
	filepath.Format(_T("%s\\%s%s.%s"), path, CAMERAFILE_OLDTRACE_PREFIX, name, CAMERAFILE_OLDTRACE_EXT);

	CTraceFileReader reader;
	if ( reader.Open(tracepath) < 0 )	return;

	CArchive *ar = OpenProgramFileToWrite( filepath );
	if ( ar == NULL )	return;


	m_trace_convert_status.Format(_T("[Converting] %s \r\n -> %s"), tracepath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	INT16 limit = (1 << (16-1)) - 1;
	double max = 0.0;
	for ( UINT frame_no = 0 ; frame_no < reader.m_num_frames ; frame_no++ )
		for ( UINT peak_no = 0 ; peak_no < reader.m_num_peaks ; peak_no++ )
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				double f = reader.Signal( i, peak_no, frame_no ) - reader.Background( i, peak_no, frame_no );
				if ( f > max )	max = f;
			}



	INT32 num_frames = reader.m_num_frames;
	INT16 num_peaks = 2*reader.m_num_peaks;
	ar->Write((void *)&num_frames, sizeof(INT32));
	ar->Write((void *)&num_peaks, sizeof(INT16));

	INT32 temp32;
	INT16 temp16;
	if ( max < limit )	max = limit;
	for ( UINT frame_no = 0 ; frame_no < reader.m_num_frames ; frame_no++ )
		for ( UINT peak_no = 0 ; peak_no < reader.m_num_peaks ; peak_no++ )
			for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				double f = reader.Signal( i, peak_no, frame_no ) - reader.Background( i, peak_no, frame_no );
				temp32 = (INT32) ( f * limit * 1.0 / max );
				temp16 = ( temp32 > (INT32)limit ) ? limit : (INT16)temp32;
                ar->Write((void *)&temp16, sizeof(INT16));
			}

	CloseProgramFile(ar);
	reader.Close();

	LogMsg(_T("Info"), Stringify(_T("%s -> %s"), tracepath, filepath));
	m_trace_convert_status.Format(_T("[Done] %s \r\n -> %s"), tracepath, filepath);
	if ( ::IsWindow(m_hWnd) )
	{
		UpdateData(FALSE);
		UpdateWindow();
	}

	return;
}


void CMovieConverterDialog::ConvertFilmFolder(LPCTSTR folder )
{
	MSG message;
	CDirectoryTraverse directory;
	directory.SetFormat(_T(""), CAMERAFILE_FILM_EXT);
	directory.SetPath( folder );

	if ( directory.InitTraverse() < 0 )	return;
	CString fullpath;
	CString name;
	BOOL is_dir;
	while ( directory.Traverse( name, is_dir ) == 0 )
	{

		if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
		if ( ::IsWindow(m_hWnd) )	UpdateWindow();

		if ( m_is_working != TRUE )	break;

		fullpath = directory.m_path + '\\' + name;
		if ( is_dir )
		{
			ConvertFilmFolder(fullpath);
		}
		else
		{
			if ( m_film_convert_cbindex == FILM_CONVERT_TO_OLD_FILM )
	            ConvertFilmToOldFilm( fullpath );
			else if ( m_film_convert_cbindex == FILM_CONVERT_TO_GRAY_TIFF )
				ConvertFilmToGrayTIFF( fullpath );
			else if ( m_film_convert_cbindex == FILM_CONVERT_TO_8BITCOLOR_TIFF )
				ConvertFilmTo8BitColorTIFF( fullpath );
		}
	}
	directory.CloseTraverse();

	return;
}

void CMovieConverterDialog::ConvertTraceFolder(LPCTSTR folder)
{
	MSG message;
	CDirectoryTraverse directory;
	directory.SetFormat(_T(""), CAMERAFILE_TRACE_EXT);
	directory.SetPath( folder );

	if ( directory.InitTraverse() < 0 )	return;
	CString fullpath;
	CString name;
	BOOL is_dir;
	while ( directory.Traverse( name, is_dir ) == 0 )
	{

		if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			if ( !IsDialogMessage(&message) )
			{
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
		}
		if ( ::IsWindow(m_hWnd) )	UpdateWindow();

		if ( m_is_working != TRUE )	break;

		fullpath = directory.m_path + '\\' + name;
		if ( is_dir )
			ConvertTraceFolder(fullpath);
		else
			ConvertTraceToOldTrace(fullpath);

	}
	directory.CloseTraverse();

	return;
}

void CMovieConverterDialog::OnBnClickedFilmConvert()
{
	if ( m_is_working )	return;
	m_is_working = TRUE;
	UpdateData(TRUE);

	CString szFilters;
	szFilters.Format(_T("Film Files (*.%s;*.%s)|*.%s; *.%s|"
						"All Files (*.*)|*.*||"),
					CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path ;
	if( fileDlg.DoModal ()==IDOK )
	{
		CString filename = fileDlg.GetPathName();
		int n = filename.ReverseFind((TCHAR)'\\');
		if ( n < 0 )	n = 0;
		m_directory.SetPath( filename.Mid(0, n) );

		if ( m_film_convert_cbindex == FILM_CONVERT_TO_OLD_FILM )
            ConvertFilmToOldFilm( filename );
		else if ( m_film_convert_cbindex == FILM_CONVERT_TO_GRAY_TIFF )
			ConvertFilmToGrayTIFF( filename );
		else if ( m_film_convert_cbindex == FILM_CONVERT_TO_8BITCOLOR_TIFF )
			ConvertFilmTo8BitColorTIFF( filename );
	}

	m_is_working = FALSE;
}

void CMovieConverterDialog::OnBnClickedFilmConvertFolder()
{
	static BOOL convert_in_progress = FALSE;
	CWnd *pWnd;

	if ( m_is_working && !convert_in_progress )	return;
	if ( convert_in_progress )
	{
		m_is_working = FALSE;
		return;
	}
	UpdateData(TRUE);

	CString szFilters;
	szFilters.Format(_T("Film Files (*.%s)|*.%s|All Files (*.*)|*.*|"), 
					CAMERAFILE_FILM_EXT, CAMERAFILE_FILM_EXT );
	CDirectoryDialog dirDlg( m_directory.m_path, szFilters);
	if ( dirDlg.DoModal()  != TRUE )	return;

	m_is_working = TRUE;
	convert_in_progress = TRUE;
	pWnd = GetDlgItem(IDC_FILM_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Stop"));

	m_directory.SetPath( dirDlg.m_strPath );
	ConvertFilmFolder( m_directory.m_path );

	pWnd = GetDlgItem(IDC_FILM_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Convert Folder"));
	convert_in_progress = FALSE;
	
	m_is_working = FALSE;
}

void CMovieConverterDialog::OnBnClickedTraceConvert()
{
	if ( m_is_working )	return;
	m_is_working = TRUE;

	CString szFilters;
	szFilters.Format(_T("Trace Files (*.%s)|*.%s|All Files (*.*)|*.*||"),
					CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path ;
	if( fileDlg.DoModal ()==IDOK )
	{
		CString filename = fileDlg.GetPathName();
		int n = filename.ReverseFind((TCHAR)'\\');
		if ( n < 0 )	n = 0;
		m_directory.SetPath( filename.Mid(0, n) );

		ConvertTraceToOldTrace( filename );
	}

	m_is_working = FALSE;
}

void CMovieConverterDialog::OnBnClickedTraceConvertFolder()
{
	static BOOL convert_in_progress = FALSE;
	CWnd *pWnd;

	if ( m_is_working && !convert_in_progress )	return;
	if ( convert_in_progress )
	{
		m_is_working = FALSE;
		return;
	}

	CString szFilters;
	szFilters.Format(_T("Trace Files (*.%s)|*.%s|All Files (*.*)|*.*|"), 
					CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE_EXT );
	CDirectoryDialog dirDlg( m_directory.m_path, szFilters);
	if ( dirDlg.DoModal()  != TRUE )	return;

	m_is_working = TRUE;
	convert_in_progress = TRUE;
	pWnd = GetDlgItem(IDC_TRACE_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Stop"));

	m_directory.SetPath( dirDlg.m_strPath );
	ConvertTraceFolder( m_directory.m_path );

	pWnd = GetDlgItem(IDC_TRACE_CONVERT_FOLDER);
	if ( pWnd )	pWnd->SetWindowText(_T("Convert Folder"));
	convert_in_progress = FALSE;
	m_is_working = FALSE;
}
