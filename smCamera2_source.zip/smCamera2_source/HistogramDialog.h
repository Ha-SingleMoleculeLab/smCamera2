#pragma once
#include "smCamera.h"
#include "afxtempl.h"
#include "afxwin.h"

class CHistData
{
public:
	double ch1[2];
	double ch2[2];
	double bgsub_ch1[2];
	double bgsub_ch2[2];
	CHistData()	
	{	
		memset( ch1, 0, sizeof(double)*2 );
		memset( ch2, 0, sizeof(double)*2 );
		memset( bgsub_ch1, 0, sizeof(double)*2 );
		memset( bgsub_ch2, 0, sizeof(double)*2 );
	}
};

class CHistCutoff
{
public:
	BOOL use;
	float low;
	float high;
	CHistCutoff() {	Reset();	}
	void Reset() {	use = FALSE; low = high = 0.0;	}
};

// CHistogramDialog dialog
class CHistogramDialog : public CDialog
{
	DECLARE_DYNAMIC(CHistogramDialog)

public:
	CHistogramDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CHistogramDialog();

// Dialog Data
	enum { IDD = IDD_HISTOGRAM };
	enum { FRET_HIST = 0, CH1_HIST, CH2_HIST, SUM_HIST, NUM_HIST_TYPES	};

protected:
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CDirectoryTraverse m_directory;
	CArray<CString>	m_traces;
	CArray<CHistData> m_peaks;

	UINT m_num_used;

	CArray<UINT> m_cnt[2];
	double m_min[2];
	double m_max[2];
	double m_ymax[2];
	int m_left[2];
	int m_top[2];
	int m_height[2];
	int m_width[2];
	CStatic m_histogram[2];

	void ReadTraces();
	void InitHistogram();
	void BuildHistogram();
	void DrawHistogram(int id);
	void SaveHistogram(int id);
	
	CString m_fspath[2];
	CFrameSequence m_fs[2];
	double m_ID_in_CH1;
	double m_IA_in_CH1;

	afx_msg void OnPaint();
	afx_msg void OnBnClickedOpen();
	afx_msg void OnBnClickedReopen();
	afx_msg void OnBnClickedFS1();
	afx_msg void OnBnClickedFS2();
	afx_msg void OnEnKillfocusIDCH1();
	afx_msg void OnEnKillfocusIACH1();

	int m_histogram_cbindex[2];
	CHistCutoff m_cutoff[2][NUM_HIST_TYPES];
	double m_binsize[2][NUM_HIST_TYPES];
	double m_xoffset[NUM_HIST_TYPES];
	double m_xscale[NUM_HIST_TYPES];

	afx_msg void OnCbnSelendokCombo1();
	afx_msg void OnEnKillfocusLB1();
	afx_msg void OnEnKillfocusUB1();
	afx_msg void OnBnClickedSave1();
	afx_msg void OnEnKillfocusBinsize1();
	afx_msg void OnDeltaposYScale1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposXScale1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposXOffset1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCbnSelendokCombo2();
	afx_msg void OnEnKillfocusLB2();
	afx_msg void OnEnKillfocusUB2();
	afx_msg void OnBnClickedSave2();
	afx_msg void OnEnKillfocusBinsize2();
	afx_msg void OnDeltaposYScale2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposXScale2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposXOffset2(NMHDR *pNMHDR, LRESULT *pResult);
};
