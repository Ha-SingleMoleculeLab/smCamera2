#pragma once
#include "smCamera.h"
#include "afxwin.h"
#include "CameraFile.h"
#include "CAQServer.h"
#include "CAQClient.h"

#include "afxtempl.h"

// CMovieRecorderDialog dialog

class CMovieRecorderDialog : public CDialog
{
	DECLARE_DYNAMIC(CMovieRecorderDialog)

public:
	CMovieRecorderDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMovieRecorderDialog();

// Dialog Data
	enum { IDD = IDD_RECORDER };

protected:
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:

	UINT m_frame_w;
	UINT m_frame_h;
	BOOL m_is_acquiring;
	BOOL m_should_be_destroyed;
	BOOL m_is_recording;
	UINT64 m_recording_index;
	BOOL m_recording_with_shutter;
	CCAQServer m_server; //has a serverand a client associated. What different things do they do?
	CCAQClient m_client;
	CFilmFileWriter *m_writer; //this writes the movie data into a file


	int InitRecorder();
	int FreeRecorder();
	int StartAcquisition();
	int StopAcquisition();
	int RecordStart();
	int RecordStop();
	int Record();

	CShutterClient g_shutter_client;

	CStatic m_image;
	int m_image_left;
	int m_image_top;
	int m_image_height;
	int m_image_width;
	CStatic m_spot;
	int m_spot_left;
	int m_spot_top;
	int m_spot_height;
	int m_spot_width;
	CBitmap	*m_bitmap;
	COLORREF *m_display_buffer;

	void DrawCircle(CDC &dcMem, int x, int y, int r, COLORREF color);
	void DrawFrame();
	void UpdateFrame();	
	void SetUIs();


	double m_exposure_time;
	UINT32 m_gain;
	UINT32 m_memory_size;
	UINT32 m_background;
	UINT32 m_data_scaler;
	afx_msg void OnEnKillfocusExposureTime();
	afx_msg void OnEnKillfocusGain();
	afx_msg void OnEnKillfocusMemorySize();
	afx_msg void OnBnClickedAcquisition();
	afx_msg void OnEnKillfocusBackground();
	afx_msg void OnEnKillfocusDataScaler();

	inline UINT8 Pixel2Byte(UINT32 val)
		{
			UINT32 byte = (UINT32) ( 255 * ( ( val > m_background ) ? val-m_background : 0 ) * 1.0 / m_data_scaler ) ;
			return ( byte >= 255 ) ? 255 : byte;
		}



	CDirectoryTraverse m_directory;
	BOOL m_set_max_frame_no;
	int m_max_frame_no;
	BOOL m_save_as_old_format;
	BOOL m_save_pixel_in_8bit;
	CString m_film_comment;
	afx_msg void OnBnClickedRecordStart();
	afx_msg void OnBnClickedRecordStop();
	afx_msg void OnBnClickedSetPath();
	afx_msg void OnBnClickedFilmFirst();
	afx_msg void OnBnClickedFilmPrev();
	afx_msg void OnBnClickedFilmNext();
	afx_msg void OnBnClickedFilmLast();
	afx_msg void OnBnClickedSetMaxLength();
	afx_msg void OnEnKillfocusMaxFrame();
	afx_msg void OnBnClickedSaveAsOldFormat();
	afx_msg void OnBnClickedSavePixelIn8bit();
	afx_msg void OnEnKillfocusFilmComment();

	
	BOOL m_auto_scale;
	BOOL m_overlay_channels;
	BOOL m_log_selected_spot;
	afx_msg void OnBnClickedAutoScale();
	afx_msg void OnBnClickedOverlayChannels();
	afx_msg void OnBnClickedLogSelectedSpot();


	CPoint m_point;
	int GetChannel(CPoint point, int *px, int *py);
	

	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnDeltaposSpinx(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpiny(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinr(NMHDR *pNMHDR, LRESULT *pResult);
	
	afx_msg void OnStnClickedImage();
};