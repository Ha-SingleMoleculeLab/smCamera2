// TraceDialog.cpp : implementation file
//

#include "stdafx.h"
#include "smCamera.h"
#include "TraceDialog.h"
#include "Circle.h"
#include ".\tracedialog.h"

#define TRACE_OVERSHOOT		(1.2)
#define TRACE_V_DIV			(6)
#define TRACE_H_DIV			(7)

#define DEFAULT_PEAK_RADIUS	(10)

#define REAL_CH1(ch1, ch2)	( ( (1-m_21)*(ch1) - m_21*(ch2) ) / ( m_11 - m_21 ) )
#define REAL_CH2(ch1, ch2)	( ( m_11*(ch2) - (1-m_11)*(ch1) ) / ( m_11 - m_21 ) )

#define PI			(3.14159265)
#define Z_VALUE		(3.00)


// CTraceDialog dialog

IMPLEMENT_DYNAMIC(CTraceDialog, CDialog)
CTraceDialog::CTraceDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTraceDialog::IDD, pParent)
	, m_f0_fsum_ratio(1.0)
	, m_11(1.0)
	, m_21(0.0)
	, m_peak_no(-1)
	, m_show_total(FALSE)
	, m_show_background(FALSE)
	, m_flat_background(FALSE)
{
	m_bitmap = NULL;
	m_display_buffer = NULL;

	m_CH1 = NULL;
	m_CH2 = NULL;
	m_bg1 = NULL;
	m_bg2 = NULL;
	m_bg1_base = 0.0;
	m_bg2_base = 0.0;

	m_intensity_xoffset = 0;
	m_intensity_xscale = 1;
	m_intensity_yoffset = 0;
	m_intensity_yscale = 1;

    m_FRET_xoffset = 0;
	m_FRET_xscale = 1;
	m_FRET_yoffset = 0;
	m_FRET_yscale = 0.1;
}

CTraceDialog::~CTraceDialog()
{
}

void CTraceDialog::OnOK()
{
	CWnd *pWnd = GetFocus( );
	SetFocus();
	if ( pWnd )
	{
		pWnd->SetFocus();
		((CEdit*)pWnd)->SetSel(0, -1);
	}
	return;
}

void CTraceDialog::OnDestroy()
{
	m_film.Close();
	FreeFrame();

	CString str;
	CArchive *ar = OpenProgramFileToWrite(
					GetProgramFilePath( _PATH_TRACE, _T("trace.save") )
					);
	if ( ar )
	{
		str.Format(_T("%.3f\r\n"), m_11);
		ar->WriteString(str);	
		str.Format(_T("%.3f\r\n"), m_21);
		ar->WriteString(str);	
		str.Format(_T("%d\r\n"), m_radius[CH1]);
		ar->WriteString(str);
		str.Format(_T("%d\r\n"), m_radius[CH2]);
		ar->WriteString(str);
		str = m_directory.m_path;
		ar->WriteString(str);

		CloseProgramFile(ar);
	}

	_tchdir(_PATH_ROOT);
	CDialog::OnDestroy();
}

void CTraceDialog::OnCancel()
{
	DestroyWindow();
}

void CTraceDialog::OnPaint()
{
	CDialog::OnPaint();
	UpdateFrame();
	DrawIntensity();
	DrawFRET();
}


static RECT * __find_dest_rect(CDialog *dlg, CStatic *pane)
{
	static RECT	rect;
	long border_thickness;
	
	RECT dlgClientRct, dlgWinRct, paneWinRct;
	dlg->GetWindowRect(&dlgWinRct);
	dlg->GetClientRect(&dlgClientRct);

	pane->GetWindowRect(&paneWinRct);

	border_thickness = ( (dlgWinRct.right-dlgWinRct.left) - (dlgClientRct.right-dlgClientRct.left) )/2;
	rect.left = paneWinRct.left - ( dlgWinRct.left + border_thickness );
	dlgWinRct.top = dlgWinRct.bottom - border_thickness
					- (dlgClientRct.bottom-dlgClientRct.top) - border_thickness;
	rect.top = paneWinRct.top - ( dlgWinRct.top + border_thickness );
	rect.right = rect.left + paneWinRct.right - paneWinRct.left;
	rect.bottom = rect.top + paneWinRct.bottom - paneWinRct.top;

	return &rect;
}



BOOL CTraceDialog::OnInitDialog()
{
	CString str;
	RECT *rect;
    CDialog::OnInitDialog();

	CArchive *ar = NULL;
	if ( DoesProgramFileExist( GetProgramFilePath( _PATH_TRACE, _T("trace.save")) ) )
	{
		ar = OpenProgramFileToRead( GetProgramFilePath( _PATH_TRACE, _T("trace.save")) );
		if ( ar )
		{
			ar->ReadString(str);
			m_11 = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
			ar->ReadString(str);
			m_21 = LIMIT_DECIMAL_PLACES( _tcstod(str, NULL), 3 );
			ar->ReadString(str);
			m_radius[CH1] = _tstoi(str);
			ar->ReadString(str);
			m_radius[CH2] = _tstoi(str);
			ar->ReadString(str);
			m_directory.SetPath(str);
			CloseProgramFile(ar);
		}
	}
	else
	{
		m_11 = 1.0;
		m_21 = 0.0;
		m_radius[CH1] = DEFAULT_PEAK_RADIUS;
        m_radius[CH2] = DEFAULT_PEAK_RADIUS;
		m_directory.SetPath( _PATH_MOVIES );
	}

	rect = __find_dest_rect(this, &m_intensity);
	m_intensity_left = rect->left;
	m_intensity_top = rect->top;
	m_intensity_width = rect->right - rect->left;
	m_intensity_height = rect->bottom - rect->top;

	rect = __find_dest_rect(this, &m_FRET);
	m_FRET_left = rect->left;
	m_FRET_top = rect->top;
	m_FRET_width = rect->right - rect->left;
	m_FRET_height = rect->bottom - rect->top;

	m_peak_no = -1;
	m_peak[CH1].SetPoint( -1, -1 );
	m_peak[CH2].SetPoint( -1, -1 );

	m_from.SetPoint(-1, -1);
	m_to.SetPoint(-1, -1);

	m_show_total = FALSE;
	m_show_background = FALSE;

	m_mapping.Load();
	CWnd *pWnd;
	pWnd = GetDlgItem(IDC_MAPPING_INFO);
	if ( pWnd )	pWnd->SetWindowText( m_mapping.Information() );

	LoadProgramColorTable();
	UpdateData(FALSE);
    return TRUE;
}


void CTraceDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_IMAGE, m_image);
	DDX_Control(pDX, IDC_SPOT1, m_spot[CH1]);
	DDX_Control(pDX, IDC_SPOT2, m_spot[CH2]);
	DDX_Control(pDX, IDC_INTENSITY, m_intensity);
	DDX_Control(pDX, IDC_FRET, m_FRET);
	DDX_Control(pDX, IDC_FRAME_SLIDER, m_slider);

	DDX_Text(pDX, IDC_F0_FSUM_RATIO, m_f0_fsum_ratio);
	DDX_Text(pDX, IDC_I1_CH1, m_11);
	DDX_Text(pDX, IDC_I2_CH1, m_21);

	if ( pDX->m_bSaveAndValidate != TRUE )
	{
		CWnd *pWnd;
		CString str;

		pWnd = GetDlgItem(IDC_R1_TEXT);
		str.Format(_T("R1 : %d px"), m_radius[CH1]);
		if ( pWnd )	pWnd->SetWindowText(str);
		pWnd = GetDlgItem(IDC_R2_TEXT);
		str.Format(_T("R2 : %d px"), m_radius[CH2]);
		if ( pWnd )	pWnd->SetWindowText(str);

		int x, y;
		x = m_peak[CH1].x;
		y = m_peak[CH1].y;
		pWnd = GetDlgItem(IDC_PEAK1_TEXT);
		if ( m_film.IsOpen() && x >= 0 && y >= 0 )
			str.Format(_T("%.0f at ( %d, %d )"), m_film.Frame(x,y), x, y );
		else	str = _T("");
		if ( pWnd ) pWnd->SetWindowText(str);
		x = m_peak[CH2].x;
		y = m_peak[CH2].y;
		pWnd = GetDlgItem(IDC_PEAK2_TEXT);
		if ( m_film.IsOpen() && x >= 0 && y >= 0 )	
			str.Format(_T("%.0f at ( %d, %d )"), m_film.Frame(x,y), x, y );
		else	str = _T("");
		if ( pWnd ) pWnd->SetWindowText(str);

		pWnd = GetDlgItem(IDC_PATH);
		if ( pWnd )	pWnd->SetWindowText( m_film.m_filepath );

		pWnd = GetDlgItem(IDC_NUM_PEAKS);
		if ( m_film.m_trace )	
			str.Format(_T("%d"), m_film.m_trace->m_num_peaks );
		else
			str = _T("0");
		if ( pWnd ) pWnd->SetWindowText(str);
	}

	DDX_Text(pDX, IDC_PEAK_NO, m_peak_no);
	DDX_Check(pDX, IDC_SHOW_TOTAL, m_show_total);
	DDX_Check(pDX, IDC_SHOW_BACKGROUND, m_show_background);
	DDX_Check(pDX, IDC_FLAT_BACKGROUND, m_flat_background);
}

void CTraceDialog::InitFrame(UINT w, UINT h)
{
	CClientDC dcDlg (this);
	RECT *rect;

	FreeFrame();

	m_bitmap = new CBitmap();
	m_bitmap->CreateCompatibleBitmap(&dcDlg, w, h );
	m_display_buffer = new COLORREF[w*h];

	rect = __find_dest_rect(this, &m_image);
	m_image_left = rect->left;
	m_image_top = rect->top;
	m_image_width = rect->right - rect->left;
	m_image_height = rect->bottom - rect->top;

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		m_peak[i].SetPoint( -1, -1 );
	
        rect = __find_dest_rect(this, &(m_spot[i]));
		m_spot_left[i] = rect->left;
		m_spot_top[i] = rect->top;
		m_spot_width[i] = rect->right - rect->left;
		m_spot_height[i] = rect->bottom - rect->top;
	}

	memset(m_display_buffer, 0, sizeof(COLORREF)*w*h);
	UpdateFrame();

	if ( m_image_height * w >= m_image_width * h )
		m_image_height = (int) (( m_image_width * h * 1.0 / w ) + 0.5);
	else
		m_image_width = (int) (( m_image_height * w * 1.0 / h ) + 0.5 );

	return;
}

void CTraceDialog::FreeFrame()
{
	if ( m_display_buffer )	delete [] m_display_buffer;
	m_display_buffer = NULL;

	if ( m_bitmap )	delete m_bitmap;
	m_bitmap = NULL;

	if ( m_CH1 )	delete [] m_CH1;
	m_CH1 = NULL;
	if ( m_CH2 )	delete [] m_CH2;
	m_CH2 = NULL;
	if ( m_bg1 )	delete [] m_bg1;
	m_bg1 = NULL;
	if ( m_bg2 )	delete [] m_bg2;
	m_bg2 = NULL;

}


BOOL CTraceDialog::GetFrameCoordinate(CPoint pt, int *px, int *py)
{
	if ( !m_film.IsOpen() )	return FALSE;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	//say	w' = m_image_width / w
	//		h' = m_image_height / h
	//	[ image_left + x*w' ~ image_left + (x+1)*w' ]	-> x
	//	[ image_top + y*h' ~ image_top + (y+1)*h'	]	-> y
	//	x = (int) (pt.x - image_left)/w'
	//	y = (int) (pt.x - image_top)/h'
	int x = (int) ( w * (pt.x - m_image_left) * 1.0/m_image_width );
	int y = (int) ( h * (pt.y - m_image_top) * 1.0/m_image_height );
	if ( !( 0 <= x && x < (int)w && 0 <= y && y < (int)h ) )	return FALSE;

	if ( px )	*px = x;
	if ( py )	*py = y;
	return TRUE;;
}

BOOL CTraceDialog::GetIntensityCoordinate(CPoint pt, int *px, int *py)
{
	int x = pt.x - m_intensity_left;
	int y = m_intensity_top + m_intensity_height - pt.y;
	BOOL retval = TRUE;
	if ( !( 0 <= x && x <= m_intensity_width && 0 <= y && y <= m_intensity_height ) )
	{
		if ( x < 0 )	x = 0;
		else if ( x > m_intensity_width )	x = m_intensity_width;
		if ( y < 0 )	y = 0;
		else if ( y > m_intensity_height )	y = m_intensity_height;
		retval = FALSE;
	}
	if ( px )	*px = x;
	if ( py )	*py = y;
	return retval;
}
BOOL CTraceDialog::GetFRETCoordinate(CPoint pt, int *px, int *py)
{
	int x = pt.x - m_FRET_left;
	int y = m_FRET_top + m_FRET_height - pt.y;
	BOOL retval = TRUE;
	if ( !( 0 <= x && x <= m_FRET_width && 0 <= y && y <= m_FRET_height ) )
	{
		if ( x < 0 )	x = 0;
		else if ( x > m_FRET_width )	x = m_FRET_width;
		if ( y < 0 )	y = 0;
		else if ( y > m_FRET_height )	y = m_FRET_height;
		retval = FALSE;
	}
	if ( px )	*px = x;
	if ( py )	*py = y;
	return retval;
}


void CTraceDialog::DrawCircle(CDC &dcMem, int x, int y, int r)
{
	COLORREF color = RGB(255, 255, 0);
	
	CPen pen(PS_SOLID, 1, color);
	dcMem.SelectObject(&pen);
	dcMem.Arc(	x - r, y - r, x + 1 + r, y + 1 + r,
				x - r, y + 1 + r, x - r, y + 1 + r );
	return;
}

void CTraceDialog::UpdateFrame()
{
	if ( !m_film.IsOpen() || !m_display_buffer )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	CClientDC dcDlg (this);
	CDC dcMem;	
	
	dcMem.CreateCompatibleDC(&dcDlg);
	CBitmap *pOldBitmap = dcMem.SelectObject(m_bitmap);

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		if ( m_peak[i].x >= 0 && m_peak[i].y >= 0 )	continue;
		dcMem.SetPixelV( 0, 0, RGB( 0, 0, 0 ) );		
		dcDlg.StretchBlt( m_spot_left[i], m_spot_top[i], m_spot_width[i], m_spot_height[i],
						&dcMem, 0, 0, 1, 1, SRCCOPY );
	}

	m_bitmap->SetBitmapBits(sizeof(COLORREF)*w*h, m_display_buffer);

	int view_l, view_t, view_w, view_h, view_r;
	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		int x = m_peak[i].x;
		int y = m_peak[i].y;
		if ( x < 0 || y < 0 )	continue;

		view_r = (int) ceil( m_radius[i] * 4 * 1.0 / 3 );
        view_w = view_h = 2*view_r + 1;

		DrawCircle(dcMem, x, y, m_radius[i]);
		
        if ( x - view_r	< 0 )	view_l = 0;
		else if ( x + view_r >= (int)w )	view_l = w - 1 - view_w;
		else	view_l = x - view_r;
		if ( y - view_r < 0 )	view_t = 0;
		else if ( y + view_r >= (int)h )	view_t = h - 1 - view_h;
		else	view_t = y - view_r;
		dcDlg.StretchBlt( m_spot_left[i], m_spot_top[i], m_spot_width[i], m_spot_height[i],
							&dcMem, view_l, view_t, view_w, view_h, SRCCOPY );
	}

	//	dcDlg.SetStretchBltMode(COLORONCOLOR);
	dcDlg.StretchBlt( m_image_left, m_image_top, m_image_width, m_image_height,
						&dcMem, 0, 0, w, h, SRCCOPY);
	dcMem.SelectObject(pOldBitmap);
	dcMem.DeleteDC();

	UpdateData(FALSE);
	return;
}

void CTraceDialog::BuildTrace()
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	UINT num_frames = m_film.m_num_frames;
	if ( num_frames <= 0 )	return;

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		if ( m_peak[i].x < 0 || m_peak[i].y < 0 )	return;

	double factor;
	CString XCaption;
	if ( m_film.m_frame_cycle > ZERO_TOLERANCE )
	{
		factor = m_film.m_frame_cycle * SECOND_PER_MILLISECOND ;
		XCaption = _T("Time [s]");
		m_intensity_xscale = m_FRET_xscale = ceil( factor * num_frames * 1.0 / TRACE_H_DIV * 10 ) / 10;
	}
	else
	{
		factor = 1.0;
		XCaption = _T("Frame [.]");
		m_intensity_xscale = m_FRET_xscale = ceil( num_frames * 1.0 / TRACE_H_DIV );
	}

	CWnd *pWnd;
	pWnd = GetDlgItem(IDC_INTENSITY_XCAPTION);
	if ( pWnd )	pWnd->SetWindowText( XCaption );
	pWnd = GetDlgItem(IDC_FRET_XCAPTION);
	if ( pWnd )	pWnd->SetWindowText( XCaption );


	double emission[NUM_CHANNELS];
	double background[NUM_CHANNELS];
	double intensity_max = 0.0;
	if ( m_CH1 )	delete [] m_CH1;
	m_CH1 = NULL;
	if ( m_CH2 )	delete [] m_CH2;
	m_CH2 = NULL;
	if ( m_bg1 )	delete [] m_bg1;
	m_bg1 = NULL;
	if ( m_bg2 )	delete [] m_bg2;
	m_bg2 = NULL;


	m_CH1 = new double[num_frames];
	m_CH2 = new double[num_frames];
	m_bg1 = new double[num_frames];
	m_bg2 = new double[num_frames];
	memset(m_CH1, 0, sizeof(double)*num_frames);
	memset(m_CH2, 0, sizeof(double)*num_frames);
	memset(m_bg1, 0, sizeof(double)*num_frames);
	memset(m_bg2, 0, sizeof(double)*num_frames);

	m_bg1_base = 0.0;
	m_bg2_base = 0.0;

	int cnt = 0;
	double bg1sum = 0.0;
	double bg2sum = 0.0;

	if ( m_film.m_trace )
	{
		if ( m_peak_no < 0 || (int)m_film.m_trace->m_num_peaks <= m_peak_no )
		{
			LogErr(_T("Select a valid peak number."));
			return;
		}

		for ( UINT frame_no = 0 ; frame_no < num_frames ; frame_no++ )
		{
			m_CH1[frame_no] = m_film.m_trace->Signal( CH1, m_peak_no, frame_no );
			m_bg1[frame_no] = m_film.m_trace->Background( CH1, m_peak_no, frame_no );
			m_CH2[frame_no] = m_film.m_trace->Signal( CH2, m_peak_no, frame_no );
			m_bg2[frame_no] = m_film.m_trace->Background( CH2, m_peak_no, frame_no );

			cnt ++;
			bg1sum += m_bg1[frame_no];
			bg2sum += m_bg2[frame_no];
			m_bg1_base = bg1sum/cnt;
			m_bg2_base = bg2sum/cnt;

			if ( intensity_max < (m_CH1[frame_no]-m_bg1[frame_no]) )	intensity_max = (m_CH1[frame_no]-m_bg1[frame_no]);
			if ( intensity_max < (m_CH2[frame_no]-m_bg2[frame_no]) )	intensity_max = (m_CH2[frame_no]-m_bg2[frame_no]);
		}
		if ( m_flat_background )
		{
			for ( UINT frame_no = 0 ; frame_no < num_frames ; frame_no++ )
			{
				m_bg1[frame_no] = m_bg1_base;
				m_bg2[frame_no] = m_bg2_base;
			}
		}
	}
	else
	{
		m_film.MoveFrame(0);

		double peak_sigma[NUM_CHANNELS];
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			peak_sigma[i] = m_radius[i] * 1.0 / Z_VALUE ;

        for ( UINT frame_no = 0 ; frame_no < num_frames ; frame_no++ )
		{
			if ( !::IsWindow(m_hWnd) )	return;
			
			m_film.MoveFrame(frame_no);
			m_film.ReadFrame(NULL);
		
            for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
			{
				double sig = 0.0;
				double bg = 0.0;
				CCAQClient::AnalyzePeak( w, h, m_film.m_frame, CCAQClient::DFRAME,
										(double)m_peak[i].x, (double)m_peak[i].y, peak_sigma[i],
										NULL, NULL, &sig, &bg );
                emission[i] = sig;
				background[i] = bg;
			}

			m_CH1[frame_no] = emission[CH1];
			m_bg1[frame_no] = background[CH1];
			m_CH2[frame_no] = emission[CH2];
			m_bg2[frame_no] = background[CH2];

			cnt ++;
			bg1sum += m_bg1[frame_no];
			bg2sum += m_bg2[frame_no];
			m_bg1_base = bg1sum/cnt;
			m_bg2_base = bg2sum/cnt;

			if ( intensity_max < (m_CH1[frame_no]-m_bg1[frame_no]) )	intensity_max = (m_CH1[frame_no]-m_bg1[frame_no]);
			if ( intensity_max < (m_CH2[frame_no]-m_bg2[frame_no]) )	intensity_max = (m_CH2[frame_no]-m_bg2[frame_no]);

			m_intensity_xoffset = 0.5 * TRACE_H_DIV * m_intensity_xscale;
			m_FRET_xoffset = 0.5 * TRACE_H_DIV * m_FRET_xscale;

			m_intensity_yscale = fabs( ceil( TRACE_OVERSHOOT * intensity_max / TRACE_V_DIV ) );
			m_intensity_yoffset = 0.5 * TRACE_V_DIV * m_intensity_yscale ;
			m_FRET_yscale = 0.25;
			m_FRET_yoffset = 0.5;

			DrawIntensity();
			DrawFRET();

			if ( !::IsWindow(m_hWnd) )	return;

			MSG message;		
			//if(::PeekMessage(&message,NULL,0,0,PM_REMOVE)){
			while (::PeekMessage(&message,NULL,0,0,PM_REMOVE))
			{
				if ( !IsDialogMessage(&message) )
				{
					::TranslateMessage(&message);
					::DispatchMessage(&message);
				}
			}
			if ( ::IsWindow(m_hWnd) )	UpdateWindow();
		}
	}

	m_intensity_xoffset = 0.5 * TRACE_H_DIV * m_intensity_xscale;
	m_FRET_xoffset = 0.5 * TRACE_H_DIV * m_FRET_xscale;

	m_intensity_yscale = fabs( ceil( TRACE_OVERSHOOT * intensity_max / TRACE_V_DIV ) );
	m_intensity_yoffset = 0.5 * TRACE_V_DIV * m_intensity_yscale ;
	m_FRET_yscale = 0.25;
	m_FRET_yoffset = 0.5;

	DrawIntensity();
	DrawFRET();

	return;
}


void CTraceDialog::DrawIntensity()
{
	if ( !m_film.IsOpen() )	return;
	UINT num_frames = m_film.m_num_frames;
	if ( num_frames <= 0 )	return;

	if ( !m_CH1 || !m_CH2 || !m_bg1 || !m_bg2 )	return;

	CClientDC dcDlg (this);
	CDC dcMem;
	CBitmap bitmap;

	bitmap.CreateCompatibleBitmap(&dcDlg, m_intensity_width, m_intensity_height);
	dcMem.CreateCompatibleDC (&dcDlg);
	dcMem.SelectObject (&bitmap);
	CBrush WhiteBrush (RGB (255, 255, 255));
	dcMem.FillRect (CRect(0,0,m_intensity_width, m_intensity_height),&WhiteBrush);

	int v_div = TRACE_V_DIV;
	int h_div = TRACE_H_DIV;
	CPen GrayPen(PS_SOLID, 1, RGB(200,200,200));	
	dcMem.SelectObject(&GrayPen);
	for ( int i = 1 ; i < v_div ; i++ )
	{
		dcMem.MoveTo(0, m_intensity_height * i / v_div );
		dcMem.LineTo(m_intensity_width, m_intensity_height * i / v_div );
	}
	for ( int i = 1 ; i < h_div ; i++ )
	{
		dcMem.MoveTo( m_intensity_width * i / h_div , 0 );
		dcMem.LineTo( m_intensity_width * i / h_div , m_intensity_height );
	}

	dcDlg.SelectObject(	this->GetFont() );
	TEXTMETRIC textMetric;	
	dcDlg.GetTextMetrics(&textMetric);
	RECT rect;
	this->GetClientRect(&rect);
	CBrush BgndBrush( GetSysColor(COLOR_3DFACE) );
	dcDlg.FillRect( CRect( m_intensity_left + m_intensity_width, m_intensity_top - textMetric.tmHeight, 
							rect.right, m_intensity_top + m_intensity_height ), 
					&BgndBrush );
	dcDlg.FillRect( CRect( m_image_left + m_image_width, m_intensity_top + m_intensity_height, 
							rect.right, m_intensity_top + m_intensity_height + textMetric.tmHeight ), 
					&BgndBrush );


	CString str;
	dcDlg.SetBkMode( OPAQUE );
	dcDlg.SetBkColor( GetSysColor(COLOR_3DFACE) );

	dcDlg.SetTextAlign( TA_BASELINE | TA_LEFT );
	for ( int i = 0 ; i <= v_div ; i++ )
	{
		str.Format(_T("%.0f"), m_intensity_yoffset - m_intensity_yscale * (i - 0.5*v_div) );
		dcDlg.TextOut( m_intensity_left + m_intensity_width, m_intensity_top + m_intensity_height * i / v_div, str );
	}
	dcDlg.SetTextAlign( TA_TOP | TA_CENTER ); 
	for ( int i = 0 ; i <= h_div ; i++ )
	{
		str.Format(_T("%.3f"), m_intensity_xoffset + m_intensity_xscale * (i - 0.5*h_div) );
		dcDlg.TextOut( m_intensity_left + m_intensity_width * i / h_div, m_intensity_top + m_intensity_height, str );
	}

	double factor = m_film.m_frame_cycle * SECOND_PER_MILLISECOND ;
	if ( factor < ZERO_TOLERANCE )	factor = 1.0;

	double lx = m_intensity_xoffset - 0.5 * TRACE_H_DIV * m_intensity_xscale;
	double rx = m_intensity_xoffset + 0.5 * TRACE_H_DIV * m_intensity_xscale;
	double by = m_intensity_yoffset - 0.5 * TRACE_V_DIV * m_intensity_yscale;
	double ty = m_intensity_yoffset + 0.5 * TRACE_V_DIV * m_intensity_yscale;


	CPen YellowPen(PS_SOLID, 1, RGB(128, 128, 0));
	dcMem.SelectObject(&YellowPen);
	int current_pos = (int) ( m_intensity_width*(factor*m_slider.GetPos()-lx)/(rx-lx) );
	dcMem.MoveTo( current_pos, 0 );
	dcMem.LineTo( current_pos, m_intensity_height );
	
	if ( m_show_total )
	{
		CPen BlackPen(PS_SOLID, 1, RGB (0, 0, 0));
		dcMem.SelectObject(&BlackPen);
		dcMem.MoveTo( (int) ( m_intensity_width*(0-lx)/(rx-lx) ), 
					(int) ( m_intensity_height*( ty - (m_CH1[0]+m_CH2[0]-m_bg1[0]-m_bg2[0]) )/(ty-by) ) );
		for ( UINT i = 0 ; i < num_frames ; i++ )
			dcMem.LineTo( (int) ( m_intensity_width*(factor*i-lx)/(rx-lx) ), 
						(int) ( m_intensity_height*( ty - (m_CH1[i]+m_CH2[i]-m_bg1[i]-m_bg2[i]) )/(ty-by) ) );
	}

    CPen GreenPen(PS_SOLID, 1, RGB (0, 128, 0));
	dcMem.SelectObject(&GreenPen);
	dcMem.MoveTo( (int) ( m_intensity_width*(0-lx)/(rx-lx) ), 
				(int) ( m_intensity_height*( ty - (m_CH1[0]-m_bg1[0]) )/(ty-by) ) );
	for ( UINT i = 0 ; i < num_frames ; i++ )
		dcMem.LineTo( (int) ( m_intensity_width*(factor*i-lx)/(rx-lx) ), 
					(int) ( m_intensity_height*( ty - (m_CH1[i]-m_bg1[i]) )/(ty-by) ) );

	CPen RedPen(PS_SOLID, 1, RGB (255, 0, 0));
	dcMem.SelectObject(&RedPen);
	dcMem.MoveTo( (int) ( m_intensity_width*(0-lx)/(rx-lx) ), 
				(int) ( m_intensity_height*( ty - (m_CH2[0]-m_bg2[0]) )/(ty-by) ) );
	for ( UINT i = 0 ; i < num_frames ; i++ )
		dcMem.LineTo( (int) ( m_intensity_width*(factor*i-lx)/(rx-lx) ), 
					(int) ( m_intensity_height*( ty - (m_CH2[i]-m_bg2[i]) )/(ty-by) ) );

	if ( m_show_background )
	{
		CPen LGreenPen(PS_SOLID, 1, RGB (128, 255, 128));
		dcMem.SelectObject(&LGreenPen);
		dcMem.MoveTo( (int) ( m_intensity_width*(0-lx)/(rx-lx) ), 
					(int) ( m_intensity_height*( ty - (m_bg1[0]-m_bg1_base) )/(ty-by) ) );
		for ( UINT i = 0 ; i < num_frames ; i++ )
			dcMem.LineTo( (int) ( m_intensity_width*(factor*i-lx)/(rx-lx) ), 
						(int) ( m_intensity_height*( ty - (m_bg1[i]-m_bg1_base) )/(ty-by) ) );
		
        CPen LRedPen(PS_SOLID, 1, RGB (255, 128, 128));
		dcMem.SelectObject(&LRedPen);
		dcMem.MoveTo( (int) ( m_intensity_width*(0-lx)/(rx-lx) ), 
					(int) ( m_intensity_height*( ty - (m_bg2[0]-m_bg2_base) )/(ty-by) ) );
		for ( UINT i = 0 ; i < num_frames ; i++ )
			dcMem.LineTo( (int) ( m_intensity_width*(factor*i-lx)/(rx-lx) ), 
						(int) ( m_intensity_height*( ty - (m_bg2[i]-m_bg2_base) )/(ty-by) ) );
	}
	
	dcDlg.BitBlt(m_intensity_left, m_intensity_top, m_intensity_width, m_intensity_height, &dcMem,0,0,SRCCOPY);

//	if ( GetIntensityCoordinate(m_from, NULL, NULL) && GetIntensityCoordinate(m_to, NULL, NULL) )
	if ( GetIntensityCoordinate(m_from, NULL, NULL) )
	{
		CPoint to = m_to;
		if ( to.x < m_intensity_left )	to.x = m_intensity_left;
		else if ( to.x > m_intensity_left + m_intensity_width )	to.x = m_intensity_left + m_intensity_width;
		if ( to.y < m_intensity_top )	to.y = m_intensity_top;
		if ( to.y > m_intensity_top + m_intensity_height )	to.y = m_intensity_top + m_intensity_height;
		dcDlg.MoveTo(m_from);
		dcDlg.LineTo(m_from.x, to.y);
		dcDlg.LineTo(to);
		dcDlg.LineTo(to.x, m_from.y);
		dcDlg.LineTo(m_from);
	}

}

void CTraceDialog::DrawFRET()
{
	if ( !m_film.IsOpen() )	return;
	UINT num_frames = m_film.m_num_frames;
	if ( num_frames <= 0 )	return;

	if ( !m_CH1 || !m_CH2 || !m_bg1 || !m_bg2 )	return;

	CClientDC dcDlg (this);
	CDC dcMem;
	CBitmap bitmap;

	bitmap.CreateCompatibleBitmap(&dcDlg, m_FRET_width, m_FRET_height);
	dcMem.CreateCompatibleDC (&dcDlg);
	
	CBrush WhiteBrush (RGB (255, 255, 255));
	CPen GrayPen(PS_SOLID, 1, RGB(200,200,200));
	
	dcMem.SelectObject (&bitmap);
	dcMem.FillRect (CRect(0,0,m_FRET_width, m_FRET_height),&WhiteBrush);

	dcMem.SelectObject(&GrayPen);
	
	int v_div = TRACE_V_DIV;
	int h_div = TRACE_H_DIV;

	for ( int i = 1 ; i < v_div ; i++ )
	{
		dcMem.MoveTo(0, m_FRET_height * i / v_div );
		dcMem.LineTo(m_FRET_width, m_FRET_height * i / v_div );
		
	}
	for ( int i = 1 ; i < h_div ; i++ )
	{
		dcMem.MoveTo( m_FRET_width * i / h_div , 0 );
		dcMem.LineTo( m_FRET_width * i / h_div , m_FRET_height );
	}

	dcDlg.SelectObject(	this->GetFont() );
	TEXTMETRIC textMetric;	
	dcDlg.GetTextMetrics(&textMetric);
	RECT rect;
	this->GetClientRect(&rect);
	CBrush BgndBrush( GetSysColor(COLOR_3DFACE) );
	dcDlg.FillRect( CRect( m_FRET_left + m_FRET_width, m_FRET_top - textMetric.tmHeight, 
							rect.right, m_FRET_top + m_FRET_height ), 
					&BgndBrush );
	dcDlg.FillRect( CRect( m_image_left + m_image_width, m_FRET_top + m_FRET_height, 
							rect.right, m_FRET_top + m_FRET_height + textMetric.tmHeight ), 
					&BgndBrush );

	CString str;
	dcDlg.SetBkMode( OPAQUE );
	dcDlg.SetBkColor( GetSysColor(COLOR_3DFACE) );

	dcDlg.SetTextAlign( TA_BASELINE | TA_LEFT );
	for ( int i = 0 ; i <= v_div ; i++ )
	{
		str.Format(_T("%.2f"), m_FRET_yoffset - m_FRET_yscale * (i - 0.5*v_div) );
		dcDlg.TextOut( m_FRET_left + m_FRET_width, m_FRET_top + m_FRET_height * i / v_div, str );
	}
	dcDlg.SetTextAlign( TA_TOP | TA_CENTER ); 
	for ( int i = 0 ; i <= h_div ; i++ )
	{
		str.Format(_T("%.3f"), m_FRET_xoffset + m_FRET_xscale * (i - 0.5*h_div) );
		dcDlg.TextOut( m_FRET_left + m_FRET_width * i / h_div, m_FRET_top + m_FRET_height, str );
	}

	double factor = m_film.m_frame_cycle * SECOND_PER_MILLISECOND ;
	if ( factor < ZERO_TOLERANCE )	factor = 1.0;


	double lx = m_FRET_xoffset - 0.5 * TRACE_H_DIV * m_FRET_xscale;
	double rx = m_FRET_xoffset + 0.5 * TRACE_H_DIV * m_FRET_xscale;
	double by = m_FRET_yoffset - 0.5 * TRACE_V_DIV * m_FRET_yscale;
	double ty = m_FRET_yoffset + 0.5 * TRACE_V_DIV * m_FRET_yscale;

	CPen YellowPen(PS_SOLID, 1, RGB(128, 128, 0));
	dcMem.SelectObject(&YellowPen);
	int current_pos = (int) ( m_FRET_width*(factor*m_slider.GetPos()-lx)/(rx-lx) );
	dcMem.MoveTo( current_pos, 0 );
	dcMem.LineTo( current_pos, m_FRET_height );


	double ch1, ch2;
	CPen BluePen(PS_SOLID, 1, RGB (0, 0, 255));
	dcMem.SelectObject(&BluePen);

	ch1 = REAL_CH1( m_CH1[0]-m_bg1[0], m_CH2[0]-m_bg2[0] );
	ch2 = REAL_CH2( m_CH1[0]-m_bg1[0], m_CH2[0]-m_bg2[0] );
	dcMem.MoveTo( (int) ( m_FRET_width*(0-lx)/(rx-lx) ), 
				(int) ( m_FRET_height*( ty - (ch2/(ch1+ch2)) )/(ty-by) ) );
	for ( UINT i = 0 ; i < num_frames ; i++ )
	{
		ch1 = REAL_CH1( m_CH1[i]-m_bg1[i], m_CH2[i]-m_bg2[i] );
		ch2 = REAL_CH2( m_CH1[i]-m_bg1[i], m_CH2[i]-m_bg2[i] );
		dcMem.LineTo( (int) ( m_FRET_width*(factor*i-lx)/(rx-lx) ), 
					(int) ( m_FRET_height*( ty - (ch2/(ch1+ch2)) )/(ty-by) ) );
	}

	dcDlg.BitBlt(m_FRET_left, m_FRET_top, m_FRET_width, m_FRET_height, &dcMem,0,0,SRCCOPY);

	//if ( GetFRETCoordinate(m_from, NULL, NULL) && GetFRETCoordinate(m_to, NULL, NULL) )
	if ( GetFRETCoordinate(m_from, NULL, NULL) )
	{
		CPoint to = m_to;
		if ( to.x < m_FRET_left )	to.x = m_FRET_left;
		else if ( to.x > m_FRET_left + m_FRET_width )	to.x = m_FRET_left + m_FRET_width;
		if ( to.y < m_FRET_top )	to.y = m_FRET_top;
		if ( to.y > m_FRET_top + m_FRET_height )	to.y = m_FRET_top + m_FRET_height;

		dcDlg.MoveTo(m_from);
		dcDlg.LineTo(m_from.x, to.y);
		dcDlg.LineTo(to);
		dcDlg.LineTo(to.x, m_from.y);
		dcDlg.LineTo(m_from);
	}
}




BEGIN_MESSAGE_MAP(CTraceDialog, CDialog)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_OPEN, OnBnClickedOpen)
	ON_BN_CLICKED(IDC_BUILD, OnBnClickedBuild)
	ON_BN_CLICKED(IDC_SAVE, OnBnClickedSave)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX1, OnDeltaposSpinx1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY1, OnDeltaposSpiny1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR1, OnDeltaposSpinr1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINX2, OnDeltaposSpinx2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINY2, OnDeltaposSpiny2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINR2, OnDeltaposSpinr2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_INTENSITY_YSCALE, OnDeltaposIntensityYscale)
	ON_NOTIFY(UDN_DELTAPOS, IDC_INTENSITY_YOFFSET, OnDeltaposIntensityYoffset)
	ON_NOTIFY(UDN_DELTAPOS, IDC_INTENSITY_XOFFSET, OnDeltaposIntensityXoffset)
	ON_NOTIFY(UDN_DELTAPOS, IDC_FRET_YSCALE, OnDeltaposFRETYscale)
	ON_NOTIFY(UDN_DELTAPOS, IDC_FRET_YOFFSET, OnDeltaposFRETYoffset)
	ON_NOTIFY(UDN_DELTAPOS, IDC_FRET_XOFFSET, OnDeltaposFRETXoffset)
	ON_EN_KILLFOCUS(IDC_F0_FSUM_RATIO, OnEnKillfocusF0FsumRatio)
	ON_EN_KILLFOCUS(IDC_I1_CH1, OnEnKillfocusI1CH1)
	ON_EN_KILLFOCUS(IDC_I2_CH1, OnEnKillfocusI2CH1)
	ON_EN_KILLFOCUS(IDC_PEAK_NO, OnEnKillfocusPeakNo)
	ON_NOTIFY(UDN_DELTAPOS, IDC_PEAK_NO_SPIN, OnDeltaposPeakNoSpin)
	ON_BN_CLICKED(IDC_LOAD_MAP, OnBnClickedLoadMap)
	ON_BN_CLICKED(IDC_MAP12, OnBnClickedMap12)
	ON_BN_CLICKED(IDC_MAP21, OnBnClickedMap21)
	ON_WM_LBUTTONUP()
	ON_BN_CLICKED(IDC_SHOW_TOTAL, OnBnClickedShowTotal)
	ON_BN_CLICKED(IDC_SHOW_BACKGROUND, OnBnClickedShowBackground)
	ON_BN_CLICKED(IDC_FLAT_BACKGROUND, OnBnClickedFlatBackground)
END_MESSAGE_MAP()


// CTraceDialog message handlers

void CTraceDialog::OnLButtonDown(UINT nFlags, CPoint point)
{
	if ( !m_film.IsOpen() )	return;
	
	int x, y;
	if ( GetFrameCoordinate(point, &x, &y) != TRUE )	return;
    m_peak[CH1].SetPoint( x, y );


	int w = m_film.m_frame_w;
	int h = m_film.m_frame_h;
	CChannels ch( w, h );

	if ( (int)ch.l[CH1] <= x && x <= (int)ch.r[CH1] )
	{
		m_peak[CH1].SetPoint( x , y );
		int x2 = ch.l[CH2] + (x - ch.l[CH1]);
		int y2 = y;
		m_peak[CH2].SetPoint( x2, y2 );
	}
	else if ( (int)ch.l[CH2] <= x && x <= (int)ch.r[CH2] )
	{
		m_peak[CH2].SetPoint( x, y );
		int x1 = ch.l[CH1] + (x - ch.l[CH2]);
		int y1 = y;
		m_peak[CH1].SetPoint( x1, y1 );
	}

	m_peak_no = -1;
	UpdateFrame();
	CDialog::OnLButtonDown(nFlags, point);
}


void CTraceDialog::OnRButtonDown(UINT nFlags, CPoint point)
{
	if ( !m_film.IsOpen() )	return;

	int x, y;
	if ( GetFrameCoordinate(point, &x, &y) != TRUE )	return;
	m_peak[CH2].SetPoint( x, y );

	m_peak_no = -1;
	UpdateFrame();	
	CDialog::OnRButtonDown(nFlags, point);
}


void CTraceDialog::OnMouseMove(UINT nFlags, CPoint point)
{
	if ( !m_film.IsOpen() )	return;

	if ( nFlags & MK_SHIFT )
	{
		m_from.SetPoint(-1, -1);
		m_to.SetPoint(-1, -1);
		if ( GetIntensityCoordinate(point, NULL, NULL) || GetFRETCoordinate(point, NULL, NULL) )
		{
			UINT num_frames = m_film.m_num_frames;
			double frame_cycle = m_film.m_frame_cycle;

			if ( frame_cycle > ZERO_TOLERANCE )
				m_intensity_xscale = m_FRET_xscale = ceil( frame_cycle * SECOND_PER_MILLISECOND * num_frames * 1.0 / TRACE_H_DIV * 10 ) / 10;
			else
				m_intensity_xscale = m_FRET_xscale = ceil( num_frames * 1.0 / TRACE_H_DIV );

			m_intensity_xoffset = 0.5 * TRACE_H_DIV * m_intensity_xscale;
			m_FRET_xoffset = 0.5 * TRACE_H_DIV * m_FRET_xscale;
			DrawIntensity();
			DrawFRET();
		}
	}
	else if ( nFlags & MK_LBUTTON )
	{
		m_to.SetPoint(point.x, point.y);
		if ( GetIntensityCoordinate(m_from, NULL, NULL) )
			DrawIntensity();
		else if ( GetFRETCoordinate(m_from, NULL, NULL) )
			DrawFRET();
		else
		{
			if ( GetIntensityCoordinate(point, NULL, NULL) )
				m_from.SetPoint(point.x, point.y);
			else if ( GetFRETCoordinate(point, NULL, NULL) )
				m_from.SetPoint(point.x, point.y);
		}
	}
	else
	{
		m_from.SetPoint(-1, -1);
		m_to.SetPoint(-1, -1);

	}

	CDialog::OnMouseMove(nFlags, point);
}



void CTraceDialog::OnLButtonUp(UINT nFlags, CPoint point)
{
	int x1, x2;
	BOOL intensity_flag = FALSE, FRET_flag = FALSE;
	
	if ( GetIntensityCoordinate(m_from, &x1, NULL) )
	{
		intensity_flag = TRUE;
		GetIntensityCoordinate(m_to, &x2, NULL);
	}
	else if ( GetFRETCoordinate(m_from, &x1, NULL) )
	{
		FRET_flag = TRUE;
		GetFRETCoordinate(m_to, &x2, NULL);
	}		

	m_from.SetPoint(-1, -1);
	m_to.SetPoint(-1, -1);

	if ( intensity_flag )
	{
		m_intensity_xoffset +=  ( (x1+x2)*0.5/m_intensity_width - 0.5 ) * m_intensity_xscale * TRACE_H_DIV;
		m_intensity_xscale *= abs(x1-x2) * 1.0 / m_intensity_width;
		m_FRET_xoffset = m_intensity_xoffset;
		m_FRET_xscale = m_intensity_xscale;
		DrawIntensity();
		DrawFRET();
	}
	else if ( FRET_flag )
	{
		m_FRET_xoffset +=  ( (x1+x2)*0.5/m_FRET_width - 0.5 ) * m_FRET_xscale * TRACE_H_DIV;
		m_FRET_xscale *= abs(x1-x2) * 1.0 / m_FRET_width;
		m_intensity_xoffset = m_FRET_xoffset;
		m_intensity_xscale = m_FRET_xscale;
		DrawIntensity();
		DrawFRET();
	}

	CDialog::OnLButtonUp(nFlags, point);
}


void CTraceDialog::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if ( !m_film.IsOpen() )	return;
	if ( pScrollBar != (CScrollBar*)&m_slider )	return;

	m_film.MoveFrame(m_slider.GetPos());
	m_film.ReadFrame(NULL);
	m_film.DrawFrame(m_display_buffer);
	UpdateFrame();
	DrawIntensity();
	DrawFRET();
	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CTraceDialog::OnDeltaposSpinx1(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;

	int x = m_peak[CH1].x;
	int y = m_peak[CH1].y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	x++;
	else	x--;

	if ( x >= (int)w )	x = w-1;
	if ( x < 0 )	x = 0;

	m_peak[CH1].x = x;
	UpdateFrame();
	*pResult = 0;
}

void CTraceDialog::OnDeltaposSpiny1(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() )	return;
	UINT h = m_film.m_frame_h;

	int x = m_peak[CH1].x;
	int y = m_peak[CH1].y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	y--;
	else	y++;

	if ( y >= (int)h )	y = h-1;
	if ( y < 0 )	y = 0;

	m_peak[CH1].y = y;
	UpdateFrame();
	*pResult = 0;
}

void CTraceDialog::OnDeltaposSpinr1(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_radius[CH1]++;
	else	m_radius[CH1]--;

	int max_radius = ( w < h ) ? (w/2-1) : (h/2-1);
	if ( m_radius[CH1] > max_radius )	m_radius[CH1] = max_radius;
	if ( m_radius[CH1] < 1 )	m_radius[CH1] = 1;

	UpdateFrame();
	*pResult = 0;
}

void CTraceDialog::OnDeltaposSpinx2(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;

	int x = m_peak[CH2].x;
	int y = m_peak[CH2].y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	x++;
	else	x--;

	if ( x >= (int)w )	x = w-1;
	if ( x < 0 )	x = 0;

	m_peak[CH2].x = x;
	UpdateFrame();
	*pResult = 0;
}

void CTraceDialog::OnDeltaposSpiny2(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() )	return;
	UINT h = m_film.m_frame_h;

	int x = m_peak[CH2].x;
	int y = m_peak[CH2].y;
	if ( x < 0 || y < 0 )	return;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	y--;
	else	y++;

	if ( y >= (int)h )	y = h-1;
	if ( y < 0 )	y = 0;

	m_peak[CH2].y = y;
	UpdateFrame();
	*pResult = 0;
}

void CTraceDialog::OnDeltaposSpinr2(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_radius[CH2]++;
	else	m_radius[CH2]--;

	int max_radius = ( w < h ) ? (w/2-1) : (h/2-1);
	if ( m_radius[CH2] > max_radius )	m_radius[CH2] = max_radius;
	if ( m_radius[CH2] < 1 )	m_radius[CH2] = 1;

	UpdateFrame();
	*pResult = 0;
}

void CTraceDialog::OnBnClickedOpen()
{
	CString szFilters;
	szFilters.Format(_T("Trace Files (*.%s)|*.%s|"
						"Trace Files (*.%s)|*.%s|"
						"Trace Files (*.%s)|*.%s|"
						"Trace Files (*.%s)|*.%s|"
						"Film & TIFF Files (*.%s;*.%s;*.%s;*.%s)|*.%s; *.%s; *.%s; *.%s|"
						"All Files (*.*)|*.*||"),
						CAMERAFILE_TRACE_EXT, CAMERAFILE_TRACE_EXT,						
						CAMERAFILE_TRACE2_EXT, CAMERAFILE_TRACE2_EXT,						
						CAMERAFILE_BGTRACE_EXT, CAMERAFILE_BGTRACE_EXT,						
						CAMERAFILE_BGTRACE2_EXT, CAMERAFILE_BGTRACE2_EXT,						
						CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT,						
						CAMERAFILE_FILM_EXT, CAMERAFILE_OLDFILM_EXT, CAMERAFILE_TIFF1_EXT, CAMERAFILE_TIFF2_EXT );
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path;
	if( fileDlg.DoModal () != IDOK )	return;

	m_peak_no = -1;
	m_film.Close();
	if ( m_film.Open( fileDlg.GetPathName() ) < 0 )
	{
		LogErr(Stringify(_T("Open File[%s] Failed."), fileDlg.GetPathName()));
		return;		
	}

	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	InitFrame( w, h );

	m_film.ReadFrame(NULL);
	m_film.DrawFrame( m_display_buffer );
	UpdateFrame();
	m_film.MoveFrame(0);

	m_slider.SetRange( 0, (int)m_film.m_num_frames - 1, TRUE );
	int pagesize = (int) ceil( m_film.m_num_frames * 1.0 / 100 );
	if ( pagesize <= 0 )	pagesize = 1;
	m_slider.SetPageSize(pagesize);
	m_slider.SetPos(0);

	CWnd *pWnd;
	pWnd = GetDlgItem(IDC_BUILD);
	if ( pWnd )	pWnd->EnableWindow(TRUE);
	pWnd = GetDlgItem(IDC_SAVE);
	if ( pWnd )	pWnd->EnableWindow(TRUE);
	pWnd = GetDlgItem(IDC_FRAME_SLIDER);
	if ( pWnd )	pWnd->EnableWindow(TRUE);
	pWnd = GetDlgItem(IDC_FILEPATH);
	if ( pWnd )
	{
		pWnd->SetWindowText( m_film.m_filepath );
		((CEdit*)pWnd)->SetSel(0, -1);
	}

	int n;
	CString path = m_film.m_filepath;

	n = path.ReverseFind((TCHAR)'\\');
	if ( n < 0 )	n = 0;
	path = path.Mid(0, n);
	m_directory.SetPath(path);
}

void CTraceDialog::OnBnClickedBuild()
{
	BuildTrace();
	return;
}

void CTraceDialog::OnBnClickedSave()
{
	if ( !m_film.IsOpen() )	return;
	UINT w = m_film.m_frame_w;
	UINT h = m_film.m_frame_h;
	UINT num_frames = m_film.m_num_frames;
	if ( num_frames <= 0 )	return;

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		if ( m_peak[i].x < 0 || m_peak[i].y < 0 )	return;

	if ( !m_CH1 || !m_CH2 || !m_bg1 || !m_bg2 )		return;


	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(FALSE, NULL, NULL, OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = m_directory.m_path;
	if ( fileDlg.DoModal ()!=IDOK )	return;



	CString str;
	CArchive *ar = OpenProgramFileToWrite( fileDlg.GetPathName(), TRUE );
	if ( ar == NULL )	return;

	double factor;
	if ( m_film.m_frame_cycle > ZERO_TOLERANCE )
	{
		factor = m_film.m_frame_cycle * SECOND_PER_MILLISECOND ;
		str.Format(_T("Time [s]"));
	}
	else
	{
		factor = 1.0;
		str.Format(_T("Frame [.]"));
	}
	str.AppendFormat(_T(" \t CH1 \t BGND1 \t CH2 \t BGND2 \r\n"));
	ar->WriteString(str);

	for ( UINT i = 0 ; i < num_frames ; i++ )
	{
		str.Format(_T("%.3f \t %.0f \t %.0f \t %.0f \t %.0f \r\n"), 
					i * factor, m_CH1[i], m_bg1[i], m_CH2[i], m_bg2[i]);
		ar->WriteString(str);
	}

	CloseProgramFile(ar);
	return;
}

void CTraceDialog::OnDeltaposIntensityYscale(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	double new_scale = LIMIT_DECIMAL_PLACES( ScaleToNewValue( m_intensity_yscale, ( pNMUpDown->iDelta < 0 ) ), 0 );
	if ( new_scale > ZERO_TOLERANCE )	m_intensity_yscale = new_scale;

	double f = m_intensity_yoffset/m_intensity_yscale;
	if ( fabs(f-floor(f)) < fabs(f-ceil(f)) )	
		m_intensity_yoffset = floor(f)*m_intensity_yscale;
	else	
		m_intensity_yoffset = ceil(f)*m_intensity_yscale;	

	*pResult = 0;
	DrawIntensity();
}

void CTraceDialog::OnDeltaposIntensityYoffset(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )
		m_intensity_yoffset -= m_intensity_yscale;
	else
		m_intensity_yoffset += m_intensity_yscale;
	*pResult = 0;
	DrawIntensity();
}

void CTraceDialog::OnDeltaposIntensityXoffset(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )
		m_intensity_xoffset += m_intensity_xscale;
	else
		m_intensity_xoffset -= m_intensity_xscale;
	*pResult = 0;
	m_FRET_xoffset = m_intensity_xoffset;
	DrawIntensity();
	DrawFRET();
}

void CTraceDialog::OnDeltaposFRETYscale(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	double new_scale = LIMIT_DECIMAL_PLACES( ScaleToNewValue( m_FRET_yscale, ( pNMUpDown->iDelta < 0 ) ), 2 );
	if ( new_scale > ZERO_TOLERANCE )	m_FRET_yscale = new_scale;
	*pResult = 0;
	DrawFRET();
}

void CTraceDialog::OnDeltaposFRETYoffset(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )
		m_FRET_yoffset -= m_FRET_yscale;
	else
		m_FRET_yoffset += m_FRET_yscale;
	*pResult = 0;
	DrawFRET();
}

void CTraceDialog::OnDeltaposFRETXoffset(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )
		m_FRET_xoffset += m_FRET_xscale;
	else
		m_FRET_xoffset -= m_FRET_xscale;
	*pResult = 0;
	m_intensity_xoffset = m_FRET_xoffset;
	DrawIntensity();
	DrawFRET();
}

void CTraceDialog::OnEnKillfocusF0FsumRatio()
{
	double backup = m_f0_fsum_ratio;
	UpdateData(TRUE);
	m_f0_fsum_ratio = LIMIT_DECIMAL_PLACES( m_f0_fsum_ratio, 3 );
	if ( m_f0_fsum_ratio < 0 )	m_f0_fsum_ratio = backup;

	UpdateData(FALSE);
	if ( m_film.m_trace )
	{
		m_film.m_trace->SetF0FsumRatio( m_f0_fsum_ratio );

		m_film.MoveFrame( m_slider.GetPos() );
		m_film.ReadFrame(NULL);
		m_film.DrawFrame(m_display_buffer);
		UpdateFrame();
	}
}

void CTraceDialog::OnEnKillfocusI1CH1()
{
	double backup = m_11;
	UpdateData(TRUE);
	
	m_11 = LIMIT_DECIMAL_PLACES( m_11, 3 );
	if ( m_11 >= 0.0 && m_11 <= 1.0 && fabs(m_11-m_21) > 0.01 )
	{
		DrawIntensity();
		DrawFRET();
	}
	else
		m_11 = backup;

	UpdateData(FALSE);
}

void CTraceDialog::OnEnKillfocusI2CH1()
{
	double backup = m_21;
	UpdateData(TRUE);
	
	m_21 = LIMIT_DECIMAL_PLACES( m_21, 3 );
	if ( m_21 >= 0.0 && m_21 <= 1.0 && fabs(m_11-m_21) > 0.01 )
	{
		DrawIntensity();
		DrawFRET();
	}
	else
		m_21 = backup;
	
	UpdateData(FALSE);
}

void CTraceDialog::OnEnKillfocusPeakNo()
{
	int backup = m_peak_no;
	UpdateData(TRUE);

	if ( m_film.m_trace 
		&& backup != m_peak_no
		&& 0 <= m_peak_no && m_peak_no < (int) m_film.m_trace->m_num_peaks )
	{
		CPeakSet set = m_film.m_trace->m_peaks[m_peak_no];
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			m_peak[i].x = (int) ( set.p[i].x + 0.5 );
			m_peak[i].y = (int) ( set.p[i].y + 0.5 );
			//m_radius[i] = (int) ceil( m_film.m_trace->m_peak_radius );
		}

		UpdateFrame();
		BuildTrace();
	}
	else
	{
		m_peak_no = backup;
		UpdateData(FALSE);
	}
}

void CTraceDialog::OnDeltaposPeakNoSpin(NMHDR *pNMHDR, LRESULT *pResult)
{
	if ( !m_film.m_trace )	return;
	int backup = m_peak_no;

	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	if ( pNMUpDown->iDelta < 0 )	m_peak_no++;
	else	m_peak_no--;

	if ( m_peak_no < 0 )	m_peak_no = 0;
	if ( m_peak_no >= (int) m_film.m_trace->m_num_peaks )	m_peak_no = (int)m_film.m_trace->m_num_peaks - 1;

	if ( m_peak_no != backup )
	{
		CPeakSet set = m_film.m_trace->m_peaks[m_peak_no];
		for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
		{
			m_peak[i].x = (int) ( set.p[i].x + 0.5 );
			m_peak[i].y = (int) ( set.p[i].y + 0.5 );
			//m_radius[i] = (int) ceil( m_film.m_trace->m_peak_radius );
		}

		UpdateFrame();
		BuildTrace();
	}
}



void CTraceDialog::OnBnClickedLoadMap()
{
	CString szFilters;
	szFilters.Format(_T("All Files (*.*)|*.*||"));
	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
	fileDlg.m_ofn.lpstrInitialDir = _PATH_COMMON;
	if( fileDlg.DoModal ()==IDOK )
	{
		m_mapping.Load(fileDlg.GetPathName());

		CWnd *pWnd = GetDlgItem(IDC_MAPPING_INFO);
		if ( pWnd )	pWnd->SetWindowText( m_mapping.Information() );

		if ( m_mapping.m_is_mapping_ready != TRUE )
			LogErr(Stringify(_T("Load Mapping File[%s] Failed."), fileDlg.GetPathName()));
	}
}


void CTraceDialog::OnBnClickedMap12()
{
	UINT16 w = m_film.m_frame_w;
	UINT16 h = m_film.m_frame_h;
	if ( !m_mapping.IsCompatible( w, h ) || !m_mapping.m_is_mapping_ready )
	{
		LogErr(_T("This mapping is not valid."));
		return;
	}

	int x1 = m_peak[CH1].x;
	int y1 = m_peak[CH1].y;
	int x2 = (int) ( m_mapping.X2(x1, y1) + 0.5 );
	int y2 = (int) ( m_mapping.Y2(x1, y1) + 0.5 );	
	if ( x2 < 0 )	x2 = 0;
	if ( x2 >= w )	x2 = w-1;
	if ( y2 < 0 )	y2 = 0;
	if ( y2 >= h )	y2 = h-1;
	m_peak[CH2].SetPoint( x2, y2 );
	UpdateFrame();
	return;
}

void CTraceDialog::OnBnClickedMap21()
{
	UINT16 w = m_film.m_frame_w;
	UINT16 h = m_film.m_frame_h;
	if ( !m_mapping.IsCompatible( w, h ) || !m_mapping.m_is_mapping_ready )
	{
		LogErr(_T("This mapping is not valid."));
		return;
	}

	int x2 = m_peak[CH2].x;
	int y2 = m_peak[CH2].y;
	int x1 = (int) ( m_mapping.X1(x2, y2) + 0.5 );
	int y1 = (int) ( m_mapping.Y1(x2, y2) + 0.5 );	
	if ( x1 < 0 )	x1 = 0;
	if ( x1 >= w )	x1 = w-1;
	if ( y1 < 0 )	y1 = 0;
	if ( y1 >= h )	y1 = h-1;
	m_peak[CH1].SetPoint( x1, y1 );
	UpdateFrame();
	return;
}


void CTraceDialog::OnBnClickedShowTotal()
{
	UpdateData(TRUE);
	DrawIntensity();
}

void CTraceDialog::OnBnClickedShowBackground()
{
	UpdateData(TRUE);
	DrawIntensity();
}

void CTraceDialog::OnBnClickedFlatBackground()
{
	UpdateData(TRUE);

	BuildTrace();
	DrawIntensity();
	DrawFRET();
}

