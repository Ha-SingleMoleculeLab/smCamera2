#pragma once

#include "afxtempl.h"
#include "Peaks.h"
//#include "libtiff/tiffio.h"

#define CAMERAFILE_FILM_PREFIX		_T("film")
#define CAMERAFILE_FILM_EXT			_T("smm")
#define CAMERAFILE_OLDFILM_PREFIX	_T("hel")
#define CAMERAFILE_OLDFILM_EXT		_T("pma")
#define CAMERAFILE_FLOG_PREFIX		_T("film")
#define CAMERAFILE_FLOG_EXT			_T("log")
#define CAMERAFILE_PEAKTRACE_EXT	_T("pkt")
#define CAMERAFILE_TIFF1_EXT		_T("tif")
#define CAMERAFILE_TIFF2_EXT		_T("tiff")
//#define CAMERAFILE_TRACE_PREFIX		_T("trace")
//#define CAMERAFILE_BGTRACE_PREFIX	_T("bgtrace")
#define CAMERAFILE_PEAKS_EXT		_T("pks")
#define CAMERAFILE_TRACE_EXT		_T("smt")
#define CAMERAFILE_TRACE2_EXT		_T("smt2")
#define CAMERAFILE_TLOG_EXT			_T("tlog")
#define CAMERAFILE_BGPEAKS_EXT		_T("bgpks")
#define CAMERAFILE_BGTRACE_EXT		_T("bgsmt")
#define CAMERAFILE_BGTRACE2_EXT		_T("bgsmt2")
#define CAMERAFILE_BGTLOG_EXT		_T("bgtlog")
#define CAMERAFILE_OLDTRACE_PREFIX	_T("hel")
#define CAMERAFILE_OLDTRACE_EXT		_T("traces")
#define CAMERAFILE_TLOG_PREFIX		_T("trace")

enum class CAMERAFILE_TYPE_T	//I changed enum to enum class. //restore
{
	CAMERAFILE_UNKNOWN = 0, 
	CAMERAFILE_FILM, 
	CAMERAFILE_OLDFILM,
	CAMERAFILE_PEAKS,
	CAMERAFILE_PEAKTRACE,
	CAMERAFILE_TIFF,
	CAMERAFILE_TRACE, 
	CAMERAFILE_OLDTRACE,
	NUM_CAMERAFILE_TYPES 
};

/************************************************************************************/
/***************				CPeaksFileWriter					*****************/
/************************************************************************************/

class CPeaksFileWriter
{
public:
	CPeaksFileWriter()	{	m_filepath = _T("");	}
	
	CString m_filepath;
	int SetFilepath(LPCTSTR filepath, BOOL background=FALSE);
	inline int SetBGFilepath(LPCTSTR path)	{	return SetFilepath( path, TRUE );	}

//	inline int SetFilepath(LPCTSTR path, LPCTSTR name)
//		{	
//			CString str;
//			str.Format(_T("%s\\%s."), path, name);
//			return SetFilepath(str);
//		}

	int Write(UINT16 w, UINT16 h, CArray<CPeakSet> *peaks);
};

/************************************************************************************/
/***************				CPeaksFileReader					*****************/
/************************************************************************************/


class CPeaksFileReader
{
public:
	UINT16 m_frame_w;
	UINT16 m_frame_h;
	CArray<CPeakSet> m_peaks;
	
	int Read(LPCTSTR filepath);
	int ReadPeaksFileOf(LPCTSTR filepath);
};

/************************************************************************************/
/***************				CPeakTraceFileWriter					*****************/
/************************************************************************************/

class CPeakTraceFileWriter
{
public:
	CPeakTraceFileWriter()
		{	
			m_filepath = _T("");
			m_archive = NULL;
			Close();
		}
	virtual ~CPeakTraceFileWriter()	{	Close();	}
	
	CString m_filepath;
	int SetFilepath(LPCTSTR filepath);
	inline int SetFilepath(LPCTSTR path, LPCTSTR name)
		{	
			CString str;
			str.Format(_T("%s\\%s."), path, name);
			return SetFilepath(str);
		}

	UINT16 m_frame_w;
	UINT16 m_frame_h;

	CArchive *m_archive;
	int Open();
	int Close();
	int Write(UINT frame_no, CPeakSet *peaks);

	inline BOOL IsOpen()
		{	return ( m_archive != NULL );	}
};

/************************************************************************************/
/***************				CTIFFFileWriter						*****************/
/************************************************************************************/

class CTIFFFileWriter
{
public:
	CTIFFFileWriter()	
		{	
			m_tiff = NULL;
			Close();
		}
	virtual ~CTIFFFileWriter() {	Close();	}

	CString m_filepath;
	int SetFilepath(LPCTSTR filepath);
	inline int SetFilepath(LPCTSTR path, LPCTSTR name)
		{
			CString str;
			str.Format(_T("%s\\%s."), path, name);
			return SetFilepath(str);
		}

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	UINT8 m_byte_per_pixel;
	BOOL m_8bit_color;

	//TIFF *m_tiff;
	void *m_tiff;

	int Open();
	int Close();
//	int Write(int num_frames, long *images);
	int Write(int num_frames, double *images);

	inline BOOL IsOpen()
		{	return ( m_tiff != NULL );	}
	inline UINT8 Pixel2Byte(double val)
		{	
			int byte = (int) ( 255 * ( val-m_background ) / m_data_scaler );
			return ( byte < 0 ) ? 0 : ( ( byte >= 255 ) ? 255 : (UINT8)byte );
		}

};


/************************************************************************************/
/***************				CTIFFFileReader						*****************/
/************************************************************************************/

class CTIFFFileReader
{
public:
	CTIFFFileReader()	
		{	
			m_tiff = NULL;
			Close();	
		}
	virtual ~CTIFFFileReader()	{	Close();	}

	CString m_filepath;

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	UINT8 m_byte_per_pixel;
	UINT m_num_frames;

	//TIFF *m_tiff;
	void *m_tiff;

	int Open(LPCTSTR filepath);
	int Close();
//	inline int FrameNo()
//		{	
//			if ( !m_tiff )	return -1;
//			return (int) TIFFCurrentDirectory(m_tiff);
//		}
//	inline int MoveFrame(UINT frame_no)
//		{
//			if ( !m_tiff )	return -1;
//			return ( TIFFSetDirectory(m_tiff, (tdir_t)frame_no) == 0 ) ? -1 : 0 ;
//		}
	int FrameNo();
	int MoveFrame(UINT frame_no);
	int ReadFrame(double *pFrame);

	inline BOOL IsOpen()
		{	return ( m_tiff != NULL );	}

};



/************************************************************************************/
/***************				CFilmLogFileWriter					*****************/
/************************************************************************************/

class CFilmLogFileWriter
{
public:
	CFilmLogFileWriter()	{	m_filepath = _T("");	}

	CString m_filepath;
	int SetFilepath(LPCTSTR filepath);
	inline int SetFilepath(LPCTSTR path, LPCTSTR name)
		{
			m_filepath.Format(_T("%s\\%s%s.%s"), 
							path, CAMERAFILE_FLOG_PREFIX, name, CAMERAFILE_FLOG_EXT);
			return 0;
		}

	int Write( UINT64 server_index, UINT16 frame_w, UINT16 frame_h, UINT32 background, UINT32 scaler, UINT8 byte_per_pixel,
				CString info, int bit_depth, int gain, double exposure_time, double frame_cycle,
				int area_left, int area_right, int area_bottom, int area_top );
	int AddComment(LPCTSTR comment);
};

/************************************************************************************/
/***************				CFilmFileWriter						*****************/
/************************************************************************************/

class CFilmFileWriter
{
public:
	CFilmFileWriter(BOOL old_format=FALSE)	
		{	
			m_file = NULL;
			m_buffer = NULL;
			Close();
			m_write_as_old_format = old_format;
		}
	virtual ~CFilmFileWriter()	{	Close();	}

	CString m_filepath;
	int SetFilepath(LPCTSTR filepath);
	inline int SetFilepath(LPCTSTR path, LPCTSTR name)
		{
			CString str;
			if ( m_write_as_old_format )
				str.Format(_T("%s\\%s%s."), path, CAMERAFILE_OLDFILM_PREFIX, name);
			else
				str.Format(_T("%s\\%s%s."), path, CAMERAFILE_FILM_PREFIX, name);
			return SetFilepath( str );
		}


	BOOL m_write_as_old_format;

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	UINT8 m_byte_per_pixel;
	float m_frame_cycle;
	UINT8 *m_buffer;

	CFile *m_file;
	CFilmLogFileWriter m_flog;
	CPeakTraceFileWriter m_pktrace;
	int Open();
	int Close();
	//int Write(UINT bpp, UINT8 *image);
	int Write(UINT32 *image);
	//int Write(int num_images, UINT32 *images);

	inline BOOL IsOpen()
		{	return ( m_file != NULL );	}
	inline UINT8 Pixel2Byte(double val)
		{	
			int byte = (int) ( 255 * ( val-m_background ) / m_data_scaler );
			return ( byte < 0 ) ? 0 : ( ( byte >= 255 ) ? 255 : (UINT8)byte );
		}

};

/************************************************************************************/
/***************				CFilmFileReader						*****************/
/************************************************************************************/

class CFilmFileReader
{
public:
	CFilmFileReader()	
		{	
			m_file = NULL;
			m_frame_buffer = NULL;
			Close();	
		}
	virtual ~CFilmFileReader()	{	Close();	}

	CString m_filepath;

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	UINT8 m_byte_per_pixel;
	float m_frame_cycle;

	UINT m_header_size;
	UINT m_num_frames;

	CFile *m_file;
	UINT8 *m_frame_buffer;

	int Open(LPCTSTR filepath);
	int Close();
	inline int FrameNo()	
		{	
			if ( !m_file )	return -1;
			UINT byte_per_frame = m_byte_per_pixel * m_frame_w * m_frame_h ;
			ULONGLONG pos = m_file->GetPosition() - m_header_size;
			return (int) ( pos * 1.0 / byte_per_frame );
		}
	inline int MoveFrame(UINT frame_no)
		{	
			if ( !m_file )	return -1;
			UINT byte_per_frame = m_byte_per_pixel * m_frame_w * m_frame_h ;
			ULONGLONG offset = (ULONGLONG) m_header_size + (ULONGLONG)frame_no * byte_per_frame ;
			if ( offset != m_file->Seek( offset, CFile::begin )	)	return -1;
			return 0;
		}
	int ReadFrame(double *pFrame);

	inline BOOL IsOpen()
		{	return ( m_file != NULL );	}
	inline double Byte2Pixel(int byte, double min=-1, double max=-1)
		{
			if ( min < 0 )	min = m_background;
			if ( max < 0 )	max = min + m_data_scaler;
			return ( byte < 0 ) ? min : ( ( byte >= 255 ) ? max : (min + (max-min) * byte * 1.0 / 255) );
		}
	
};




/************************************************************************************/
/***************				CTraceLogFileWriter					*****************/
/************************************************************************************/

class CTraceLogFileWriter
{
public:
	CTraceLogFileWriter()	{	m_filepath = _T("");	}

	CString m_filepath;
	int SetFilepath(LPCTSTR filepath, BOOL background=FALSE);
	inline int SetBGFilepath(LPCTSTR path)	{	return SetFilepath( path, TRUE );	}
//	inline int SetFilepath(LPCTSTR path, LPCTSTR name)
//		{
//			m_filepath.Format(_T("%s\\%s%s.%s"), 
//							path, CAMERAFILE_TLOG_PREFIX, name, CAMERAFILE_TLOG_EXT);
//			return 0;
//		}

	int Write(UINT16 frame_w, UINT16 frame_h, double frame_cycle, UINT32 num_frames,
				double peak_radius, double peak_sigma, BOOL find[NUM_CHANNELS] );
};

/************************************************************************************/
/***************				CTraceFileWriter					*****************/
/************************************************************************************/

class CTraceFileWriter
{
public:
	CTraceFileWriter()
		{
			m_archive = NULL;
			m_archive2 = NULL;
			m_data = NULL;
			m_data2 = NULL;
			Close();
		}
	virtual ~CTraceFileWriter()	{	Close();	}

	CString m_filmpath;
	CString m_filepath;
	CString m_filepath2;
	inline int SetFilmpath(LPCTSTR path)
		{
			m_filmpath = path;
			return 1;
		}
	int SetFilepath(LPCTSTR path, BOOL background=FALSE);
	inline int SetBGFilepath(LPCTSTR path)	{	return SetFilepath( path, TRUE );	}


	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	float m_frame_cycle;
	float m_peak_radius;
	float m_peak_sigma;

	UINT32 m_num_frames;
	UINT32 m_num_peaks;
	CArchive *m_archive;
	CArchive *m_archive2;
	float *m_data;
	float *m_data2;
	CPeaksFileWriter m_peaks;
	CTraceLogFileWriter m_tlog;

	int Open(UINT num_frames, CArray<CPeakSet> *peaks);
	int Close();
	int Write();
	int SaveMaximumSnapshot(UINT16 w, UINT16 h, double *snapshot);

	inline BOOL IsOpen()
		{	return ( m_data != NULL );	}
	inline float& Signal( int ch, UINT peak_no, UINT frame_no)
		{	return m_data[ ( 2 * NUM_CHANNELS * peak_no + 2*(ch-CH1) ) * m_num_frames + frame_no ];	}
	inline float& Background( int ch, UINT peak_no, UINT frame_no)
		{	return m_data[ ( 2 * NUM_CHANNELS * peak_no + 2*(ch-CH1) + 1 ) * m_num_frames + frame_no ];	}
	inline float& Signal2( int ch, UINT peak_no, UINT frame_no)
		{	return m_data2[ ( 2 * NUM_CHANNELS * peak_no + 2*(ch-CH1) ) * m_num_frames + frame_no ];	}
	inline float& Background2( int ch, UINT peak_no, UINT frame_no)
		{	return m_data2[ ( 2 * NUM_CHANNELS * peak_no + 2*(ch-CH1) + 1 ) * m_num_frames + frame_no ];	}

};


/************************************************************************************/
/***************				CTraceFileReader					*****************/
/************************************************************************************/


class CTraceFileReader
{
public:
	CTraceFileReader()
		{
			m_data = NULL;
			m_snapshot = NULL;
			Close();
		}
	virtual ~CTraceFileReader()	{	Close();	}

	CString m_filepath;

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;

	float m_frame_cycle;
	float m_peak_radius;
	float m_peak_sigma;

	UINT32 m_num_frames;
	UINT32 m_num_peaks;
	CArray<CPeakSet> m_peaks;

	float *m_data;

	int Open(LPCTSTR filepath);
	int Close();

	inline BOOL IsOpen()
		{	return ( m_data != NULL );	}

	double *m_snapshot;
	int LoadSnapshot();
	int LoadMaximumSnapshot();
	inline float Snapshot(int x, int y)
		{	return (float) ( ( m_snapshot ) ? m_snapshot[ m_frame_w * y + x ] : 0.0 ) ;	}

	float m_f0_fsum_ratio;
	inline void SetF0FsumRatio(double ratio)	
		{	if ( ratio >= 0 )	m_f0_fsum_ratio = (float)ratio;	}

	inline float& Signal( int ch, UINT peak_no, UINT frame_no)
		{	return m_data[ ( 2 * NUM_CHANNELS * peak_no + 2*(ch-CH1) ) * m_num_frames + frame_no ];	}
	inline float& Background( int ch, UINT peak_no, UINT frame_no)
		{	return m_data[ ( 2 * NUM_CHANNELS * peak_no + 2*(ch-CH1) + 1 ) * m_num_frames + frame_no ];	}
};

/************************************************************************************/
/***************					CFilm							*****************/
/************************************************************************************/


class CFilm
{
public:
	CFilm();
	virtual ~CFilm()	{	Close();	}

	CString m_filepath;

	UINT16 m_frame_w;
	UINT16 m_frame_h;
	UINT32 m_background;
	UINT32 m_data_scaler;
	
	float m_frame_cycle;
	UINT m_num_frames;
	UINT m_frame_no;

	CFilmFileReader *m_film;
	CPeaksFileReader *m_peaks;
	CTIFFFileReader *m_tiff;
	CTraceFileReader *m_trace;

	double *m_data;
	double *m_frame;
	double *m_temp_frame;

	int Open(LPCTSTR filepath);
	int Close();
	int MoveFrame(UINT frame_no);	
	int ReadFrame(double *pFrame);
	int DrawFrame(UINT16 w, UINT16 h, COLORREF *display);
	int StartAveragingFrames();
	int AddToAveragingFrames();
	int FinishAveragingFrames(int frame_cnt, double *pAveFrame);
	int MakeAverageFrame(int from, int to, double *pAveFrame);
//	int MakeMaximumFrame(int from, int to, double *pMaxFrame);

	inline BOOL IsOpen() 
		{	return ( m_data != NULL );	}
	inline int MakeAverageFrame(double *pAveFrame)
		{	return MakeAverageFrame(0, ((int)m_num_frames)-1, pAveFrame);	}
	inline int DrawFrame(COLORREF *display)
		{	return DrawFrame( m_frame_w, m_frame_h, display);		}

	inline UINT8 Pixel2Byte(double val)
		{	
			int byte = (int) ( 255 * ( val-m_background ) / m_data_scaler );
			return ( byte < 0 ) ? 0 : ( ( byte >= 255 ) ? 255 : (UINT8)byte );
		}
	inline double Byte2Pixel(UINT8 byte)
		{
			return m_background + m_data_scaler * byte / 255 ;
		}

	inline int LastFrameNo()		
		{	return (int) m_frame_no - 1;	}
	inline double& Frame(int x, int y)	
		{	return m_frame[ m_frame_w*y + x ];	}
	inline double& TempFrame(int x, int y)	
		{	return m_temp_frame[ m_frame_w*y + x ];	}
};