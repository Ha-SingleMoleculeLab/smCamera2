#pragma once
#include "afxwin.h"
#include "CameraFile.h"
#include "smCamera.h"

// CMovieConverterDialog dialog

class CMovieConverterDialog : public CDialog
{
	DECLARE_DYNAMIC(CMovieConverterDialog)

public:
	CMovieConverterDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMovieConverterDialog();

// Dialog Data
	enum { IDD = IDD_CONVERTER };
	enum { FILM_CONVERT_TO_OLD_FILM = 0, FILM_CONVERT_TO_GRAY_TIFF = 1, FILM_CONVERT_TO_8BITCOLOR_TIFF };

protected:
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();	
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:

	BOOL m_is_working;
	int m_film_convert_cbindex;
	CString m_film_convert_status;
	CString m_trace_convert_status;
	CDirectoryTraverse m_directory;

	void ConvertFilmToOldFilm(LPCTSTR filmpath);
	void ConvertFilmToGrayTIFF(LPCTSTR filmpath);
	void ConvertFilmTo8BitColorTIFF(LPCTSTR filmpath);
	void ConvertTraceToOldTrace(LPCTSTR tracepath);
	void ConvertFilmFolder(LPCTSTR filmpath);
	void ConvertTraceFolder(LPCTSTR tracepath);

	afx_msg void OnBnClickedFilmConvert();
	afx_msg void OnBnClickedFilmConvertFolder();
	afx_msg void OnBnClickedTraceConvert();
	afx_msg void OnBnClickedTraceConvertFolder();
};