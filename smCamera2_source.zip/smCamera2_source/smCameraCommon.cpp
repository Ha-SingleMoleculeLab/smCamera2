#include "stdafx.h"
#include "smCamera.h"

CString _PATH_ROOT;
CString _PATH_COMMON;
CString _PATH_DEVICES;
CString _PATH_TOOLS;
CString _PATH_MOVIES;

CString _PATH_FRAME_SEQUENCE;
CString _PATH_CAMERA;
CString _PATH_MOVIE_RECORDER;
CString _PATH_MOVIE_ANALYSIS;
CString _PATH_MOVIE_MAPPER;
CString _PATH_HISTOGRAM;
CString _PATH_TRACE;
CString _PATH_FAKE;

//paths for shutter
CString _PATH_SHUTTER;
CString _PATH_SHUTTER_CONTROLERS;
CString _PATH_SHUTTER_CONTROLERS_NI_PCI_6503;
CString _PATH_SHUTTER_CONTROLERS_NI_PCI_6722;




#include <direct.h>
static BOOL InitProgramDirectories()
{
	CString setup_file;
	setup_file.Format(_T("%s.setup"), PROGRAM_NAME );
	CArchive *ar = OpenProgramFileToRead( setup_file );
	if ( ar )
	{
		ar->ReadString(_PATH_ROOT);
		CloseProgramFile(ar);
	}
	else
	{
		LogNotice(_T("Select the directory to be used as the program root."));

		ar = OpenProgramFileToWrite( setup_file );
		if ( ar == NULL )
		{
			LogErr(_T("Failed to create a program setup file."));
			return FALSE;	
		}
		PickContainer();
		//CDirectoryDialog dirDlg(_T(""), NULL);
		//if ( dirDlg.DoModal()  == TRUE )	_PATH_ROOT = dirDlg.m_strPath;
		//else
		//{
		//	LogErr(_T("Program root should be set up"));
		//	return FALSE;
		//}
		_PATH_ROOT = _PATH_FAKE;
		ar->WriteString(_PATH_ROOT);
		CloseProgramFile(ar);
	}

	_PATH_ROOT = _T(_PATH_ROOT) + _T("\\");

	if ( MakeProgramDirectory(_PATH_ROOT ) != TRUE
		|| _tchdir(_PATH_ROOT) != 0 )
	{
		LogErr(Stringify(_T("Changing directory to the program root [%s] failed : %s "), 
						_PATH_ROOT, _tcserror(errno) ) );
		return FALSE;
	}

	_PATH_COMMON = _PATH_ROOT + _T("Common\\");
	_PATH_DEVICES = _PATH_ROOT + _T("Devices\\");
	_PATH_TOOLS = _PATH_ROOT + _T("Tools\\");
	_PATH_MOVIES = _PATH_ROOT + _T("Movies\\");

	_PATH_FRAME_SEQUENCE = _PATH_COMMON + _T("FrameSequence\\");
	_PATH_CAMERA = _PATH_DEVICES + _T("Camera\\");
	_PATH_MOVIE_RECORDER = _PATH_TOOLS + _T("MovieRecorder\\");
	_PATH_MOVIE_ANALYSIS = _PATH_TOOLS + _T("MovieAnalysis\\");
	_PATH_MOVIE_MAPPER = _PATH_TOOLS + _T("MovieMapper\\");
	_PATH_HISTOGRAM = _PATH_TOOLS + _T("Histogram\\");
	_PATH_TRACE = _PATH_TOOLS + _T("Trace\\");

	_PATH_SHUTTER = _PATH_DEVICES + _T("Shutter\\");
	_PATH_SHUTTER_CONTROLERS = _PATH_SHUTTER + _T("Controllers\\");
	_PATH_SHUTTER_CONTROLERS_NI_PCI_6503 = _PATH_SHUTTER_CONTROLERS + _T("NI PCI-6503\\");
	_PATH_SHUTTER_CONTROLERS_NI_PCI_6722 = _PATH_SHUTTER_CONTROLERS + _T("NI PCI-6722\\");


	return ( MakeProgramDirectory( _PATH_COMMON )
		&& MakeProgramDirectory( _PATH_DEVICES )
		&& MakeProgramDirectory( _PATH_TOOLS )
		&& MakeProgramDirectory( _PATH_MOVIES )
		&& MakeProgramDirectory( _PATH_FRAME_SEQUENCE )
		&& MakeProgramDirectory( _PATH_CAMERA ) 
		&& MakeProgramDirectory( _PATH_MOVIE_RECORDER )
		&& MakeProgramDirectory( _PATH_MOVIE_ANALYSIS )
		&& MakeProgramDirectory( _PATH_MOVIE_MAPPER )
		&& MakeProgramDirectory( _PATH_HISTOGRAM )
		&& MakeProgramDirectory( _PATH_TRACE )
		&& MakeProgramDirectory( _PATH_SHUTTER )
		&& MakeProgramDirectory( _PATH_SHUTTER_CONTROLERS )
		&& MakeProgramDirectory( _PATH_SHUTTER_CONTROLERS_NI_PCI_6503 )
		&& MakeProgramDirectory( _PATH_SHUTTER_CONTROLERS_NI_PCI_6722 )
		);
}


/*********************** Devices Management *************************************/
void InitDevices()
{
	CWaitCursor	wait;

	CView *view = ((CFrameWnd*) theApp.m_pMainWnd)->GetActiveView();
	CEdit &edit = ((CEditView*)view)->GetEditCtrl();
	LogOpen(view, &edit, theApp.GetStatusBar());


	LogMsg(_T("Info"), _T("Initializing Program Directories...") );
	if ( InitProgramDirectories() != TRUE )
	{
		LogErr(_T("Failed to initialized program diretories."));
		exit(0);
	}

	LogMsg(_T("Info"), _T("Initializing Shutter...") );
	g_shutter.Init();
	g_shutter.Load();

	LogMsg(_T("Info"), _T("Initialization Complete.") );
}

void FreeDevices()
{
	CWaitCursor	wait;

	LogMsg(_T("Info"), _T("Shutting Down...") );
	LogMsg(_T("Info"), _T("Freeing Shutter...") );
	//g_shutter_client.Close();
	g_shutter.Free();
	LogMsg(_T("Info"), _T("Freeing Camera...") );
	g_camera.CameraFree();

	LogClose();
}

/*********************** Color Table *************************************/

static int __load_color_table(LPCSTR table_path, UINT16 table[3][256])
{
	int i;
	int n;	
	CArchive *ar;
	CString str;

	ar = OpenProgramFileToRead( table_path );
	if ( ar == NULL )	return -1;
	for ( i = 0 ; i < 256 ; i++ )
	{
        if ( ar->ReadString(str) == TRUE )
		{
			str = str.TrimLeft();
			n = str.FindOneOf(_T(" \t"));
			if ( n < 0 )	goto FAIL;
			table[0][i] = (UINT8) _tstoi( str.Mid(0, n) );
			str = str.Mid(n+1);
			str = str.TrimLeft();
			n =	str.FindOneOf(_T(" \t"));
			if ( n < 0 )	goto FAIL;
			table[1][i] = (UINT8) _tstoi( str.Mid(0, n) );
			str = str.Mid(n+1);
			str = str.TrimLeft();
			table[2][i] = (UINT8) _tstoi( str );
		}
		else
		{
			table[0][i] = table[1][i] = table[2][i] = 255;
		}
	}
	CloseProgramFile(ar);
	return 0;

FAIL:
	LogErr(Stringify(_T("Loading Color Table [%s] Failed at line[%d][%s]"), table_path, i, str));
	CloseProgramFile(ar);
	return -1;
}

static UINT16 __color0_tbl[NUM_CHANNELS][3][256];
static UINT16 __color1_tbl[NUM_CHANNELS][3][256];
static UINT16 __tiff_colormap[3][256];

void LoadProgramColorTable()
{
	CString str;

	for ( int i = CH1 ; i < NUM_CHANNELS ; i++ )
	{
		str.Format(_T("CH%d_color0.tbl"), i-CH1+1);
        if ( __load_color_table( GetProgramFilePath(_T(_PATH_COMMON), str), __color0_tbl[i] ) < 0 )
		{
			for ( int k = 0 ; k < 256 ; k++ )
			{
				__color0_tbl[i][0][k] = 255;
				__color0_tbl[i][1][k] = 255;
				__color0_tbl[i][2][k] = 255;
			}
		}

		str.Format(_T("CH%d_color1.tbl"), i-CH1+1);
        if ( __load_color_table( GetProgramFilePath(_T(_PATH_COMMON), str), __color1_tbl[i] ) < 0 )
		{
			for ( int k = 0 ; k < 256 ; k++ )
			{
				__color1_tbl[i][0][k] = 255;
				__color1_tbl[i][1][k] = 255;
				__color1_tbl[i][2][k] = 255;
			}
		}
	}

	str = _T("tiff_colormap.tbl");
	if ( __load_color_table(GetProgramFilePath(_T(_PATH_COMMON), str), __tiff_colormap) < 0 )
	{
		for ( int i = 0 ; i < 256 ; i++ )
		{
			__tiff_colormap[0][i] = i;
			__tiff_colormap[1][i] = i;
			__tiff_colormap[2][i] = i;
		}
	}
	for ( int i = 0 ; i < 256 ; i++ )
	{
		__tiff_colormap[0][i] *= 256;
		__tiff_colormap[1][i] *= 256;
		__tiff_colormap[2][i] *= 256;
	}

	return;
}

COLORREF ProgramColor0( int ch, UINT8 byte)
{
	return RGBReverse( __color0_tbl[ch][0][byte], __color0_tbl[ch][1][byte], __color0_tbl[ch][2][byte] ); 
}
COLORREF ProgramColor1( int ch, UINT8 byte)
{
	return RGBReverse( __color1_tbl[ch][0][byte], __color1_tbl[ch][1][byte], __color1_tbl[ch][2][byte] ); 
}

UINT16 *ProgramTIFFR()
{
	return __tiff_colormap[0];
}
UINT16 *ProgramTIFFG()
{
	return __tiff_colormap[1];
}
UINT16 *ProgramTIFFB()
{
	return __tiff_colormap[2];
}

void PickContainer()
    {
        LPWSTR g_path;
		IFileDialog *pfd;
        if (SUCCEEDED(CoCreateInstance(CLSID_FileOpenDialog, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pfd))))
        {
            DWORD dwOptions;
            if (SUCCEEDED(pfd->GetOptions(&dwOptions)))
            {
                pfd->SetOptions(dwOptions | FOS_PICKFOLDERS);
            }
            if (SUCCEEDED(pfd->Show(NULL)))
            {
                IShellItem *psi;
                if (SUCCEEDED(pfd->GetResult(&psi)))
                {
                    if(!SUCCEEDED(psi->GetDisplayName(SIGDN_DESKTOPABSOLUTEPARSING, &g_path)))
{
MessageBox(NULL, "GetIDListName() failed", NULL, NULL);
}
					_PATH_FAKE=g_path;
psi->Release();
                }
            }
            pfd->Release();
        }
    }
