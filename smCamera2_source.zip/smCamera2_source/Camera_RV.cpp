#include "stdafx.h"
#include "AndorSDK/ATMCD32D.h"
#include "../LKSLib/LKSLibCommon.h"

#include "Camera.h"
#include "smCamera.h"

#define CAMERA_MODEL_NAME	_T("Andor Ixon")
#define DEFAULT_EXPOSURE_TIME	(100)	//in millisecond
#define SUFFICIENTLY_HIGH_TEMP_BEFORE_SHUTDOWN	(-20)	//in 'C


static int __ad_channel = 0;	//First AD Channel
static int __output_amplification_type = 0;	//Electron Multiplying CCD
static int __preamp_gain_index;
//static int __vertical_clock_voltage_param = +2;
static int __vertical_clock_voltage_param = 0;


static int __read_mode = 4;			//image mode
static int __number_of_accumulations = 1;
static int __trigger_mode = 0;		//Internal Trigger mode


//	//LKSCMT : 080305 
//	//In some andor cameras, frame transfer mode does not work although I turn it on in proper way.
//	//However, if we use a strange acquisition mode 7, it works.
//	//It seems to be a sort of hack mode. It is not described in the manual.
//LKSCMT : 2009.08.26
//Now, I doubt about the comment above. Andor guys specifically mentions that 7 should not be used. However, it works. I am not sure whether it works in frame transfer mode, though.
//LKSCMT : 2009.08.26
//According to simple test, Mode 5 & FT(frame transfer) off is very different from Mode 5 & FT on. 
//Interestingly, Mode 7 alone gives similar result with Mode 5 & FT on. There is something with this strange mode. As a reminder, old 'Single' uses Mode 7 without SetFrameTransfer()
static int __acquisition_mode = 5;	//Run Till Abort mode
static int __frame_transfer_mode = 1;	//Frame Transfer On
//static int __acquisition_mode = 7;		//Unlimited Frame Transfer

static int __EMCCD_gain_mode = 0;	//8bit. default mode

static unsigned int __error_code = DRV_SUCCESS;
static CString __error_string;

inline static LPCSTR __camera_error_string(LPCSTR function, unsigned int code)
{
	__error_string.Format(_T("%s Failed with [%d]"), function, code);
	return __error_string;
}

#define IF_CAMERA_FAILED	if ( __error_code != DRV_SUCCESS )
#define CAMERA_FUNCTION( function, function_str )	\
{	\
	__error_code = function;	\
	IF_CAMERA_FAILED	LogMsg(_T("Camera"), __camera_error_string(function_str, __error_code) );	\
	IF_CAMERA_FAILED	goto CAMERA_FAILED;	\
}



CCamera::CCamera() 
{
	m_is_initialized = FALSE;
	m_name = _T("");
	m_interface = _T("");	

	m_num_physical_h_pixels = 0;
	m_num_physical_v_pixels = 0;
	m_physical_pixel_width = 0;
	m_physical_pixel_height = 0;
	m_buffer_size = 0;
	m_bit_depth = sizeof(long)*8;

	m_hspeed = 0;
	m_vspeed = 0;

	m_num_h_pixels = 0;
	m_num_v_pixels = 0;

	m_set_temperature = 0;
	m_max_temperature = 0;
	m_min_temperature = 0;

	m_gain = 0;
	m_min_gain = 0;
	m_max_gain = 0;

	m_exposure_time = 100;
	m_kinetic_cycle_time = 100;
}
CCamera::~CCamera()
{
	CameraFree();
}


void CCamera::CameraInit()
{
	if ( m_is_initialized )	return;

	m_is_initialized = FALSE;
	m_name = _T("");
	m_interface = _T("");	

	m_is_subimage_available = FALSE;
	m_is_gain_available = FALSE;
	m_is_fan_available = FALSE;
	m_is_cooler_available = FALSE;

	m_is_acquiring = FALSE;
	m_first_image_index = -1;
	m_last_image_index = -1;
	m_continuous_image_index = -1;
	m_is_fan_on = FALSE;
	m_is_cooler_on = FALSE;
	m_is_shutter_open = FALSE;

	//Set No Binning as default
	m_num_h_pixels_to_bin = 1;
	m_num_v_pixels_to_bin = 1;

	if (SIMULATION == 1)
	{
		m_num_physical_h_pixels = 128;
		m_num_physical_v_pixels = 128;
	}

	if (SIMULATION == 0)
	{
		long num_total_cameras;
		CAMERA_FUNCTION( GetAvailableCameras(&num_total_cameras), _T("GetAvailableCameras()") );
		LogMsg(_T("Camera"), Stringify(_T("Initializing Camera... : %ld %s Camera(s) were found. The first one will be used."), num_total_cameras, CAMERA_MODEL_NAME));
		if ( num_total_cameras <= 0 )	goto CAMERA_FAILED;
	
		//Use first camera	
		long camera_handle;
		CAMERA_FUNCTION( GetCameraHandle(0, &camera_handle) , _T("GetCameraHandle()"));
		CAMERA_FUNCTION( SetCurrentCamera(camera_handle) , _T("SetCurrentCamera()"));
		CAMERA_FUNCTION( Initialize(".") , _T("Initialize()"));
	
		//if ( CloseShutter()	< 0 )	goto CAMERA_FAILED;

	
		int x, y;
		CAMERA_FUNCTION( GetDetector( &x, &y ) , _T("GetDetector()"));
		m_num_physical_h_pixels = (long) x;
		m_num_physical_v_pixels = (long) y;

		char temp[MAX_PATH];
		CAMERA_FUNCTION( GetHeadModel( temp ) , _T("GetHeadModel()"));
		m_name = _T("Andor Ixon ");
		m_name += temp;

		CAMERA_FUNCTION( GetControllerCardModel( temp ) , _T("GetControllerCardModel()"));
		m_interface = _T("PCI ");
		m_interface += temp;
		
		float xs, ys;
		CAMERA_FUNCTION( GetPixelSize(&xs, &ys) , _T("GetPixelSize()"));
		m_physical_pixel_width = (double) xs;
		m_physical_pixel_height = (double) ys;

		CAMERA_FUNCTION( GetSizeOfCircularBuffer(&m_buffer_size) , _T("GetSizeOfCircularBuffer()"));

		AndorCapabilities caps;
		caps.ulSize = sizeof(AndorCapabilities);
		CAMERA_FUNCTION( GetCapabilities(&caps) , _T("GetCapabilities()"));

		CAMERA_FUNCTION( SetADChannel(__ad_channel) , _T("SetADChannel()"));
		CAMERA_FUNCTION( GetBitDepth(__ad_channel, &m_bit_depth) , _T("GetBitDepth()"));
		CAMERA_FUNCTION( SetOutputAmplifier(__output_amplification_type) , _T("SetOutputAmplifier()"));

		int num;


		//Vertical Shift Speed

		//Vertical Clock Voltage Amplitude should be adjusted for fast VSspeed.
		//cf. SetVSAmplitude
		CAMERA_FUNCTION( SetVSAmplitude(__vertical_clock_voltage_param) , _T("SetVSAmplitude()"));

		//Find Fastest Vertical Shift Speed
		int fastest_vs_speed_index;
		float fastest_vs_speed;
		CAMERA_FUNCTION( GetFastestRecommendedVSSpeed( &fastest_vs_speed_index, &fastest_vs_speed) , _T("GetFastestRecommendedVSSpeed()"));
		SetVSpeed( fastest_vs_speed_index );


		//Horizontal Shift Speed
		//Find Fastest Horizontal Shift Speed
		int max_hs_speed_index = 0;
		double max_hs_speed = 0.0;
		GetNumberHSpeeds( &num );
		for ( int i = 0 ; i < num ; i++ )
		{
			double hs_speed;
			GetHSpeed( i, &hs_speed );
			if ( max_hs_speed < hs_speed )
			{			
				max_hs_speed = hs_speed;
				max_hs_speed_index = i;	
			}
		}
		SetHSpeed( max_hs_speed_index );
		CAMERA_FUNCTION( SetReadMode(__read_mode) , _T("SetReadMode()"));
		CAMERA_FUNCTION( SetNumberAccumulations(__number_of_accumulations), _T("SetNumberAccumulations()"));
		CAMERA_FUNCTION( SetTriggerMode(__trigger_mode) , _T("SetTriggerMode()"));

		CAMERA_FUNCTION( SetAcquisitionMode(__acquisition_mode) , _T("SetAcquisitionMode()"));
		CAMERA_FUNCTION( SetFrameTransferMode(__frame_transfer_mode) , _T("SetFrameTransferMode()"));

		m_is_subimage_available = caps.ulReadModes & AC_READMODE_SUBIMAGE;
		m_is_gain_available = caps.ulSetFunctions & AC_SETFUNCTION_EMCCDGAIN;
		m_is_fan_available = caps.ulFeatures & AC_FEATURES_FANCONTROL;
		m_is_cooler_available = caps.ulSetFunctions & AC_SETFUNCTION_TEMPERATURE;
	
	
		// LKSCMT: Baseline Clamp causes unwanted bistability.
		// Reza: Just changed the SetBaselineClamp(0)to SetBaselineClamp(1)!
		if ( caps.ulSetFunctions & AC_SETFUNCTION_BASELINECLAMP )
		{
			CAMERA_FUNCTION( SetBaselineClamp(1), _T("SetBaselineClamp()") );
			LogMsg(_T("Info"), Stringify(_T("This camera supports baseline clamp - so it was turned off.")));
		}

		if ( m_is_cooler_available )
		{
			CAMERA_FUNCTION( GetTemperatureRange(&m_min_temperature, &m_max_temperature) , _T("GetTemperatureRange()"));
			if ( CoolerOnOff( TRUE ) < 0 )	goto CAMERA_FAILED;
			if ( SetTemperature( m_min_temperature ) < 0 )	goto CAMERA_FAILED;
		}
	
		if ( m_is_fan_available )
		{	
			if ( FanOnOff( TRUE ) < 0 )	goto CAMERA_FAILED;
		}

		if ( m_is_gain_available )
		{
		//	//LKSCMT: I do not know which mode is the best, since Andor1, 2 and Trap camera support only AC_EMGAIN_8BIT
		//	//		, but later I can choose to select the best mode if it is available.
		//	//LogMsg("", Stringify("AC_EMGAIN_LINEAR12[%d]", caps.ulEMGainCapability & AC_EMGAIN_LINEAR12));
		//	//SetEMGainMode(2);

		//LKSCMT: I decided to use the highest available EMGainMode, like the following.
			if ( caps.ulEMGainCapability & AC_EMGAIN_REAL12 )	// 0x1000
			{
				__EMCCD_gain_mode = 3;
				LogMsg(_T("Camera"), _T("Real EM gain mode."));
			}
			else if ( caps.ulEMGainCapability & AC_EMGAIN_LINEAR12 )	// 0x0100
			{
				__EMCCD_gain_mode = 2;
				LogMsg(_T("Camera"), _T("Linear EM gain mode."));
			}
			else if ( caps.ulEMGainCapability & AC_EMGAIN_12BIT )	// 0x0010
			{
				__EMCCD_gain_mode = 1;
				LogMsg(_T("Camera"), _T("12 Bit EM gain mode."));
			}
			else // if ( caps.ulEMGainCapability & AC_EMGAIN_8BIT )
			{
				__EMCCD_gain_mode = 0;
				LogMsg(_T("Camera"), _T("(Default) 8 Bit EM gain mode."));
			}

			CAMERA_FUNCTION( SetEMGainMode(__EMCCD_gain_mode) , _T("SetEMGainMode()"));
			CAMERA_FUNCTION( GetEMGainRange(&m_min_gain, &m_max_gain) , _T("GetEMGainRange()"));
			if ( SetGain(m_min_gain) < 0 )	goto CAMERA_FAILED;
		}
	
		SetExposureTime(DEFAULT_EXPOSURE_TIME, FALSE);
		FlipImage(FALSE, FALSE);
		RotateImage(0);

		if ( CloseShutter()	< 0 )	goto CAMERA_FAILED;
	}
	//Set Full Resolution as default
	if ( SetImagingArea(1, m_num_physical_h_pixels, 1, m_num_physical_v_pixels) < 0 )	
			goto CAMERA_FAILED;
	m_is_initialized = TRUE;
	return;
CAMERA_FAILED:
	m_is_initialized = FALSE;
	LogMsg(_T("Error"), _T("Camera Initialization Failed."));
	return;
}


void CCamera::CameraLoad(LPCSTR path)
{
	if ( m_is_initialized != TRUE )	return;
	if ( DoesProgramFileExist(path) != TRUE )	return;


	CArchive *ar = NULL;
	ar = OpenProgramFileToRead(path);
	if ( ar == NULL )	return;

	CCamera *pOldCamera = NULL;
	pOldCamera = (CCamera *) malloc( sizeof(CCamera) );

	if ( ar->Read((void *)pOldCamera, sizeof(CCamera)) != sizeof(CCamera) 
		|| pOldCamera->m_is_initialized != TRUE )
	{
		CloseProgramFile(ar);
		free( (void *)pOldCamera );
		pOldCamera = NULL;
		return;
	}

    CloseProgramFile(ar);


	if ( SetHSpeed( pOldCamera->m_hspeed ) < 0 )	goto CAMERA_FAILED;
	if ( SetVSpeed( pOldCamera->m_vspeed ) < 0 )	goto CAMERA_FAILED;

	m_num_h_pixels_to_bin = pOldCamera->m_num_h_pixels_to_bin;
	m_num_v_pixels_to_bin = pOldCamera->m_num_v_pixels_to_bin;

	if ( m_is_subimage_available )
	{
		if ( SetImagingArea(pOldCamera->m_image_left, pOldCamera->m_image_right, 
							pOldCamera->m_image_bottom, pOldCamera->m_image_top) < 0 )
			goto CAMERA_FAILED;
	}

	if ( m_is_cooler_available )
	{
		if ( CoolerOnOff(pOldCamera->m_is_cooler_on) < 0 )	goto CAMERA_FAILED;		
		if ( SetTemperature( pOldCamera->m_set_temperature ) < 0 )	goto CAMERA_FAILED;		
	}
	
	if ( m_is_gain_available )
	{
		if ( SetGain(pOldCamera->m_gain) < 0 )	goto CAMERA_FAILED;
	}

	SetExposureTime(pOldCamera->m_exposure_time, FALSE);
	FlipImage(pOldCamera->m_h_flip, pOldCamera->m_v_flip);
	RotateImage(pOldCamera->m_rotate);

CAMERA_FAILED:
	free( (void *)pOldCamera );
	return;
}

void CCamera::CameraSave(LPCSTR path)
{
	if ( !m_is_initialized )	return;

	CArchive *ar = OpenProgramFileToWrite( path );
	if ( ar )
	{
		ar->Write((void *)this, sizeof(CCamera));
		CloseProgramFile(ar);
	}
	return;
}

void CCamera::CameraFree()
{	
	if ( !m_is_initialized )	return;
	m_is_initialized = FALSE;

	MSG msg;
	int temperature;

	StopAcquisition();
	CloseShutter();
	FanOnOff(TRUE);
	CoolerOnOff(FALSE);
	
	while (1)
	{
		GetTemperature(&temperature);
		LogMsg(_T("Camera"), 
			Stringify(_T("Waiting until the camera temperature rise sufficiently. T[%d'C]-->[%d'C]"), 
						temperature, SUFFICIENTLY_HIGH_TEMP_BEFORE_SHUTDOWN)  
				);
		if ( temperature > SUFFICIENTLY_HIGH_TEMP_BEFORE_SHUTDOWN )	break;

		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		Sleep(1000);
	}
	ShutDown();

	return;
}

int CCamera::GetNumberHSpeeds(int *num)
{
	int num_hs_speeds;
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( GetNumberHSSpeeds( __ad_channel, __output_amplification_type, &num_hs_speeds ) , _T("GetNumberHSSpeeds()"));
		
		if ( num )	*num = num_hs_speeds;
	}
	return 0;	
CAMERA_FAILED:
	return -1;
}

int CCamera::GetHSpeed(int index, double *speed)
{
	float hs_speed;
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION ( GetHSSpeed( __ad_channel, __output_amplification_type, index, &hs_speed), _T("GetHSSpeed()"));

		if ( speed )	*speed = hs_speed;
	}
	return 0;	
CAMERA_FAILED:
	return -1;
}

int CCamera::SetHSpeed(int index)
{
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetHSSpeed(__output_amplification_type, index) , _T("SetHSSpeed()"));
		m_hspeed = index;

		double hspeed = 0.0;
		GetHSpeed( m_hspeed, &hspeed );	
		LogMsg(_T("Camera"), Stringify(_T("HSSpeed is set at [%d. %.3f MHz]"), m_hspeed, hspeed));
	

		//Find Minimum PreAmplifier Gain
		__preamp_gain_index = 0;
		float preamp_gain;
		float min_preamp_gain = -1.0;
	
		int num;
		CAMERA_FUNCTION( GetNumberPreAmpGains(&num) , _T("GetNumberPreAmpGains()"));
		for ( int i = 0 ; i < num ; i++ )
		{
			int is_available;

			CAMERA_FUNCTION( GetPreAmpGain( i, &preamp_gain ) , _T("GetPreAmpGain()"));
			CAMERA_FUNCTION( 
				IsPreAmpGainAvailable( __ad_channel, __output_amplification_type, m_hspeed, i, &is_available ),
				_T("IsPreAmpGainAvailable()")
							);
					
			if ( is_available && ( min_preamp_gain < 0 || min_preamp_gain > preamp_gain ) )
			{
				min_preamp_gain = preamp_gain;
				__preamp_gain_index = i;
			}
		}
		LogMsg(_T("Camera"), Stringify(_T("PreAmpGain[ %d of %d : %f]"), __preamp_gain_index, num, min_preamp_gain));
// Reza: In this section, the program has found the minimum pre-amp gain value and use that. 
// quick and dirty fix for the pre-amp gain to manually set it to maximum.
// There are 3 levels but they start at 0 (0, 1, 2) so maximum is 2.
		__preamp_gain_index = 2;
// End Reza edit.
		CAMERA_FUNCTION( SetPreAmpGain(__preamp_gain_index), _T("SetPreAmpGain()"));
	}
	double backup_exposure_time = m_exposure_time;
	SetExposureTime( ZERO_LIKE_VALUE, FALSE );
	LogMsg(_T("Camera"), 
		Stringify(_T("At this readout speed, fastest available exposure time is [%.3f] ms : Exposure/Kinetic Cycle = %.3f%%"),
							m_exposure_time, 100*m_exposure_time/m_kinetic_cycle_time) );
	SetExposureTime( backup_exposure_time, FALSE );
	
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::GetNumberVSpeeds(int *num)
{
	int num_vs_speeds;
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( GetNumberVSSpeeds( &num_vs_speeds ) , _T("GetNumberVSSpeeds()"));

		if ( num )	*num = num_vs_speeds;
	}
	return 0;	
CAMERA_FAILED:
	return -1;
}

int CCamera::GetVSpeed(int index, double *speed)
{
	float vs_speed;
	CAMERA_FUNCTION ( GetVSSpeed( index, &vs_speed ), _T("GetVSSpeed()"));

	if ( speed )	*speed = vs_speed;
	return 0;	
CAMERA_FAILED:
	return -1;
}

int CCamera::SetVSpeed(int index)
{
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetVSSpeed(index) , _T("SetVSSpeed()"));
		m_vspeed = index;
	
		double vspeed = 0.0;
		GetVSpeed(m_vspeed, &vspeed);
	
		int fastest_index;
		float fastest_speed;
		CAMERA_FUNCTION( GetFastestRecommendedVSSpeed( &fastest_index, &fastest_speed ) , _T("GetFastestRecommendedVSSpeed()"));
	
		LogMsg(_T("Camera"), Stringify(_T("VSSpeed is set at [%d. %.3f us/pixel]"), m_vspeed, vspeed));
		if ( m_vspeed < fastest_index )
			LogNotice( Stringify(_T("Fastest Recommended VSSpeed is [%d. %.3f us/pixel]"), fastest_index, fastest_speed) );	
	}

	double backup_exposure_time = m_exposure_time;
	SetExposureTime( ZERO_LIKE_VALUE, FALSE);
	LogMsg(_T("Camera"), 
		Stringify(_T("At this readout speed, fastest available exposure time is [%.3f] ms : Exposure/Kinetic Cycle = %.3f%%"),
						m_exposure_time, 100*m_exposure_time/m_kinetic_cycle_time) );
	SetExposureTime( backup_exposure_time, FALSE );
	

	return 0;
CAMERA_FAILED:
	return -1;
}
	

int CCamera::SetImagingArea(long left, long right, long bottom, long top)
{
	if ( left >= right || bottom >= top )
	{
		LogMsg(_T("Error"),  _T("left >= right or bottom >= top") );
		return -1;        		
	}
	if ( (right-left+1)%m_num_h_pixels_to_bin != 0
		|| (top-bottom+1)%m_num_v_pixels_to_bin != 0 )
	{
		LogMsg(_T("Error"),  _T("Invalid Binning.") );
		return -1;
	}
	m_image_left = left;
	m_image_right = right;
	m_image_bottom = bottom;
	m_image_top = top;

	m_num_h_pixels = (m_image_right-m_image_left+1)/m_num_h_pixels_to_bin;
	m_num_v_pixels = (m_image_top-m_image_bottom+1)/m_num_v_pixels_to_bin;
	if ( m_rotate != 0 )
		{
			long temp = m_num_h_pixels;
			m_num_h_pixels = m_num_v_pixels;
			m_num_v_pixels = temp;
		}
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetImage( m_num_h_pixels_to_bin, m_num_v_pixels_to_bin, left, right, bottom, top) , _T("SetImage()"));
		

		
	}

	return 0;	
CAMERA_FAILED:
	return -1;
}

int CCamera::SetBinning(long h_binning, long v_binning)
{
	if ( h_binning <= 0 || v_binning <= 0 )
	{
		LogMsg(_T("Error"), Stringify(_T("Binning should be positive integer: h_binning[%ld] v_binning[%ld]")));
		return -1;
	}
	if ( (m_image_right-m_image_left+1)%h_binning != 0 
		|| (m_image_top-m_image_bottom+1)%v_binning != 0 )
	{
		LogMsg(_T("Error"), _T("Invalid Binning.") );
		return -1;
	}
	if (SIMULATION == 0)
	{
	
		CAMERA_FUNCTION( SetImage( h_binning, v_binning, 
								m_image_left, m_image_right, 
								m_image_bottom, m_image_top ),
						_T("SetImage()")
						);
	}
	m_num_h_pixels_to_bin = h_binning;
	m_num_v_pixels_to_bin = v_binning;

	m_num_h_pixels = (m_image_right-m_image_left+1)/m_num_h_pixels_to_bin;
	m_num_v_pixels = (m_image_top-m_image_bottom+1)/m_num_v_pixels_to_bin;

	if ( m_rotate != 0 )
	{
		long temp = m_num_h_pixels;
		m_num_h_pixels = m_num_v_pixels;
		m_num_v_pixels = temp;
	}
	

	return 0;	
CAMERA_FAILED:
	return -1;
}


int CCamera::CoolerOnOff(BOOL onoff)
{
	if (SIMULATION == 0)
	{
		if ( onoff )
		{
			CAMERA_FUNCTION( CoolerON() , _T("CoolerON()"));
			if ( SetTemperature( m_set_temperature ) < 0 )	return -1;
		}
		else
		{
			CAMERA_FUNCTION( CoolerOFF() , _T("CoolerOFF()"));
		}
	}
	m_is_cooler_on = onoff;
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::FanOnOff(BOOL onoff)
{
	if (SIMULATION == 0)
	{
		if ( onoff )	
		{
			CAMERA_FUNCTION( SetFanMode(0) , _T("SetFanMode()"));
		}
		else
		{
			CAMERA_FUNCTION( SetFanMode(2) , _T("SetFanMode()"));
		}
	}
	m_is_fan_on = onoff;
	return 0;
CAMERA_FAILED:
	return -1;
}

inline static unsigned int __set_temperature(int temperature)
{
	return SetTemperature(temperature);
}
inline static unsigned int __get_temperature(int *temperature)
{
	return GetTemperature(temperature);
}

int CCamera::SetTemperature(int temperature)
{
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( __set_temperature(temperature) , _T("SetTemperature()"));
	}
	m_set_temperature = temperature;
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::GetTemperature(int *temperature)
{
	if (SIMULATION == 0)
	{
		static unsigned int temp_code;
		unsigned int code = __get_temperature(temperature);

		switch(code)
		{
		case DRV_TEMP_OFF:
			if ( code != temp_code )	m_temperature_control_status = _T("Temperature is OFF.");
			break;
		case DRV_TEMP_STABILIZED:
			if ( code != temp_code )	m_temperature_control_status = _T("Temperature has stabilized at set point.");
			break;
		case DRV_TEMP_NOT_REACHED:
			if ( code != temp_code )	m_temperature_control_status = _T("Temperature has not reached set point.");
			break;
		case DRV_TEMP_DRIFT:
			if ( code != temp_code )	m_temperature_control_status = _T("Temperature had stabilized but has since drifted.");
			break;
		default:
			if ( code != temp_code )	m_temperature_control_status = _T("Temperature failed.");
			temp_code = code;
			return -1;
		}
		temp_code = code;
	}

	if (SIMULATION)
		*temperature = -10;
	return 0;
}

int CCamera::FlipImage(BOOL h_flip, BOOL v_flip)
{
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetImageFlip( h_flip, v_flip ), _T("SetImageFlip()"));
	}
	m_h_flip = h_flip;
	m_v_flip = v_flip;
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::RotateImage(int rotate)
{
	if ( m_num_h_pixels != m_num_v_pixels && m_is_acquiring == TRUE )
	{
		LogMsg(_T("Camera"), _T("RotateImage Failed : Frame Width != Frame Height"));
		return -1;
	}

	if ( abs(rotate) > 1 )
	{
		LogMsg(_T("Camera"), _T("Invalid Rotation."));
		return -1;
	}

	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetImageRotate( (rotate==-1) ? 2 : rotate ) , _T("SetImageRotate()"));
	}

	if ( abs(m_rotate) != abs(rotate) )
	{
		long temp = m_num_h_pixels;
		m_num_h_pixels = m_num_v_pixels;
		m_num_v_pixels = temp;
	}
	m_rotate = rotate;
	
	return 0;
CAMERA_FAILED:
	return -1;
}

inline static unsigned int __set_exposure_time(float time)
{
	return SetExposureTime(time);
}
int CCamera::SetExposureTime(double time, BOOL verbose)
{
	if ( time <= 0 )
	{
		LogMsg(_T("Error"), _T("Invalid Exposure Time."));
		return -1;
	}
	float exposure, accumulate, kinetic;
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( __set_exposure_time((float)(time * SECOND_PER_MILLISECOND)) , _T("__set_exposure_time()"));

		
		CAMERA_FUNCTION( GetAcquisitionTimings(&exposure, &accumulate, &kinetic) , _T("GetAcquisitionTimings()"));
		m_exposure_time = (double) exposure * MILLISECOND_PER_SECOND;    	
		m_kinetic_cycle_time = (double) kinetic * MILLISECOND_PER_SECOND;
	}
	if ( verbose )
		LogMsg(_T("Camera"), Stringify(_T("Exposure Time[%.3f ms] Kinetice Cycle[%.3f ms]"), m_exposure_time, m_kinetic_cycle_time));
	
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::SetGain(int gain)
{
	if ( gain < m_min_gain || m_max_gain < gain )
	{
		LogMsg(_T("Error"), Stringify(_T("Gain[%d] Out of Range : %d ~ %d"), gain, m_min_gain, m_max_gain ) );
		return -1;
	}
	if (SIMULATION == 0)
	{
	
		CAMERA_FUNCTION( SetEMCCDGain(gain) , _T("SetEMCCDGain()"));
		CAMERA_FUNCTION( GetEMCCDGain(&m_gain) , _T("GetEMCCDGain()"));
		LogMsg(_T("Camera"), Stringify(_T("Gain[%d]"), m_gain));
	}
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::OpenShutter()
{
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetShutter(1,1,1,1) , _T("SetShutter()"));
	}
	m_is_shutter_open = TRUE;
	return 0;
CAMERA_FAILED:
	return -1;
}

int CCamera::CloseShutter()
{
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetShutter(1,2,1,1) , _T("SetShutter()"));
	}
	m_is_shutter_open = FALSE;
	return 0;
CAMERA_FAILED:
	return -1;
}

static HANDLE __h_saturation_event;
static BOOL __is_saturation_alarm_set;
inline static unsigned int __start_acquisition()
{
	return StartAcquisition();
}
int CCamera::StartAcquisition()
{
	
	__h_saturation_event = CreateEvent( NULL,	//security
											TRUE,	//manual reset
											FALSE,	//initial state is non-signaled
											NULL	//name string
											);
	__is_saturation_alarm_set = TRUE;
	if (SIMULATION == 0)
	{
		CAMERA_FUNCTION( SetSaturationEvent(__h_saturation_event) , _T("SetSaturationEvent()"));
		CAMERA_FUNCTION( __start_acquisition() , _T("StartAcquisition()"));
	}
	m_is_acquiring = TRUE;
	m_first_image_index = -1;
	m_last_image_index = -1;
	m_continuous_image_index = -1;
	return 0;
CAMERA_FAILED:
	AbortAcquisition();
	m_is_acquiring = FALSE;
	__is_saturation_alarm_set = FALSE;
	return -1;
}

int CCamera::StopAcquisition()
{	
	if ( !m_is_acquiring )	return 0;

	m_first_image_index = -1;
	m_last_image_index = -1;
	m_continuous_image_index = -1;
	m_is_acquiring = FALSE;
	if (SIMULATION == 0)
	{
		__error_code = CancelWait();
		IF_CAMERA_FAILED	LogMsg(_T("Camera"), __camera_error_string(_T("CancelWait()"), __error_code) );
		CAMERA_FUNCTION( AbortAcquisition() , _T("AbortAcquisition()"));
	}
	return 0;
CAMERA_FAILED:
	return -1;
}


int CCamera::WaitForImages(int timeout, int *num)
{	
	if ( m_is_acquiring != TRUE )	
		return -1;

	if (SIMULATION == 0)
	{
		if ( __is_saturation_alarm_set )
		{
			DWORD ret = WaitForSingleObject(__h_saturation_event, 0);
			if ( ret == WAIT_OBJECT_0 )
			{
				__error_code = AbortAcquisition();
				IF_CAMERA_FAILED
				{
					__camera_error_string(_T("AbortAcquisition()"), __error_code);
				}
				else
				{
					m_is_acquiring = FALSE;
				}	
				LogMsg(_T("Error"),  _T("The sensor has been saturated to a potentially damaging level.") );
				return -1;
			}
		}	
		unsigned int code;
		code = WaitForAcquisitionTimeOut(timeout);
		if ( code != DRV_SUCCESS )
		{
			if ( num )	*num = 0;
			return 0;
		}
		CAMERA_FUNCTION( GetNumberNewImages(&m_first_image_index, &m_last_image_index) , _T("GetNumberNewImages()"));


		if ( m_first_image_index > m_last_image_index )
		{
			LogMsg(_T("Error"), _T("Fatal Error : Image retrieval overtook image acquisition."));
			return -1;
		}
		if ( num )	*num = m_last_image_index - m_first_image_index + 1;
	}
	if (SIMULATION && num)
		*num = 3;

	return 0;
CAMERA_FAILED:
	return -1;
}


inline static unsigned int __get_images(long f, long l, long *array, unsigned long size, long *vf, long *vl)
{
	return GetImages(f, l, array, size, vf, vl);
}

int CCamera::GetImagesContinuous(int num, long *image)
{
	if (SIMULATION == 0)
	{
		if ( m_first_image_index < 0 )	return -1;
		if ( m_continuous_image_index < 0 )	m_continuous_image_index = m_first_image_index;

		if ( m_continuous_image_index < m_first_image_index )
		{
			LogMsg(_T("Error"), _T("Some images were lost and can not be recovered."));
			return -1;
		}
		else if ( m_continuous_image_index > m_first_image_index )
		{
			LogMsg(_T("Error"), _T("Fatal Error : image index decreased with an unknown reason."));
			return -1;
		}

		if ( num == 0 )	return 0;
		if ( num < 0 )
		{
			LogMsg(_T("Error"), _T("Invalid Number of Images."));
			return -1;
		}
		if ( !image )
		{
			LogMsg(_T("Error"), _T("Invaild Pointer."));
			return -1;
		}

		long validfirst, validlast;
		CAMERA_FUNCTION( __get_images( m_first_image_index, m_first_image_index + num - 1,
										image, num * m_num_h_pixels * m_num_v_pixels,
										&validfirst, &validlast ),
						_T("GetImages()")
						);
		m_first_image_index += num;	
		m_continuous_image_index = m_first_image_index;
	}
	if ( SIMULATION )
	{
		
		for (int dummy=0; dummy < m_num_h_pixels * m_num_v_pixels ; dummy++)
		{
			image [dummy] =  dummy % m_num_h_pixels;
		}
	}


	return num;
CAMERA_FAILED:
	return -1;
}

int CCamera::GetImagesLatest(int num, long *image)
{
	if (SIMULATION == 0)
	{
		if ( m_first_image_index < 0 )	return -1;

		if ( num < 0 )
		{
			LogMsg(_T("Error"), _T("Invalid Number of Images."));
			return -1;
		}
		if ( !image )
		{
			LogMsg(_T("Error"), _T("Invaild Pointer."));
			return -1;
		}

		int num_available = ( m_last_image_index - m_first_image_index + 1 );
		int num_to_read = ( num > num_available ) ? num_available : num;
		if ( num_to_read == 0 )	return 0;

		long validfirst, validlast;
		CAMERA_FUNCTION( __get_images( m_last_image_index - num_to_read + 1, m_last_image_index,
										image, num * m_num_h_pixels * m_num_v_pixels,
										&validfirst, &validlast ),
						_T("GetImages()")
						);
		m_first_image_index = m_last_image_index + 1;
		return num_to_read;
	}
	if ( SIMULATION )
	{
		
		for (int dummy=0; dummy < m_num_h_pixels * m_num_v_pixels ; dummy++)
		{
			image [dummy] =  dummy % m_num_h_pixels;
		}
	}
		
CAMERA_FAILED:
	return -1;
}