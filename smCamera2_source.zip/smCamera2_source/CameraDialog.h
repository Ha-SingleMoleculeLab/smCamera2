#pragma once
#include "afxwin.h"


// CCameraDialog dialog

class CCameraDialog : public CDialog
{
	DECLARE_DYNAMIC(CCameraDialog)

public:
	CCameraDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCameraDialog();

// Dialog Data
	enum { IDD = IDD_CAMERA };

protected:
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnDestroy();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	BOOL m_was_acquiring;	
	void UpdateStatus();	

	CComboBox m_hspeed_combo;
	CComboBox m_vspeed_combo;
	afx_msg void OnCbnSelendokHSpeedCombo();
	afx_msg void OnCbnSelendokVSpeedCombo();


	BOOL m_is_fan_on;
	BOOL m_is_cooler_on;
	afx_msg void OnBnClickedFanOnoff();
	afx_msg void OnBnClickedCoolerOnoff();

	int m_temperature;
	afx_msg void OnEnKillfocusTemperatureEdit();


	long m_image_left;
	long m_image_right;
	long m_image_bottom;
	long m_image_top;
	afx_msg void OnEnKillfocusImageLeft();
	afx_msg void OnEnKillfocusImageRight();
	afx_msg void OnEnKillfocusImageBottom();
	afx_msg void OnEnKillfocusImageTop();

	int m_num_pixels_to_bin;
	afx_msg void OnEnKillfocusBinningEdit();

	BOOL m_h_flip;
	BOOL m_v_flip;
	BOOL m_rotate0;
	BOOL m_rotate90;
	BOOL m_rotate270;
	afx_msg void OnBnClickedHFlip();
	afx_msg void OnBnClickedVFlip();
	afx_msg void OnBnClickedRotate0();
	afx_msg void OnBnClickedRotate90();
	afx_msg void OnBnClickedRotate270();
};