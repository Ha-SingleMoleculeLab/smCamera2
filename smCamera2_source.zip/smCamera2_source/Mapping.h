#pragma once
#include "afxtempl.h"

#include "../LKSLib/IDLPolyFitTools.h"


class CMappingPair
{
public:
	double x1;
	double y1;
	double x2;
	double y2;
};

#define NUM_MAPPING_COEFFS	(NUM_COEFFS_FOR_IDLPOLYFIT2D3)

class CMapping
{
public:
	CMapping(UINT w=0, UINT h=0);
	virtual ~CMapping();

	BOOL m_is_mapping_ready;
	UINT m_frame_w;
	UINT m_frame_h;
	time_t	m_time;

	CString m_path;
	void Reset(UINT w, UINT h);	
	int Load( LPCTSTR filepath = NULL );
	int Save( LPCTSTR filepath = NULL );
	LPCTSTR Information();

	CArray<CMappingPair> m_pairs;
	int AddMappingPair(double x1, double y1, double x2, double y2);
	int DoRoughMapping();
	double m_rough_xcoeff1[3];
	double m_rough_ycoeff1[3];
	double m_rough_xcoeff2[3];
	double m_rough_ycoeff2[3];
	int UseRoughMapping(double err);

	int DoMapping();
	double m_xcoeff1[NUM_MAPPING_COEFFS];
	double m_ycoeff1[NUM_MAPPING_COEFFS];
	double m_xerr1;
	double m_yerr1;
	double m_xcoeff2[NUM_MAPPING_COEFFS];
	double m_ycoeff2[NUM_MAPPING_COEFFS];
	double m_xerr2;
	double m_yerr2;

	int SuperposeOnto1( UINT w, UINT h, double *destFrame, double *srcFrame, double *srcBackground, 
						UINT xfrom, UINT yfrom, UINT area_w, UINT area_h );
	int SuperposeOnto2( UINT w, UINT h, double *destFrame, double *srcFrame, double *srcBackground, 
						UINT xfrom, UINT yfrom, UINT area_w, UINT area_h );

	double X2(double x1, double y1);	
	double Y2(double x1, double y1);
	double X1(double x2, double y2);
	double Y1(double x2, double y2);
	inline double X2Err(double x1, double y1)
		{	return ( m_is_mapping_ready ) ? m_xerr2 : -1.0;	}
	inline double Y2Err(double x1, double y1)
		{	return ( m_is_mapping_ready ) ? m_yerr2 : -1.0;	}
	inline double X1Err(double x2, double y2)
		{	return ( m_is_mapping_ready ) ? m_xerr1 : -1.0;	}
	inline double Y1Err(double x2, double y2)
		{	return ( m_is_mapping_ready ) ? m_yerr1 : -1.0;	}
	inline BOOL IsCompatible(UINT w, UINT h)	
		{	return ( m_frame_w == w && m_frame_h == h );	}

};