#include "stdafx.h"
#include "../LKSLib/LKSLibCommon.h"
#include "Circle.h"
#include "CAQClient.h"
#include "smCamera.h"


CCAQClient::CCAQClient() 
{
	m_header = NULL;
	//m_point_data = NULL;
	m_image_data = NULL;

	m_index = 0;
}

CCAQClient::~CCAQClient()
{
	CAQClose();
}

int CCAQClient::CAQOpen()
{
	CAQClose();

	if ( m_shmem.Open( CAQ_SHMEM_NAME ) < 0 )
	{
	//	LogErr( _T("Shared Memory Open Failed.") );
		return -1;
	}

	m_header = (CCAQHeader *) m_shmem.pBuffer;
	m_image_data = (UINT32 *) ( m_shmem.pBuffer + sizeof(CCAQHeader) );

	m_index = 0;
	return 0;
}

int CCAQClient::CAQClose()
{
	m_shmem.Close();

	m_header = NULL;
	//m_point_data = NULL;
	m_image_data = NULL;

	m_index = 0;
	return 0;
}

int CCAQClient::CAQModeReadFrom(double time)
{
	if ( m_header == NULL )	return -1;
	double last_sync_time = ProgramTime_Tick2Second( m_header->last_sync_tick );
	INT64 index = m_header->last_sync_index + (INT64) ceil( (time - last_sync_time) * m_header->sampling_rate ) ;
	if ( index < 0 )	return -1;

	m_index = index;
	return 0;
}

int CCAQClient::CAQModeReadFromNow()
{
	if ( m_header == NULL )	return -1;

//	m_index = m_header->num_acquired ;
	m_index = m_header->num_acquired ;
	return 0;
}

int CCAQClient::CAQModeReadContinue()
{
	m_index = m_index + 1 ;
	return 0;
}

#define Z_VALUE		(3.00)

int CCAQClient::FindCenter
		(UINT w, UINT h, void *pFrame, UINT frame_data_type,
		double orgx, double orgy, double radius,
		double *pcx, double *pcy)
{
	if ( pFrame == NULL )	return -1;
	if ( frame_data_type > CCAQClient::U32FRAME )	return -1;

	int l = (int) floor( orgx - radius );
	int r = (int) ceil( orgx + radius );
	int b = (int) floor( orgy - radius );
	int t = (int) ceil( orgy + radius );
	if ( l < 0 || (int)w <= r )	return -1;
	if ( b < 0 || (int)h <= t )	return -1;

	int cnt = 0;
	double sum = 0.0;
	for ( int x = l ; x <= r ; x++ )
	{
		for ( int y = b ; y <= t ; y++ )
		{
			double f;
			if ( frame_data_type == CCAQClient::DFRAME )
			{
				f = ((double *)pFrame)[ w*y + x ];
			}
			else if ( frame_data_type == CCAQClient::U32FRAME )
			{
				UINT32 u32 = ((UINT32 *)pFrame)[ w*y + x ];
				f = (double) u32;
			}
			cnt += 1;
			sum += f;
		}
	}
	if ( cnt <= 0 )	return -1;

	double mean = sum/cnt;

	double mass = 0.0;
	double mx = 0.0;
	double my = 0.0;
	for ( int x = l ; x <= r ; x++ )
	{
		for ( int y = b ; y <= t ; y++ )
		{
			double f;
			if ( frame_data_type == CCAQClient::DFRAME )
			{
				f = ((double *)pFrame)[ w*y + x ];
			}
			else if ( frame_data_type == CCAQClient::U32FRAME )
			{
				UINT32 u32 = ((UINT32 *)pFrame)[ w*y + x ];
				f = (double) u32;
			}
			if ( f > mean )
			{
				mass += f-mean;
				mx += x * (f-mean);
				my += y * (f-mean);
			}
		}
	}
	double cx = mx/mass;
	double cy = my/mass;

	if ( mass < ZERO_TOLERANCE )	return -1;
	if ( ( l - cx ) * ( r - cx ) >= 0 || ( b - cy ) * ( t - cy ) >= 0 )	return -1;
	if ( pcx )	*pcx = cx;
	if ( pcy )	*pcy = cy;
	return 0;
}

int CCAQClient::AnalyzePeak
(UINT w, UINT h, void *pFrame, UINT frame_data_type,
double x0, double y0, double sigma, 
double *sig, double *bg, double *sig2, double *bg2)
{
	if ( pFrame == NULL )	return -1;
	if ( frame_data_type > CCAQClient::U32FRAME )	return -1;

	int ix0 = (int) ( x0 + 0.5 );
	int iy0 = (int) ( y0 + 0.5 );
	double collectr = Z_VALUE * sigma ;
	int erange = CCircle::extended_range( collectr );
	if ( ix0-erange < 0 || (int)w <= ix0+erange )	return -1;
	if ( iy0-erange < 0 || (int)h <= iy0+erange )	return -1;	
	double *area = new double[ SQR( 2*erange + 1 ) ];

	UINT N = 0;
	int cnt = 0;
	double wsum = 0.0;
	double wsum2 = 0.0;
	double ssum = 0.0;
	double ssum2 = 0.0;
	for ( int x = ix0-erange ; x <= ix0+erange ; x++ )
	{
		for ( int y = iy0-erange ; y <= iy0+erange ; y++ )
		{
			double f;
			if ( frame_data_type == CCAQClient::DFRAME )
			{
				f = ((double *)pFrame)[ w*y + x ];
			}
			else if ( frame_data_type == CCAQClient::U32FRAME )
			{
				UINT32 u32 = ((UINT32 *)pFrame)[ w*y + x ];
				f = (double) u32;
			}

			area[N] = f;
			N++;

			if ( CCircle::in( x-ix0, y-iy0, collectr ) == TRUE )
			{
                double w = exp( -0.5 * ( SQR(x-x0) + SQR(y-y0) )/SQR(sigma) );

				cnt ++;
				wsum += w;
				ssum += w*f;
				wsum2 += 1.0;
				ssum2 += f;
			}
//			else
//			{
//				area[N] = f;
//				N++;
//			}
		}
	}
	double background = Select_Kth_among_N( (UINT) ceil( 0.5*N ), N, area );
	delete [] area;
	if ( sig ) *sig = ssum;
	if ( sig2 ) *sig2 = ssum2;
	if ( bg ) *bg = wsum * background;
	if ( bg2 ) *bg2 = wsum2 * background;
	return cnt;
}
	
UINT32 *CCAQClient::CAQReadImage()
{
	if ( m_header == NULL )	return NULL;
	if ( m_index >= m_header->num_acquired )
	{
		LogMsg(_T("Error"), _T("Client tries to read ahead of camera acquisition."));
		return NULL;
	}
	if ( m_index < m_header->num_dismissed )
	{
		LogMsg(_T("Error"), _T("Requested data is not avaialble in the buffer anymore. Increase CAQ buffer size."));
        return NULL;
	}
	UINT w = m_header->frame_w;
	UINT h = m_header->frame_h;
	//UINT bpp = m_header->bpp;
	return &( m_image_data[ ( m_index % m_header->size ) * w * h ] );
}
