// smCamera.h : main header file for the smCamera application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

#include "smCameraCommon.h"
#include "Camera.h"
#include "..\ShutterManager\ShutterClient.h"
#include "..\ShutterManager\Shutter.h"
extern CCamera g_camera;
//extern CShutterClient g_shutter_client;
extern CShutter	g_shutter;
extern BYTE camera_memory[10000000];
extern BYTE shutter_memory[100000];
extern BOOL g_camera_recording_on;
#define SIMULATION 0

// CsmCameraApp:
// See smCamera.cpp for the implementation of this class
//

class CsmCameraApp : public CWinApp
{
public:
	CsmCameraApp();


// Overrides
public:
	virtual BOOL InitInstance();
	CStatusBar* GetStatusBar();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CsmCameraApp theApp;
#include "smCameraView.h"
extern CsmCameraView *theView;