#pragma once
#include "CAQ.h"
#include "LocalSharedMemory.h"

class CCAQClient
{
public:
	CCAQClient();
	virtual ~CCAQClient();

	int CAQOpen();
	int CAQClose();
	int CAQModeReadFrom(double time);
	int CAQModeReadFromNow();
	int CAQModeReadContinue();

	UINT32 *CAQReadImage();
	inline UINT32 CAQReadPixel(UINT32 *image, UINT x, UINT y)
	{
		UINT w = m_header->frame_w;
		return image[ w*y + x ];
	}

	enum {	DFRAME = 0, U32FRAME = 1	};
	static int FindCenter
		(UINT w, UINT h, void *pFrame, UINT frame_data_type,
		double orgx, double orgy, double radius,
		double *cx, double *cy);
	static int AnalyzePeak
		(UINT w, UINT h, void *pFrame, UINT frame_data_type,
		double x0, double y0, double sigma, 
		double *sig, double *bg, double *sig2, double *bg2);


	inline BOOL IsOpen()	{	return ( m_header != NULL );	}
	inline BOOL IsRunning()	{	return ( m_header != NULL && m_header->is_running );	}

	CLocalSharedMemory m_shmem; //shared memomey. shared with CAQClient?
	CCAQHeader *m_header; //this header defined in CAQ.h contains lots of relevant parameters for an image data.
	//CCAQPoint *m_point_data;
	UINT32 *m_image_data; //a pointer to an image

	UINT64 m_index;
};